-- ============================================================================
-- TECNIFLOW - MIGRAÇÃO INCREMENTAL 002 (RASCUNHO - NÃO APLICAR)
-- ATENÇÃO: ESTE ARQUIVO É UM RASCUNHO PRELIMINAR E NÃO DEVE SER APLICADO.
-- A persistência dos módulos operacionais (clientes, ordens de serviço, estoque)
-- permanece no banco local SQLite durante a etapa atual de Supabase Auth.
-- ============================================================================

BEGIN;

-- BLOQUEIO DE SEGURANÇA: Impede execução acidental no banco de dados
DO $$
BEGIN
  RAISE EXCEPTION 'BLOQUEIO DE SEGURANÇA: Este script 002_auth_data_api.sql é um rascunho preliminar e NÃO deve ser aplicado ao banco de dados. A persistência de dados operacionais permanece no banco local SQLite.';
END $$;

-- 1. ADICIONAR VÍNCULO IMUTÁVEL COM SUPABASE AUTH (auth.users UUID)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_schema = 'tecniflow' AND table_name = 'users' AND column_name = 'auth_user_id'
  ) THEN
    ALTER TABLE tecniflow.users ADD COLUMN auth_user_id UUID UNIQUE;
    
    -- Se o schema auth existir (instância Supabase), adiciona constraint FK
    IF EXISTS (SELECT 1 FROM information_schema.schemata WHERE schema_name = 'auth') THEN
      ALTER TABLE tecniflow.users 
        ADD CONSTRAINT fk_users_auth_users 
        FOREIGN KEY (auth_user_id) REFERENCES auth.users(id) ON DELETE CASCADE;
    END IF;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_users_auth_user_id ON tecniflow.users(auth_user_id);

-- 2. FUNÇÃO AUXILIAR ESTÁVEL PARA RESOLVER COMPANY_ID DO USUÁRIO AUTENTICADO
-- Executada como SECURITY DEFINER com search_path vazio para evitar search_path injection
CREATE OR REPLACE FUNCTION tecniflow.get_authenticated_company_id()
RETURNS VARCHAR(36)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
  SELECT company_id 
  FROM tecniflow.users 
  WHERE auth_user_id = (SELECT auth.uid())
  LIMIT 1;
$$;

-- Revoga acesso público/anon e concede apenas para authenticated
REVOKE ALL ON FUNCTION tecniflow.get_authenticated_company_id() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION tecniflow.get_authenticated_company_id() TO authenticated;

-- 3. HABILITAR E ATUALIZAR POLÍTICAS RLS NAS TABELAS DO TECNIFLOW

-- Empresas (companies): usuário só pode visualizar e atualizar sua própria empresa
ALTER TABLE tecniflow.companies ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  DROP POLICY IF EXISTS companies_isolation_policy ON tecniflow.companies;
  CREATE POLICY companies_isolation_policy ON tecniflow.companies
    FOR ALL
    TO authenticated
    USING (id = tecniflow.get_authenticated_company_id())
    WITH CHECK (id = tecniflow.get_authenticated_company_id());
END $$;

-- Usuários (users): nunca expõe hash de senha; apenas membros da mesma empresa
ALTER TABLE tecniflow.users ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  DROP POLICY IF EXISTS users_isolation_policy ON tecniflow.users;
  CREATE POLICY users_isolation_policy ON tecniflow.users
    FOR SELECT
    TO authenticated
    USING (company_id = tecniflow.get_authenticated_company_id());
END $$;

-- Clientes (clients): isolamento estrito por company_id
ALTER TABLE tecniflow.clients ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  DROP POLICY IF EXISTS clients_isolation_policy ON tecniflow.clients;
  CREATE POLICY clients_isolation_policy ON tecniflow.clients
    FOR ALL
    TO authenticated
    USING (company_id = tecniflow.get_authenticated_company_id())
    WITH CHECK (company_id = tecniflow.get_authenticated_company_id());
END $$;

-- Estoque (inventory_items): isolamento estrito por company_id
ALTER TABLE tecniflow.inventory_items ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  DROP POLICY IF EXISTS inventory_isolation_policy ON tecniflow.inventory_items;
  CREATE POLICY inventory_isolation_policy ON tecniflow.inventory_items
    FOR ALL
    TO authenticated
    USING (company_id = tecniflow.get_authenticated_company_id())
    WITH CHECK (company_id = tecniflow.get_authenticated_company_id());
END $$;

-- Ordens de Serviço (orders): isolamento estrito por company_id
ALTER TABLE tecniflow.orders ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  DROP POLICY IF EXISTS orders_isolation_policy ON tecniflow.orders;
  CREATE POLICY orders_isolation_policy ON tecniflow.orders
    FOR ALL
    TO authenticated
    USING (company_id = tecniflow.get_authenticated_company_id())
    WITH CHECK (company_id = tecniflow.get_authenticated_company_id());
END $$;

-- Serviços da OS (order_services): isolamento estrito por company_id
ALTER TABLE tecniflow.order_services ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  DROP POLICY IF EXISTS order_services_isolation_policy ON tecniflow.order_services;
  CREATE POLICY order_services_isolation_policy ON tecniflow.order_services
    FOR ALL
    TO authenticated
    USING (company_id = tecniflow.get_authenticated_company_id())
    WITH CHECK (company_id = tecniflow.get_authenticated_company_id());
END $$;

-- Peças da OS (order_parts): isolamento estrito por company_id
ALTER TABLE tecniflow.order_parts ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  DROP POLICY IF EXISTS order_parts_isolation_policy ON tecniflow.order_parts;
  CREATE POLICY order_parts_isolation_policy ON tecniflow.order_parts
    FOR ALL
    TO authenticated
    USING (company_id = tecniflow.get_authenticated_company_id())
    WITH CHECK (company_id = tecniflow.get_authenticated_company_id());
END $$;

-- Movimentos de Estoque (inventory_movements): somente leitura direta por company_id
ALTER TABLE tecniflow.inventory_movements ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  DROP POLICY IF EXISTS movements_isolation_policy ON tecniflow.inventory_movements;
  CREATE POLICY movements_isolation_policy ON tecniflow.inventory_movements
    FOR SELECT
    TO authenticated
    USING (company_id = tecniflow.get_authenticated_company_id());
END $$;

-- Histórico da OS (order_history): somente leitura direta por company_id
ALTER TABLE tecniflow.order_history ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  DROP POLICY IF EXISTS order_history_isolation_policy ON tecniflow.order_history;
  CREATE POLICY order_history_isolation_policy ON tecniflow.order_history
    FOR SELECT
    TO authenticated
    USING (company_id = tecniflow.get_authenticated_company_id());
END $$;

-- 4. RPC TRANSACIONAL: PROVISIONAMENTO IDEMPOTENTE PÓS-AUTH SUPABASE
-- Chamado após confirmação de e-mail ou login inicial com token verificado.
-- Cria atomicamente a empresa e o usuário owner caso ainda não existam.
CREATE OR REPLACE FUNCTION public.rpc_sync_user_profile(
  p_company_name TEXT,
  p_company_document TEXT DEFAULT '',
  p_company_phone TEXT DEFAULT '',
  p_company_whatsapp TEXT DEFAULT '',
  p_company_address TEXT DEFAULT '',
  p_owner_name TEXT DEFAULT ''
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_auth_uid UUID;
  v_user_email TEXT;
  v_existing_company_id VARCHAR(36);
  v_new_company_id VARCHAR(36);
  v_new_user_id VARCHAR(36);
  v_safe_owner_name TEXT;
  v_safe_company_name TEXT;
  v_result JSONB;
BEGIN
  v_auth_uid := (SELECT auth.uid());
  IF v_auth_uid IS NULL THEN
    RAISE EXCEPTION 'Acesso não autorizado: sessão Supabase Auth não encontrada.';
  END IF;

  SELECT email INTO v_user_email FROM auth.users WHERE id = v_auth_uid;
  IF v_user_email IS NULL THEN
    RAISE EXCEPTION 'Usuário não encontrado no catálogo auth.users.';
  END IF;

  -- Verifica se o usuário já possui vínculo cadastrado
  SELECT company_id INTO v_existing_company_id 
  FROM tecniflow.users 
  WHERE auth_user_id = v_auth_uid;

  IF v_existing_company_id IS NOT NULL THEN
    SELECT jsonb_build_object(
      'status', 'existing',
      'company_id', c.id,
      'company_name', c.name,
      'user_email', u.email,
      'user_name', u.name,
      'role', u.role
    ) INTO v_result
    FROM tecniflow.companies c
    JOIN tecniflow.users u ON u.company_id = c.id
    WHERE u.auth_user_id = v_auth_uid;

    RETURN v_result;
  END IF;

  -- Gera UUIDs para nova empresa e usuário no schema tecniflow
  v_new_company_id := gen_random_uuid()::text;
  v_new_user_id := gen_random_uuid()::text;
  v_safe_company_name := COALESCE(NULLIF(TRIM(p_company_name), ''), 'Minha Assistência Técnica');
  v_safe_owner_name := COALESCE(NULLIF(TRIM(p_owner_name), ''), split_part(v_user_email, '@', 1));

  -- Cria empresa
  INSERT INTO tecniflow.companies (
    id, name, document, phone, whatsapp, email, address, warranty_terms, receipt_notes, created_at
  ) VALUES (
    v_new_company_id,
    v_safe_company_name,
    COALESCE(TRIM(p_company_document), ''),
    COALESCE(TRIM(p_company_phone), ''),
    COALESCE(TRIM(p_company_whatsapp), ''),
    v_user_email,
    COALESCE(TRIM(p_company_address), ''),
    '',
    '',
    now()
  );

  -- Cria usuário owner vinculado ao auth.users UUID
  INSERT INTO tecniflow.users (
    id, company_id, name, email, password_hash, role, auth_user_id, created_at
  ) VALUES (
    v_new_user_id,
    v_new_company_id,
    v_safe_owner_name,
    LOWER(TRIM(v_user_email)),
    '', -- Senha gerenciada exclusivamente pelo Supabase Auth
    'owner',
    v_auth_uid,
    now()
  );

  RETURN jsonb_build_object(
    'status', 'created',
    'company_id', v_new_company_id,
    'company_name', v_safe_company_name,
    'user_email', v_user_email,
    'user_name', v_safe_owner_name,
    'role', 'owner'
  );
END;
$$;

REVOKE ALL ON FUNCTION public.rpc_sync_user_profile(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.rpc_sync_user_profile(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated;

-- 5. RPC TRANSACIONAL: TRANSIÇÃO ATÔMICA DE STATUS E BAIXA DE ESTOQUE
-- Garante versionamento otimista, trava pessimista FOR UPDATE, rollback total e consistência
CREATE OR REPLACE FUNCTION public.rpc_update_order_status_and_stock(
  p_order_id VARCHAR(36),
  p_expected_version INTEGER,
  p_new_status VARCHAR(50),
  p_user_name TEXT,
  p_notes TEXT DEFAULT ''
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_company_id VARCHAR(36);
  v_order RECORD;
  v_part RECORD;
  v_item RECORD;
  v_history_id VARCHAR(36);
  v_movement_id VARCHAR(36);
BEGIN
  v_company_id := tecniflow.get_authenticated_company_id();
  IF v_company_id IS NULL THEN
    RAISE EXCEPTION 'Acesso não autorizado: empresa não vinculada.';
  END IF;

  -- Trava pessimista da OS para consistência concorrente
  SELECT * INTO v_order 
  FROM tecniflow.orders 
  WHERE id = p_order_id AND company_id = v_company_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Ordem de serviço não encontrada ou não pertence à sua empresa.';
  END IF;

  -- Validação de versão concorrente
  IF v_order.version != p_expected_version THEN
    RAISE EXCEPTION 'Conflito de versão concorrente. Recarregue a ordem de serviço antes de salvar.';
  END IF;

  -- Se transitar para cancelado, estorna estoque debitado anteriormente
  IF p_new_status = 'cancelado' AND v_order.status != 'cancelado' THEN
    FOR v_part IN 
      SELECT * FROM tecniflow.order_parts 
      WHERE order_id = p_order_id AND company_id = v_company_id AND inventory_debited = 1 AND inventory_item_id IS NOT NULL
      FOR UPDATE
    LOOP
      SELECT * INTO v_item 
      FROM tecniflow.inventory_items 
      WHERE id = v_part.inventory_item_id AND company_id = v_company_id
      FOR UPDATE;

      IF FOUND THEN
        UPDATE tecniflow.inventory_items 
        SET quantity = quantity + v_part.quantity, updated_at = now()
        WHERE id = v_part.inventory_item_id;

        v_movement_id := gen_random_uuid()::text;
        INSERT INTO tecniflow.inventory_movements (
          id, company_id, item_id, type, quantity, previous_quantity, new_quantity, order_id, reason, user_name, created_at
        ) VALUES (
          v_movement_id,
          v_company_id,
          v_part.inventory_item_id,
          'entrada',
          v_part.quantity,
          v_item.quantity,
          v_item.quantity + v_part.quantity,
          p_order_id,
          'Estorno por cancelamento da OS #' || v_order.order_number,
          p_user_name,
          now()
        );

        UPDATE tecniflow.order_parts 
        SET inventory_debited = 0 
        WHERE id = v_part.id;
      END IF;
    END LOOP;
  END IF;

  -- Se transitar para pronto ou entregue, debita itens pendentes
  IF (p_new_status IN ('pronto', 'entregue')) AND (v_order.status NOT IN ('pronto', 'entregue')) THEN
    FOR v_part IN 
      SELECT * FROM tecniflow.order_parts 
      WHERE order_id = p_order_id AND company_id = v_company_id AND inventory_debited = 0 AND inventory_item_id IS NOT NULL
      FOR UPDATE
    LOOP
      SELECT * INTO v_item 
      FROM tecniflow.inventory_items 
      WHERE id = v_part.inventory_item_id AND company_id = v_company_id
      FOR UPDATE;

      IF NOT FOUND THEN
        RAISE EXCEPTION 'Item de estoque da peça % não encontrado.', v_part.description;
      END IF;

      IF v_item.quantity < v_part.quantity THEN
        RAISE EXCEPTION 'Estoque insuficiente para a peça %. Quantidade em estoque: %, necessária: %', 
          v_item.name, v_item.quantity, v_part.quantity;
      END IF;

      UPDATE tecniflow.inventory_items 
      SET quantity = quantity - v_part.quantity, updated_at = now()
      WHERE id = v_part.inventory_item_id;

      v_movement_id := gen_random_uuid()::text;
      INSERT INTO tecniflow.inventory_movements (
        id, company_id, item_id, type, quantity, previous_quantity, new_quantity, order_id, reason, user_name, created_at
      ) VALUES (
        v_movement_id,
        v_company_id,
        v_part.inventory_item_id,
        'saida',
        v_part.quantity,
        v_item.quantity,
        v_item.quantity - v_part.quantity,
        p_order_id,
        'Baixa automática da OS #' || v_order.order_number,
        p_user_name,
        now()
      );

      UPDATE tecniflow.order_parts 
      SET inventory_debited = 1 
      WHERE id = v_part.id;
    END LOOP;
  END IF;

  -- Atualiza o status e incrementa a versão da OS
  UPDATE tecniflow.orders 
  SET status = p_new_status,
      version = version + 1,
      updated_at = now(),
      completed_at = CASE WHEN p_new_status = 'entregue' THEN now() ELSE completed_at END
  WHERE id = p_order_id AND company_id = v_company_id;

  -- Registra no histórico da OS
  v_history_id := gen_random_uuid()::text;
  INSERT INTO tecniflow.order_history (
    id, company_id, order_id, action, description, user_name, created_at
  ) VALUES (
    v_history_id,
    v_company_id,
    p_order_id,
    'status_alterado',
    'Status alterado de ' || v_order.status || ' para ' || p_new_status || COALESCE('. ' || NULLIF(p_notes, ''), ''),
    p_user_name,
    now()
  );

  RETURN jsonb_build_object(
    'order_id', p_order_id,
    'new_status', p_new_status,
    'new_version', v_order.version + 1
  );
END;
$$;

REVOKE ALL ON FUNCTION public.rpc_update_order_status_and_stock(VARCHAR, INTEGER, VARCHAR, TEXT, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.rpc_update_order_status_and_stock(VARCHAR, INTEGER, VARCHAR, TEXT, TEXT) TO authenticated;

COMMIT;
