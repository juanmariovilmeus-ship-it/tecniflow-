-- ============================================================================
-- TECNIFLOW - MIGRATION 010: TELEMETRIA DE FALHAS, READINESS E HARDENING DE PAPÉIS
-- Schema: tecniflow / public
-- Transacional, idempotente e segura (PostgreSQL / Supabase)
-- ============================================================================

BEGIN;

-- ----------------------------------------------------------------------------
-- 1. PREFLIGHT CHECKS: Validação de pré-requisitos essenciais
-- ----------------------------------------------------------------------------
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.schemata WHERE schema_name = 'tecniflow') THEN
    RAISE EXCEPTION 'PREFLIGHT_FAILED: Schema tecniflow não encontrado. Execute tecniflow_schema.sql primeiro.';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'tecniflow' AND table_name = 'companies') THEN
    RAISE EXCEPTION 'PREFLIGHT_FAILED: Tabela tecniflow.companies não encontrada.';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'tecniflow' AND table_name = 'users') THEN
    RAISE EXCEPTION 'PREFLIGHT_FAILED: Tabela tecniflow.users não encontrada.';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'current_company_id' AND pronamespace = 'tecniflow'::regnamespace) THEN
    RAISE EXCEPTION 'PREFLIGHT_FAILED: Função tecniflow.current_company_id() não encontrada.';
  END IF;
END $$;

-- ----------------------------------------------------------------------------
-- 2. HARDENING DE PAPÉIS: Restrição estrita a 'owner' para dados e logo da empresa
-- ----------------------------------------------------------------------------

-- 2.1 Atualização de tf_update_company com validação explícita de papel 'owner'
CREATE OR REPLACE FUNCTION public.tf_update_company(
  p_name text,
  p_document text DEFAULT '',
  p_phone text DEFAULT '',
  p_whatsapp text DEFAULT '',
  p_email text DEFAULT '',
  p_address text DEFAULT '',
  p_warranty_terms text DEFAULT '',
  p_receipt_notes text DEFAULT ''
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_uid UUID;
  v_company_id VARCHAR(36);
  v_user_role VARCHAR(20);
  v_company RECORD;
BEGIN
  v_uid := (SELECT auth.uid());
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Não autenticado.';
  END IF;

  v_company_id := tecniflow.current_company_id();
  IF v_company_id IS NULL THEN
    RAISE EXCEPTION 'Acesso não autorizado.';
  END IF;

  -- Validação estrita de papel: apenas 'owner' pode alterar dados cadastrais
  SELECT role INTO v_user_role
  FROM tecniflow.users
  WHERE auth_user_id = v_uid AND company_id = v_company_id
  LIMIT 1;

  IF v_user_role IS DISTINCT FROM 'owner' THEN
    RAISE EXCEPTION 'Apenas o proprietário da assistência técnica pode alterar dados cadastrais da empresa.';
  END IF;

  IF p_name IS NULL OR trim(p_name) = '' THEN
    RAISE EXCEPTION 'O nome da empresa é obrigatório.';
  END IF;

  PERFORM tecniflow.validate_contacts(p_phone, p_whatsapp, p_document, p_email, false);
  IF length(p_name) > 100 OR length(coalesce(p_address, '')) > 255 THEN
    RAISE EXCEPTION 'Dados da empresa excedem o tamanho permitido.';
  END IF;

  UPDATE tecniflow.companies
  SET name = substring(trim(p_name), 1, 100),
      document = substring(COALESCE(trim(p_document), ''), 1, 50),
      phone = substring(COALESCE(trim(p_phone), ''), 1, 30),
      whatsapp = substring(COALESCE(trim(p_whatsapp), ''), 1, 30),
      email = substring(lower(COALESCE(trim(p_email), '')), 1, 100),
      address = substring(COALESCE(trim(p_address), ''), 1, 255),
      warranty_terms = COALESCE(trim(p_warranty_terms), ''),
      receipt_notes = COALESCE(trim(p_receipt_notes), '')
  WHERE id = v_company_id
  RETURNING * INTO v_company;

  RETURN jsonb_build_object('company', to_jsonb(v_company));
END;
$$;

REVOKE ALL ON FUNCTION public.tf_update_company(text, text, text, text, text, text, text, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.tf_update_company(text, text, text, text, text, text, text, text) TO authenticated;

-- 2.2 Atualização de tf_update_company_logo com validação explícita de papel 'owner'
CREATE OR REPLACE FUNCTION public.tf_update_company_logo(
  p_logo_data_url text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_uid UUID;
  v_company_id VARCHAR(36);
  v_user_role VARCHAR(20);
  v_company RECORD;
  v_clean_logo TEXT;
BEGIN
  v_uid := (SELECT auth.uid());
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Não autenticado.';
  END IF;

  v_company_id := tecniflow.current_company_id();
  IF v_company_id IS NULL THEN
    RAISE EXCEPTION 'Acesso não autorizado.';
  END IF;

  -- Validação estrita de papel: apenas 'owner' pode alterar logotipo
  SELECT role INTO v_user_role
  FROM tecniflow.users
  WHERE auth_user_id = v_uid AND company_id = v_company_id
  LIMIT 1;

  IF v_user_role IS DISTINCT FROM 'owner' THEN
    RAISE EXCEPTION 'Apenas o proprietário da assistência técnica pode alterar o logotipo da empresa.';
  END IF;

  IF p_logo_data_url IS NOT NULL AND trim(p_logo_data_url) <> '' THEN
    PERFORM tecniflow.validate_company_logo(p_logo_data_url);
    v_clean_logo := trim(p_logo_data_url);
  ELSE
    v_clean_logo := NULL;
  END IF;

  UPDATE tecniflow.companies
  SET company_logo_data_url = v_clean_logo
  WHERE id = v_company_id
  RETURNING * INTO v_company;

  RETURN jsonb_build_object('company', to_jsonb(v_company));
END;
$$;

REVOKE ALL ON FUNCTION public.tf_update_company_logo(text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.tf_update_company_logo(text) TO authenticated;

-- ----------------------------------------------------------------------------
-- 3. TABELA DE TELEMETRIA DE FALHAS: tecniflow.error_telemetry
-- Schema privado, colunas estritamente tipadas e sem dados pessoais/sensíveis
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tecniflow.error_telemetry (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id VARCHAR(36) NOT NULL REFERENCES tecniflow.companies(id) ON DELETE CASCADE,
  user_id VARCHAR(36) NOT NULL REFERENCES tecniflow.users(id) ON DELETE CASCADE,
  area VARCHAR(20) NOT NULL CHECK (area IN ('auth', 'billing', 'orders', 'inventory', 'clients', 'help', 'network', 'system', 'ui')),
  code VARCHAR(50) NOT NULL,
  severity VARCHAR(10) NOT NULL CHECK (severity IN ('info', 'warn', 'error', 'fatal')),
  correlation_id UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_error_telemetry_company_created ON tecniflow.error_telemetry(company_id, created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS idx_error_telemetry_correlation ON tecniflow.error_telemetry(company_id,user_id,correlation_id);
CREATE INDEX IF NOT EXISTS idx_error_telemetry_user_time ON tecniflow.error_telemetry(user_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_error_telemetry_created_at ON tecniflow.error_telemetry(created_at);
CREATE INDEX IF NOT EXISTS idx_error_telemetry_area_code ON tecniflow.error_telemetry(area, code, created_at DESC);

-- Bloqueio total da Data API (Supabase PostgREST) na tabela de telemetria
ALTER TABLE tecniflow.error_telemetry ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE tecniflow.error_telemetry FROM PUBLIC, anon, authenticated;

-- ----------------------------------------------------------------------------
-- 4. RPC DE REGISTRO SEGURO: public.tf_record_error_telemetry
-- Ingestão autenticada via RPC com deduplicação e limite atômico de taxa
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.tf_record_error_telemetry(
  p_area text,
  p_code text,
  p_severity text,
  p_correlation_id uuid
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_uid UUID;
  v_company_id VARCHAR(36);
  v_user_id VARCHAR(36);
  v_clean_area VARCHAR(20);
  v_clean_code VARCHAR(50);
  v_clean_severity VARCHAR(10);
  v_recent_count INTEGER;
  v_daily_count INTEGER;
BEGIN
  v_uid := (SELECT auth.uid());
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Não autenticado.';
  END IF;

  SELECT id, company_id INTO v_user_id, v_company_id
  FROM tecniflow.users
  WHERE auth_user_id = v_uid
  LIMIT 1;

  IF v_user_id IS NULL OR v_company_id IS NULL THEN
    RAISE EXCEPTION 'Acesso não autorizado ou usuário não vinculado.';
  END IF;

  -- 1. Validação estrita de enum da área
  v_clean_area := lower(trim(COALESCE(p_area, '')));
  IF v_clean_area NOT IN ('auth', 'billing', 'orders', 'inventory', 'clients', 'help', 'network', 'system', 'ui') THEN
    RAISE EXCEPTION 'Área de telemetria inválida.';
  END IF;

  -- 2. Validação estrita de severidade
  v_clean_severity := lower(trim(COALESCE(p_severity, '')));
  IF v_clean_severity NOT IN ('info', 'warn', 'error', 'fatal') THEN
    RAISE EXCEPTION 'Severidade de telemetria inválida.';
  END IF;

  -- 3. Validação do código fixo: apenas letras maiúsculas, dígitos e underscore (3 a 50 chars)
  v_clean_code := upper(trim(COALESCE(p_code, '')));
  IF v_clean_code NOT IN ('UI_RENDER_CRASH','RPC_NOT_FOUND','RPC_ERROR','PERMISSION_DENIED','SUBSCRIPTION_EXPIRED','HELP_RATE_LIMIT','HELP_CHAT_ERROR','NETWORK_FAILURE','AUTH_SERVICE_ERROR','BILLING_SERVICE_ERROR') THEN
    RAISE EXCEPTION 'Código de telemetria inválido. Deve ser alfanumérico em maiúsculas (3 a 50 caracteres).';
  END IF;

  v_clean_severity := CASE WHEN v_clean_code='SUBSCRIPTION_EXPIRED' THEN 'info' WHEN v_clean_code IN ('PERMISSION_DENIED','HELP_RATE_LIMIT') THEN 'warn' ELSE 'error' END;

  -- 4. Validação do correlation_id
  IF p_correlation_id IS NULL THEN
    RAISE EXCEPTION 'correlation_id é obrigatório e deve ser um UUID válido.';
  END IF;

  -- 5. Trava atômica por usuário para controle de volume
  PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('telemetry_' || v_company_id, 870213));

  IF EXISTS (SELECT 1 FROM tecniflow.error_telemetry WHERE company_id=v_company_id AND user_id=v_user_id AND correlation_id=p_correlation_id) THEN RETURN jsonb_build_object('recorded',false,'reason','deduplicated'); END IF;

  SELECT count(*) INTO v_daily_count FROM tecniflow.error_telemetry WHERE company_id=v_company_id AND created_at>=date_trunc('day',now());
  IF v_daily_count>=200 THEN RETURN jsonb_build_object('recorded',false,'reason','daily_rate_limited'); END IF;

  -- 6. Deduplicação: descarta duplicatas idênticas (mesmo user, área e código) nos últimos 10 segundos
  IF EXISTS (
    SELECT 1 FROM tecniflow.error_telemetry
    WHERE user_id = v_user_id
      AND area = v_clean_area
      AND code = v_clean_code
      AND created_at > now() - INTERVAL '60 seconds'
  ) THEN
    RETURN jsonb_build_object(
      'recorded', false,
      'reason', 'deduplicated',
      'correlation_id', p_correlation_id
    );
  END IF;

  -- 7. Limite de taxa (Burst/Volume): no máximo 10 eventos por minuto por usuário
  SELECT count(*) INTO v_recent_count
  FROM tecniflow.error_telemetry
  WHERE user_id = v_user_id
    AND created_at > now() - INTERVAL '60 seconds';

  IF v_recent_count >= 10 THEN
    RETURN jsonb_build_object(
      'recorded', false,
      'reason', 'rate_limited',
      'correlation_id', p_correlation_id
    );
  END IF;

  -- 8. Retenção ativa de 30 dias: expurgo de registros antigos
  DELETE FROM tecniflow.error_telemetry
  WHERE company_id=v_company_id AND created_at < now() - INTERVAL '30 days';

  -- 9. Inserção limpa e estruturada
  INSERT INTO tecniflow.error_telemetry (
    company_id, user_id, area, code, severity, correlation_id, created_at
  ) VALUES (
    v_company_id, v_user_id, v_clean_area, v_clean_code, v_clean_severity, p_correlation_id, now()
  );

  RETURN jsonb_build_object(
    'recorded', true,
    'correlation_id', p_correlation_id
  );
END;
$$;

REVOKE ALL ON FUNCTION public.tf_record_error_telemetry(text, text, text, uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.tf_record_error_telemetry(text, text, text, uuid) TO authenticated;

-- ----------------------------------------------------------------------------
-- 5. RPC DE DIAGNÓSTICO / READINESS: public.tf_health_probe
-- Consulta ultraleve para /api/health/ready sem dados e sem exposição interna
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.tf_health_probe()
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
  SELECT jsonb_build_object('status',CASE WHEN ready THEN 'ok' ELSE 'unavailable' END,'ready',ready,'timestamp',now())
  FROM (SELECT
    to_regclass('auth.users') IS NOT NULL AND
    to_regclass('tecniflow.companies') IS NOT NULL AND
    to_regclass('tecniflow.users') IS NOT NULL AND
    to_regclass('tecniflow.clients') IS NOT NULL AND
    to_regclass('tecniflow.orders') IS NOT NULL AND
    to_regclass('tecniflow.inventory_items') IS NOT NULL AND
    to_regclass('tecniflow.company_subscriptions') IS NOT NULL AND
    to_regclass('tecniflow.help_ai_quota_usage') IS NOT NULL AND
    to_regclass('tecniflow.error_telemetry') IS NOT NULL AND
    to_regprocedure('public.tf_sync_current_user()') IS NOT NULL AND
    to_regprocedure('public.tf_get_company()') IS NOT NULL AND
    to_regprocedure('public.tf_get_billing_status()') IS NOT NULL AND
    NOT EXISTS (SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='tecniflow' AND c.relkind='r' AND
      (NOT c.relrowsecurity OR has_table_privilege('anon',c.oid,'select,insert,update,delete') OR has_table_privilege('authenticated',c.oid,'select,insert,update,delete') OR has_any_column_privilege('anon',c.oid,'select,insert,update') OR has_any_column_privilege('authenticated',c.oid,'select,insert,update')))
    AS ready) checks;
$$;

REVOKE ALL ON FUNCTION public.tf_health_probe() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.tf_health_probe() TO anon, authenticated;

-- ----------------------------------------------------------------------------
-- 6. VISÃO ADMINISTRATIVA DE AUDITORIA: tecniflow.v_admin_error_summary
-- Acessível SOMENTE no SQL Editor do painel Supabase (sem concessões a app users)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW tecniflow.v_admin_error_summary AS
SELECT
  area,
  code,
  severity,
  count(*) AS total_occurrences,
  count(DISTINCT company_id) AS affected_companies,
  min(created_at) AS first_seen,
  max(created_at) AS last_seen
FROM tecniflow.error_telemetry
WHERE created_at >= now() - INTERVAL '7 days'
GROUP BY area, code, severity
ORDER BY total_occurrences DESC;

REVOKE ALL ON TABLE tecniflow.v_admin_error_summary FROM PUBLIC, anon, authenticated;

-- Preserve the existing signup trigger body; lock its name resolution and direct grants.
DO $auth_trigger_hardening$
BEGIN
 IF EXISTS (SELECT 1 FROM pg_proc WHERE oid=to_regprocedure('public.handle_new_user()') AND prorettype='trigger'::regtype) THEN
   ALTER FUNCTION public.handle_new_user() SET search_path='';
   REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC,anon,authenticated;
 END IF;
END;
$auth_trigger_hardening$;
COMMIT;
