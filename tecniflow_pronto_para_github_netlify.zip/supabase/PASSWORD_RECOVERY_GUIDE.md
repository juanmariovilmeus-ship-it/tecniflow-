# TecniFlow - Guia de Ativação e Validação da Recuperação de Senha

Este documento descreve a arquitetura de recuperação de senha implementada no TecniFlow, separando estritamente as proteções prontas no código dos pré-requisitos externos necessários para a entrada em produção.

---

## 1. O que está implementado e validado no código

1. **Solicitação com Proteção e Validação de E-mail**:
   - Normalização rigorosa (`trim().toLowerCase()`).
   - Validação de formato (`RFC 5322` simplificada) e comprimento máximo de 100 caracteres.
   - Mensagem neutra anti-enumeração de usuários:
     *"Se existir uma conta com este e-mail, você receberá as instruções de recuperação. Confira também o spam."*
   - Cooldown de 60 segundos com bloqueio de duplo clique e contador regressivo na interface.
   - Tradução contextual de erros do Supabase Auth para português (Rate Limit 429, falha de conexão, erro no servidor SMTP 500).

2. **Resolução de URL de Redirecionamento e Proteção de Iframe**:
   - Rota canônica: `/?auth=recovery` (compatível também com links legados contendo `#reset-password` ou `#type=recovery`).
   - Proteção contra disparo em iframes/previews: caso o aplicativo esteja rodando dentro de um iframe ou preview efêmero sem uma URL pública configurada (`VITE_SUPABASE_RESET_REDIRECT_URL`), o envio é bloqueado preventivamente com o aviso:
     *"A recuperação por e-mail estará disponível no endereço publicado do TecniFlow."*
   - Validação estrita de overrides: exige HTTPS (ou HTTP em `localhost`), bloqueia credenciais embutidas (`user:pass@`) e URLs malformadas.

3. **Interceptação de Callback e Isolamento de Sessão**:
   - O callback de recuperação é tratado **antes** de qualquer bootstrap de `/api/auth/me` ou sincronização de empresa.
   - Uma sessão temporária de recuperação **nunca** dispara inicialização de dados cadastrais ou faturamento no dashboard, mantendo a tela em modo exclusivo de redefinição de senha.
   - Suporte aos estados de recuperação:
     - `verifying`: verificação inicial do token recebido.
     - `ready`: token validado e sessão autorizada para digitar a nova senha.
     - `expired_or_invalid`: link expirado (`otp_expired`) ou inválido; exibe botões "Solicitar Novo Link" e "Voltar ao Login" sem exibir formulário inútil que fingiria conseguir salvar.

4. **Atualização Segura de Senha e Limpeza Transacional**:
   - Exige no mínimo 12 caracteres.
   - **Não utiliza `.trim()`** na senha para preservar espaços intencionais de passphrases.
   - Valida confirmação de senha idêntica na interface.
   - Utiliza campos com `autoComplete="new-password"`.
   - Verifica existência de sessão de recuperação ativa antes de chamar `supabase.auth.updateUser`.
   - Após sucesso: revoga a sessão temporária via `supabase.auth.signOut()`, invalida o `SessionCoordinator`, limpa parâmetros e hashes da URL via `window.history.replaceState` e retorna à tela de login com mensagem de confirmação.

---

## 2. Pré-requisitos de Produção (Configurações no Supabase Dashboard)

Para que e-mails reais cheguem aos usuários no ambiente final de produção, os seguintes passos devem ser realizados no painel administrativo do Supabase (fora deste repositório):

1. **Definir a URL Canônica do TecniFlow**:
   - No painel do Supabase -> **Authentication** -> **URL Configuration**:
     - **Site URL**: Definir a URL oficial definitiva da aplicação (ex.: `https://app.tecniflow.com.br`).
     - **Redirect URLs**: Adicionar as URLs de retorno autorizadas:
       - `https://app.tecniflow.com.br/?auth=recovery`
       - `https://app.tecniflow.com.br/#auth-callback` (para confirmação de cadastro)

2. **Configurar Provedor SMTP Próprio (Custom SMTP)**:
   - No painel do Supabase -> **Authentication** -> **Email Settings** -> **SMTP Settings**:
     - Ativar **Enable Custom SMTP**.
     - Configurar credenciais de um serviço transacional (ex.: Resend, SendGrid, Amazon SES ou Postmark).
     - Configurar o remetente oficial (ex.: `contato@tecniflow.com.br` ou `suporte@tecniflow.com.br`).
   - *Nota*: O serviço de e-mail padrão do Supabase possui limites estritos de envio (rate limit) destinados apenas a testes de desenvolvimento.

3. **Homologação e Teste Fim a Fim no Domínio Publicado**:
   - No domínio publicado, acesse a tela de login -> clique em "Esqueci minha senha" -> informe o e-mail cadastrado.
   - Verifique a entrega do e-mail, clique no link de recuperação e certifique-se de que a tela de nova senha seja exibida.
   - Digite a nova senha de no mínimo 12 caracteres, salve e faça login novamente com a nova credencial.
