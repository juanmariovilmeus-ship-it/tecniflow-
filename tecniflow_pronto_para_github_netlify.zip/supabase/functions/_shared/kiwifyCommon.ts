/**
 * Módulo puro e compartilhado de segurança e contratos da Kiwify
 * Compatível universalmente com Node.js (20+) e Deno / Supabase Edge Functions.
 * 
 * Regras estritas:
 * 1. HMAC-SHA1 calculado sobre o corpo original da requisição (UTF-8)
 * 2. Comparação em tempo constante
 * 3. Validação fail-closed sem fallbacks permissivos
 * 4. Parser de datas determinístico com fuso America/Sao_Paulo (-03:00)
 */

export interface KiwifyConfig {
  enabled: boolean;
  checkoutUrl: string;
  webhookSecret: string;
  allowedProductIds: string[];
  planId: string;
}

export function isKiwifyCheckoutUrl(value: string): boolean {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && url.hostname === 'pay.kiwify.com.br'
      && !url.username && !url.password && !url.port && !url.search && !url.hash
      && /^\/[A-Za-z0-9]+\/?$/.test(url.pathname);
  } catch { return false; }
}

export function isKiwifyConfigured(config: KiwifyConfig): boolean {
  return config.enabled === true && isKiwifyCheckoutUrl(config.checkoutUrl)
    && config.webhookSecret.length >= 8 && !config.webhookSecret.includes('...')
    && config.allowedProductIds.length > 0
    && config.allowedProductIds.every(id => Boolean(id.trim()) && !id.includes('...'))
    && !config.planId.includes('...');
}

export interface WebhookValidationResult {
  valid: boolean;
  statusCode: number;
  errorCode?: string;
  errorMessage?: string;
  parsedBody?: any;
}

export interface KiwifyGrantData {
  eventType: string;
  orderId: string;
  subscriptionId: string;
  orderStatus: string;
  productId: string;
  planId: string;
  amountCents: number;
  currency: string;
  sck: string | null;
  approvedDate: string; // ISO UTC
  orderCreatedAt: string | null; // data assinada de criação do pedido
  accessUntil: string;  // ISO UTC
  nextPayment: string | null; // ISO UTC
  eventId: string | null;
  payloadHash: string;
}

/**
 * Validação segura de assinatura HMAC-SHA1 da Kiwify.
 * Contrato: HMAC-SHA1 do corpo original, sem parse/serialização antes da comparação.
 * https://docs.kiwify.com.br/api-reference/webhooks/receiving
 */
export async function verifyKiwifyWebhookSignature(
  rawBodyText: string,
  signature: string | null | undefined,
  secretKey: string
): Promise<WebhookValidationResult> {
  if (!secretKey || secretKey.length < 8 || secretKey.includes('...')) {
    return {
      valid: false,
      statusCode: 503,
      errorCode: 'billing_not_configured',
      errorMessage: 'Serviço de cobrança não configurado no servidor.',
    };
  }

  if (!signature || typeof signature !== 'string') {
    return {
      valid: false,
      statusCode: 401,
      errorCode: 'missing_signature',
      errorMessage: 'Assinatura HMAC ausente na requisição.',
    };
  }

  const cleanSignature = signature.trim().toLowerCase();
  if (!/^[0-9a-f]{40}$/.test(cleanSignature)) {
    return {
      valid: false,
      statusCode: 401,
      errorCode: 'invalid_signature_format',
      errorMessage: 'Formato de assinatura HMAC-SHA1 inválido.',
    };
  }

  if (!rawBodyText || !rawBodyText.trim()) {
    return {
      valid: false,
      statusCode: 400,
      errorCode: 'empty_body',
      errorMessage: 'Corpo da requisição vazio.',
    };
  }

  const encoder = new TextEncoder();
  const key = await crypto.subtle.importKey(
    'raw',
    encoder.encode(secretKey),
    { name: 'HMAC', hash: 'SHA-1' },
    false,
    ['sign']
  );

  const signatureBytes = await crypto.subtle.sign(
    'HMAC',
    key,
    encoder.encode(rawBodyText)
  );

  const expectedHash = Array.from(new Uint8Array(signatureBytes))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')
    .toLowerCase();

  if (expectedHash.length !== cleanSignature.length) {
    return {
      valid: false,
      statusCode: 401,
      errorCode: 'signature_mismatch',
      errorMessage: 'Assinatura HMAC inválida.',
    };
  }

  // Comparação em tempo constante (evita ataques de timing)
  let diff = 0;
  for (let i = 0; i < expectedHash.length; i++) {
    diff |= expectedHash.charCodeAt(i) ^ cleanSignature.charCodeAt(i);
  }

  if (diff !== 0) {
    return {
      valid: false,
      statusCode: 401,
      errorCode: 'signature_mismatch',
      errorMessage: 'Assinatura HMAC inválida.',
    };
  }

  let parsed: any;
  try {
    parsed = JSON.parse(rawBodyText);
  } catch {
    return {
      valid: false,
      statusCode: 400,
      errorCode: 'invalid_json',
      errorMessage: 'Corpo da requisição não é um JSON válido.',
    };
  }

  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    return {
      valid: false,
      statusCode: 400,
      errorCode: 'invalid_payload_type',
      errorMessage: 'O payload recebido deve ser um objeto JSON.',
    };
  }

  return {
    valid: true,
    statusCode: 200,
    parsedBody: parsed,
  };
}

/**
 * Verifica dias válidos no mês (considerando anos bissextos)
 */
function isCalendarDateValid(year: number, month: number, day: number): boolean {
  if (month < 1 || month > 12 || day < 1) return false;
  const isLeap = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
  const daysInMonths = [31, isLeap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  return day <= daysInMonths[month - 1];
}

/**
 * Parser de datas determinístico e independente do fuso horário da máquina.
 * Suporta:
 *  - "YYYY-MM-DD HH:mm" (formato real Kiwify, e.g. "2026-11-01 10:30")
 *  - "YYYY-MM-DD HH:mm:ss"
 *  - Formatos ISO com offset ("...-03:00") ou UTC ("...Z")
 * Para formatos sem indicação de fuso, assume explicitamente America/Sao_Paulo (UTC-3).
 * Retorna ISO UTC string ou null se inválida.
 */
export function parseKiwifyDate(dateStr: unknown): string | null {
  if (!dateStr || typeof dateStr !== 'string') return null;
  const trimmed = dateStr.trim();
  if (!trimmed) return null;

  // Regex para formato oficial: YYYY-MM-DD HH:mm[:ss] ou YYYY-MM-DDTHH:mm[:ss]
  const pattern = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,9}))?)?(?:(Z)|([+-]\d{2})(?::?(\d{2}))?)?$/;
  const match = trimmed.match(pattern);
  if (!match) return null;

  const year = parseInt(match[1], 10);
  const month = parseInt(match[2], 10);
  const day = parseInt(match[3], 10);
  const hour = parseInt(match[4], 10);
  const minute = parseInt(match[5], 10);
  const second = match[6] ? parseInt(match[6], 10) : 0;
  const millisecond = Number((match[7] || '').slice(0, 3).padEnd(3, '0'));

  if (hour < 0 || hour > 23 || minute < 0 || minute > 59 || second < 0 || second > 59) {
    return null;
  }

  if (!isCalendarDateValid(year, month, day)) {
    return null;
  }

  let totalOffsetMinutes = -180; // Default Brasil (America/Sao_Paulo UTC-3 = -180 min)
  if (match[8] === 'Z') {
    totalOffsetMinutes = 0;
  } else if (match[9]) {
    const tzHours = Number(match[9].slice(1));
    const tzMins = match[10] ? Number(match[10]) : 0;
    if (tzHours > 23 || tzMins > 59) return null;
    totalOffsetMinutes = (tzHours * 60 + tzMins) * (match[9].startsWith('-') ? -1 : 1);
  }

  // Cálculo UTC puramente aritmético
  const calendar = new Date(0);
  calendar.setUTCFullYear(year, month - 1, day);
  calendar.setUTCHours(hour, minute, second, millisecond);
  const utcMs = calendar.getTime() - (totalOffsetMinutes * 60 * 1000);
  const utcDate = new Date(utcMs);

  return isNaN(utcDate.getTime()) ? null : utcDate.toISOString();
}

/**
 * Validação rigorosa dos campos obrigatórios para concessão de acesso (GRANT).
 * Rejeita categoricamente qualquer ausência de campos canônicos ou valores divergentes.
 */
export function validateKiwifyGrantPayload(
  body: any,
  config: KiwifyConfig
): { valid: true; grantData: KiwifyGrantData } | { valid: false; reason: string } {
  const eventType = body?.webhook_event_type;
  const orderStatus = body?.order_status;

  // 1. Validar que é evento de pagamento aprovado
  const isApprovedEvent = ['order_approved', 'subscription_renewed'].includes(eventType) && orderStatus === 'paid';
  if (!isApprovedEvent) {
    return { valid: false, reason: 'Evento não é de concessão de acesso (order_approved/subscription_renewed com status paid).' };
  }

  // 2. Commissions.charge_amount: inteiro estrito 4990
  const chargeAmount = body?.Commissions?.charge_amount;
  if (typeof chargeAmount !== 'number' || !Number.isInteger(chargeAmount) || chargeAmount !== 4990) {
    return { valid: false, reason: `Valor da comissão (${chargeAmount}) diverge do canônico (4990 centavos).` };
  }

  // 3. Commissions.currency: 'BRL'
  const currency = body?.Commissions?.currency;
  if (currency !== 'BRL') {
    return { valid: false, reason: `Moeda (${currency}) diverge do canônico (BRL).` };
  }

  // 4. Product.product_id permitido
  const productId = body?.Product?.product_id;
  if (!productId || typeof productId !== 'string' || !config.allowedProductIds.includes(productId.trim())) {
    return { valid: false, reason: `Produto Kiwify (${productId}) não autorizado.` };
  }

  // O primeiro pagamento assinado identifica o plano real. Se há allowlist
  // configurada, ela continua obrigatória; o banco fixa a identidade por assinatura.
  if (config.planId.includes('...')) {
    return { valid: false, reason: 'Configuração de plano Kiwify inválida.' };
  }
  const payloadPlanId = body?.Subscription?.plan?.id;
  if (typeof payloadPlanId !== 'string' || !payloadPlanId.trim()) {
    return { valid: false, reason: 'Identificador do plano Kiwify ausente.' };
  }
  if (config.planId.trim() && payloadPlanId.trim() !== config.planId.trim()) {
    return { valid: false, reason: 'Plano Kiwify diverge do plano canônico configurado.' };
  }

  // 6. Frequency: estritamente 'monthly'
  const frequency = body?.Subscription?.plan?.frequency;
  if (frequency !== 'monthly') {
    return { valid: false, reason: `Frequência da assinatura (${frequency}) diverge de 'monthly'.` };
  }

  // 7. subscription_id: não vazio e consistente com Subscription.id
  const rootSubId = body?.subscription_id ? String(body.subscription_id).trim() : null;
  const objSubId = body?.Subscription?.id ? String(body.Subscription.id).trim() : null;

  if (!rootSubId && !objSubId) {
    return { valid: false, reason: 'Identificador de assinatura Kiwify ausente.' };
  }

  if (rootSubId && objSubId && rootSubId !== objSubId) {
    return { valid: false, reason: 'Inconsistência entre subscription_id e Subscription.id.' };
  }

  const finalSubId = rootSubId || objSubId!;

  // 8. order_id: não vazio
  const orderId = body?.order_id ? String(body.order_id).trim() : null;
  if (!orderId) {
    return { valid: false, reason: 'Identificador do pedido (order_id) ausente.' };
  }

  // 9. Datas do ciclo: approved_date e access_until/next_payment
  const approvedDateStr = body?.approved_date;
  const parsedApprovedDate = parseKiwifyDate(approvedDateStr);
  if (!parsedApprovedDate) {
    return { valid: false, reason: `Data de aprovação inválida ou ausente: ${approvedDateStr}` };
  }

  const accessUntilStr = body?.customer_access?.access_until || body?.Subscription?.customer_access?.access_until;
  const nextPaymentStr = body?.Subscription?.next_payment;

  const parsedAccessUntil = parseKiwifyDate(accessUntilStr);
  const parsedNextPayment = parseKiwifyDate(nextPaymentStr);

  const cycleEndStr = parsedNextPayment || parsedAccessUntil;
  if (!cycleEndStr) {
    return { valid: false, reason: 'Data de término do ciclo (access_until/next_payment) inválida ou ausente.' };
  }

  const startTime = new Date(parsedApprovedDate).getTime();
  const endTime = new Date(cycleEndStr).getTime();

  if (endTime <= startTime) {
    return { valid: false, reason: 'Data final do ciclo deve ser posterior à data de aprovação.' };
  }

  // Pagamentos atrasados preservam o vencimento original e podem cobrir menos de 25 dias.
  const durationDays = (endTime - startTime) / (24 * 3600 * 1000);
  if (durationDays <= 0 || durationDays > 35) {
    return { valid: false, reason: `Duração do ciclo (${durationDays.toFixed(1)} dias) fora dos limites mensais esperados (maior que zero e até 35 dias).` };
  }

  // 10. SCK opaco (tracking)
  const rawSck = body?.TrackingParameters?.sck || body?.sck;
  const sck = rawSck ? String(rawSck).trim() : null;

  // 11. Hash determinístico do payload para auditoria
  const payloadHash = ''; // Calculado pelo chamador se necessário

  return {
    valid: true,
    grantData: {
      eventType,
      orderId,
      subscriptionId: finalSubId,
      orderStatus,
      productId: productId.trim(),
      planId: payloadPlanId.trim(),
      amountCents: chargeAmount,
      currency,
      sck,
      approvedDate: parsedApprovedDate,
      orderCreatedAt: parseKiwifyDate(body?.created_at),
      accessUntil: cycleEndStr,
      nextPayment: parsedNextPayment,
      eventId: body?.webhook_event_id ? String(body.webhook_event_id).trim() : null,
      payloadHash,
    },
  };
}

