// Supabase Edge Function: mercadopago-webhook
// Recebe webhooks do Mercado Pago, valida assinatura HMAC em tempo constante e consulta a API para confirmar pagamentos

import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { hmac } from 'https://deno.land/x/hmac@v2.0.1/mod.ts';

serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: { 'Access-Control-Allow-Origin': '*' } });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
    const mpEnabled = Deno.env.get('MERCADO_PAGO_ENABLED') === 'true';
    const mpMode = Deno.env.get('MERCADO_PAGO_MODE')?.trim().toLowerCase();
    const mpAccessToken = Deno.env.get('MERCADO_PAGO_ACCESS_TOKEN')?.trim() || '';
    const mpWebhookSecret = Deno.env.get('MERCADO_PAGO_WEBHOOK_SECRET')?.trim() || '';
    const mpCollectorId = Deno.env.get('MERCADO_PAGO_COLLECTOR_ID')?.trim() || '';

    // 1. Cobrança explicitamente desligada por padrão nesta fase ou segredos incompletos -> 503 sem processar
    const isModeValid = mpMode === 'production' || mpMode === 'test';
    const isTokenReal = Boolean(mpAccessToken && !mpAccessToken.includes('...'));
    const isSecretReal = Boolean(mpWebhookSecret && !mpWebhookSecret.includes('...'));
    const isCollectorReal = Boolean(mpCollectorId && !mpCollectorId.includes('...'));

    if (!mpEnabled || !isModeValid || !isTokenReal || !isSecretReal || !isCollectorReal) {
      return new Response(JSON.stringify({ error: 'billing_not_configured' }), {
        status: 503,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    const url = new URL(req.url);
    const bodyText = await req.text();
    let body: any = {};
    try {
      body = JSON.parse(bodyText);
    } catch {}

    const queryDataId = url.searchParams.get('data.id') || url.searchParams.get('id');
    const bodyDataId = body?.data?.id ? String(body.data.id) : undefined;
    const dataId = String(queryDataId || bodyDataId || '');

    if (!dataId) {
      return new Response(JSON.stringify({ error: 'Identificador ausente' }), { status: 400 });
    }

    // Consistência estrita entre parâmetro assinado e corpo da requisição
    if (bodyDataId && queryDataId && bodyDataId !== queryDataId) {
      return new Response(JSON.stringify({ error: 'Inconsistência entre assinatura e dados do corpo' }), { status: 400 });
    }

    // 2. Validação obrigatória da assinatura HMAC
    const signatureHeader = req.headers.get('x-signature') || '';
    const requestIdHeader = req.headers.get('x-request-id') || '';

    if (!signatureHeader) {
      return new Response(JSON.stringify({ error: 'Assinatura ausente' }), { status: 401 });
    }

    const parts = signatureHeader.split(',');
    let ts = '';
    let v1 = '';
    for (const p of parts) {
      const [k, v] = p.split('=').map((s) => s.trim());
      if (k === 'ts') ts = v;
      if (k === 'v1') v1 = v;
    }

    if (!ts || !v1) {
      return new Response(JSON.stringify({ error: 'Formato de assinatura inválido' }), { status: 401 });
    }

    // Janela de frescor estrita: rejeita se > 10 minutos (proteção contra replay attack)
    const eventTime = parseInt(ts, 10);
    const nowSec = Math.floor(Date.now() / 1000);
    if (isNaN(eventTime) || Math.abs(nowSec - eventTime) > 600) {
      return new Response(JSON.stringify({ error: 'Assinatura expirada (replay attack evitado)' }), { status: 401 });
    }

    const manifest = `id:${dataId};request-id:${requestIdHeader};ts:${ts};`;
    const calculatedHash = hmac('sha256', mpWebhookSecret, manifest, 'utf8', 'hex');

    // Comparação em tempo constante
    let match = true;
    if (calculatedHash.length !== v1.length) {
      match = false;
    } else {
      let diff = 0;
      for (let i = 0; i < calculatedHash.length; i++) {
        diff |= calculatedHash.charCodeAt(i) ^ v1.charCodeAt(i);
      }
      match = diff === 0;
    }

    if (!match) {
      return new Response(JSON.stringify({ error: 'Assinatura inválida' }), { status: 401 });
    }

    // 3. Whitelist de tópicos permitidos
    const eventType = String(body?.type || url.searchParams.get('type') || body?.action || 'payment');
    const allowedTopics = ['payment', 'subscription_preapproval', 'preapproval', 'authorized_payment'];
    if (!allowedTopics.some((t) => eventType.toLowerCase().includes(t))) {
      return new Response(JSON.stringify({ received: true, ignored: true, reason: 'unsupported_topic' }), { status: 200 });
    }

    // 4. Consultar o recurso oficial na API do Mercado Pago
    const mpRes = await fetch(`https://api.mercadopago.com/v1/payments/${dataId}`, {
      headers: { Authorization: `Bearer ${mpAccessToken}` },
    });

    if (!mpRes.ok) {
      return new Response(JSON.stringify({ error: 'Falha ao consultar pagamento na API oficial' }), { status: 400 });
    }

    const paymentData = await mpRes.json();
    const companyId = paymentData.external_reference;

    if (!companyId || typeof companyId !== 'string' || !companyId.trim()) {
      return new Response(JSON.stringify({ error: 'Pagamento sem vínculo com empresa (external_reference)' }), { status: 400 });
    }

    if (paymentData.currency_id !== 'BRL') {
      return new Response(JSON.stringify({ error: 'Moeda divergente de BRL' }), { status: 400 });
    }

    const amountCents = Math.round(Number(paymentData.transaction_amount) * 100);
    if (amountCents !== 4990) {
      return new Response(JSON.stringify({ error: 'Valor divergente do plano canônico R$ 49,90' }), { status: 400 });
    }

    if (String(paymentData.collector_id) !== String(mpCollectorId)) {
      return new Response(JSON.stringify({ error: 'Conta recebedora divergente da oficial' }), { status: 400 });
    }

    let status = 'pending';
    if (paymentData.status === 'approved') status = 'approved';
    else if (paymentData.status === 'refunded') status = 'refunded';
    else if (paymentData.status === 'charged_back') status = 'charged_back';
    else if (paymentData.status === 'rejected' || paymentData.status === 'cancelled') status = 'rejected';

    // 5. Chamar a bridge segura public.tf_process_billing_payment usando service_role
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const { data: result, error: rpcError } = await supabase.rpc('tf_process_billing_payment', {
      p_company_id: companyId.trim(),
      p_mp_payment_id: String(paymentData.id),
      p_mp_preapproval_id: paymentData.order?.id ? String(paymentData.order.id) : null,
      p_amount_cents: amountCents,
      p_currency: 'BRL',
      p_status: status,
      p_payment_date: paymentData.date_approved || paymentData.date_created || new Date().toISOString(),
    });

    if (rpcError) {
      console.error('[MP Edge Webhook] Erro ao gravar no banco:', rpcError);
      return new Response(JSON.stringify({ error: 'Falha ao processar pagamento no banco de dados.' }), { status: 500 });
    }

    return new Response(JSON.stringify({ success: true, result }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: 'Erro interno ao processar notificação.' }), { status: 500 });
  }
});
