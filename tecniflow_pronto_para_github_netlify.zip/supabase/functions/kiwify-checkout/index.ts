// Supabase Edge Function: kiwify-checkout
// Cria sessão de checkout Kiwify chamando a RPC segura tf_create_billing_intent
// que gera o intent opaco no servidor (256 bits, TTL 24h) e vincula à empresa via auth.uid()

import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { isKiwifyConfigured, isKiwifyCheckoutUrl } from '../_shared/kiwifyCommon.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  if (req.method !== 'POST') {
    return new Response(
      JSON.stringify({ error: 'method_not_allowed', message: 'Apenas método POST é suportado.' }),
      { status: 405, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY') || '';

    // 1. Configuração fail-closed
    const kiwifyEnabled = Deno.env.get('KIWIFY_ENABLED') === 'true';
    const rawCheckoutUrl = Deno.env.get('KIWIFY_CHECKOUT_URL')?.trim() || '';
    const webhookSecret = Deno.env.get('KIWIFY_WEBHOOK_SECRET')?.trim() || '';
    const rawAllowedProducts = Deno.env.get('KIWIFY_ALLOWED_PRODUCT_IDS')?.trim() || '';
    const planId = Deno.env.get('KIWIFY_PLAN_ID')?.trim() || '';

    let checkoutUrl = '';
    try {
      if (rawCheckoutUrl.startsWith('https://pay.kiwify.com.br/')) {
        const parsed = new URL(rawCheckoutUrl);
        if (isKiwifyCheckoutUrl(rawCheckoutUrl)) {
          checkoutUrl = rawCheckoutUrl;
        }
      }
    } catch {}

    const allowedProductIds = rawAllowedProducts
      .split(',')
      .map((p) => p.trim())
      .filter((p) => p.length > 0 && !p.includes('...'));

    const isConfigured = Boolean(supabaseUrl && supabaseAnonKey) && isKiwifyConfigured({
      enabled: kiwifyEnabled, checkoutUrl, webhookSecret, allowedProductIds, planId,
    });

    if (!isConfigured) {
      return new Response(
        JSON.stringify({
          error: 'billing_not_configured',
          message:
            'A contratação online está em fase de configuração pela administração. Entre em contato com o suporte para ativar sua assinatura.',
        }),
        { status: 503, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // 2. Extrair e verificar JWT do usuário autenticado
    const authHeader = req.headers.get('Authorization') || '';
    if (!authHeader.startsWith('Bearer ')) {
      return new Response(JSON.stringify({ error: 'Não autorizado' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Cliente autenticado com o token do usuário para invocar RPC segura
    const userClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const {
      data: { user },
      error: authError,
    } = await userClient.auth.getUser();

    if (authError || !user) {
      return new Response(JSON.stringify({ error: 'Sessão inválida ou expirada' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // 3. Invocar tf_create_billing_intent: gera o token criptográfico no banco com TTL de 24h
    // Valida papel de 'owner' e bloqueia se já possui assinatura paga ativa e vigente
    const { data: intentResult, error: intentError } = await userClient.rpc('tf_create_billing_intent', {
      p_product_id: allowedProductIds[0],
      p_plan_id: planId,
    });

    if (intentError) {
      return new Response(
        JSON.stringify({
          error: 'intent_creation_failed',
          message: intentError.message || 'Falha ao registrar intenção de checkout.',
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const opaqueToken = intentResult?.token;
    if (!opaqueToken) {
      return new Response(
        JSON.stringify({ error: 'Token de checkout não retornado pelo banco.' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // 4. Construir URL Kiwify passando SOMENTE o sck opaco (zero dados pessoais ou company_id na URL)
    const targetUrl = new URL(checkoutUrl);
    targetUrl.searchParams.set('sck', opaqueToken);

    return new Response(
      JSON.stringify({
        checkout_url: targetUrl.toString(),
        intent_id: opaqueToken,
        expires_at: intentResult?.expires_at,
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (err: any) {
    return new Response(JSON.stringify({ error: 'Erro interno ao gerar checkout Kiwify.' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

