// Supabase Edge Function: kiwify-webhook
// Recebe webhooks oficiais da Kiwify, valida assinatura HMAC-SHA1 na querystring
// calculada diretamente sobre os bytes UTF-8 brutos (raw body) em tempo constante e invoca
// a bridge segura public.tf_process_kiwify_payment via service_role

import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import {
  verifyKiwifyWebhookSignature,
  validateKiwifyGrantPayload,
  parseKiwifyDate,
  isKiwifyConfigured,
  type KiwifyConfig,
} from '../_shared/kiwifyCommon.ts';

const MAX_BODY_BYTES = 512 * 1024; // 512 KB

serve(async (req: Request) => {
  // 1. Tratamento estrito de métodos HTTP (POST apenas; OPTIONS/HEAD para preflight/health)
  if (req.method === 'OPTIONS' || req.method === 'HEAD') {
    return new Response(null, {
      status: 204,
      headers: {
        'Allow': 'POST, OPTIONS, HEAD',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS, HEAD',
        'Access-Control-Allow-Headers': 'content-type',
      },
    });
  }

  if (req.method !== 'POST') {
    return new Response(
      JSON.stringify({ error: 'method_not_allowed', message: 'Apenas método POST é suportado.' }),
      {
        status: 405,
        headers: {
          'Allow': 'POST, OPTIONS, HEAD',
          'Content-Type': 'application/json',
        },
      }
    );
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';

    // 2. Configuração fail-closed
    const kiwifyEnabled = Deno.env.get('KIWIFY_ENABLED') === 'true';
    const webhookSecret = Deno.env.get('KIWIFY_WEBHOOK_SECRET')?.trim() || '';
    const checkoutUrl = Deno.env.get('KIWIFY_CHECKOUT_URL')?.trim() || '';
    const rawAllowedProducts = Deno.env.get('KIWIFY_ALLOWED_PRODUCT_IDS')?.trim() || '';
    const planId = Deno.env.get('KIWIFY_PLAN_ID')?.trim() || '';

    const allowedProductIds = rawAllowedProducts
      .split(',')
      .map((p) => p.trim())
      .filter((p) => p.length > 0 && !p.includes('...'));

    const isSecretValid = Boolean(webhookSecret && webhookSecret.length >= 8 && !webhookSecret.includes('...'));
    const isPlanValid = Boolean(planId && !planId.includes('...'));

    if (!supabaseUrl || !supabaseServiceKey || !isKiwifyConfigured({
      enabled: kiwifyEnabled, webhookSecret, checkoutUrl, allowedProductIds, planId,
    })) {
      return new Response(
        JSON.stringify({
          error: 'billing_not_configured',
          message: 'Webhook Kiwify não configurado no servidor.',
        }),
        { status: 503, headers: { 'Content-Type': 'application/json' } }
      );
    }

    const config: KiwifyConfig = {
      enabled: kiwifyEnabled,
      webhookSecret,
      checkoutUrl,
      allowedProductIds,
      planId,
    };

    // 3. Validação de Content-Type
    const contentType = req.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) {
      return new Response(
        JSON.stringify({ error: 'invalid_content_type', message: 'Content-Type deve ser application/json.' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }

    // 4. Limite de tamanho do corpo
    const contentLength = req.headers.get('content-length');
    if (contentLength && parseInt(contentLength, 10) > MAX_BODY_BYTES) {
      return new Response(
        JSON.stringify({ error: 'payload_too_large', message: 'Tamanho da requisição excede o limite de 512KB.' }),
        { status: 413, headers: { 'Content-Type': 'application/json' } }
      );
    }

    const rawBody = await req.text();
    if (new TextEncoder().encode(rawBody).byteLength > MAX_BODY_BYTES) {
      return new Response(
        JSON.stringify({ error: 'payload_too_large', message: 'Tamanho da requisição excede o limite de 512KB.' }),
        { status: 413, headers: { 'Content-Type': 'application/json' } }
      );
    }

    const url = new URL(req.url);
    const signature = url.searchParams.get('signature');

    // 5. Validação HMAC-SHA1 oficial sobre os bytes UTF-8 brutos (raw body) em tempo constante
    const signatureResult = await verifyKiwifyWebhookSignature(rawBody, signature, webhookSecret);
    if (!signatureResult.valid) {
      return new Response(
        JSON.stringify({ error: signatureResult.errorCode, message: signatureResult.errorMessage }),
        { status: signatureResult.statusCode, headers: { 'Content-Type': 'application/json' } }
      );
    }

    const body = signatureResult.parsedBody;
    const eventType = typeof body.webhook_event_type === 'string' ? body.webhook_event_type.trim() : '';
    const orderId = String(body.order_id || '').trim();
    const orderStatus = String(body.order_status || '').trim();

    if (!eventType || !orderId) {
      return new Response(
        JSON.stringify({ error: 'invalid_payload', message: 'Identificadores de evento ou pedido ausentes.' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }

    if (!['order_approved', 'subscription_renewed', 'subscription_canceled',
      'subscription_late', 'order_refunded', 'chargeback', 'order_rejected',
      'pix_created', 'billet_created'].includes(eventType)) {
      return new Response(JSON.stringify({ success: true, ignored: true }), {
        status: 200, headers: { 'Content-Type': 'application/json' },
      });
    }
    const productId = body.Product?.product_id;
    if (typeof productId !== 'string' || !allowedProductIds.includes(productId.trim())) {
      return new Response(JSON.stringify({ error: 'product_not_allowed' }), { status: 400 });
    }
    if (body.subscription_id && body.Subscription?.id
      && String(body.subscription_id).trim() !== String(body.Subscription.id).trim()) {
      return new Response(JSON.stringify({ error: 'subscription_mismatch' }), { status: 400 });
    }

    // Hash SHA-256 do payload canônico para auditoria e deduplicação
    const hashBuffer = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(JSON.stringify(body)));
    const payloadHash = Array.from(new Uint8Array(hashBuffer))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');

    const eventId = String(body.webhook_event_id || body.event_id || `${orderId}_${eventType}_${orderStatus}`);

    const isGrantEvent = ['order_approved', 'subscription_renewed'].includes(eventType) && orderStatus === 'paid';

    let validatedData: any = null;
    if (isGrantEvent) {
      // 6. Para eventos de concessão (GRANT): validação FAIL-CLOSED estrita
      const grantValidation = validateKiwifyGrantPayload(body, config);
      if (!grantValidation.valid) {
        return new Response(
          JSON.stringify({ error: 'grant_validation_failed', reason: grantValidation.reason }),
          { status: 400, headers: { 'Content-Type': 'application/json' } }
        );
      }
      validatedData = grantValidation.grantData;
    } else {
      // Eventos não-grant (cancelamento, atraso, estorno, pix_created, etc.)
      const subscriptionObj = body.Subscription;
      const rootSubId = body.subscription_id ? String(body.subscription_id).trim() : null;
      const objSubId = subscriptionObj?.id ? String(subscriptionObj.id).trim() : null;
      const subscriptionId = rootSubId || objSubId || null;

      const rawSck = body.TrackingParameters?.sck || body.sck;
      const sck = rawSck ? String(rawSck).trim() : null;

      validatedData = {
        eventType,
        orderId,
        subscriptionId,
        orderStatus,
        productId: String(body.Product?.product_id || '').trim(),
        planId: String(subscriptionObj?.plan?.id || '').trim(),
        amountCents: typeof body.Commissions?.charge_amount === 'number' ? body.Commissions.charge_amount : 0,
        currency: String(body.Commissions?.currency || 'BRL').trim().toUpperCase(),
        sck,
        approvedDate: parseKiwifyDate(body.approved_date),
        orderCreatedAt: parseKiwifyDate(body.created_at),
        accessUntil: parseKiwifyDate(subscriptionObj?.customer_access?.access_until),
        nextPayment: parseKiwifyDate(subscriptionObj?.next_payment),
      };
    }

    // 7. Chamar a bridge segura public.tf_process_kiwify_payment via service_role
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const { data: result, error: rpcError } = await supabase.rpc('tf_process_kiwify_payment', {
      p_event_type: validatedData.eventType,
      p_order_id: validatedData.orderId,
      p_subscription_id: validatedData.subscriptionId,
      p_order_status: validatedData.orderStatus,
      p_product_id: validatedData.productId,
      p_plan_id: validatedData.planId,
      p_amount_cents: validatedData.amountCents,
      p_currency: validatedData.currency,
      p_sck: validatedData.sck,
      p_access_until: validatedData.accessUntil,
      p_next_payment: validatedData.nextPayment,
      p_approved_date: validatedData.approvedDate,
      p_event_id: eventId,
      p_payload_hash: payloadHash,
      p_order_created_at: validatedData.orderCreatedAt,
    });

    if (rpcError) {
      console.error('[Kiwify Webhook] database_error', { code: rpcError.code });
      return new Response(
        JSON.stringify({ error: 'database_error', message: 'Falha temporária ao registrar a notificação.' }),
        { status: 500, headers: { 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ success: true, result }),
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    );
  } catch (err: any) {
    return new Response(
      JSON.stringify({ error: 'internal_error', message: 'Erro interno ao processar webhook Kiwify.' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
});

