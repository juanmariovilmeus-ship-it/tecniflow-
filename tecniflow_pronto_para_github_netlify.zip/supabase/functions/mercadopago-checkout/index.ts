// Supabase Edge Function: mercadopago-checkout
// Cria sessão de checkout no Mercado Pago vinculada à empresa autenticada via auth.uid()

import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
    const mpEnabled = Deno.env.get('MERCADO_PAGO_ENABLED') === 'true';
    const mpMode = Deno.env.get('MERCADO_PAGO_MODE')?.trim().toLowerCase();
    const mpAccessToken = Deno.env.get('MERCADO_PAGO_ACCESS_TOKEN')?.trim() || '';
    const mpPlanId = Deno.env.get('MERCADO_PAGO_PLAN_ID')?.trim() || '';
    const mpWebhookSecret = Deno.env.get('MERCADO_PAGO_WEBHOOK_SECRET')?.trim() || '';
    const mpCollectorId = Deno.env.get('MERCADO_PAGO_COLLECTOR_ID')?.trim() || '';
    const appUrl = (Deno.env.get('APP_URL')?.trim() || '').replace(/\/+$/, '');

    // 1. Cobrança explicitamente desligada por padrão nesta fase
    const isModeValid = mpMode === 'production' || mpMode === 'test';
    const isPlanReal = Boolean(mpPlanId && mpPlanId !== 'TECNIFLOW-MENSAL-4990' && !mpPlanId.includes('...'));
    const isTokenReal = Boolean(mpAccessToken && !mpAccessToken.includes('...'));
    const isSecretReal = Boolean(mpWebhookSecret && !mpWebhookSecret.includes('...'));
    const isCollectorReal = Boolean(mpCollectorId && !mpCollectorId.includes('...'));
    const isAppUrlValid = appUrl.startsWith('https://');

    if (!mpEnabled || !isModeValid || !isTokenReal || !isPlanReal || !isSecretReal || !isCollectorReal || !isAppUrlValid) {
      return new Response(
        JSON.stringify({
          error: 'billing_not_configured',
          message: 'A contratação online está em fase de configuração pela administração. Entre em contato com o suporte para ativar sua assinatura.',
        }),
        { status: 503, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // 2. Extrair e verificar JWT do usuário autenticado
    const authHeader = req.headers.get('Authorization') || '';
    if (!authHeader.startsWith('Bearer ')) {
      return new Response(JSON.stringify({ error: 'Não autorizado' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const token = authHeader.replace('Bearer ', '').trim();
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);

    if (authError || !user) {
      return new Response(JSON.stringify({ error: 'Sessão inválida ou expirada' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // 3. Resolver empresa e perfil através do schema privado tecniflow
    const { data: userData, error: userError } = await supabase
      .schema('tecniflow')
      .from('users')
      .select('id, company_id, role, name')
      .eq('auth_user_id', user.id)
      .single();

    if (userError || !userData) {
      return new Response(JSON.stringify({ error: 'Usuário não vinculado a uma empresa' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (userData.role !== 'owner') {
      return new Response(JSON.stringify({ error: 'Apenas o proprietário pode gerenciar a assinatura' }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const companyId = userData.company_id;

    // 4. Impedir cobrança precoce durante os 7 dias gratuitos
    const { data: subData } = await supabase
      .schema('tecniflow')
      .from('company_subscriptions')
      .select('status, trial_ends_at')
      .eq('company_id', companyId)
      .single();

    const now = new Date();
    if (subData && subData.status === 'trial') {
      const trialEnds = new Date(subData.trial_ends_at);
      if (now.getTime() < trialEnds.getTime()) {
        const formattedDate = trialEnds.toLocaleDateString('pt-BR', {
          day: '2-digit',
          month: '2-digit',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        });
        return new Response(
          JSON.stringify({
            error: 'trial_active',
            message: `Seu período de avaliação gratuita de 7 dias ainda está ativo até ${formattedDate}. A contratação estará liberada ao término do teste, garantindo o aproveitamento integral dos seus 7 dias gratuitos sem cobranças antecipadas.`,
            trial_ends_at: subData.trial_ends_at,
          }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    // 5. Validar plano na API do Mercado Pago
    const planRes = await fetch(`https://api.mercadopago.com/preapproval_plan/${mpPlanId}`, {
      headers: { Authorization: `Bearer ${mpAccessToken}` },
    });

    if (!planRes.ok) {
      return new Response(
        JSON.stringify({
          error: 'billing_not_configured',
          message: 'Plano de assinatura não localizado no Mercado Pago.',
        }),
        { status: 503, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const planData = await planRes.json();
    const amount = Number(planData.auto_recurring?.transaction_amount);
    if (amount !== 49.9 && amount !== 49.90) {
      return new Response(
        JSON.stringify({ error: 'billing_not_configured', message: 'Valor do plano Mercado Pago diverge de R$ 49,90.' }),
        { status: 503, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (String(planData.collector_id) !== String(mpCollectorId)) {
      return new Response(
        JSON.stringify({ error: 'billing_not_configured', message: 'Conta recebedora do plano diverge da cadastrada.' }),
        { status: 503, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // 6. Criar preapproval na API do Mercado Pago
    const backUrl = `${appUrl}/#subscription`;
    const mpRes = await fetch('https://api.mercadopago.com/preapproval', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${mpAccessToken}`,
      },
      body: JSON.stringify({
        preapproval_plan_id: mpPlanId,
        reason: 'TecniFlow Mensal - Assinatura da Assistência Técnica',
        external_reference: companyId,
        payer_email: user.email,
        auto_recurring: {
          frequency: 1,
          frequency_type: 'months',
          transaction_amount: 49.9,
          currency_id: 'BRL',
        },
        back_url: backUrl,
        status: 'pending',
      }),
    });

    if (!mpRes.ok) {
      return new Response(JSON.stringify({ error: 'Falha ao comunicar com o Mercado Pago' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const checkoutData = await mpRes.json();
    return new Response(
      JSON.stringify({
        checkout_url: checkoutData.init_point,
        preapproval_id: checkoutData.id,
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message || 'Erro interno' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
