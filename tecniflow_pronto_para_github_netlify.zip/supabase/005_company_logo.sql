-- ============================================================================
-- TECNIFLOW - MIGRAÇÃO INCREMENTAL 005: IDENTIDADE VISUAL E LOGOTIPO DA EMPRESA
-- Schema Privado: tecniflow
-- RPC Pública Dedicada: public.tf_update_company_logo(p_logo_data_url text)
-- RPC Atualizada: public.tf_sync_current_user() (para carregar o logotipo na sessão)
-- Garantia: Assinatura de public.tf_update_company preservada sem alterações
-- Idempotente, transacional, sem DROP de dados preexistentes
-- ============================================================================

BEGIN;

-- 1. ADICIONAR COLUNA company_logo_data_url EM tecniflow.companies SE NÃO EXISTIR
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'tecniflow' AND table_name = 'companies' AND column_name = 'company_logo_data_url'
  ) THEN
    ALTER TABLE tecniflow.companies ADD COLUMN company_logo_data_url TEXT;
  END IF;
END $$;

-- 2. FUNÇÃO DE VALIDAÇÃO DE FORMATO E TAMANHO DO LOGOTIPO
CREATE OR REPLACE FUNCTION tecniflow.validate_company_logo(p_logo text)
RETURNS boolean LANGUAGE plpgsql IMMUTABLE SET search_path = '' AS $validate$
DECLARE v_bytes bytea; v_mime text; v_base64 text;
BEGIN
  IF p_logo IS NULL OR p_logo = '' THEN RETURN true; END IF;
  IF octet_length(p_logo)>307200 THEN RAISE EXCEPTION 'A foto excede o tamanho permitido.'; END IF;
  IF p_logo !~ '^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$' THEN
    RAISE EXCEPTION 'Formato de foto inválido.';
  END IF;
  v_mime := split_part(split_part(p_logo,';',1), '/',2);
  v_base64 := split_part(p_logo,',',2);
  BEGIN v_bytes := decode(v_base64,'base64');
  EXCEPTION WHEN invalid_parameter_value THEN RAISE EXCEPTION 'Imagem inválida.'; END;
  IF replace(encode(v_bytes,'base64'),chr(10),'') <> v_base64 THEN RAISE EXCEPTION 'Imagem inválida.'; END IF;
  IF NOT (
    (v_mime='png' AND octet_length(v_bytes)>=33 AND encode(substring(v_bytes FROM 1 FOR 8),'hex')='89504e470d0a1a0a' AND encode(substring(v_bytes FROM 13 FOR 4),'hex')='49484452') OR
    (v_mime='jpeg' AND octet_length(v_bytes)>=12 AND encode(substring(v_bytes FROM 1 FOR 3),'hex')='ffd8ff' AND encode(substring(v_bytes FROM octet_length(v_bytes)-1 FOR 2),'hex')='ffd9') OR
    (v_mime='webp' AND octet_length(v_bytes)>=20 AND encode(substring(v_bytes FROM 1 FOR 4),'hex')='52494646' AND encode(substring(v_bytes FROM 9 FOR 4),'hex')='57454250')
  ) THEN RAISE EXCEPTION 'O conteúdo não corresponde ao formato da imagem.'; END IF;
  RETURN true;
END; $validate$;
DO $constraint$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='tecniflow.companies'::regclass AND conname='companies_logo_valid') THEN
    ALTER TABLE tecniflow.companies ADD CONSTRAINT companies_logo_valid CHECK (tecniflow.validate_company_logo(company_logo_data_url));
  END IF;
END; $constraint$;

-- 3. RPC DEDICADA: public.tf_update_company_logo
-- Resolve company_id EXCLUSIVAMENTE via current_company_id() / auth.uid()
-- Não aceita company_id externo; atualiza somente o logotipo da empresa autenticada.
CREATE OR REPLACE FUNCTION public.tf_update_company_logo(
  p_logo_data_url text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_company_id VARCHAR(36);
  v_company RECORD;
  v_clean_logo TEXT;
BEGIN
  v_company_id := tecniflow.current_company_id();
  IF v_company_id IS NULL THEN
    RAISE EXCEPTION 'Acesso não autorizado.';
  END IF;

  IF p_logo_data_url IS NOT NULL AND trim(p_logo_data_url) <> '' THEN
    PERFORM tecniflow.validate_company_logo(p_logo_data_url);
    v_clean_logo := trim(p_logo_data_url);
  ELSE
    v_clean_logo := NULL;
  END IF;

  UPDATE tecniflow.companies
  SET company_logo_data_url = v_clean_logo
  WHERE id = v_company_id
  RETURNING * INTO v_company;

  RETURN jsonb_build_object('company', to_jsonb(v_company));
END;
$$;

-- 4. ATUALIZAR public.tf_sync_current_user PARA CARREGAR company_logo_data_url NA SESSÃO
CREATE OR REPLACE FUNCTION public.tf_sync_current_user()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_uid UUID;
  v_user RECORD;
  v_company RECORD;
  v_auth_email text;
  v_raw_meta jsonb;
  v_company_id VARCHAR(36);
  v_user_id VARCHAR(36);
  v_company_name VARCHAR(100);
  v_company_doc VARCHAR(50);
  v_company_phone VARCHAR(30);
  v_company_whatsapp VARCHAR(30);
  v_company_address VARCHAR(255);
  v_owner_name VARCHAR(100);
  v_existing_conflict VARCHAR(36);
BEGIN
  v_uid := (SELECT auth.uid());
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Não autenticado. Sessão inválida ou expirada no Supabase Auth.';
  END IF;

  -- Lock transacional no nível de sessão do auth.uid() para evitar corridas concorrentes
  PERFORM pg_advisory_xact_lock(hashtext(v_uid::text));

  -- 1. Verifica se já existe vínculo estabelecido para este auth.uid()
  SELECT u.id, u.company_id, u.name, u.email, u.role
  INTO v_user
  FROM tecniflow.users u
  WHERE u.auth_user_id = v_uid;

  IF FOUND THEN
    SELECT c.id, c.name, c.document, c.phone, c.whatsapp, c.email, c.address, c.warranty_terms, c.receipt_notes, c.company_logo_data_url
    INTO v_company
    FROM tecniflow.companies c
    WHERE c.id = v_user.company_id;

    RETURN jsonb_build_object(
      'user', to_jsonb(v_user),
      'company', to_jsonb(v_company)
    );
  END IF;

  -- 2. Não encontrado: obter dados do auth.users para provisionamento atômico
  SELECT email, raw_user_meta_data
  INTO v_auth_email, v_raw_meta
  FROM auth.users
  WHERE id = v_uid;

  IF v_auth_email IS NULL OR trim(v_auth_email) = '' THEN
    RAISE EXCEPTION 'E-mail do usuário autenticado não encontrado no Supabase Auth.';
  END IF;

  v_auth_email := lower(trim(v_auth_email));
  IF length(v_auth_email) > 100 THEN
    RAISE EXCEPTION 'E-mail de autenticação excede o limite permitido de 100 caracteres.';
  END IF;

  -- 3. Prevenção estrita de invasão/mesclagem por e-mail com contas legadas
  SELECT id INTO v_existing_conflict
  FROM tecniflow.users
  WHERE lower(email) = v_auth_email AND (auth_user_id IS NULL OR auth_user_id != v_uid)
  LIMIT 1;

  IF v_existing_conflict IS NOT NULL THEN
    RAISE EXCEPTION 'Conflito de cadastro: já existe um usuário registrado com este e-mail no banco. Para segurança dos dados, a unificação requer procedimento de migração e não é realizada automaticamente.';
  END IF;

  -- 4. Criar empresa e usuário vinculados de forma atômica
  v_company_id := gen_random_uuid()::text;
  v_user_id := gen_random_uuid()::text;

  v_company_name := COALESCE(trim(v_raw_meta->>'company_name'), '');
  IF v_company_name = '' THEN
    v_company_name := 'Minha Assistência Técnica';
  END IF;
  v_company_name := substring(v_company_name, 1, 100);

  v_owner_name := COALESCE(trim(v_raw_meta->>'owner_name'), '');
  IF v_owner_name = '' THEN
    v_owner_name := split_part(v_auth_email, '@', 1);
  END IF;
  v_owner_name := substring(v_owner_name, 1, 100);

  v_company_doc := substring(COALESCE(trim(v_raw_meta->>'company_document'), ''), 1, 50);
  v_company_phone := substring(COALESCE(trim(v_raw_meta->>'company_phone'), ''), 1, 30);
  v_company_whatsapp := substring(COALESCE(trim(v_raw_meta->>'company_whatsapp'), ''), 1, 30);
  v_company_address := substring(COALESCE(trim(v_raw_meta->>'company_address'), ''), 1, 255);

  INSERT INTO tecniflow.companies (
    id, name, document, phone, whatsapp, email, address, warranty_terms, receipt_notes, company_logo_data_url, created_at
  ) VALUES (
    v_company_id, v_company_name, v_company_doc, v_company_phone, v_company_whatsapp, v_auth_email, v_company_address, '', '', NULL, now()
  );

  INSERT INTO tecniflow.users (
    id, company_id, name, email, password_hash, role, auth_user_id, created_at
  ) VALUES (
    v_user_id, v_company_id, v_owner_name, v_auth_email, '', 'owner', v_uid, now()
  );

  SELECT u.id, u.company_id, u.name, u.email, u.role
  INTO v_user
  FROM tecniflow.users u
  WHERE u.id = v_user_id;

  SELECT c.id, c.name, c.document, c.phone, c.whatsapp, c.email, c.address, c.warranty_terms, c.receipt_notes, c.company_logo_data_url
  INTO v_company
  FROM tecniflow.companies c
  WHERE c.id = v_company_id;

  RETURN jsonb_build_object(
    'user', to_jsonb(v_user),
    'company', to_jsonb(v_company)
  );
END;
$$;

-- 5. PERMISSÕES EXPLÍCITAS E SEGURANÇA DAS RPCS
REVOKE ALL ON FUNCTION public.tf_update_company_logo(text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.tf_update_company_logo(text) TO authenticated;

REVOKE ALL ON FUNCTION public.tf_sync_current_user() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.tf_sync_current_user() TO authenticated;

COMMIT;
