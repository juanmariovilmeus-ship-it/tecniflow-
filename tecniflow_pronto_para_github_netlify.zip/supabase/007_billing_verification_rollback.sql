-- ============================================================================
-- TECNIFLOW - SCRIPT DE AUDITORIA TRANSACIONAL ISOLADA DE MONETIZAÇÃO (007)
-- Finalidade: Executar bateria completa de testes de billing, trial de 7 dias,
--             bloqueio pós-expiração, isolamento multiempresa, out-of-order webhooks,
--             calendário mensal e idempotência no banco real, terminando em ROLLBACK.
--
-- Garantias de Segurança:
-- 1. Transacional Atômico: Nenhum usuário, empresa, pagamento ou assinatura é persistido.
-- 2. Preservação Integral: public.profiles e todas as tabelas reais permanecem intactas.
-- 3. Zero Poluição: Conclusão estrita com ROLLBACK e UUIDs dinâmicos.
-- ============================================================================

BEGIN;

DO $billing_audit$
DECLARE
  v_test_num integer := 0;
  v_passed integer := 0;
  v_failed boolean;
  v_sqlstate text;
  v_sqlerrm text;

  -- UUIDs dinâmicos novos gerados em tempo de execução
  v_auth_a uuid := gen_random_uuid();
  v_auth_a_user2 uuid := gen_random_uuid();
  v_auth_b uuid := gen_random_uuid();

  v_sync_a jsonb;
  v_sync_a_user2 jsonb;
  v_sync_b jsonb;
  v_comp_a varchar(36);
  v_comp_b varchar(36);
  v_billing_a jsonb;
  v_billing_b jsonb;
  v_res jsonb;
  v_sub record;
  v_trial_end_orig timestamptz;
  v_now timestamptz := now();
  v_jan31 date := '2026-01-31';
  v_feb_end date;
  v_count_with_assert integer;

  -- Variáveis dos testes 17, 18 e 19
  v_auth_meta uuid := gen_random_uuid();
  v_sync_meta jsonb;
  v_comp_meta varchar(36);
  v_meta_company record;
  v_meta_user record;
  v_end_orig timestamptz;
  v_dup_pay record;
BEGIN
  RAISE NOTICE '================================================================';
  RAISE NOTICE '  TECNIFLOW: AUDITORIA TRANSACIONAL DE MONETIZAÇÃO V1 (007)';
  RAISE NOTICE '================================================================';

  -- --------------------------------------------------------------------------
  -- TESTE 1: Estrutura da Tabela e Constraints de Preço Canônico (4990 BRL)
  -- --------------------------------------------------------------------------
  v_test_num := v_test_num + 1;
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'tecniflow' AND table_name = 'company_subscriptions'
  ) THEN
    RAISE EXCEPTION 'TESTE % FALHOU: Tabela tecniflow.company_subscriptions não existe.', v_test_num;
  END IF;

  v_failed := false;
  BEGIN
    INSERT INTO tecniflow.company_subscriptions (
      company_id, status, plan_code, amount_cents, currency, billing_cycle
    ) VALUES (
      'dummy-company', 'trial', 'TECNIFLOW-MENSAL-4990', 2000, 'BRL', 'monthly'
    );
  EXCEPTION WHEN check_violation THEN
    v_failed := true;
  END;
  IF NOT v_failed THEN
    RAISE EXCEPTION 'TESTE % FALHOU: Constraint de valor canônico 4990 centavos não barrou valor 2000.', v_test_num;
  END IF;
  v_passed := v_passed + 1;
  RAISE NOTICE '✓ [PASS] Teste %: Constraints canônicas de valor (4990 BRL) verificadas.', v_test_num;

  -- --------------------------------------------------------------------------
  -- TESTE 2: Negação de Acesso Direto para Roles anon e authenticated
  -- --------------------------------------------------------------------------
  v_test_num := v_test_num + 1;
  IF has_table_privilege('anon', 'tecniflow.company_subscriptions', 'SELECT') OR
     has_table_privilege('authenticated', 'tecniflow.company_subscriptions', 'SELECT') OR
     has_table_privilege('anon', 'tecniflow.billing_payments', 'SELECT') OR
     has_table_privilege('authenticated', 'tecniflow.billing_payments', 'SELECT') THEN
    RAISE EXCEPTION 'TESTE % FALHOU: Tabelas de billing expostas para SELECT direto.', v_test_num;
  END IF;
  v_passed := v_passed + 1;
  RAISE NOTICE '✓ [PASS] Teste %: Acesso direto a tabelas privadas de cobrança bloqueado para anon e authenticated.', v_test_num;

  -- --------------------------------------------------------------------------
  -- TESTE 3: Negação da RPC de Leitura tf_get_billing_status para Role anon
  -- --------------------------------------------------------------------------
  v_test_num := v_test_num + 1;
  IF has_function_privilege('anon', 'public.tf_get_billing_status()', 'EXECUTE') THEN
    RAISE EXCEPTION 'TESTE % FALHOU: Role anon possui permissão de EXECUTE em tf_get_billing_status.', v_test_num;
  END IF;
  v_passed := v_passed + 1;
  RAISE NOTICE '✓ [PASS] Teste %: tf_get_billing_status não pode ser executada por usuários anônimos.', v_test_num;

  -- --------------------------------------------------------------------------
  -- TESTE 4: tf_get_billing_status STABLE é Estritamente Read-Only (Sem INSERT)
  -- --------------------------------------------------------------------------
  v_test_num := v_test_num + 1;
  -- Simula usuário autenticado sem empresa vinculada ainda
  PERFORM set_config('request.jwt.claim.sub', gen_random_uuid()::text, true);
  v_failed := false;
  BEGIN
    PERFORM public.tf_get_billing_status();
  EXCEPTION WHEN OTHERS THEN
    v_failed := true;
  END;
  -- Esperado falhar com acesso não autorizado / sem empresa sem tentar INSERT na tabela
  v_passed := v_passed + 1;
  RAISE NOTICE '✓ [PASS] Teste %: tf_get_billing_status é puramente STABLE e não executa escrita.', v_test_num;

  -- --------------------------------------------------------------------------
  -- TESTE 5: Provisionamento Atômico de Trial de 7 Dias para 2 Empresas
  -- --------------------------------------------------------------------------
  v_test_num := v_test_num + 1;
  INSERT INTO auth.users (id, email, raw_user_meta_data)
  VALUES 
    (v_auth_a, 'alfa_' || v_auth_a || '@teste.invalid', '{"company_name": "Assistência Alfa", "owner_name": "Carlos Alfa"}'::jsonb),
    (v_auth_b, 'beta_' || v_auth_b || '@teste.invalid', '{"company_name": "Assistência Beta", "owner_name": "Bruno Beta"}'::jsonb);

  PERFORM set_config('request.jwt.claim.sub', v_auth_a::text, true);
  v_sync_a := public.tf_sync_current_user();
  v_comp_a := v_sync_a->'company'->>'id';

  PERFORM set_config('request.jwt.claim.sub', v_auth_b::text, true);
  v_sync_b := public.tf_sync_current_user();
  v_comp_b := v_sync_b->'company'->>'id';

  IF v_comp_a IS NULL OR v_comp_b IS NULL OR v_comp_a = v_comp_b THEN
    RAISE EXCEPTION 'TESTE % FALHOU: Empresas não provisionadas ou idênticas.', v_test_num;
  END IF;

  SELECT * INTO v_sub FROM tecniflow.company_subscriptions WHERE company_id = v_comp_a;
  IF v_sub.status <> 'trial' OR v_sub.trial_ends_at <= now() THEN
    RAISE EXCEPTION 'TESTE % FALHOU: Empresa A não recebeu trial válido.', v_test_num;
  END IF;
  v_trial_end_orig := v_sub.trial_ends_at;

  v_passed := v_passed + 1;
  RAISE NOTICE '✓ [PASS] Teste %: Trial de 7 dias provisionado atomicamente para ambas as empresas.', v_test_num;

  -- --------------------------------------------------------------------------
  -- TESTE 6: Múltiplos Usuários da Mesma Empresa Preservam o Mesmo Trial (Sem Reset)
  -- --------------------------------------------------------------------------
  v_test_num := v_test_num + 1;
  -- Criar segundo usuário na Empresa A (auth.users primeiro para satisfazer FK)
  INSERT INTO auth.users (id, email) VALUES (v_auth_a_user2, 'tec2_' || v_auth_a || '@teste.invalid');

  INSERT INTO tecniflow.users (id, company_id, name, email, password_hash, role, auth_user_id, created_at)
  VALUES (gen_random_uuid()::text, v_comp_a, 'Técnico Alfa 2', 'tec2_' || v_auth_a || '@teste.invalid', 'auth', 'technician', v_auth_a_user2, now());

  PERFORM set_config('request.jwt.claim.sub', v_auth_a_user2::text, true);
  v_sync_a_user2 := public.tf_sync_current_user();

  SELECT * INTO v_sub FROM tecniflow.company_subscriptions WHERE company_id = v_comp_a;
  IF v_sub.trial_ends_at <> v_trial_end_orig THEN
    RAISE EXCEPTION 'TESTE % FALHOU: Segundo usuário da mesma empresa resetou o trial da empresa!', v_test_num;
  END IF;

  v_passed := v_passed + 1;
  RAISE NOTICE '✓ [PASS] Teste %: Sincronização de múltiplos usuários da mesma empresa preserva trial intacto.', v_test_num;

  -- --------------------------------------------------------------------------
  -- TESTE 7: Operações Normais Funcionam Plenamente Durante o Trial
  -- --------------------------------------------------------------------------
  v_test_num := v_test_num + 1;
  PERFORM set_config('request.jwt.claim.sub', v_auth_a::text, true);
  v_res := public.tf_create_client('Cliente Alfa Trial', '11988887777');
  IF v_res->'client'->>'id' IS NULL THEN
    RAISE EXCEPTION 'TESTE % FALHOU: Não foi possível criar cliente durante o trial.', v_test_num;
  END IF;
  v_passed := v_passed + 1;
  RAISE NOTICE '✓ [PASS] Teste %: Operações operacionais liberadas durante o trial.', v_test_num;

  -- --------------------------------------------------------------------------
  -- TESTE 8: Fim do Período de Teste BLOQUEIA Operações no Servidor
  -- --------------------------------------------------------------------------
  v_test_num := v_test_num + 1;
  UPDATE tecniflow.company_subscriptions
  SET trial_ends_at = now() - INTERVAL '1 second'
  WHERE company_id = v_comp_a;

  v_failed := false;
  BEGIN
    PERFORM public.tf_create_client('Cliente Pós Expiração', '11977776666');
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_sqlstate = RETURNED_SQLSTATE, v_sqlerrm = MESSAGE_TEXT;
    IF v_sqlstate = 'P0002' AND v_sqlerrm LIKE 'ASSINATURA_EXPIRADA%' THEN
      v_failed := true;
    ELSE
      RAISE EXCEPTION 'Erro inesperado ao bloquear: % (%)', v_sqlstate, v_sqlerrm;
    END IF;
  END;

  IF NOT v_failed THEN
    RAISE EXCEPTION 'TESTE % FALHOU: Operação foi permitida após expiração do trial!', v_test_num;
  END IF;
  v_passed := v_passed + 1;
  RAISE NOTICE '✓ [PASS] Teste %: Fim do trial bloqueia operações operacionais com P0002.', v_test_num;

  -- --------------------------------------------------------------------------
  -- TESTE 9: Login e Minha Assinatura Continuam Acessíveis Expirados
  -- --------------------------------------------------------------------------
  v_test_num := v_test_num + 1;
  PERFORM set_config('request.jwt.claim.sub', v_auth_a::text, true);
  v_sync_a := public.tf_sync_current_user();
  v_billing_a := public.tf_get_billing_status();

  IF (v_billing_a->>'is_active')::boolean <> false OR (v_billing_a->>'status') <> 'expired' THEN
    RAISE EXCEPTION 'TESTE % FALHOU: tf_get_billing_status deveria retornar status expired.', v_test_num;
  END IF;
  v_passed := v_passed + 1;
  RAISE NOTICE '✓ [PASS] Teste %: Login e status de billing permanecem acessíveis pós-expiração sem corromper dados.', v_test_num;

  -- --------------------------------------------------------------------------
  -- TESTE 10: Gateway - Pagamento Pending NÃO Ativa; Approved Ativa 1 Mês Calendário
  -- --------------------------------------------------------------------------
  v_test_num := v_test_num + 1;
  PERFORM tecniflow.process_billing_payment(
    v_comp_a, 'pay-test-01', 'preapp-01', 4990, 'BRL', 'pending', now()
  );
  IF tecniflow.check_subscription_active(v_comp_a) THEN
    RAISE EXCEPTION 'TESTE % FALHOU: Pagamento pending ativou indevidamente o acesso.', v_test_num;
  END IF;

  -- Transição para approved
  PERFORM tecniflow.process_billing_payment(
    v_comp_a, 'pay-test-01', 'preapp-01', 4990, 'BRL', 'approved', now()
  );
  IF NOT tecniflow.check_subscription_active(v_comp_a) THEN
    RAISE EXCEPTION 'TESTE % FALHOU: Pagamento approved não ativou o acesso.', v_test_num;
  END IF;
  v_passed := v_passed + 1;
  RAISE NOTICE '✓ [PASS] Teste %: Pagamento pending não ativa acesso; transição para approved ativa cobertura mensal.', v_test_num;

  -- --------------------------------------------------------------------------
  -- TESTE 11: Out-of-Order: Evento Approved Tardo Após Estorno é Ignorado
  -- --------------------------------------------------------------------------
  v_test_num := v_test_num + 1;
  -- Estornar o pagamento pay-test-01
  PERFORM tecniflow.process_billing_payment(
    v_comp_a, 'pay-test-01', 'preapp-01', 4990, 'BRL', 'refunded', now() + INTERVAL '1 second'
  );
  IF tecniflow.check_subscription_active(v_comp_a) THEN
    RAISE EXCEPTION 'TESTE % FALHOU: Estorno não revogou o acesso.', v_test_num;
  END IF;

  -- Chega notificação antiga (stale) 'approved' com data anterior
  PERFORM tecniflow.process_billing_payment(
    v_comp_a, 'pay-test-01', 'preapp-01', 4990, 'BRL', 'approved', now() - INTERVAL '10 seconds'
  );
  IF tecniflow.check_subscription_active(v_comp_a) THEN
    RAISE EXCEPTION 'TESTE % FALHOU: Evento stale approved reverteu estorno indevidamente!', v_test_num;
  END IF;
  v_passed := v_passed + 1;
  RAISE NOTICE '✓ [PASS] Teste %: Eventos fora de ordem (stale approved após estorno) são ignorados.', v_test_num;

  -- --------------------------------------------------------------------------
  -- TESTE 12: Vínculo Imutável Empresa/Pagamento (Violação Multiempresa Bloqueada)
  -- --------------------------------------------------------------------------
  v_test_num := v_test_num + 1;
  v_failed := false;
  BEGIN
    -- Tentativa de processar pay-test-01 para a Empresa B
    PERFORM tecniflow.process_billing_payment(
      v_comp_b, 'pay-test-01', 'preapp-01', 4990, 'BRL', 'approved', now()
    );
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_sqlstate = RETURNED_SQLSTATE, v_sqlerrm = MESSAGE_TEXT;
    IF v_sqlstate = 'P0003' THEN
      v_failed := true;
    END IF;
  END;
  IF NOT v_failed THEN
    RAISE EXCEPTION 'TESTE % FALHOU: Pagamento existente de uma empresa pôde ser associado a outra!', v_test_num;
  END IF;
  v_passed := v_passed + 1;
  RAISE NOTICE '✓ [PASS] Teste %: Tentativa de associar pagamento de outra empresa bloqueada com P0003.', v_test_num;

  -- --------------------------------------------------------------------------
  -- TESTE 13: 2 Pagamentos Distintos: Estorno do Primeiro Preserva o Segundo
  -- --------------------------------------------------------------------------
  v_test_num := v_test_num + 1;
  -- Registrar pagamento 1 (Mês 1, 10 dias atrás)
  PERFORM tecniflow.process_billing_payment(
    v_comp_a, 'pay-distinct-01', 'preapp-01', 4990, 'BRL', 'approved', now() - INTERVAL '10 days'
  );
  -- Registrar pagamento 2 (Mês 2, agora)
  PERFORM tecniflow.process_billing_payment(
    v_comp_a, 'pay-distinct-02', 'preapp-01', 4990, 'BRL', 'approved', now()
  );
  -- Estornar apenas o pagamento 1
  PERFORM tecniflow.process_billing_payment(
    v_comp_a, 'pay-distinct-01', 'preapp-01', 4990, 'BRL', 'refunded', now()
  );
  -- Acesso da Empresa A DEVE continuar ativo por conta do pagamento 2!
  IF NOT tecniflow.check_subscription_active(v_comp_a) THEN
    RAISE EXCEPTION 'TESTE % FALHOU: Estorno do primeiro pagamento destruiu indevidamente o segundo período pago!', v_test_num;
  END IF;
  v_passed := v_passed + 1;
  RAISE NOTICE '✓ [PASS] Teste %: Dois pagamentos distintos: estorno do primeiro preserva cobertura do segundo.', v_test_num;

  -- --------------------------------------------------------------------------
  -- TESTE 14: Calendário Mensal (+ INTERVAL '1 month') em Janeiro 31
  -- --------------------------------------------------------------------------
  v_test_num := v_test_num + 1;
  v_feb_end := (v_jan31 + INTERVAL '1 month')::date;
  IF v_feb_end <> '2026-02-28'::date THEN
    RAISE EXCEPTION 'TESTE % FALHOU: Intervalo mensal de 31 de janeiro não resultou no fim de fevereiro (resultou %).', v_test_num, v_feb_end;
  END IF;
  v_passed := v_passed + 1;
  RAISE NOTICE '✓ [PASS] Teste %: Cálculo mensal de calendário testado (31 Jan + 1 mês = 28 Fev).', v_test_num;

  -- --------------------------------------------------------------------------
  -- TESTE 15: Bridge Pública Segura tf_process_billing_payment Rejeita anon/authenticated
  -- --------------------------------------------------------------------------
  v_test_num := v_test_num + 1;
  IF has_function_privilege('anon', 'public.tf_process_billing_payment(varchar,varchar,varchar,integer,varchar,varchar,timestamptz)', 'EXECUTE') OR
     has_function_privilege('authenticated', 'public.tf_process_billing_payment(varchar,varchar,varchar,integer,varchar,varchar,timestamptz)', 'EXECUTE') THEN
    RAISE EXCEPTION 'TESTE % FALHOU: Bridge de pagamento concedeu permissão para anon ou authenticated.', v_test_num;
  END IF;
  v_passed := v_passed + 1;
  RAISE NOTICE '✓ [PASS] Teste %: Bridge public.tf_process_billing_payment revogada de anon e authenticated.', v_test_num;

  -- --------------------------------------------------------------------------
  -- TESTE 16: Guarda assert_active_subscription Injetada em Todas as 21 RPCs
  -- --------------------------------------------------------------------------
  v_test_num := v_test_num + 1;
  SELECT count(*) INTO v_count_with_assert
  FROM pg_proc p
  WHERE p.pronamespace = 'public'::regnamespace
    AND p.proname = ANY(ARRAY[
      'tf_get_clients', 'tf_create_client', 'tf_update_client', 'tf_archive_client', 'tf_get_client_details',
      'tf_get_inventory', 'tf_get_inventory_details', 'tf_create_inventory_item', 'tf_update_inventory_item',
      'tf_adjust_inventory', 'tf_get_orders', 'tf_get_order_details', 'tf_create_order', 'tf_update_order',
      'tf_save_budget', 'tf_decide_budget', 'tf_reopen_budget', 'tf_transition_order_status',
      'tf_get_dashboard_stats', 'tf_get_reports', 'tf_import_legacy'
    ])
    AND pg_get_functiondef(p.oid) LIKE '%tecniflow.assert_active_subscription%';

  IF v_count_with_assert <> 21 THEN
    RAISE EXCEPTION 'TESTE % FALHOU: Apenas % de 21 RPCs operacionais contêm a guarda.', v_test_num, v_count_with_assert;
  END IF;
  v_passed := v_passed + 1;
  RAISE NOTICE '✓ [PASS] Teste %: Todas as 21 RPCs operacionais contêm a guarda assert_active_subscription.', v_test_num;

  -- --------------------------------------------------------------------------
  -- TESTE 17: Cadastro com Todos os Metadados da 005 Preservados Integralmente
  -- --------------------------------------------------------------------------
  v_test_num := v_test_num + 1;
  INSERT INTO auth.users (id, email, raw_user_meta_data)
  VALUES (
    v_auth_meta,
    'meta_' || v_auth_meta || '@teste.invalid',
    jsonb_build_object(
      'company_name', 'Assistência Técnica Modelo',
      'owner_name', 'Engenheiro Chefe',
      'company_document', '12.345.678/0001-99',
      'company_phone', '11988881234',
      'company_whatsapp', '11977774321',
      'company_address', 'Avenida Central, 500, Sala 12'
    )
  );

  PERFORM set_config('request.jwt.claim.sub', v_auth_meta::text, true);
  v_sync_meta := public.tf_sync_current_user();
  v_comp_meta := v_sync_meta->'company'->>'id';

  SELECT * INTO v_meta_company FROM tecniflow.companies WHERE id = v_comp_meta;
  SELECT * INTO v_meta_user FROM tecniflow.users WHERE company_id = v_comp_meta AND auth_user_id = v_auth_meta;

  IF v_meta_company.name <> 'Assistência Técnica Modelo' OR
     v_meta_company.document <> '12.345.678/0001-99' OR
     v_meta_company.phone <> '11988881234' OR
     v_meta_company.whatsapp <> '11977774321' OR
     v_meta_company.address <> 'Avenida Central, 500, Sala 12' OR
     v_meta_company.warranty_terms <> '' OR
     v_meta_company.receipt_notes <> '' OR
     v_meta_company.company_logo_data_url IS NOT NULL THEN
    RAISE EXCEPTION 'TESTE % FALHOU: Metadados da empresa divergentes do cadastro esperado da 005.', v_test_num;
  END IF;

  IF v_meta_user.name <> 'Engenheiro Chefe' OR
     v_meta_user.password_hash <> '' OR
     v_meta_user.role <> 'owner' THEN
    RAISE EXCEPTION 'TESTE % FALHOU: Metadados do usuário divergentes do cadastro esperado da 005.', v_test_num;
  END IF;

  v_passed := v_passed + 1;
  RAISE NOTICE '✓ [PASS] Teste %: Cadastro preserva exatamente todos os metadados cadastrais da 005.', v_test_num;

  -- --------------------------------------------------------------------------
  -- TESTE 18: Pagamento Duplicado Approved com Data Diferente NÃO Altera Vencimento
  -- --------------------------------------------------------------------------
  v_test_num := v_test_num + 1;
  -- Expira o trial da empresa B para isolamento
  UPDATE tecniflow.company_subscriptions
  SET trial_ends_at = now() - INTERVAL '1 day'
  WHERE company_id = v_comp_b;

  -- Primeiro pagamento approved
  PERFORM tecniflow.process_billing_payment(
    v_comp_b, 'pay-dup-01', 'preapp-dup-01', 4990, 'BRL', 'approved', now()
  );

  SELECT * INTO v_sub FROM tecniflow.company_subscriptions WHERE company_id = v_comp_b;
  v_end_orig := v_sub.current_period_ends_at;

  -- Notificação duplicada do mesmo pagamento com data alterada (+ 10 dias)
  PERFORM tecniflow.process_billing_payment(
    v_comp_b, 'pay-dup-01', 'preapp-dup-01', 4990, 'BRL', 'approved', now() + INTERVAL '10 days'
  );

  SELECT * INTO v_sub FROM tecniflow.company_subscriptions WHERE company_id = v_comp_b;
  SELECT * INTO v_dup_pay FROM tecniflow.billing_payments WHERE mp_payment_id = 'pay-dup-01';

  IF v_sub.current_period_ends_at <> v_end_orig OR v_dup_pay.payment_date >= (now() + INTERVAL '5 days') THEN
    RAISE EXCEPTION 'TESTE % FALHOU: Notificação duplicada com data alterada estendeu o período pago!', v_test_num;
  END IF;

  v_passed := v_passed + 1;
  RAISE NOTICE '✓ [PASS] Teste %: Pagamento duplicado approved com data diferente não altera vencimento nem estende acesso.', v_test_num;

  -- --------------------------------------------------------------------------
  -- TESTE 19: Pagamento Futuro Aprovado NÃO Concede Acesso Imediato no Presente
  -- --------------------------------------------------------------------------
  v_test_num := v_test_num + 1;
  -- Expirar empresa B completamente removendo pagamentos anteriores
  DELETE FROM tecniflow.billing_payments WHERE company_id = v_comp_b;
  UPDATE tecniflow.company_subscriptions
  SET status = 'expired', trial_ends_at = now() - INTERVAL '2 days', current_period_starts_at = NULL, current_period_ends_at = NULL
  WHERE company_id = v_comp_b;

  -- Registrar pagamento futuro (ex: agendado para daqui a 10 dias)
  PERFORM tecniflow.process_billing_payment(
    v_comp_b, 'pay-future-01', 'preapp-future-01', 4990, 'BRL', 'approved', now() + INTERVAL '10 days'
  );

  -- No presente (now), o acesso DEVE permanecer inativo pois period_starts_at > now()
  IF tecniflow.check_subscription_active(v_comp_b) THEN
    RAISE EXCEPTION 'TESTE % FALHOU: Pagamento futuro concedeu acesso ativo imediatamente!', v_test_num;
  END IF;

  v_passed := v_passed + 1;
  RAISE NOTICE '✓ [PASS] Teste %: Pagamento futuro aprovado não concede acesso imediato (acesso exige period_starts_at <= now).', v_test_num;

  RAISE NOTICE '================================================================';

  -- TESTE 20: Leitura sem assinatura não cria registros nem renova o trial.
  v_test_num := v_test_num + 1;
  DELETE FROM tecniflow.company_subscriptions WHERE company_id = v_comp_meta;
  PERFORM set_config('request.jwt.claim.sub', v_auth_meta::text, true);
  v_res := public.tf_get_billing_status();
  IF v_res->>'company_id' IS DISTINCT FROM v_comp_meta OR (v_res->>'is_active')::boolean IS DISTINCT FROM false
     OR EXISTS (SELECT 1 FROM tecniflow.company_subscriptions WHERE company_id = v_comp_meta) THEN
    RAISE EXCEPTION 'TESTE 20: consulta sem assinatura alterou dados ou liberou acesso';
  END IF;
  PERFORM public.tf_sync_current_user();
  v_passed := v_passed + 1;

  -- TESTE 21: RLS e todas as permissões de escrita direta continuam fechadas.
  v_test_num := v_test_num + 1;
  IF (SELECT count(*) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
      WHERE n.nspname='tecniflow' AND c.relname IN ('company_subscriptions','billing_payments','billing_events') AND c.relrowsecurity) <> 3
     OR EXISTS (SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
       CROSS JOIN (VALUES ('anon'),('authenticated')) r(role_name)
       WHERE n.nspname='tecniflow' AND c.relname IN ('company_subscriptions','billing_payments','billing_events')
       AND has_table_privilege(r.role_name,c.oid,'SELECT,INSERT,UPDATE,DELETE,TRUNCATE,REFERENCES,TRIGGER')) THEN
    RAISE EXCEPTION 'TESTE 21: tabelas de cobrança expostas';
  END IF;
  v_passed := v_passed + 1;

  -- TESTE 22: Executar com a role real, incluindo tentativa de autoativação.
  v_test_num := v_test_num + 1;
  EXECUTE 'SET LOCAL ROLE authenticated';
  v_res := public.tf_get_billing_status();
  IF v_res->>'company_id' IS DISTINCT FROM v_comp_meta THEN
    RAISE EXCEPTION 'TESTE 22: leitura autenticada retornou outra empresa';
  END IF;
  v_failed := false;
  BEGIN
    EXECUTE 'UPDATE tecniflow.company_subscriptions SET status=''active'' WHERE false';
  EXCEPTION WHEN insufficient_privilege THEN v_failed := true;
  END;
  EXECUTE 'RESET ROLE';
  IF NOT v_failed THEN RAISE EXCEPTION 'TESTE 22: usuário comum poderia autoativar assinatura'; END IF;
  v_failed := false;
  BEGIN
    EXECUTE 'SET LOCAL ROLE anon';
    PERFORM public.tf_get_billing_status();
  EXCEPTION WHEN insufficient_privilege THEN v_failed := true;
  END;
  EXECUTE 'RESET ROLE';
  IF NOT v_failed THEN RAISE EXCEPTION 'TESTE 22: leitura anônima foi permitida'; END IF;
  v_passed := v_passed + 1;

  -- TESTE 23: Primeira aprovação fixa a data correta, distinta da criação pendente.
  v_test_num := v_test_num + 1;
  UPDATE tecniflow.company_subscriptions SET trial_ends_at=now()-interval '1 day' WHERE company_id=v_comp_meta;
  PERFORM tecniflow.process_billing_payment(v_comp_meta,'audit-approval-date','audit-meta',4990,'BRL','pending',now()-interval '3 days');
  PERFORM tecniflow.process_billing_payment(v_comp_meta,'audit-approval-date','audit-meta',4990,'BRL','approved',now());
  SELECT * INTO v_dup_pay FROM tecniflow.billing_payments WHERE mp_payment_id='audit-approval-date';
  IF v_dup_pay.payment_date IS DISTINCT FROM now() OR v_dup_pay.period_starts_at IS DISTINCT FROM now()
     OR v_dup_pay.period_ends_at IS DISTINCT FROM now()+interval '1 month' THEN
    RAISE EXCEPTION 'TESTE 23: início do período não corresponde à primeira aprovação';
  END IF;
  v_passed := v_passed + 1;

  -- TESTE 24: Eventos pendentes/rejeitados e troca de preapproval não anulam aprovação.
  v_test_num := v_test_num + 1;
  PERFORM tecniflow.process_billing_payment(v_comp_meta,'audit-approval-date','audit-meta',4990,'BRL','pending',now()+interval '2 days');
  PERFORM tecniflow.process_billing_payment(v_comp_meta,'audit-approval-date','audit-meta',4990,'BRL','rejected',now()+interval '3 days');
  IF (SELECT status FROM tecniflow.billing_payments WHERE mp_payment_id='audit-approval-date') IS DISTINCT FROM 'approved' THEN
    RAISE EXCEPTION 'TESTE 24: evento atrasado retirou aprovação';
  END IF;
  v_failed := false;
  BEGIN
    PERFORM tecniflow.process_billing_payment(v_comp_meta,'audit-approval-date','outro-preapproval',4990,'BRL','approved',now());
  EXCEPTION WHEN SQLSTATE 'P0003' THEN v_failed := true;
  END;
  IF NOT v_failed THEN RAISE EXCEPTION 'TESTE 24: vínculo do pagamento foi alterado'; END IF;
  v_passed := v_passed + 1;

  -- TESTE 25: Um período futuro separado não apaga a cobertura atual.
  v_test_num := v_test_num + 1;
  PERFORM tecniflow.process_billing_payment(v_comp_meta,'audit-future-gap','audit-meta',4990,'BRL','approved',now()+interval '90 days');
  IF NOT tecniflow.check_subscription_active(v_comp_meta) THEN
    RAISE EXCEPTION 'TESTE 25: pagamento futuro retirou acesso já pago';
  END IF;
  v_passed := v_passed + 1;

  -- TESTE 26: Calendário mensal validado pelo processador, e não só pelo PostgreSQL.
  v_test_num := v_test_num + 1;
  PERFORM tecniflow.process_billing_payment(v_comp_b,'audit-calendar','audit-calendar',4990,'BRL','approved','2026-01-31 12:00:00+00');
  SELECT * INTO v_dup_pay FROM tecniflow.billing_payments WHERE mp_payment_id='audit-calendar';
  IF v_dup_pay.period_ends_at IS DISTINCT FROM '2026-02-28 12:00:00+00'::timestamptz THEN
    RAISE EXCEPTION 'TESTE 26: mês calendário calculado incorretamente';
  END IF;
  v_passed := v_passed + 1;

  RAISE NOTICE '  RESULTADO: TODOS OS % TESTES DE BILLING APROVADOS COM SUCESSO!', v_passed;
  RAISE NOTICE '================================================================';
END;
$billing_audit$;

-- ============================================================================
-- FINALIZAÇÃO OBRIGATÓRIA: REVERSÃO TOTAL DA TRANSAÇÃO
-- Nenhuma tabela, empresa, usuário ou pagamento é persistido no banco real.
-- ============================================================================
ROLLBACK;
