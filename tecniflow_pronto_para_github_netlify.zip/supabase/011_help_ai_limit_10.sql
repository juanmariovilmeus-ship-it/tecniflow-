-- Limite de 10/dia/empresa. Preserva uso existente e 6/min/usuário.
-- Aplicar após 009 e 010. Reaplicação segura; não zera contadores.
BEGIN;
CREATE OR REPLACE FUNCTION public.tf_reserve_help_ai_quota()
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE
  v_uid uuid := (SELECT auth.uid());
  v_company varchar(36);
  v_now timestamptz := now();
  v_start timestamptz;
  v_reset timestamptz;
  v_daily integer;
  v_minute integer;
  v_first timestamptz;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Acesso não autorizado.' USING ERRCODE='42501'; END IF;
  v_company := tecniflow.current_company_id();
  IF v_company IS NULL THEN RAISE EXCEPTION 'Empresa não vinculada.' USING ERRCODE='42501'; END IF;
  -- Uma trava compartilhada por todas as chamadas desta empresa protege a contagem e a reserva.
  PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(v_company,492817294));
  v_start := (((v_now AT TIME ZONE 'America/Sao_Paulo')::date)::timestamp) AT TIME ZONE 'America/Sao_Paulo';
  v_reset := ((((v_now AT TIME ZONE 'America/Sao_Paulo')::date+1)::timestamp)) AT TIME ZONE 'America/Sao_Paulo';
  DELETE FROM tecniflow.help_ai_quota_usage WHERE company_id=v_company AND created_at<v_now-interval '30 days';
  SELECT count(*)::integer INTO v_daily FROM tecniflow.help_ai_quota_usage WHERE company_id=v_company AND created_at>=v_start;
  IF v_daily>=10 THEN
    RETURN jsonb_build_object('allowed',false,'reason','quota_exceeded','used',v_daily,'limit',10,'remaining',0,'reset_at',v_reset);
  END IF;
  SELECT count(*)::integer,min(created_at) INTO v_minute,v_first FROM tecniflow.help_ai_quota_usage
    WHERE user_id=v_uid::text AND created_at>v_now-interval '60 seconds';
  IF v_minute>=6 THEN
    RETURN jsonb_build_object('allowed',false,'reason','rate_limit','used',v_daily,'limit',10,
      'remaining',greatest(0,10-v_daily),'reset_at',v_reset,
      'retry_after_seconds',greatest(1,ceil(extract(epoch FROM(v_first+interval '60 seconds'-v_now)))::integer));
  END IF;
  INSERT INTO tecniflow.help_ai_quota_usage(company_id,user_id,created_at) VALUES(v_company,v_uid::text,v_now);
  RETURN jsonb_build_object('allowed',true,'used',v_daily+1,'limit',10,'remaining',9-v_daily,
    'reset_at',v_reset,'remaining_minute',5-v_minute);
END;
$$;
CREATE OR REPLACE FUNCTION public.tf_get_help_ai_quota_status()
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path='' AS $$
DECLARE
  v_uid uuid := (SELECT auth.uid());
  v_company varchar(36);
  v_start timestamptz;
  v_reset timestamptz;
  v_daily integer;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Acesso não autorizado.' USING ERRCODE='42501'; END IF;
  v_company:=tecniflow.current_company_id();
  IF v_company IS NULL THEN RAISE EXCEPTION 'Empresa não vinculada.' USING ERRCODE='42501'; END IF;
  v_start:=(((now() AT TIME ZONE 'America/Sao_Paulo')::date)::timestamp) AT TIME ZONE 'America/Sao_Paulo';
  v_reset:=((((now() AT TIME ZONE 'America/Sao_Paulo')::date+1)::timestamp)) AT TIME ZONE 'America/Sao_Paulo';
  SELECT count(*)::integer INTO v_daily FROM tecniflow.help_ai_quota_usage WHERE company_id=v_company AND created_at>=v_start;
  RETURN jsonb_build_object('used',v_daily,'limit',10,'remaining',greatest(0,10-v_daily),'allowed',v_daily<10,'reset_at',v_reset);
END;
$$;
REVOKE ALL ON FUNCTION public.tf_reserve_help_ai_quota() FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_reserve_help_ai_quota() TO authenticated;
REVOKE ALL ON FUNCTION public.tf_get_help_ai_quota_status() FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_get_help_ai_quota_status() TO authenticated;
COMMIT;
