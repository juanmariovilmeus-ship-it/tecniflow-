-- ============================================================================
-- TECNIFLOW - MIGRAÇÃO 008: INTEGRAÇÃO KIWIFY MONETIZAÇÃO V1
-- ============================================================================
-- Aplicação: Controle de Gastos (Supabase / PostgreSQL)
-- Modo: Incremental, idempotente, transacional e com fail-closed estrito.
--
-- Recursos implementados:
-- 1. Tabela de intents de checkout com geração criptográfica no servidor (billing_intents)
-- 2. Tabela permanente de assinaturas Kiwify por empresa (company_kiwify_subscriptions)
-- 3. Índices únicos e restrições nas tabelas existentes (company_subscriptions, billing_payments, billing_events)
-- 4. RPC pública tf_create_billing_intent gerando token seguro no banco com TTL de 24h
-- 5. Função interna segura tecniflow.process_kiwify_payment com:
--    - Validação prévia a qualquer consumo de intent
--    - Suporte a tombstones terminais (reembolso/chargeback antes de aprovação)
--    - Bloqueio estrito de reativação por aprovação tardia
--    - Isolamento de histórico multi-assinaturas
--    - Datas de ciclo válidas, até 35 dias e com vencimento original preservado em atraso
--    - Zero vazamento de identificadores opacos em logs/erros
-- 6. Bridge pública public.tf_process_kiwify_payment restrita exclusivamente a service_role
-- ============================================================================

BEGIN;

DO $preflight$
BEGIN
  IF to_regclass('tecniflow.companies') IS NULL
     OR to_regclass('tecniflow.company_subscriptions') IS NULL
     OR to_regclass('tecniflow.billing_payments') IS NULL
     OR to_regclass('tecniflow.billing_events') IS NULL THEN
    RAISE EXCEPTION 'Aplique e revise as migrações anteriores do TecniFlow antes da 008.';
  END IF;
END;
$preflight$;

-- 1. TABELA PRIVADA DE INTENTS DE CHECKOUT (tecniflow.billing_intents)
CREATE TABLE IF NOT EXISTS tecniflow.billing_intents (
  id VARCHAR(64) PRIMARY KEY, -- Token opaco de 64 hex chars, com 244 bits aleatórios em dois UUIDs v4
  company_id VARCHAR(36) NOT NULL REFERENCES tecniflow.companies(id) ON DELETE CASCADE,
  provider VARCHAR(20) NOT NULL DEFAULT 'kiwify',
  product_id VARCHAR(100) NOT NULL,
  plan_id VARCHAR(100),
  status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'consumed', 'expired', 'canceled')),
  consumed_by_order_id VARCHAR(100),
  consumed_by_subscription_id VARCHAR(100),
  consumed_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_billing_intents_company_status 
  ON tecniflow.billing_intents(company_id, status);

CREATE INDEX IF NOT EXISTS idx_billing_intents_order 
  ON tecniflow.billing_intents(consumed_by_order_id) 
  WHERE consumed_by_order_id IS NOT NULL;

-- 2. TABELA PERMANENTE DE ASSINATURAS KIWIFY (tecniflow.company_kiwify_subscriptions)
-- Garante vínculo perpétuo e histórico por subscription_id sem sobrescrever assinaturas anteriores
CREATE TABLE IF NOT EXISTS tecniflow.company_kiwify_subscriptions (
  subscription_id VARCHAR(100) PRIMARY KEY,
  company_id VARCHAR(36) NOT NULL REFERENCES tecniflow.companies(id) ON DELETE CASCADE,
  status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'canceled', 'late', 'ended')),
  cancel_at_period_end BOOLEAN NOT NULL DEFAULT false,
  plan_id VARCHAR(100),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_company_kiwify_subs_comp 
  ON tecniflow.company_kiwify_subscriptions(company_id, created_at DESC);

ALTER TABLE tecniflow.company_kiwify_subscriptions
  ADD COLUMN IF NOT EXISTS product_id VARCHAR(100);

-- 3. ADICIONAR COLUNAS KIWIFY EM TABELAS EXISTENTES DE FORMA IDEMPOTENTE
-- A. Em tecniflow.company_subscriptions
DO $alter_subs$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_schema = 'tecniflow' AND table_name = 'company_subscriptions' AND column_name = 'kiwify_subscription_id'
  ) THEN
    ALTER TABLE tecniflow.company_subscriptions ADD COLUMN kiwify_subscription_id VARCHAR(100);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_schema = 'tecniflow' AND table_name = 'company_subscriptions' AND column_name = 'kiwify_order_id'
  ) THEN
    ALTER TABLE tecniflow.company_subscriptions ADD COLUMN kiwify_order_id VARCHAR(100);
  END IF;
END;
$alter_subs$;

CREATE UNIQUE INDEX IF NOT EXISTS idx_company_subscriptions_kiwify_sub 
  ON tecniflow.company_subscriptions(kiwify_subscription_id) 
  WHERE kiwify_subscription_id IS NOT NULL;

-- B. Em tecniflow.billing_payments
DO $alter_payments$
BEGIN
  ALTER TABLE tecniflow.billing_payments ALTER COLUMN mp_payment_id DROP NOT NULL;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_schema = 'tecniflow' AND table_name = 'billing_payments' AND column_name = 'kiwify_order_id'
  ) THEN
    ALTER TABLE tecniflow.billing_payments ADD COLUMN kiwify_order_id VARCHAR(100);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_schema = 'tecniflow' AND table_name = 'billing_payments' AND column_name = 'kiwify_subscription_id'
  ) THEN
    ALTER TABLE tecniflow.billing_payments ADD COLUMN kiwify_subscription_id VARCHAR(100);
  END IF;
END;
$alter_payments$;

CREATE UNIQUE INDEX IF NOT EXISTS idx_billing_payments_kiwify_order 
  ON tecniflow.billing_payments(kiwify_order_id) 
  WHERE kiwify_order_id IS NOT NULL;

-- C. Em tecniflow.billing_events
DO $alter_events$
BEGIN
  ALTER TABLE tecniflow.billing_events ALTER COLUMN mp_event_id DROP NOT NULL;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_schema = 'tecniflow' AND table_name = 'billing_events' AND column_name = 'kiwify_event_id'
  ) THEN
    ALTER TABLE tecniflow.billing_events ADD COLUMN kiwify_event_id VARCHAR(100);
  END IF;
END;
$alter_events$;

CREATE UNIQUE INDEX IF NOT EXISTS idx_billing_events_kiwify_event 
  ON tecniflow.billing_events(kiwify_event_id) 
  WHERE kiwify_event_id IS NOT NULL;

-- 4. SEGURANÇA E RLS: NENHUM ACESSO DIRETO PARA anon OU authenticated
ALTER TABLE tecniflow.billing_intents ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE tecniflow.billing_intents FROM PUBLIC, anon, authenticated;

ALTER TABLE tecniflow.company_kiwify_subscriptions ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE tecniflow.company_kiwify_subscriptions FROM PUBLIC, anon, authenticated;

-- 5. REVOGAÇÃO DE OVERLOADS ANTERIORES E CRIAÇÃO DA RPC SEGURA
-- Revoga overload antigo que aceitava token e expires_at definidos pelo cliente
DROP FUNCTION IF EXISTS public.tf_create_billing_intent(VARCHAR, VARCHAR, VARCHAR, TIMESTAMPTZ);
DROP FUNCTION IF EXISTS public.tf_process_kiwify_payment(VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, INTEGER, VARCHAR, VARCHAR, TIMESTAMPTZ, TIMESTAMPTZ, TIMESTAMPTZ, VARCHAR, VARCHAR);
DROP FUNCTION IF EXISTS tecniflow.process_kiwify_payment(VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, INTEGER, VARCHAR, VARCHAR, TIMESTAMPTZ, TIMESTAMPTZ, TIMESTAMPTZ, VARCHAR, VARCHAR);

-- Nova RPC: Gera o token criptográfico no servidor com TTL rígido de 24 horas
-- Impede iniciar checkout se a empresa já possuir assinatura paga vigente
CREATE OR REPLACE FUNCTION public.tf_create_billing_intent(
  p_product_id VARCHAR(100) DEFAULT NULL,
  p_plan_id VARCHAR(100) DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_uid UUID;
  v_company_id VARCHAR(36);
  v_user_role VARCHAR(20);
  v_now TIMESTAMPTZ := now();
  v_expires_at TIMESTAMPTZ := v_now + INTERVAL '24 hours';
  v_token VARCHAR(64);
  v_sub RECORD;
  v_product_id VARCHAR(100);
  v_plan_id VARCHAR(100);
BEGIN
  v_uid := (SELECT auth.uid());
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Não autenticado.';
  END IF;

  v_company_id := tecniflow.current_company_id();
  IF v_company_id IS NULL THEN
    RAISE EXCEPTION 'Acesso não autorizado ou empresa não localizada.';
  END IF;

  -- Validação estrita do papel 'owner' conforme schema real
  SELECT role INTO v_user_role
  FROM tecniflow.users
  WHERE auth_user_id = v_uid AND company_id = v_company_id
  LIMIT 1;

  IF v_user_role IS DISTINCT FROM 'owner' THEN
    RAISE EXCEPTION 'Apenas o proprietário da assistência técnica pode iniciar contratações.';
  END IF;

  -- Bloquear início de novo checkout se já possui assinatura paga ativa e vigente
  SELECT * INTO v_sub
  FROM tecniflow.company_subscriptions
  WHERE company_id = v_company_id;

  IF FOUND THEN
    IF v_sub.current_period_starts_at IS NOT NULL
       AND v_sub.current_period_starts_at <= v_now
       AND v_sub.current_period_ends_at > v_now THEN
      RAISE EXCEPTION 'Sua assinatura já está ativa e com período pago vigente.';
    END IF;
  END IF;

  -- Produto canônico TecniFlow
  v_product_id := COALESCE(NULLIF(trim(p_product_id), ''), 'fe3f16c0-d5f4-11f1-bd40-b570d8dc84fc');
  v_plan_id := NULLIF(trim(p_plan_id), '');

  IF v_product_id IS NULL THEN
    RAISE EXCEPTION 'Produto de cobrança deve estar configurado antes do checkout.';
  END IF;

  -- Token de 64 hex chars com 244 bits aleatórios (dois UUIDs v4) via CSPRNG
  v_token := replace(gen_random_uuid()::text || gen_random_uuid()::text, '-', '');

  INSERT INTO tecniflow.billing_intents (
    id, company_id, provider, product_id, plan_id, status, expires_at, created_at
  ) VALUES (
    v_token, v_company_id, 'kiwify', v_product_id, v_plan_id, 'pending', v_expires_at, v_now
  );

  RETURN jsonb_build_object(
    'success', true,
    'token', v_token,
    'company_id', v_company_id,
    'product_id', v_product_id,
    'plan_id', v_plan_id,
    'expires_at', v_expires_at
  );
END;
$$;

REVOKE ALL ON FUNCTION public.tf_create_billing_intent(VARCHAR, VARCHAR) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.tf_create_billing_intent(VARCHAR, VARCHAR) TO authenticated;

-- 6. FUNÇÃO INTERNA SEGURA DE PROCESSAMENTO DE WEBHOOK KIWIFY
CREATE OR REPLACE FUNCTION tecniflow.process_kiwify_payment(
  p_event_type VARCHAR(50),
  p_order_id VARCHAR(100),
  p_subscription_id VARCHAR(100),
  p_order_status VARCHAR(50),
  p_product_id VARCHAR(100),
  p_plan_id VARCHAR(100),
  p_amount_cents INTEGER,
  p_currency VARCHAR(3),
  p_sck VARCHAR(100),
  p_access_until TIMESTAMPTZ,
  p_next_payment TIMESTAMPTZ,
  p_approved_date TIMESTAMPTZ,
  p_event_id VARCHAR(100),
  p_payload_hash VARCHAR(64),
  p_order_created_at TIMESTAMPTZ DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_company_id VARCHAR(36) := NULL;
  v_intent RECORD;
  v_sub RECORD;
  v_existing_payment RECORD;
  v_now TIMESTAMPTZ := now();
  v_pay_start TIMESTAMPTZ;
  v_pay_end TIMESTAMPTZ;
  v_new_status VARCHAR(20);
  v_has_approved BOOLEAN := false;
  v_has_currently_active_coverage BOOLEAN := false;
  v_coverage_start TIMESTAMPTZ := NULL;
  v_coverage_end TIMESTAMPTZ := NULL;
  v_pay RECORD;
  v_current_sub_id VARCHAR(100);
  v_binding RECORD;
BEGIN
  -- 1. Deduplicação determinística de evento de webhook
  IF p_event_id IS NOT NULL AND trim(p_event_id) <> '' THEN
    IF EXISTS (SELECT 1 FROM tecniflow.billing_events WHERE kiwify_event_id = trim(p_event_id)) THEN
      RETURN jsonb_build_object('success', true, 'duplicate_event', true, 'message', 'Evento Kiwify já processado anteriormente.');
    END IF;
  END IF;

  -- 2. Ignorar eventos desconhecidos sem tocar em intents ou recalcular assinaturas
  IF p_event_type IS NULL OR p_event_type NOT IN (
    'order_approved', 'subscription_renewed', 'subscription_canceled', 
    'subscription_late', 'order_refunded', 'chargeback', 
    'pix_created', 'billet_created', 'order_rejected'
  ) THEN
    RETURN jsonb_build_object('success', true, 'ignored', true, 'message', 'Tipo de evento não operacional ignorado.');
  END IF;

  -- 3. Eventos informativos que não concedem nem alteram acesso:
  -- pix_created, billet_created, order_rejected, waiting_payment, refused
  -- Registram no histórico de auditoria SEM consumir intent de checkout!
  IF p_event_type IN ('pix_created', 'billet_created', 'order_rejected')
     OR (p_event_type IN ('order_approved', 'subscription_renewed')
         AND p_order_status IN ('waiting_payment', 'refused')) THEN
    
    -- Se temos subscription vinculada, tenta resolver a empresa apenas para auditar
    IF p_subscription_id IS NOT NULL AND trim(p_subscription_id) <> '' THEN
      SELECT company_id INTO v_company_id
      FROM tecniflow.company_kiwify_subscriptions
      WHERE subscription_id = trim(p_subscription_id)
      LIMIT 1;
    END IF;

    IF v_company_id IS NULL AND p_sck IS NOT NULL AND trim(p_sck) <> '' THEN
      SELECT company_id INTO v_company_id
      FROM tecniflow.billing_intents
      WHERE id = trim(p_sck);
    END IF;

    IF v_company_id IS NOT NULL THEN
      INSERT INTO tecniflow.billing_events (
        id, company_id, kiwify_event_id, event_type, payload, processed_at
      ) VALUES (
        gen_random_uuid()::text, v_company_id, p_event_id, p_event_type,
        jsonb_build_object('order_id', p_order_id, 'status', p_order_status, 'hash', p_payload_hash),
        v_now
      ) ON CONFLICT (kiwify_event_id) WHERE kiwify_event_id IS NOT NULL DO NOTHING;
    END IF;

    RETURN jsonb_build_object('success', true, 'granted', false, 'message', 'Evento informativo registrado sem alteração de acesso.');
  END IF;

  -- 4. Validação Rigorosa de Pagamento Aprovado / Renovação (GRANT)
  IF p_event_type IN ('order_approved', 'subscription_renewed') AND p_order_status = 'paid' THEN
    IF p_amount_cents IS DISTINCT FROM 4990 OR p_currency IS DISTINCT FROM 'BRL' THEN
      RAISE EXCEPTION 'Valor (% centavos) ou moeda (%) Kiwify diverge do canônico (4990 BRL).', p_amount_cents, p_currency
        USING ERRCODE = 'P0005';
    END IF;

    IF NULLIF(trim(p_plan_id), '') IS NULL OR NULLIF(trim(p_product_id), '') IS NULL THEN
      RAISE EXCEPTION 'Produto e plano assinados são obrigatórios no pagamento.' USING ERRCODE = 'P0005';
    END IF;

    IF p_subscription_id IS NULL OR trim(p_subscription_id) = '' THEN
      RAISE EXCEPTION 'Identificador de assinatura Kiwify obrigatório para concessão de acesso.'
        USING ERRCODE = 'P0005';
    END IF;

    IF p_approved_date IS NULL THEN
      RAISE EXCEPTION 'Data de aprovação do pagamento Kiwify é obrigatória.'
        USING ERRCODE = 'P0005';
    END IF;

    v_pay_start := p_approved_date;
    v_pay_end := COALESCE(p_next_payment, p_access_until);

    IF p_order_created_at IS NOT NULL AND p_order_created_at > p_approved_date + INTERVAL '1 minute' THEN
      RAISE EXCEPTION 'Criação do pedido posterior à aprovação.' USING ERRCODE = 'P0005';
    END IF;

    IF v_pay_end IS NULL OR v_pay_end <= v_pay_start THEN
      RAISE EXCEPTION 'Data de término do ciclo de cobrança Kiwify ausente ou inválida.'
        USING ERRCODE = 'P0005';
    END IF;

    -- Atraso reduz a cobertura restante; a data final continua sendo a do provedor.
    IF (v_pay_end - v_pay_start) > INTERVAL '35 days' THEN
      RAISE EXCEPTION 'Duração do ciclo Kiwify excede o limite mensal esperado de 35 dias.'
        USING ERRCODE = 'P0005';
    END IF;
  END IF;

  -- 5. Resolução Segura da Empresa
  -- A. Por vínculo permanente de assinatura Kiwify (renovações, cancelamentos, reembolsos)
  IF p_subscription_id IS NOT NULL AND trim(p_subscription_id) <> '' THEN
    SELECT company_id INTO v_company_id
    FROM tecniflow.company_kiwify_subscriptions
    WHERE subscription_id = trim(p_subscription_id)
    LIMIT 1;

    IF v_company_id IS NULL THEN
      SELECT company_id INTO v_company_id
      FROM tecniflow.company_subscriptions
      WHERE kiwify_subscription_id = trim(p_subscription_id)
      LIMIT 1;
    END IF;
  END IF;

  -- B. Por tombstone de pedido já registrado anteriormente (estorno antes de aprovação)
  IF v_company_id IS NULL AND p_order_id IS NOT NULL THEN
    SELECT company_id INTO v_company_id
    FROM tecniflow.billing_payments
    WHERE kiwify_order_id = trim(p_order_id)
    LIMIT 1;
  END IF;

  -- C. Se ainda não vinculada, resolve pelo intent de checkout (p_sck)
  IF v_company_id IS NULL THEN
    IF p_sck IS NULL OR trim(p_sck) = '' THEN
      RAISE EXCEPTION 'Identificador de rastreamento sck ausente para assinatura Kiwify não vinculada.'
        USING ERRCODE = 'P0004';
    END IF;

    SELECT * INTO v_intent
    FROM tecniflow.billing_intents
    WHERE id = trim(p_sck)
    FOR UPDATE;

    IF NOT FOUND THEN
      -- Mensagem genérica: zero exibição do token
      RAISE EXCEPTION 'Intent de checkout não encontrado.'
        USING ERRCODE = 'P0004';
    END IF;

    -- Validação de TTL do intent
    -- O pedido deve começar dentro do TTL. A compensação de boleto pode terminar depois.
    IF v_intent.expires_at <= v_now AND NOT (
      p_order_created_at IS NOT NULL
      AND p_order_created_at >= v_intent.created_at - INTERVAL '1 minute'
      AND p_order_created_at < v_intent.expires_at
      AND p_order_created_at <= v_now
    ) THEN
      UPDATE tecniflow.billing_intents SET status = 'expired' WHERE id = v_intent.id;
      RAISE EXCEPTION 'Intent de checkout Kiwify expirou.'
        USING ERRCODE = 'P0004';
    END IF;

    -- Confronto de produto e plano
    IF p_product_id IS NOT NULL AND trim(p_product_id) <> '' 
       AND v_intent.product_id IS NOT NULL AND v_intent.product_id <> trim(p_product_id) THEN
      RAISE EXCEPTION 'Produto do webhook diverge do registrado no intent.'
        USING ERRCODE = 'P0005';
    END IF;

    IF v_intent.plan_id IS NOT NULL AND p_plan_id IS NOT NULL AND trim(p_plan_id) <> '' 
       AND v_intent.plan_id <> trim(p_plan_id) THEN
      RAISE EXCEPTION 'Plano do webhook diverge do registrado no intent.'
        USING ERRCODE = 'P0005';
    END IF;

    -- Se já consumido:
    IF v_intent.status = 'consumed' THEN
      IF v_intent.consumed_by_order_id = p_order_id THEN
        -- Retry do mesmo pedido
        IF v_intent.consumed_by_subscription_id IS NOT NULL AND p_subscription_id IS NOT NULL 
           AND v_intent.consumed_by_subscription_id <> p_subscription_id THEN
          RAISE EXCEPTION 'Inconsistência de assinatura no retry do mesmo pedido.'
            USING ERRCODE = 'P0004';
        END IF;
        v_company_id := v_intent.company_id;
      ELSE
        RAISE EXCEPTION 'Intent de checkout Kiwify já foi consumido por outro pedido.'
          USING ERRCODE = 'P0004';
      END IF;
    ELSIF v_intent.status <> 'pending' THEN
      RAISE EXCEPTION 'Intent de checkout Kiwify não está em estado pendente.'
        USING ERRCODE = 'P0004';
    ELSE
      -- Intent pendente válido: vincula e consome atomicamente no GRANT
      v_company_id := v_intent.company_id;
      IF p_event_type IN ('order_approved', 'subscription_renewed') AND p_order_status = 'paid' THEN
        UPDATE tecniflow.billing_intents
        SET
          status = 'consumed',
          plan_id = COALESCE(plan_id, NULLIF(trim(p_plan_id), '')),
          consumed_by_order_id = p_order_id,
          consumed_by_subscription_id = p_subscription_id,
          consumed_at = v_now
        WHERE id = v_intent.id;
      END IF;
    END IF;
  END IF;

  IF v_company_id IS NULL THEN
    RAISE EXCEPTION 'Não foi possível associar a notificação Kiwify a nenhuma assistência técnica.'
      USING ERRCODE = 'P0004';
  END IF;

  -- 6. Lock Exclusivo na Assinatura Geral da Empresa
  SELECT * INTO v_sub
  FROM tecniflow.company_subscriptions
  WHERE company_id = v_company_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Registro de assinatura da empresa não localizado.';
  END IF;

  -- Outro worker pode ter concluído o mesmo evento enquanto este aguardava o lock.
  IF p_event_id IS NOT NULL AND EXISTS (
    SELECT 1 FROM tecniflow.billing_events WHERE kiwify_event_id = p_event_id
  ) THEN
    RETURN jsonb_build_object('success', true, 'duplicate_event', true);
  END IF;

  -- Tracking enviado junto de um vínculo conhecido também deve ser consistente.
  -- Renovações legítimas podem conservar o intent consumido mesmo após seu TTL.
  IF p_sck IS NOT NULL AND trim(p_sck) <> '' THEN
    SELECT * INTO v_intent FROM tecniflow.billing_intents WHERE id = trim(p_sck) FOR UPDATE;
    IF NOT FOUND OR v_intent.company_id IS DISTINCT FROM v_company_id THEN
      RAISE EXCEPTION 'Vínculo de checkout inconsistente.' USING ERRCODE = 'P0004';
    END IF;
    IF v_intent.product_id IS DISTINCT FROM NULLIF(trim(p_product_id), '')
       OR (p_event_type IN ('order_approved', 'subscription_renewed')
           AND v_intent.plan_id IS NOT NULL
           AND v_intent.plan_id IS DISTINCT FROM NULLIF(trim(p_plan_id), '')) THEN
      RAISE EXCEPTION 'Produto ou plano diverge do vínculo de checkout.' USING ERRCODE = 'P0005';
    END IF;
    IF v_intent.status = 'consumed' THEN
      IF v_intent.consumed_by_subscription_id IS DISTINCT FROM p_subscription_id THEN
        RAISE EXCEPTION 'Assinatura diverge do vínculo de checkout.' USING ERRCODE = 'P0004';
      END IF;
    ELSIF v_intent.status <> 'pending' OR (
      v_intent.expires_at <= v_now AND NOT (
        p_order_created_at IS NOT NULL
        AND p_order_created_at >= v_intent.created_at - INTERVAL '1 minute'
        AND p_order_created_at < v_intent.expires_at
        AND p_order_created_at <= v_now
      )
    ) THEN
      RAISE EXCEPTION 'Vínculo de checkout indisponível ou expirado.' USING ERRCODE = 'P0004';
    END IF;
  END IF;

  -- Vínculo de Assinatura Permanente
  IF p_subscription_id IS NOT NULL AND trim(p_subscription_id) <> '' THEN
    -- Impede que uma mesma assinatura pertença a outra empresa
    IF EXISTS (
      SELECT 1 FROM tecniflow.company_kiwify_subscriptions 
      WHERE subscription_id = trim(p_subscription_id) AND company_id <> v_company_id
    ) THEN
      RAISE EXCEPTION 'Assinatura Kiwify já pertence a outra assistência técnica registrada.'
        USING ERRCODE = 'P0003';
    END IF;

    INSERT INTO tecniflow.company_kiwify_subscriptions AS existing_binding (
      subscription_id, company_id, status, cancel_at_period_end, plan_id, product_id, created_at, updated_at
    ) VALUES (
      trim(p_subscription_id), v_company_id, 'active', false,
      COALESCE(NULLIF(trim(p_plan_id), ''),
        (SELECT plan_id FROM tecniflow.billing_intents WHERE id = trim(p_sck)),
        (SELECT plan_id FROM tecniflow.company_kiwify_subscriptions WHERE subscription_id = trim(p_subscription_id))
      ), NULLIF(trim(p_product_id), ''), v_now, v_now
    ) ON CONFLICT (subscription_id) DO UPDATE SET
      updated_at = v_now,
      product_id = COALESCE(existing_binding.product_id, EXCLUDED.product_id),
      plan_id = COALESCE(existing_binding.plan_id, EXCLUDED.plan_id)
    RETURNING * INTO v_binding;

    IF v_binding.company_id IS DISTINCT FROM v_company_id
       OR (p_product_id IS NOT NULL AND trim(p_product_id) <> ''
           AND v_binding.product_id IS DISTINCT FROM trim(p_product_id))
       OR (p_plan_id IS NOT NULL AND trim(p_plan_id) <> ''
           AND v_binding.plan_id IS DISTINCT FROM trim(p_plan_id)) THEN
      RAISE EXCEPTION 'Identidade da assinatura não pode ser alterada.' USING ERRCODE = 'P0003';
    END IF;
  END IF;

  -- 7. Processamento do Pedido e Pagamento
  SELECT * INTO v_existing_payment
  FROM tecniflow.billing_payments
  WHERE kiwify_order_id = p_order_id
  FOR UPDATE;

  IF FOUND AND (
    v_existing_payment.company_id IS DISTINCT FROM v_company_id
    OR (p_subscription_id IS NOT NULL AND v_existing_payment.kiwify_subscription_id IS NOT NULL
        AND v_existing_payment.kiwify_subscription_id IS DISTINCT FROM p_subscription_id)
  ) THEN
    RAISE EXCEPTION 'Identidade do pedido não pode ser alterada.' USING ERRCODE = 'P0003';
  END IF;

  -- Evento: Pagamento Aprovado / Renovado
  IF p_event_type IN ('order_approved', 'subscription_renewed') AND p_order_status = 'paid' THEN
    IF FOUND THEN
      -- Vínculo imutável com a empresa
      IF v_existing_payment.company_id <> v_company_id THEN
        RAISE EXCEPTION 'Violação de vínculo: pedido Kiwify pertence a outra empresa.'
          USING ERRCODE = 'P0003';
      END IF;

      -- Tombstone terminal: Reembolso ou chargeback já gravados impedem aprovação tardia!
      IF v_existing_payment.status IN ('refunded', 'charged_back') THEN
        RETURN jsonb_build_object('success', true, 'duplicate', true, 'tombstone_terminal', true, 'status', v_sub.status);
      END IF;

      -- Já aprovado: não altera datas nem estende período
      IF v_existing_payment.status = 'approved' THEN
        RETURN jsonb_build_object('success', true, 'duplicate', true, 'unchanged_dates', true, 'status', v_sub.status);
      END IF;

      -- Atualizar para approved
      UPDATE tecniflow.billing_payments
      SET
        status = 'approved',
        payment_date = v_pay_start,
        period_starts_at = v_pay_start,
        period_ends_at = v_pay_end,
        kiwify_subscription_id = COALESCE(p_subscription_id, kiwify_subscription_id),
        updated_at = v_now
      WHERE kiwify_order_id = p_order_id;
    ELSE
      -- Novo pagamento aprovado
      INSERT INTO tecniflow.billing_payments (
        id, company_id, kiwify_order_id, kiwify_subscription_id,
        amount_cents, currency, status, payment_date, period_starts_at, period_ends_at,
        created_at, updated_at
      ) VALUES (
        gen_random_uuid()::text, v_company_id, p_order_id, p_subscription_id,
        p_amount_cents, p_currency, 'approved', v_pay_start, v_pay_start, v_pay_end,
        v_now, v_now
      );
    END IF;

    -- Atualiza assinatura atual da empresa
    -- Um pagamento histórico não substitui a assinatura atual ainda vigente.
    IF v_sub.kiwify_subscription_id IS NULL
       OR v_sub.kiwify_subscription_id = p_subscription_id
       OR (
         NOT (COALESCE(v_sub.current_period_starts_at <= v_now
                       AND v_now < v_sub.current_period_ends_at, false))
         AND v_pay_start >= COALESCE((
           SELECT max(payment_date) FROM tecniflow.billing_payments
           WHERE company_id = v_company_id AND status = 'approved'
             AND kiwify_subscription_id = v_sub.kiwify_subscription_id
         ), '-infinity'::timestamptz)
       ) THEN
      UPDATE tecniflow.company_subscriptions
      SET kiwify_subscription_id = p_subscription_id,
          kiwify_order_id = p_order_id,
          cancel_at_period_end = COALESCE(v_binding.cancel_at_period_end, false),
          updated_at = v_now
      WHERE company_id = v_company_id;
    END IF;

  -- Eventos Terminais: Reembolso ou Chargeback
  ELSIF p_event_type IN ('order_refunded', 'chargeback') OR p_order_status IN ('refunded', 'chargedback') THEN
    IF FOUND THEN
      IF v_existing_payment.company_id <> v_company_id THEN
        RAISE EXCEPTION 'Violação de vínculo: pedido pertence a outra empresa.' USING ERRCODE = 'P0003';
      END IF;

      UPDATE tecniflow.billing_payments
      SET
        status = CASE WHEN p_event_type = 'chargeback' OR p_order_status = 'chargedback' THEN 'charged_back' ELSE 'refunded' END,
        updated_at = v_now
      WHERE kiwify_order_id = p_order_id;
    ELSE
      -- Gravação de TOMBSTONE terminal se o estorno chegar antes da aprovação!
      INSERT INTO tecniflow.billing_payments (
        id, company_id, kiwify_order_id, kiwify_subscription_id,
        amount_cents, currency, status, payment_date, period_starts_at, period_ends_at,
        created_at, updated_at
      ) VALUES (
        gen_random_uuid()::text, v_company_id, p_order_id, p_subscription_id,
        4990, 'BRL', -- metadados do plano canônico; tombstone nunca concede cobertura
        CASE WHEN p_event_type = 'chargeback' OR p_order_status = 'chargedback' THEN 'charged_back' ELSE 'refunded' END,
        v_now, v_now, v_now,
        v_now, v_now
      );
    END IF;

    -- Na Kiwify, estorno/chargeback também encerra renovações da assinatura.
    -- O período de outros pagamentos aprovados continua sendo recalculado abaixo.
    IF p_subscription_id IS NOT NULL THEN
      UPDATE tecniflow.company_kiwify_subscriptions
      SET status = 'canceled', cancel_at_period_end = true, updated_at = v_now
      WHERE subscription_id = p_subscription_id AND company_id = v_company_id;
      IF v_sub.kiwify_subscription_id = p_subscription_id THEN
        UPDATE tecniflow.company_subscriptions
        SET cancel_at_period_end = true, updated_at = v_now
        WHERE company_id = v_company_id;
      END IF;
    END IF;

  -- Evento: Cancelamento da Assinatura (Paid-through)
  ELSIF p_event_type = 'subscription_canceled' THEN
    IF p_subscription_id IS NOT NULL THEN
      UPDATE tecniflow.company_kiwify_subscriptions
      SET
        cancel_at_period_end = true,
        status = 'canceled',
        updated_at = v_now
      WHERE subscription_id = p_subscription_id AND company_id = v_company_id;

      -- Só afeta cancel_at_period_end da empresa se for a assinatura ATUAL dela
      IF v_sub.kiwify_subscription_id = p_subscription_id THEN
        UPDATE tecniflow.company_subscriptions
        SET
          cancel_at_period_end = true,
          updated_at = v_now
        WHERE company_id = v_company_id;
      END IF;
    END IF;

  -- Evento: Atraso (subscription_late)
  ELSIF p_event_type = 'subscription_late' THEN
    IF p_subscription_id IS NOT NULL THEN
      UPDATE tecniflow.company_kiwify_subscriptions
      SET
        status = 'late',
        updated_at = v_now
      WHERE subscription_id = p_subscription_id AND company_id = v_company_id;
    END IF;
  END IF;

  -- 8. Recalcular Cobertura Contínua dos Pagamentos Aprovados
  -- Avalia todos os pagamentos aprovados da empresa, preservando o período pago mesmo em cancelamentos
  FOR v_pay IN (
    SELECT payment_date, period_starts_at, period_ends_at
    FROM tecniflow.billing_payments
    WHERE company_id = v_company_id
      AND status = 'approved'
    ORDER BY payment_date ASC
  ) LOOP
    IF v_has_currently_active_coverage AND v_pay.payment_date > v_coverage_end THEN
      EXIT;
    END IF;

    v_has_approved := true;
    IF v_coverage_start IS NULL THEN
      v_coverage_start := v_pay.period_starts_at;
      v_coverage_end := v_pay.period_ends_at;
    ELSE
      IF v_pay.period_starts_at <= v_coverage_end OR v_pay.payment_date <= v_coverage_end THEN
        -- Extensão contínua
        v_coverage_end := GREATEST(v_coverage_end, v_pay.period_ends_at);
      ELSE
        -- Hiato: inicia novo bloco
        v_coverage_start := v_pay.period_starts_at;
        v_coverage_end := v_pay.period_ends_at;
      END IF;
    END IF;

    IF v_coverage_start <= v_now AND v_now < v_coverage_end THEN
      v_has_currently_active_coverage := true;
    END IF;
  END LOOP;

  -- 9. Determinar Status Efetivo da Assinatura
  SELECT * INTO v_sub FROM tecniflow.company_subscriptions WHERE company_id = v_company_id;

  IF v_has_currently_active_coverage THEN
    v_new_status := CASE WHEN v_sub.cancel_at_period_end THEN 'canceled' ELSE 'active' END;
  ELSIF v_has_approved AND v_now < v_coverage_end THEN
    v_new_status := CASE WHEN v_now < v_sub.trial_ends_at THEN 'trial' ELSE 'expired' END;
  ELSE
    v_coverage_start := NULL;
    v_coverage_end := NULL;
    IF v_now < v_sub.trial_ends_at THEN
      v_new_status := 'trial';
    ELSE
      v_new_status := 'expired';
    END IF;
  END IF;

  UPDATE tecniflow.company_subscriptions
  SET
    status = v_new_status,
    current_period_starts_at = v_coverage_start,
    current_period_ends_at = v_coverage_end,
    updated_at = v_now
  WHERE company_id = v_company_id;

  -- 10. Auditoria do Evento
  INSERT INTO tecniflow.billing_events (
    id, company_id, kiwify_event_id, event_type, payload, processed_at
  ) VALUES (
    gen_random_uuid()::text, v_company_id, p_event_id, p_event_type,
    jsonb_build_object(
      'order_id', p_order_id,
      'subscription_id', p_subscription_id,
      'status', p_order_status,
      'amount_cents', p_amount_cents,
      'hash', p_payload_hash
    ),
    v_now
  ) ON CONFLICT (kiwify_event_id) WHERE kiwify_event_id IS NOT NULL DO NOTHING;

  RETURN jsonb_build_object(
    'success', true,
    'company_id', v_company_id,
    'status', v_new_status,
    'is_active', tecniflow.check_subscription_active(v_company_id),
    'current_period_ends_at', v_coverage_end
  );
END;
$$;

REVOKE ALL ON FUNCTION tecniflow.process_kiwify_payment(VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, INTEGER, VARCHAR, VARCHAR, TIMESTAMPTZ, TIMESTAMPTZ, TIMESTAMPTZ, VARCHAR, VARCHAR, TIMESTAMPTZ) FROM PUBLIC, anon, authenticated;

-- 7. BRIDGE PÚBLICA PARA SERVICE_ROLE (SUPABASE EDGE FUNCTION)
-- Validação do papel real do chamador (auth.role / session_user)
CREATE OR REPLACE FUNCTION public.tf_process_kiwify_payment(
  p_event_type VARCHAR(50),
  p_order_id VARCHAR(100),
  p_subscription_id VARCHAR(100),
  p_order_status VARCHAR(50),
  p_product_id VARCHAR(100),
  p_plan_id VARCHAR(100),
  p_amount_cents INTEGER,
  p_currency VARCHAR(3),
  p_sck VARCHAR(100),
  p_access_until TIMESTAMPTZ,
  p_next_payment TIMESTAMPTZ,
  p_approved_date TIMESTAMPTZ,
  p_event_id VARCHAR(100),
  p_payload_hash VARCHAR(64),
  p_order_created_at TIMESTAMPTZ DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_caller_role text;
BEGIN
  v_caller_role := COALESCE(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    NULLIF(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role',
    session_user
  );

  IF v_caller_role NOT IN ('service_role', 'postgres') THEN
    RAISE EXCEPTION 'Acesso negado: função reservada exclusivamente para service_role.'
      USING ERRCODE = '42501';
  END IF;

  RETURN tecniflow.process_kiwify_payment(
    p_event_type,
    p_order_id,
    p_subscription_id,
    p_order_status,
    p_product_id,
    p_plan_id,
    p_amount_cents,
    p_currency,
    p_sck,
    p_access_until,
    p_next_payment,
    p_approved_date,
    p_event_id,
    p_payload_hash,
    p_order_created_at
  );
END;
$$;

REVOKE ALL ON FUNCTION public.tf_process_kiwify_payment(VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, INTEGER, VARCHAR, VARCHAR, TIMESTAMPTZ, TIMESTAMPTZ, TIMESTAMPTZ, VARCHAR, VARCHAR, TIMESTAMPTZ) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.tf_process_kiwify_payment(VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, INTEGER, VARCHAR, VARCHAR, TIMESTAMPTZ, TIMESTAMPTZ, TIMESTAMPTZ, VARCHAR, VARCHAR, TIMESTAMPTZ) TO service_role;

COMMIT;

