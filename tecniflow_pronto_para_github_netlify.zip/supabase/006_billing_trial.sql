-- ============================================================================
-- TECNIFLOW - MIGRAÇÃO INCREMENTAL 006: MONETIZAÇÃO, TRIAL 7 DIAS E MERCADO PAGO
-- Schema Privado: tecniflow
-- RPC Pública Leitura: public.tf_get_billing_status() (STABLE, STRICTLY READ-ONLY)
-- Atualização: public.tf_sync_current_user() (preserva exatamente a extração da 005)
-- Bridge Segura: public.tf_process_billing_payment() (SECURITY DEFINER, ONLY service_role)
-- Proteção Dinâmica: injeção de tecniflow.assert_active_subscription() nas 21 RPCs
-- Idempotente, transacional, sem alteração em public.profiles ou contratos da 003
-- ============================================================================

BEGIN;

-- 1. TABELA PRIVADA DE ASSINATURAS POR EMPRESA
CREATE TABLE IF NOT EXISTS tecniflow.company_subscriptions (
  company_id VARCHAR(36) PRIMARY KEY REFERENCES tecniflow.companies(id) ON DELETE CASCADE,
  status VARCHAR(20) NOT NULL DEFAULT 'trial' CHECK (status IN ('trial', 'active', 'past_due', 'canceled', 'expired')),
  plan_code VARCHAR(50) NOT NULL DEFAULT 'TECNIFLOW-MENSAL-4990' CHECK (plan_code = 'TECNIFLOW-MENSAL-4990'),
  amount_cents INTEGER NOT NULL DEFAULT 4990 CHECK (amount_cents = 4990),
  currency VARCHAR(3) NOT NULL DEFAULT 'BRL' CHECK (currency = 'BRL'),
  billing_cycle VARCHAR(20) NOT NULL DEFAULT 'monthly' CHECK (billing_cycle = 'monthly'),
  trial_starts_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  trial_ends_at TIMESTAMPTZ NOT NULL DEFAULT (now() + INTERVAL '7 days'),
  current_period_starts_at TIMESTAMPTZ,
  current_period_ends_at TIMESTAMPTZ,
  cancel_at_period_end BOOLEAN NOT NULL DEFAULT false,
  mp_preapproval_id VARCHAR(100),
  mp_payer_id VARCHAR(100),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_subscriptions_preapproval 
  ON tecniflow.company_subscriptions(mp_preapproval_id) 
  WHERE mp_preapproval_id IS NOT NULL;

-- 2. TABELA PRIVADA DE PAGAMENTOS
CREATE TABLE IF NOT EXISTS tecniflow.billing_payments (
  id VARCHAR(36) PRIMARY KEY,
  company_id VARCHAR(36) NOT NULL REFERENCES tecniflow.companies(id) ON DELETE CASCADE,
  mp_payment_id VARCHAR(100) NOT NULL UNIQUE,
  mp_preapproval_id VARCHAR(100),
  amount_cents INTEGER NOT NULL CHECK (amount_cents = 4990),
  currency VARCHAR(3) NOT NULL DEFAULT 'BRL' CHECK (currency = 'BRL'),
  status VARCHAR(20) NOT NULL CHECK (status IN ('approved', 'pending', 'rejected', 'refunded', 'charged_back')),
  payment_date TIMESTAMPTZ NOT NULL,
  period_starts_at TIMESTAMPTZ,
  period_ends_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_billing_payments_company 
  ON tecniflow.billing_payments(company_id, payment_date DESC);

-- 3. TABELA PRIVADA DE EVENTOS E AUDITORIA DE WEBHOOKS
CREATE TABLE IF NOT EXISTS tecniflow.billing_events (
  id VARCHAR(36) PRIMARY KEY,
  company_id VARCHAR(36) REFERENCES tecniflow.companies(id) ON DELETE CASCADE,
  mp_event_id VARCHAR(100) UNIQUE,
  event_type VARCHAR(100) NOT NULL,
  payload JSONB NOT NULL,
  processed_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 4. SEGURANÇA E RLS: ZERO ACESSO DIRETO PARA anon E authenticated
ALTER TABLE tecniflow.company_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE tecniflow.billing_payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE tecniflow.billing_events ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON TABLE tecniflow.company_subscriptions FROM PUBLIC, anon, authenticated;
REVOKE ALL ON TABLE tecniflow.billing_payments FROM PUBLIC, anon, authenticated;
REVOKE ALL ON TABLE tecniflow.billing_events FROM PUBLIC, anon, authenticated;

-- 5. BACKFILL IDEMPOTENTE: INICIAR 7 DIAS A PARTIR DE now() DA MIGRAÇÃO PARA EMPRESAS ANTIGAS
-- Como solicitado: empresas antigas ainda não tiveram trial; conceder 7 dias a partir de now() da aplicação
-- Reexecuções não reiniciam graças a ON CONFLICT DO NOTHING
INSERT INTO tecniflow.company_subscriptions (
  company_id, status, plan_code, amount_cents, currency, billing_cycle,
  trial_starts_at, trial_ends_at, created_at, updated_at
)
SELECT
  c.id, 'trial', 'TECNIFLOW-MENSAL-4990', 4990, 'BRL', 'monthly',
  now(), now() + INTERVAL '7 days', now(), now()
FROM tecniflow.companies c
ON CONFLICT (company_id) DO NOTHING;

-- 6. FUNÇÃO INTERNA DE VERIFICAÇÃO DE ASSINATURA ATIVA
-- Comparação estrita de início e fim: v_now < trial_ends_at ou (starts <= v_now < ends)
CREATE OR REPLACE FUNCTION tecniflow.check_subscription_active(p_company_id VARCHAR(36))
RETURNS boolean
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_sub RECORD;
  v_now TIMESTAMPTZ := now();
BEGIN
  IF p_company_id IS NULL THEN
    RETURN false;
  END IF;

  SELECT * INTO v_sub
  FROM tecniflow.company_subscriptions
  WHERE company_id = p_company_id;

  IF NOT FOUND THEN
    RETURN false;
  END IF;

  -- 1. Período de teste gratuito (7 dias corridos controlados pelo relógio do servidor)
  IF v_sub.status = 'trial' THEN
    RETURN v_now < v_sub.trial_ends_at;
  END IF;

  -- 2. Assinatura ativa: válido se o período pago já iniciou e ainda não expirou
  IF v_sub.status = 'active' THEN
    RETURN v_sub.current_period_starts_at IS NOT NULL 
       AND v_sub.current_period_ends_at IS NOT NULL 
       AND v_sub.current_period_starts_at <= v_now 
       AND v_now < v_sub.current_period_ends_at;
  END IF;

  -- 3. Assinatura cancelada: acesso mantido até o término do ciclo já pago (paid-through)
  IF v_sub.status = 'canceled' THEN
    RETURN v_sub.current_period_starts_at IS NOT NULL 
       AND v_sub.current_period_ends_at IS NOT NULL 
       AND v_sub.current_period_starts_at <= v_now 
       AND v_now < v_sub.current_period_ends_at;
  END IF;

  -- 4. Status past_due ou expired bloqueiam operações
  RETURN false;
END;
$$;

-- 7. FUNÇÃO INTERNA ASSERT: BLOQUEIA OPERAÇÕES SE EXPIRADO
CREATE OR REPLACE FUNCTION tecniflow.assert_active_subscription()
RETURNS VARCHAR(36)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_company_id VARCHAR(36);
  v_active boolean;
BEGIN
  v_company_id := tecniflow.current_company_id();
  IF v_company_id IS NULL THEN
    RAISE EXCEPTION 'Acesso não autorizado.';
  END IF;

  v_active := tecniflow.check_subscription_active(v_company_id);
  IF NOT v_active THEN
    RAISE EXCEPTION 'ASSINATURA_EXPIRADA: O período de acesso do TecniFlow expirou. Regularize sua assinatura na aba Minha Assinatura para continuar utilizando o sistema.'
      USING ERRCODE = 'P0002';
  END IF;

  RETURN v_company_id;
END;
$$;

REVOKE ALL ON FUNCTION tecniflow.check_subscription_active(VARCHAR) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION tecniflow.assert_active_subscription() FROM PUBLIC, anon, authenticated;

-- 8. RPC PÚBLICA DE LEITURA ESTRITA: public.tf_get_billing_status
-- STABLE, 100% READ-ONLY (SEM INSERT), comparações estritas < end
CREATE OR REPLACE FUNCTION public.tf_get_billing_status()
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_company_id VARCHAR(36);
  v_uid UUID;
  v_sub RECORD;
  v_user_role VARCHAR(20);
  v_is_active boolean;
  v_effective_status VARCHAR(20);
  v_days_left integer := 0;
  v_payments JSONB := '[]'::jsonb;
  v_now TIMESTAMPTZ := now();
BEGIN
  v_uid := (SELECT auth.uid());
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Não autenticado.';
  END IF;

  v_company_id := tecniflow.current_company_id();
  IF v_company_id IS NULL THEN
    RAISE EXCEPTION 'Acesso não autorizado.';
  END IF;

  SELECT role INTO v_user_role
  FROM tecniflow.users
  WHERE auth_user_id = v_uid
  LIMIT 1;

  SELECT * INTO v_sub
  FROM tecniflow.company_subscriptions
  WHERE company_id = v_company_id;

  IF NOT FOUND THEN
    -- Leitura pura: retorna status sem criar/modificar dados
    RETURN jsonb_build_object(
      'company_id', v_company_id,
      'status', 'expired',
      'plan_code', 'TECNIFLOW-MENSAL-4990',
      'plan_name', 'TecniFlow Mensal',
      'amount_cents', 4990,
      'currency', 'BRL',
      'billing_cycle', 'monthly',
      'trial_starts_at', v_now,
      'trial_ends_at', v_now,
      'trial_days_remaining', 0,
      'current_period_starts_at', NULL,
      'current_period_ends_at', NULL,
      'cancel_at_period_end', false,
      'is_active', false,
      'can_operate', false,
      'user_role', COALESCE(v_user_role, 'collaborator'),
      'is_owner', COALESCE(v_user_role = 'owner', false),
      'payments', '[]'::jsonb,
      'server_time', v_now
    );
  END IF;

  v_is_active := tecniflow.check_subscription_active(v_company_id);

  IF v_sub.status = 'trial' THEN
    IF v_now < v_sub.trial_ends_at THEN
      v_effective_status := 'trial';
      v_days_left := GREATEST(0, CEIL(EXTRACT(EPOCH FROM (v_sub.trial_ends_at - v_now)) / 86400.0)::integer);
    ELSE
      v_effective_status := 'expired';
      v_days_left := 0;
    END IF;
  ELSIF v_sub.status = 'active' THEN
    IF v_sub.current_period_starts_at IS NOT NULL AND v_sub.current_period_ends_at IS NOT NULL 
       AND v_sub.current_period_starts_at <= v_now AND v_now < v_sub.current_period_ends_at THEN
      v_effective_status := 'active';
    ELSE
      v_effective_status := 'expired';
    END IF;
  ELSIF v_sub.status = 'canceled' THEN
    IF v_sub.current_period_starts_at IS NOT NULL AND v_sub.current_period_ends_at IS NOT NULL 
       AND v_sub.current_period_starts_at <= v_now AND v_now < v_sub.current_period_ends_at THEN
      v_effective_status := 'canceled';
    ELSE
      v_effective_status := 'expired';
    END IF;
  ELSE
    v_effective_status := v_sub.status;
  END IF;

  SELECT COALESCE(
    jsonb_agg(
      jsonb_build_object(
        'id', p.id,
        'amount_cents', p.amount_cents,
        'currency', p.currency,
        'status', p.status,
        'payment_date', p.payment_date,
        'period_starts_at', p.period_starts_at,
        'period_ends_at', p.period_ends_at
      ) ORDER BY p.payment_date DESC
    ),
    '[]'::jsonb
  ) INTO v_payments
  FROM tecniflow.billing_payments p
  WHERE p.company_id = v_company_id;

  RETURN jsonb_build_object(
    'company_id', v_company_id,
    'status', v_effective_status,
    'plan_code', v_sub.plan_code,
    'plan_name', 'TecniFlow Mensal',
    'amount_cents', v_sub.amount_cents,
    'currency', v_sub.currency,
    'billing_cycle', v_sub.billing_cycle,
    'trial_starts_at', v_sub.trial_starts_at,
    'trial_ends_at', v_sub.trial_ends_at,
    'trial_days_remaining', v_days_left,
    'current_period_starts_at', v_sub.current_period_starts_at,
    'current_period_ends_at', v_sub.current_period_ends_at,
    'cancel_at_period_end', v_sub.cancel_at_period_end,
    'is_active', v_is_active,
    'can_operate', v_is_active,
    'user_role', COALESCE(v_user_role, 'collaborator'),
    'is_owner', COALESCE(v_user_role = 'owner', false),
    'payments', v_payments,
    'server_time', v_now
  );
END;
$$;

-- 9. ATUALIZAR public.tf_sync_current_user PRESERVANDO EXATAMENTE A 005
-- Extração exata: company_name, owner_name, company_document, company_phone, company_whatsapp, company_address
-- password_hash='', warranty_terms='', receipt_notes='', email normalizado com limite 100
CREATE OR REPLACE FUNCTION public.tf_sync_current_user()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_uid UUID;
  v_user RECORD;
  v_company RECORD;
  v_sub RECORD;
  v_auth_email text;
  v_raw_meta jsonb;
  v_company_id VARCHAR(36);
  v_user_id VARCHAR(36);
  v_company_name VARCHAR(100);
  v_company_doc VARCHAR(50);
  v_company_phone VARCHAR(30);
  v_company_whatsapp VARCHAR(30);
  v_company_address VARCHAR(255);
  v_owner_name VARCHAR(100);
  v_existing_conflict VARCHAR(36);
  v_is_active boolean;
  v_days_left integer := 0;
  v_effective_status VARCHAR(20);
  v_now TIMESTAMPTZ := now();
BEGIN
  v_uid := (SELECT auth.uid());
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Não autenticado. Sessão inválida ou expirada no Supabase Auth.';
  END IF;

  -- Lock transacional no nível de sessão do auth.uid() para evitar corridas concorrentes
  PERFORM pg_advisory_xact_lock(hashtext(v_uid::text));

  -- 1. Verifica se já existe vínculo estabelecido para este auth.uid()
  SELECT u.id, u.company_id, u.name, u.email, u.role
  INTO v_user
  FROM tecniflow.users u
  WHERE u.auth_user_id = v_uid;

  IF FOUND THEN
    SELECT c.id, c.name, c.document, c.phone, c.whatsapp, c.email, c.address, c.warranty_terms, c.receipt_notes, c.company_logo_data_url
    INTO v_company
    FROM tecniflow.companies c
    WHERE c.id = v_user.company_id;

    -- Garante que existe registro de subscription de forma atômica (preserva trial existente se já existir)
    INSERT INTO tecniflow.company_subscriptions (
      company_id, status, plan_code, amount_cents, currency, billing_cycle,
      trial_starts_at, trial_ends_at, created_at, updated_at
    ) VALUES (
      v_user.company_id, 'trial', 'TECNIFLOW-MENSAL-4990', 4990, 'BRL', 'monthly',
      v_now, v_now + INTERVAL '7 days', v_now, v_now
    ) ON CONFLICT (company_id) DO NOTHING;

    SELECT * INTO v_sub
    FROM tecniflow.company_subscriptions
    WHERE company_id = v_user.company_id;

    v_is_active := tecniflow.check_subscription_active(v_user.company_id);

    IF v_sub.status = 'trial' THEN
      IF v_now < v_sub.trial_ends_at THEN
        v_effective_status := 'trial';
        v_days_left := GREATEST(0, CEIL(EXTRACT(EPOCH FROM (v_sub.trial_ends_at - v_now)) / 86400.0)::integer);
      ELSE
        v_effective_status := 'expired';
        v_days_left := 0;
      END IF;
    ELSIF v_sub.status IN ('active', 'canceled') THEN
      IF v_sub.current_period_starts_at IS NOT NULL AND v_sub.current_period_ends_at IS NOT NULL 
         AND v_sub.current_period_starts_at <= v_now AND v_now < v_sub.current_period_ends_at THEN
        v_effective_status := v_sub.status;
      ELSE
        v_effective_status := 'expired';
      END IF;
    ELSE
      v_effective_status := v_sub.status;
    END IF;

    RETURN jsonb_build_object(
      'user', to_jsonb(v_user),
      'company', to_jsonb(v_company),
      'billing', jsonb_build_object(
        'status', v_effective_status,
        'is_active', v_is_active,
        'can_operate', v_is_active,
        'trial_days_remaining', v_days_left,
        'trial_ends_at', v_sub.trial_ends_at,
        'current_period_ends_at', v_sub.current_period_ends_at
      )
    );
  END IF;

  -- 2. Não encontrado: obter dados do auth.users para provisionamento atômico
  SELECT email, raw_user_meta_data
  INTO v_auth_email, v_raw_meta
  FROM auth.users
  WHERE id = v_uid;

  IF v_auth_email IS NULL OR trim(v_auth_email) = '' THEN
    RAISE EXCEPTION 'E-mail do usuário autenticado não encontrado no Supabase Auth.';
  END IF;

  v_auth_email := lower(trim(v_auth_email));
  IF length(v_auth_email) > 100 THEN
    RAISE EXCEPTION 'E-mail de autenticação excede o limite permitido de 100 caracteres.';
  END IF;

  -- 3. Prevenção estrita de invasão/mesclagem por e-mail com contas legadas
  SELECT id INTO v_existing_conflict
  FROM tecniflow.users
  WHERE lower(email) = v_auth_email AND (auth_user_id IS NULL OR auth_user_id != v_uid)
  LIMIT 1;

  IF v_existing_conflict IS NOT NULL THEN
    RAISE EXCEPTION 'Conflito de cadastro: já existe um usuário registrado com este e-mail no banco. Para segurança dos dados, a unificação requer procedimento de migração e não é realizada automaticamente.';
  END IF;

  -- 4. Criar empresa e usuário vinculados de forma atômica (idêntico à 005)
  v_company_id := gen_random_uuid()::text;
  v_user_id := gen_random_uuid()::text;

  v_company_name := COALESCE(trim(v_raw_meta->>'company_name'), '');
  IF v_company_name = '' THEN
    v_company_name := 'Minha Assistência Técnica';
  END IF;
  v_company_name := substring(v_company_name, 1, 100);

  v_owner_name := COALESCE(trim(v_raw_meta->>'owner_name'), '');
  IF v_owner_name = '' THEN
    v_owner_name := split_part(v_auth_email, '@', 1);
  END IF;
  v_owner_name := substring(v_owner_name, 1, 100);

  v_company_doc := substring(COALESCE(trim(v_raw_meta->>'company_document'), ''), 1, 50);
  v_company_phone := substring(COALESCE(trim(v_raw_meta->>'company_phone'), ''), 1, 30);
  v_company_whatsapp := substring(COALESCE(trim(v_raw_meta->>'company_whatsapp'), ''), 1, 30);
  v_company_address := substring(COALESCE(trim(v_raw_meta->>'company_address'), ''), 1, 255);

  INSERT INTO tecniflow.companies (
    id, name, document, phone, whatsapp, email, address, warranty_terms, receipt_notes, company_logo_data_url, created_at
  ) VALUES (
    v_company_id, v_company_name, v_company_doc, v_company_phone, v_company_whatsapp, v_auth_email, v_company_address, '', '', NULL, v_now
  );

  INSERT INTO tecniflow.users (
    id, company_id, name, email, password_hash, role, auth_user_id, created_at
  ) VALUES (
    v_user_id, v_company_id, v_owner_name, v_auth_email, '', 'owner', v_uid, v_now
  );

  -- 5. Criação do trial de 7 dias para a nova empresa
  INSERT INTO tecniflow.company_subscriptions (
    company_id, status, plan_code, amount_cents, currency, billing_cycle,
    trial_starts_at, trial_ends_at, created_at, updated_at
  ) VALUES (
    v_company_id, 'trial', 'TECNIFLOW-MENSAL-4990', 4990, 'BRL', 'monthly',
    v_now, v_now + INTERVAL '7 days', v_now, v_now
  ) ON CONFLICT (company_id) DO NOTHING;

  SELECT * INTO v_sub
  FROM tecniflow.company_subscriptions
  WHERE company_id = v_company_id;

  SELECT u.id, u.company_id, u.name, u.email, u.role
  INTO v_user
  FROM tecniflow.users u
  WHERE u.id = v_user_id;

  SELECT c.id, c.name, c.document, c.phone, c.whatsapp, c.email, c.address, c.warranty_terms, c.receipt_notes, c.company_logo_data_url
  INTO v_company
  FROM tecniflow.companies c
  WHERE c.id = v_company_id;

  RETURN jsonb_build_object(
    'user', to_jsonb(v_user),
    'company', to_jsonb(v_company),
    'billing', jsonb_build_object(
      'status', 'trial',
      'is_active', true,
      'can_operate', true,
      'trial_days_remaining', 7,
      'trial_ends_at', v_sub.trial_ends_at,
      'current_period_ends_at', NULL
    )
  );
END;
$$;

-- 10. FUNÇÃO INTERNA SEGURA DE PROCESSAMENTO DE PAGAMENTOS
-- Redesenho robusto:
-- - Lock exclusivo de linha
-- - Vínculo imutável company_id e mp_preapproval_id
-- - Data de pagamento fixada na primeira aprovação (duplicata não estende vencimento)
-- - Transições proibidas: approved -> pending/rejected; refunded/charged_back -> não terminal
-- - Cobertura mensal de calendário (+ INTERVAL '1 month')
-- - Acesso ativo exige início <= now < fim (pagamentos futuros não liberam o momento presente)
CREATE OR REPLACE FUNCTION tecniflow.process_billing_payment(
  p_company_id VARCHAR(36),
  p_mp_payment_id VARCHAR(100),
  p_mp_preapproval_id VARCHAR(100),
  p_amount_cents INTEGER,
  p_currency VARCHAR(3),
  p_status VARCHAR(20),
  p_payment_date TIMESTAMPTZ
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_sub RECORD;
  v_existing_payment RECORD;
  v_pay RECORD;
  v_coverage_start TIMESTAMPTZ := NULL;
  v_coverage_end TIMESTAMPTZ := NULL;
  v_has_approved BOOLEAN := false;
  v_has_currently_active_coverage BOOLEAN := false;
  v_new_status VARCHAR(20);
  v_now TIMESTAMPTZ := now();
  v_pay_start TIMESTAMPTZ;
  v_pay_end TIMESTAMPTZ;
BEGIN
  IF p_company_id IS NULL THEN
    RAISE EXCEPTION 'ID da empresa obrigatório.';
  END IF;

  IF p_mp_payment_id IS NULL OR trim(p_mp_payment_id) = '' THEN
    RAISE EXCEPTION 'ID do pagamento Mercado Pago obrigatório.';
  END IF;

  IF p_amount_cents <> 4990 OR p_currency <> 'BRL' THEN
    RAISE EXCEPTION 'Valor ou moeda divergente do plano canônico TECNIFLOW-MENSAL-4990.';
  END IF;

  -- 1. Lock exclusivo na linha de assinatura da empresa
  SELECT * INTO v_sub
  FROM tecniflow.company_subscriptions
  WHERE company_id = p_company_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Assinatura da empresa não encontrada.';
  END IF;

  -- 2. Verificar se o pagamento já existe (vínculo imutável com a empresa e preapproval)
  SELECT * INTO v_existing_payment
  FROM tecniflow.billing_payments
  WHERE mp_payment_id = p_mp_payment_id
  FOR UPDATE;

  IF FOUND THEN
    -- Vínculo imutável: pagamento jamais pode migrar ou atualizar outra empresa
    IF v_existing_payment.company_id <> p_company_id THEN
      RAISE EXCEPTION 'Tentativa de violação: pagamento pertence a outra empresa'
        USING ERRCODE = 'P0003';
    END IF;

    -- Vínculo imutável: preapproval não pode divergir
    IF v_existing_payment.mp_preapproval_id IS NOT NULL AND p_mp_preapproval_id IS NOT NULL 
       AND v_existing_payment.mp_preapproval_id <> p_mp_preapproval_id THEN
      RAISE EXCEPTION 'Tentativa de violação: assinatura preapproval divergente'
        USING ERRCODE = 'P0003';
    END IF;

    -- Proibir regressão de status terminal (refunded / charged_back para qualquer não terminal)
    IF v_existing_payment.status IN ('refunded', 'charged_back') AND p_status NOT IN ('refunded', 'charged_back') THEN
      RETURN jsonb_build_object('success', true, 'duplicate', true, 'ignored_terminal_regression', true, 'status', v_sub.status);
    END IF;

    -- Proibir regressão de pagamento aprovado para pending ou rejected
    IF v_existing_payment.status = 'approved' AND p_status IN ('pending', 'rejected') THEN
      RETURN jsonb_build_object('success', true, 'duplicate', true, 'ignored_approved_regression', true, 'status', v_sub.status);
    END IF;

    -- Se já for 'approved' e receber nova notificação 'approved' (duplicata com qualquer data):
    -- FIXA a data de pagamento e o intervalo já gravados; não altera payment_date nem period_ends_at!
    IF v_existing_payment.status = 'approved' AND p_status = 'approved' THEN
      UPDATE tecniflow.billing_payments
      SET updated_at = v_now
      WHERE mp_payment_id = p_mp_payment_id;

      RETURN jsonb_build_object('success', true, 'duplicate', true, 'unchanged_dates', true, 'status', v_sub.status);
    END IF;

    -- Atualiza status (ex.: de approved para refunded) preservando a payment_date original
    UPDATE tecniflow.billing_payments
    SET
      status = p_status,
      -- A data de aprovação passa a valer na primeira aprovação; eventos posteriores não a deslocam.
      payment_date = CASE WHEN p_status = 'approved' THEN p_payment_date ELSE payment_date END,
      period_starts_at = CASE WHEN p_status = 'approved' THEN p_payment_date ELSE period_starts_at END,
      period_ends_at = CASE WHEN p_status = 'approved' THEN p_payment_date + INTERVAL '1 month' ELSE period_ends_at END,
      mp_preapproval_id = COALESCE(p_mp_preapproval_id, mp_preapproval_id),
      updated_at = v_now
    WHERE mp_payment_id = p_mp_payment_id;

  ELSE
    -- Novo pagamento registrado: calcula período fixo deste pagamento
    v_pay_start := p_payment_date;
    v_pay_end := p_payment_date + INTERVAL '1 month';

    INSERT INTO tecniflow.billing_payments (
      id, company_id, mp_payment_id, mp_preapproval_id, amount_cents, currency, status,
      payment_date, period_starts_at, period_ends_at, created_at, updated_at
    ) VALUES (
      gen_random_uuid()::text, p_company_id, p_mp_payment_id, p_mp_preapproval_id,
      p_amount_cents, p_currency, p_status, p_payment_date, v_pay_start, v_pay_end, v_now, v_now
    );
  END IF;

  -- 3. Recomputar cobertura contínua de pagamentos 'approved' não estornados
  FOR v_pay IN (
    SELECT payment_date, period_starts_at, period_ends_at
    FROM tecniflow.billing_payments
    WHERE company_id = p_company_id
      AND status = 'approved'
    ORDER BY payment_date ASC
  ) LOOP
    -- Uma cobertura futura separada não pode substituir o período que já cobre o presente.
    IF v_has_currently_active_coverage AND v_pay.payment_date > v_coverage_end THEN
      EXIT;
    END IF;
    v_has_approved := true;
    IF v_coverage_start IS NULL THEN
      v_coverage_start := v_pay.payment_date;
      v_coverage_end := v_pay.payment_date + INTERVAL '1 month';
    ELSE
      IF v_pay.payment_date < v_coverage_end THEN
        -- Extensão contínua por 1 mês calendário
        v_coverage_end := v_coverage_end + INTERVAL '1 month';
      ELSE
        -- Novo período após hiato
        v_coverage_start := v_pay.payment_date;
        v_coverage_end := v_pay.payment_date + INTERVAL '1 month';
      END IF;
    END IF;

    -- Verifica se este pagamento cobre o momento presente (início <= now < fim)
    IF v_coverage_start <= v_now AND v_now < v_coverage_end THEN
      v_has_currently_active_coverage := true;
    END IF;
  END LOOP;

  -- 4. Determina status final da assinatura
  -- Acesso pago ATIVO exige início <= now < fim (pagamentos futuros não liberam o momento presente)
  IF v_has_currently_active_coverage THEN
    v_new_status := CASE WHEN v_sub.status = 'canceled' THEN 'canceled' ELSE 'active' END;
  ELSIF v_has_approved AND v_now < v_coverage_end THEN
    -- Há pagamento futuro aprovado, mas ainda não iniciou
    v_new_status := CASE WHEN v_now < v_sub.trial_ends_at THEN 'trial' ELSE 'expired' END;
  ELSE
    -- Sem pagamentos aprovados cobrindo o presente
    v_coverage_start := NULL;
    v_coverage_end := NULL;
    IF v_now < v_sub.trial_ends_at THEN
      v_new_status := 'trial';
    ELSE
      v_new_status := 'expired';
    END IF;
  END IF;

  -- 5. Atualiza a assinatura da empresa com a cobertura recomputada
  UPDATE tecniflow.company_subscriptions
  SET
    status = v_new_status,
    current_period_starts_at = v_coverage_start,
    current_period_ends_at = v_coverage_end,
    mp_preapproval_id = COALESCE(p_mp_preapproval_id, v_sub.mp_preapproval_id),
    updated_at = v_now
  WHERE company_id = p_company_id;

  RETURN jsonb_build_object(
    'success', true,
    'status', v_new_status,
    'has_approved', v_has_approved,
    'has_active_coverage_now', v_has_currently_active_coverage,
    'current_period_starts_at', v_coverage_start,
    'current_period_ends_at', v_coverage_end
  );
END;
$$;

REVOKE ALL ON FUNCTION tecniflow.process_billing_payment(VARCHAR, VARCHAR, VARCHAR, INTEGER, VARCHAR, VARCHAR, TIMESTAMPTZ) FROM PUBLIC, anon, authenticated;

-- 11. BRIDGE PÚBLICA PARA SERVICE_ROLE (BACKEND / EDGE FUNCTION)
-- Não exposta no browser; autenticação defensiva no corpo e privilégio EXECUTE exclusivo
CREATE OR REPLACE FUNCTION public.tf_process_billing_payment(
  p_company_id VARCHAR(36),
  p_mp_payment_id VARCHAR(100),
  p_mp_preapproval_id VARCHAR(100),
  p_amount_cents INTEGER,
  p_currency VARCHAR(3),
  p_status VARCHAR(20),
  p_payment_date TIMESTAMPTZ
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  -- Verificação defensiva de papel de execução: apenas service_role ou postgres
  IF current_user <> 'service_role' AND session_user <> 'service_role' AND current_user <> 'postgres' THEN
    RAISE EXCEPTION 'Acesso negado: função reservada exclusivamente para service_role.'
      USING ERRCODE = '42501';
  END IF;

  RETURN tecniflow.process_billing_payment(
    p_company_id,
    p_mp_payment_id,
    p_mp_preapproval_id,
    p_amount_cents,
    p_currency,
    p_status,
    p_payment_date
  );
END;
$$;

REVOKE ALL ON FUNCTION public.tf_process_billing_payment(VARCHAR, VARCHAR, VARCHAR, INTEGER, VARCHAR, VARCHAR, TIMESTAMPTZ) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.tf_process_billing_payment(VARCHAR, VARCHAR, VARCHAR, INTEGER, VARCHAR, VARCHAR, TIMESTAMPTZ) TO service_role;

-- 12. INJEÇÃO DINÂMICA DA GUARDA assert_active_subscription NAS 21 RPCS OPERACIONAIS REAIS
-- Preserva 100% das assinaturas, contratos, parâmetros e código da 003 sem reescritas manuais
DO $inject$
DECLARE
  v_fn text;
  v_def text;
  v_new_def text;
  v_allowlist text[] := ARRAY[
    'tf_get_clients',
    'tf_create_client',
    'tf_update_client',
    'tf_archive_client',
    'tf_get_client_details',
    'tf_get_inventory',
    'tf_get_inventory_details',
    'tf_create_inventory_item',
    'tf_update_inventory_item',
    'tf_adjust_inventory',
    'tf_get_orders',
    'tf_get_order_details',
    'tf_create_order',
    'tf_update_order',
    'tf_save_budget',
    'tf_decide_budget',
    'tf_reopen_budget',
    'tf_transition_order_status',
    'tf_get_dashboard_stats',
    'tf_get_reports',
    'tf_import_legacy'
  ];
BEGIN
  FOREACH v_fn IN ARRAY v_allowlist LOOP
    SELECT pg_get_functiondef(p.oid) INTO v_def
    FROM pg_proc p
    WHERE p.pronamespace = 'public'::regnamespace AND p.proname = v_fn;

    IF v_def IS NULL THEN
      RAISE EXCEPTION 'Função operacional não encontrada: public.%', v_fn;
    END IF;

    IF v_def NOT LIKE '%tecniflow.assert_active_subscription%' THEN
      v_new_def := regexp_replace(
        v_def,
        '(\mBEGIN\M\s*)',
        '\1' || 'PERFORM tecniflow.assert_active_subscription();' || chr(10) || '  ',
        'i'
      );
      EXECUTE v_new_def;
    END IF;
  END LOOP;
END;
$inject$;

-- 13. PERMISSÕES EXPLÍCITAS DAS RPCS PÚBLICAS
REVOKE ALL ON FUNCTION public.tf_get_billing_status() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.tf_get_billing_status() TO authenticated;

COMMIT;
