# Guia de Preparação e Implantação da Monetização Kiwify (TecniFlow)

Este guia documenta o procedimento que o proprietário deve seguir quando decidir colocar a monetização Kiwify em produção. **Nenhum comando foi executado remotamente e nenhuma chave de produção foi alterada pelo assistente.**

---

### 1. Migração no Banco Supabase ("Controle de Gastos")

1. Abra o painel do Supabase do projeto oficial.
2. Acesse o **SQL Editor**.
3. Abra o arquivo `supabase/008_kiwify_billing.sql`, revise o conteúdo e execute-o.
4. A migração cria de forma transacional e idempotente:
   - Tabela privada `tecniflow.billing_intents` (RLS habilitado) com suporte a `plan_id NULL` antes da primeira cobrança.
   - Tabela privada `tecniflow.company_kiwify_subscriptions` (histórico perpétuo de assinaturas por empresa).
   - RPC pública `public.tf_create_billing_intent(p_product_id, p_plan_id)` (gera token seguro CSPRNG de 256 bits, TTL de 24h, exclusivo para `owner`).
   - Função interna `tecniflow.process_kiwify_payment` (validação de 4990 centavos BRL, tombstones terminais, vinculação atômica do plano descoberto, sem consumo indevido por eventos informativos).
   - Bridge pública `public.tf_process_kiwify_payment` (restrita exclusivamente a `service_role`).

---

### 2. Configurações no Painel da Kiwify

1. **Produto e Checkout**:
   - Produto: `tecniflow` (ID: `fe3f16c0-d5f4-11f1-bd40-b570d8dc84fc`).
   - Interface oficial Kiwify: a edição do produto localiza-se na rota `/products/edit/:productUUID`.
   - Na aba de planos/preços, os detalhes do plano abrem em **modal** na interface da Kiwify.
   - Link de checkout do produto: `https://pay.kiwify.com.br/Tao519J` (URL limpa, sem parâmetro query de plano). O rastreamento de contratação do SaaS é realizado exclusivamente pelo parâmetro de tracking `?sck=<token_opaco>`.
   - Preço configurado: R$ 49,90/mês (sem período de teste na Kiwify, pois os 7 dias gratuitos são geridos pelo servidor TecniFlow).
2. **Identificador do Plano (KIWIFY_PLAN_ID) — Opcional com Vinculação Automática**:
   - **Não é necessário adivinhar ou buscar o UUID interno do plano antes da primeira cobrança.**
   - O TecniFlow cria o checkout intent autenticado com produto configurado e `plan_id = NULL`.
   - O primeiro pagamento aprovado (`order_approved` / `subscription_renewed` com status `paid`) contendo assinatura HMAC válida, valor 4990 BRL e frequência mensal identifica o plano real enviado pela Kiwify em `Subscription.plan.id`.
   - A mesma transação atômica do banco de dados fixa o `plan_id` real no intent e na tabela permanente `company_kiwify_subscriptions`.
   - Renovações subsequentes validam o vínculo imutável com este plano.
   - Caso `KIWIFY_PLAN_ID` seja explicitamente configurado no servidor, atua como allowlist estrita e qualquer plano divergente é rejeitado. Placeholders contendo `...` são sumariamente rejeitados (fail-closed).
3. **Webhook**:
   - Cadastre a URL do webhook apontando para a Edge Function:
     `https://<REF_PROJETO>.supabase.co/functions/v1/kiwify-webhook`
     (ou para o servidor Express: `https://seu-dominio.com/api/billing/webhook`)
   - Selecione os eventos:
     - `order_approved`, `subscription_renewed`, `subscription_canceled`, `subscription_late`, `order_refunded`, `chargeback`, `pix_created`, `billet_created`.
   - Copie o **Token do Webhook** gerado pela Kiwify para configurar no backend.

---

### 3. Configuração de Secrets no Supabase CLI / Dashboard

No painel do Supabase (Project Settings > Edge Functions > Secrets) ou via Supabase CLI, configure:

```bash
supabase secrets set \
  KIWIFY_ENABLED="true" \
  KIWIFY_CHECKOUT_URL="https://pay.kiwify.com.br/Tao519J" \
  KIWIFY_WEBHOOK_SECRET="<TOKEN_DO_WEBHOOK_OBTIDO_NA_KIWIFY>" \
  KIWIFY_ALLOWED_PRODUCT_IDS="fe3f16c0-d5f4-11f1-bd40-b570d8dc84fc" \
  KIWIFY_PLAN_ID=""
```

*(Nota: `KIWIFY_PLAN_ID` pode ser mantido vazio `""` para vinculação atômica automática no primeiro pagamento).*

---

### 4. Implantação das Edge Functions

Com o Supabase CLI logado no projeto:

```bash
# Implanta a Edge Function de checkout (autenticada, verify_jwt = true em config.toml)
supabase functions deploy kiwify-checkout

# Implanta a Edge Function de webhook (pública com autenticação HMAC-SHA1, verify_jwt = false em config.toml)
supabase functions deploy kiwify-webhook
```

---

### 5. Arquitetura de Segurança Implementada

- **HMAC-SHA1 sobre Bytes Brutos UTF-8 (Raw Body)**: A autenticação segue rigorosamente a especificação oficial vigente da Kiwify (https://docs.kiwify.com.br/api-reference/webhooks/receiving). O cálculo do HMAC-SHA1 é realizado diretamente sobre os bytes UTF-8 brutos recebidos na requisição HTTP (`rawBodyText`), comparado em tempo constante (`diff |= expected ^ actual` / `timingSafeEqual`). Não existe fallback permissivo baseado em reserialização `JSON.stringify()`.
- **Fail-Closed Estrito**: Qualquer divergência de produto, valor (inteiro 4990 centavos BRL), frequência ('monthly'), IDs de assinatura contraditórios ou datas de ciclo inválidas causa rejeição imediata (HTTP 400), sem qualquer efeito colateral no banco de dados.
- **Zero Vazamento de Dados Pessoais na URL**: A URL de checkout repassa apenas `?sck=<token_opaco_256_bits>`, sem e-mail, nome, CPF ou `company_id`.
- **Tombstones Terminais**: Se um estorno ou chargeback for notificado antes da aprovação do pedido, um tombstone terminal é registrado, bloqueando permanentemente aprovações tardias fraudulentas ou fora de ordem.
- **Isolamento Multi-Assinaturas**: Estornos ou cancelamentos de assinaturas antigas ou distintas não afetam a assinatura vigente da empresa, preservando o período de cobertura já pago (`paid-through`).
