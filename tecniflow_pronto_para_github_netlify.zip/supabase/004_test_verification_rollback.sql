-- ============================================================================
-- TECNIFLOW - SCRIPT DE AUDITORIA TRANSACIONAL ISOLADA (SUPABASE / POSTGRESQL)
-- 
-- Finalidade: Executar bateria completa de testes de segurança, multiempresa,
--             autorização, privilégios de roles nativas e integridade operacional
--             no banco real, terminando OBRIGATORIAMENTE em ROLLBACK.
-- 
-- Garantias de Segurança:
-- 1. Transacional Atômico: Nenhum registro de teste, usuário, empresa ou
--    cliente é persistido. O script encerra estritamente com ROLLBACK.
-- 2. Preservação de Dados: public.profiles e todas as tabelas tecniflow.*
--    preexistentes permanecem 100% inalteradas.
-- 3. search_path = '': RPCs chamadas com qualificação de schema explícita.
-- 4. Simulação de Duas Identidades (Tenant A e Tenant B) via auth.uid().
-- 5. Validação Estrita Anti-Falso-Positivo:
--    - Flags de negação controladas FORA dos handlers de exceção.
--    - Verificação obrigatória do SQLSTATE ('P0001' ou '42501') e da mensagem exata.
--    - Erros inesperados interrompem a execução em vez de mascarar falhas.
-- 6. Meta-Teste de Vulnerabilidade:
--    - Injeta temporariamente uma RPC mock propositalmente desprotegida e
--      comprova formalmente que o mecanismo de auditoria a REJEITA com falha.
-- 7. Teste de Privilégios Reais de Roles PostgreSQL:
--    - Utiliza SET LOCAL ROLE anon e SET LOCAL ROLE authenticated para
--      comprovar bloqueio nativo (SQLSTATE 42501) a tabelas privadas tecniflow.*.
-- ============================================================================

BEGIN;

DO $audit$
DECLARE
  -- Contadores para auditoria antes e depois
  v_initial_companies_count INT;
  v_initial_users_count INT;
  v_initial_clients_count INT;
  v_initial_orders_count INT;
  v_initial_profiles_count INT;
  v_final_profiles_count INT;

  -- Identidades e empresas simuladas
  v_uid_a UUID := gen_random_uuid();
  v_uid_b UUID := gen_random_uuid();
  v_email_a TEXT;
  v_email_b TEXT;

  v_sync_a JSONB;
  v_sync_b JSONB;
  v_company_a_id TEXT;
  v_company_b_id TEXT;
  v_user_a_id TEXT;
  v_user_b_id TEXT;

  -- Entidades da Empresa A
  v_client_res JSONB;
  v_client_a_id TEXT;
  v_part_res JSONB;
  v_part_a_id TEXT;
  v_order_res JSONB;
  v_order_a_id TEXT;
  v_order_version INT;

  -- Variáveis auxiliares de validação estrita anti-falso-positivo
  v_temp_json JSONB;
  v_denied_count INT := 0;
  v_denied BOOLEAN := false;
  v_err_msg TEXT := '';
  v_err_state TEXT := '';
  v_meta_test_detected_vuln BOOLEAN := false;
  v_tested_checks INT := 0;
BEGIN
  RAISE NOTICE '================================================================';
  RAISE NOTICE 'INICIANDO AUDITORIA TRANSACIONAL TECNIFLOW (TERMINA EM ROLLBACK)';
  RAISE NOTICE '================================================================';

  -- 1. Snapshot de contagens pré-teste
  SELECT count(*) INTO v_initial_companies_count FROM tecniflow.companies;
  SELECT count(*) INTO v_initial_users_count FROM tecniflow.users;
  SELECT count(*) INTO v_initial_clients_count FROM tecniflow.clients;
  SELECT count(*) INTO v_initial_orders_count FROM tecniflow.orders;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'profiles') THEN
    EXECUTE 'SELECT count(*) FROM public.profiles' INTO v_initial_profiles_count;
  ELSE
    v_initial_profiles_count := 0;
  END IF;

  RAISE NOTICE 'Estado inicial verificado: % empresas, % usuários, % clientes, % OS, % perfis.',
    v_initial_companies_count, v_initial_users_count, v_initial_clients_count, v_initial_orders_count, v_initial_profiles_count;

  -- 2. Criação temporária de usuários em auth.users para satisfazer FKs
  v_email_a := 'auditoria_a_' || replace(v_uid_a::text, '-', '') || '@tecniflow.invalid';
  v_email_b := 'auditoria_b_' || replace(v_uid_b::text, '-', '') || '@tecniflow.invalid';

  INSERT INTO auth.users (id, email, raw_user_meta_data)
  VALUES
    (v_uid_a, v_email_a, jsonb_build_object('company_name', 'Oficina A (Auditoria)', 'owner_name', 'Técnico Responsável A')),
    (v_uid_b, v_email_b, jsonb_build_object('company_name', 'Oficina B (Auditoria)', 'owner_name', 'Técnico Responsável B'));

  v_tested_checks := v_tested_checks + 1;
  RAISE NOTICE '✓ [PASS] Identidades transitórias A (%) e B (%) criadas em auth.users', v_uid_a, v_uid_b;

  -- --------------------------------------------------------------------------
  -- TESTE 1: Autenticação e Provisionamento Empresa A
  -- --------------------------------------------------------------------------
  PERFORM set_config('request.jwt.claim.sub', v_uid_a::text, true);
  PERFORM set_config('request.jwt.claims', jsonb_build_object('sub', v_uid_a::text, 'role', 'authenticated')::text, true);

  v_sync_a := public.tf_sync_current_user();
  IF v_sync_a->'company'->>'id' IS NULL OR v_sync_a->'user'->>'id' IS NULL THEN
    RAISE EXCEPTION 'Falha ao sincronizar Usuário A.';
  END IF;

  v_company_a_id := v_sync_a->'company'->>'id';
  v_user_a_id := v_sync_a->'user'->>'id';

  -- Garantir que password_hash não é vazado
  IF (v_sync_a->'user' ? 'password_hash') THEN
    RAISE EXCEPTION 'Vazamento de segurança: password_hash retornado no objeto user!';
  END IF;

  -- Idempotência de tf_sync_current_user
  v_temp_json := public.tf_sync_current_user();
  IF v_temp_json->'company'->>'id' <> v_company_a_id THEN
    RAISE EXCEPTION 'Falha de idempotência: segunda chamada gerou empresa diferente!';
  END IF;

  v_tested_checks := v_tested_checks + 1;
  RAISE NOTICE '✓ [PASS] Usuário A provisionado e idempotente (Empresa: %)', v_company_a_id;

  -- --------------------------------------------------------------------------
  -- TESTE 2: Autenticação e Provisionamento Empresa B (Isolamento de Tenant)
  -- --------------------------------------------------------------------------
  PERFORM set_config('request.jwt.claim.sub', v_uid_b::text, true);
  PERFORM set_config('request.jwt.claims', jsonb_build_object('sub', v_uid_b::text, 'role', 'authenticated')::text, true);

  v_sync_b := public.tf_sync_current_user();
  v_company_b_id := v_sync_b->'company'->>'id';
  v_user_b_id := v_sync_b->'user'->>'id';

  IF v_company_b_id = v_company_a_id THEN
    RAISE EXCEPTION 'FALHA DE ISOLAMENTO: Empresa B recebeu o mesmo ID da Empresa A!';
  END IF;

  v_tested_checks := v_tested_checks + 1;
  RAISE NOTICE '✓ [PASS] Usuário B provisionado em empresa estritamente distinta (%)', v_company_b_id;

  -- --------------------------------------------------------------------------
  -- TESTE 3: Criação de Entidades na Empresa A
  -- --------------------------------------------------------------------------
  PERFORM set_config('request.jwt.claim.sub', v_uid_a::text, true);
  PERFORM set_config('request.jwt.claims', jsonb_build_object('sub', v_uid_a::text, 'role', 'authenticated')::text, true);

  -- 3.1 Cliente A
  v_client_res := public.tf_create_client(
    p_name => 'Cliente Teste Alfa',
    p_phone => '(11) 98765-4321',
    p_whatsapp => '(11) 98765-4321',
    p_email => 'cliente.alfa@exemplo.com.br',
    p_document => '12.ABC.345/01DE-35'
  );
  v_client_a_id := v_client_res->'client'->>'id';

  -- 3.2 Peça de Estoque A
  v_part_res := public.tf_create_inventory_item(
    p_name => 'Bateria Premium Teste',
    p_sku => 'BAT-AUDIT-01',
    p_category => 'baterias',
    p_quantity => 4,
    p_min_quantity => 1,
    p_cost_price_cents => 4000,
    p_sale_price_cents => 9000
  );
  v_part_a_id := v_part_res->'item'->>'id';

  -- 3.3 Ordem de Serviço A
  v_order_res := public.tf_create_order(
    p_client_id => v_client_a_id,
    p_device_type => 'smartphone',
    p_brand => 'Apple',
    p_model => 'iPhone 13',
    p_serial_imei => '354890123456789',
    p_defect_reported => 'Bateria descarregando rapidamente',
    p_priority => 'normal',
    p_estimated_delivery => '2026-11-05'
  );
  v_order_a_id := v_order_res->'order'->>'id';
  v_order_version := (v_order_res->'order'->>'version')::int;

  v_tested_checks := v_tested_checks + 1;
  RAISE NOTICE '✓ [PASS] Entidades criadas na Empresa A (Cliente: %, Peça: %, OS: #%)',
    v_client_a_id, v_part_a_id, v_order_res->'order'->>'order_number';

  -- --------------------------------------------------------------------------
  -- TESTE 4: Negação Estrita de Leitura Cruzada (Empresa B tenta ler Empresa A)
  -- --------------------------------------------------------------------------
  PERFORM set_config('request.jwt.claim.sub', v_uid_b::text, true);
  PERFORM set_config('request.jwt.claims', jsonb_build_object('sub', v_uid_b::text, 'role', 'authenticated')::text, true);

  -- 4.1 Listagem de clientes da Empresa B não pode conter clientes da Empresa A
  v_temp_json := public.tf_get_clients();
  IF jsonb_array_length(v_temp_json->'clients') <> 0 THEN
    RAISE EXCEPTION 'FALHA DE PRIVACIDADE: Empresa B conseguiu listar clientes da Empresa A!';
  END IF;

  -- 4.2 Listagem de estoque da Empresa B não pode conter peças da Empresa A
  v_temp_json := public.tf_get_inventory();
  IF jsonb_array_length(v_temp_json->'items') <> 0 THEN
    RAISE EXCEPTION 'FALHA DE PRIVACIDADE: Empresa B conseguiu listar peças da Empresa A!';
  END IF;

  -- 4.3 Listagem de OS da Empresa B não pode conter ordens da Empresa A
  v_temp_json := public.tf_get_orders();
  IF jsonb_array_length(v_temp_json->'orders') <> 0 THEN
    RAISE EXCEPTION 'FALHA DE PRIVACIDADE: Empresa B conseguiu listar OS da Empresa A!';
  END IF;

  -- 4.4 Acesso direto a detalhes de cliente por ID da Empresa A deve ser negado com mensagem exata
  v_denied := false;
  v_err_msg := '';
  v_err_state := '';
  BEGIN
    PERFORM public.tf_get_client_details(v_client_a_id);
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_err_state = RETURNED_SQLSTATE, v_err_msg = MESSAGE_TEXT;
    IF v_err_state = 'P0001' AND (v_err_msg ILIKE '%não encontrad%' OR v_err_msg ILIKE '%não pertence%') THEN
      v_denied := true;
      v_denied_count := v_denied_count + 1;
    ELSE
      RAISE EXCEPTION 'Erro inesperado em vez do bloqueio multiempresa esperado. SQLSTATE: %, Mensagem: %', v_err_state, v_err_msg;
    END IF;
  END;
  IF NOT v_denied THEN
    RAISE EXCEPTION 'FALHA DE SEGURANÇA: Empresa B conseguiu obter detalhes de cliente da Empresa A!';
  END IF;

  -- 4.5 Acesso direto a detalhes de peça por ID da Empresa A deve ser negado com mensagem exata
  v_denied := false;
  v_err_msg := '';
  v_err_state := '';
  BEGIN
    PERFORM public.tf_get_inventory_details(v_part_a_id);
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_err_state = RETURNED_SQLSTATE, v_err_msg = MESSAGE_TEXT;
    IF v_err_state = 'P0001' AND (v_err_msg ILIKE '%não encontrad%' OR v_err_msg ILIKE '%não pertence%') THEN
      v_denied := true;
      v_denied_count := v_denied_count + 1;
    ELSE
      RAISE EXCEPTION 'Erro inesperado em vez do bloqueio multiempresa esperado. SQLSTATE: %, Mensagem: %', v_err_state, v_err_msg;
    END IF;
  END;
  IF NOT v_denied THEN
    RAISE EXCEPTION 'FALHA DE SEGURANÇA: Empresa B conseguiu obter detalhes de peça da Empresa A!';
  END IF;

  -- 4.6 Acesso direto a detalhes de OS por ID da Empresa A deve ser negado com mensagem exata
  v_denied := false;
  v_err_msg := '';
  v_err_state := '';
  BEGIN
    PERFORM public.tf_get_order_details(v_order_a_id);
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_err_state = RETURNED_SQLSTATE, v_err_msg = MESSAGE_TEXT;
    IF v_err_state = 'P0001' AND (v_err_msg ILIKE '%não encontrad%' OR v_err_msg ILIKE '%não pertence%') THEN
      v_denied := true;
      v_denied_count := v_denied_count + 1;
    ELSE
      RAISE EXCEPTION 'Erro inesperado em vez do bloqueio multiempresa esperado. SQLSTATE: %, Mensagem: %', v_err_state, v_err_msg;
    END IF;
  END;
  IF NOT v_denied THEN
    RAISE EXCEPTION 'FALHA DE SEGURANÇA: Empresa B conseguiu obter detalhes de OS da Empresa A!';
  END IF;

  IF v_denied_count <> 3 THEN
    RAISE EXCEPTION 'FALHA: Contagem de bloqueios de leitura cruzada incorreta: % (esperado: 3)', v_denied_count;
  END IF;

  v_tested_checks := v_tested_checks + 1;
  RAISE NOTICE '✓ [PASS] Leitura cruzada 100%% bloqueada para Empresa B em listagens e buscas por ID com verificação de SQLSTATE e mensagem';

  -- --------------------------------------------------------------------------
  -- TESTE 5: Negação Estrita de Escrita Cruzada (Empresa B tenta alterar Empresa A)
  -- --------------------------------------------------------------------------
  v_denied_count := 0;

  -- 5.1 Empresa B tenta atualizar cliente da Empresa A
  v_denied := false;
  v_err_msg := '';
  v_err_state := '';
  BEGIN
    PERFORM public.tf_update_client(
      p_id => v_client_a_id,
      p_name => 'Tentativa Invasão',
      p_phone => '(11) 99999-9999'
    );
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_err_state = RETURNED_SQLSTATE, v_err_msg = MESSAGE_TEXT;
    IF v_err_state = 'P0001' AND (v_err_msg ILIKE '%não encontrad%' OR v_err_msg ILIKE '%não pertence%') THEN
      v_denied := true;
      v_denied_count := v_denied_count + 1;
    ELSE
      RAISE EXCEPTION 'Erro inesperado em 5.1. SQLSTATE: %, Mensagem: %', v_err_state, v_err_msg;
    END IF;
  END;
  IF NOT v_denied THEN
    RAISE EXCEPTION 'FALHA DE SEGURANÇA: Empresa B conseguiu alterar cliente da Empresa A!';
  END IF;

  -- 5.2 Empresa B tenta arquivar cliente da Empresa A
  v_denied := false;
  v_err_msg := '';
  v_err_state := '';
  BEGIN
    PERFORM public.tf_archive_client(p_id => v_client_a_id, p_archived => 1);
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_err_state = RETURNED_SQLSTATE, v_err_msg = MESSAGE_TEXT;
    IF v_err_state = 'P0001' AND (v_err_msg ILIKE '%não encontrad%' OR v_err_msg ILIKE '%não pertence%') THEN
      v_denied := true;
      v_denied_count := v_denied_count + 1;
    ELSE
      RAISE EXCEPTION 'Erro inesperado em 5.2. SQLSTATE: %, Mensagem: %', v_err_state, v_err_msg;
    END IF;
  END;
  IF NOT v_denied THEN
    RAISE EXCEPTION 'FALHA DE SEGURANÇA: Empresa B conseguiu arquivar cliente da Empresa A!';
  END IF;

  -- 5.3 Empresa B tenta alterar estoque da Empresa A
  v_denied := false;
  v_err_msg := '';
  v_err_state := '';
  BEGIN
    PERFORM public.tf_adjust_inventory(
      p_id => v_part_a_id,
      p_type => 'saida_manual',
      p_quantity => 1,
      p_reason => 'Tentativa de baixa indevida'
    );
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_err_state = RETURNED_SQLSTATE, v_err_msg = MESSAGE_TEXT;
    IF v_err_state = 'P0001' AND (v_err_msg ILIKE '%não encontrad%' OR v_err_msg ILIKE '%não pertence%') THEN
      v_denied := true;
      v_denied_count := v_denied_count + 1;
    ELSE
      RAISE EXCEPTION 'Erro inesperado em 5.3. SQLSTATE: %, Mensagem: %', v_err_state, v_err_msg;
    END IF;
  END;
  IF NOT v_denied THEN
    RAISE EXCEPTION 'FALHA DE SEGURANÇA: Empresa B conseguiu movimentar estoque da Empresa A!';
  END IF;

  -- 5.4 Empresa B tenta criar OS apontando cliente da Empresa A
  v_denied := false;
  v_err_msg := '';
  v_err_state := '';
  BEGIN
    PERFORM public.tf_create_order(
      p_client_id => v_client_a_id,
      p_device_type => 'smartphone',
      p_brand => 'Apple',
      p_model => 'Invasão',
      p_defect_reported => 'Teste cruzado'
    );
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_err_state = RETURNED_SQLSTATE, v_err_msg = MESSAGE_TEXT;
    IF v_err_state = 'P0001' AND (v_err_msg ILIKE '%não encontrad%' OR v_err_msg ILIKE '%não pertence%') THEN
      v_denied := true;
      v_denied_count := v_denied_count + 1;
    ELSE
      RAISE EXCEPTION 'Erro inesperado em 5.4. SQLSTATE: %, Mensagem: %', v_err_state, v_err_msg;
    END IF;
  END;
  IF NOT v_denied THEN
    RAISE EXCEPTION 'FALHA DE SEGURANÇA: Empresa B vinculou cliente da Empresa A a nova OS!';
  END IF;

  -- 5.5 Empresa B tenta transitar status de OS da Empresa A
  v_denied := false;
  v_err_msg := '';
  v_err_state := '';
  BEGIN
    PERFORM public.tf_transition_order_status(
      p_order_id => v_order_a_id,
      p_version => v_order_version,
      p_status => 'diagnostico'
    );
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_err_state = RETURNED_SQLSTATE, v_err_msg = MESSAGE_TEXT;
    IF v_err_state = 'P0001' AND (v_err_msg ILIKE '%não encontrad%' OR v_err_msg ILIKE '%não pertence%') THEN
      v_denied := true;
      v_denied_count := v_denied_count + 1;
    ELSE
      RAISE EXCEPTION 'Erro inesperado em 5.5. SQLSTATE: %, Mensagem: %', v_err_state, v_err_msg;
    END IF;
  END;
  IF NOT v_denied THEN
    RAISE EXCEPTION 'FALHA DE SEGURANÇA: Empresa B conseguiu alterar status de OS da Empresa A!';
  END IF;

  IF v_denied_count <> 5 THEN
    RAISE EXCEPTION 'FALHA: Contagem de bloqueios de escrita cruzada incorreta: % (esperado: 5)', v_denied_count;
  END IF;

  v_tested_checks := v_tested_checks + 1;
  RAISE NOTICE '✓ [PASS] Escrita cruzada 100%% bloqueada para Empresa B em todos os módulos operacionais com verificação de erro';

  -- --------------------------------------------------------------------------
  -- TESTE 6: Negação Estrita de Acesso Anônimo / Não Autenticado
  -- --------------------------------------------------------------------------
  PERFORM set_config('request.jwt.claim.sub', '', true);
  PERFORM set_config('request.jwt.claims', '', true);

  v_denied_count := 0;

  -- 6.1 tf_sync_current_user anônimo
  v_denied := false;
  v_err_msg := '';
  v_err_state := '';
  BEGIN
    PERFORM public.tf_sync_current_user();
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_err_state = RETURNED_SQLSTATE, v_err_msg = MESSAGE_TEXT;
    IF v_err_state = 'P0001' AND (v_err_msg ILIKE '%não autenticado%' OR v_err_msg ILIKE '%inválida ou expirada%') THEN
      v_denied := true;
      v_denied_count := v_denied_count + 1;
    ELSE
      RAISE EXCEPTION 'Erro inesperado em 6.1. SQLSTATE: %, Mensagem: %', v_err_state, v_err_msg;
    END IF;
  END;
  IF NOT v_denied THEN
    RAISE EXCEPTION 'FALHA DE SEGURANÇA: Chamada anônima a tf_sync_current_user foi aceita!';
  END IF;

  -- 6.2 tf_get_clients anônimo
  v_denied := false;
  v_err_msg := '';
  v_err_state := '';
  BEGIN
    PERFORM public.tf_get_clients();
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_err_state = RETURNED_SQLSTATE, v_err_msg = MESSAGE_TEXT;
    IF v_err_state = 'P0001' AND (v_err_msg ILIKE '%não autorizado%' OR v_err_msg ILIKE '%não autenticada%') THEN
      v_denied := true;
      v_denied_count := v_denied_count + 1;
    ELSE
      RAISE EXCEPTION 'Erro inesperado em 6.2. SQLSTATE: %, Mensagem: %', v_err_state, v_err_msg;
    END IF;
  END;
  IF NOT v_denied THEN
    RAISE EXCEPTION 'FALHA DE SEGURANÇA: Chamada anônima a tf_get_clients foi aceita!';
  END IF;

  -- 6.3 tf_get_inventory anônimo
  v_denied := false;
  v_err_msg := '';
  v_err_state := '';
  BEGIN
    PERFORM public.tf_get_inventory();
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_err_state = RETURNED_SQLSTATE, v_err_msg = MESSAGE_TEXT;
    IF v_err_state = 'P0001' AND (v_err_msg ILIKE '%não autorizado%' OR v_err_msg ILIKE '%não autenticada%') THEN
      v_denied := true;
      v_denied_count := v_denied_count + 1;
    ELSE
      RAISE EXCEPTION 'Erro inesperado em 6.3. SQLSTATE: %, Mensagem: %', v_err_state, v_err_msg;
    END IF;
  END;
  IF NOT v_denied THEN
    RAISE EXCEPTION 'FALHA DE SEGURANÇA: Chamada anônima a tf_get_inventory foi aceita!';
  END IF;

  -- 6.4 tf_get_orders anônimo
  v_denied := false;
  v_err_msg := '';
  v_err_state := '';
  BEGIN
    PERFORM public.tf_get_orders();
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_err_state = RETURNED_SQLSTATE, v_err_msg = MESSAGE_TEXT;
    IF v_err_state = 'P0001' AND (v_err_msg ILIKE '%não autorizado%' OR v_err_msg ILIKE '%não autenticada%') THEN
      v_denied := true;
      v_denied_count := v_denied_count + 1;
    ELSE
      RAISE EXCEPTION 'Erro inesperado em 6.4. SQLSTATE: %, Mensagem: %', v_err_state, v_err_msg;
    END IF;
  END;
  IF NOT v_denied THEN
    RAISE EXCEPTION 'FALHA DE SEGURANÇA: Chamada anônima a tf_get_orders foi aceita!';
  END IF;

  IF v_denied_count <> 4 THEN
    RAISE EXCEPTION 'FALHA: Chamadas anônimas não foram devidamente recusadas: % (esperado: 4)', v_denied_count;
  END IF;

  v_tested_checks := v_tested_checks + 1;
  RAISE NOTICE '✓ [PASS] Acesso anônimo recusado com exceção obrigatória para todas as RPCs públicas';

  -- --------------------------------------------------------------------------
  -- TESTE 7: Meta-Teste de Auditoria (Prova de que função vulnerável faz o teste falhar)
  -- --------------------------------------------------------------------------
  -- Objetivo: Comprovar formalmente que o padrão de verificação não gera falsos
  -- positivos e que, se uma RPC contiver falha de segurança (vazamento multiempresa),
  -- o harness de teste obrigatoriamente REJEITA a execução com falha de segurança.
  
  -- 7.1 Criamos temporariamente uma RPC mock propositalmente vulnerável
  EXECUTE $mock$
    CREATE OR REPLACE FUNCTION public._tf_meta_test_vulnerable(p_client_id TEXT)
    RETURNS JSONB
    LANGUAGE plpgsql
    SECURITY DEFINER
    SET search_path = ''
    AS $$
    DECLARE
      v_row RECORD;
    BEGIN
      -- FALHA INTENCIONAL DE AUDITORIA: Seleciona cliente ignorando o tenant do chamador
      SELECT id, name INTO v_row FROM tecniflow.clients WHERE id = p_client_id;
      IF NOT FOUND THEN
        RAISE EXCEPTION 'Cliente não encontrado.';
      END IF;
      RETURN jsonb_build_object('client', to_jsonb(v_row));
    END;
    $$;
  $mock$;

  -- 7.2 Simulamos Empresa B tentando chamar a RPC vulnerável para acessar o cliente da Empresa A
  PERFORM set_config('request.jwt.claim.sub', v_uid_b::text, true);
  PERFORM set_config('request.jwt.claims', jsonb_build_object('sub', v_uid_b::text, 'role', 'authenticated')::text, true);

  v_meta_test_detected_vuln := false;
  BEGIN
    -- Aplicamos o mesmo padrão rigoroso de validação de isolamento multiempresa
    v_denied := false;
    v_err_msg := '';
    v_err_state := '';
    BEGIN
      PERFORM public._tf_meta_test_vulnerable(v_client_a_id);
    EXCEPTION WHEN OTHERS THEN
      GET STACKED DIAGNOSTICS v_err_state = RETURNED_SQLSTATE, v_err_msg = MESSAGE_TEXT;
      IF v_err_state = 'P0001' AND (v_err_msg ILIKE '%não encontrad%' OR v_err_msg ILIKE '%não pertence%') THEN
        v_denied := true;
      END IF;
    END;

    -- Se a função vulnerável retornar sem erro (vazou dados), v_denied permanece FALSE!
    IF NOT v_denied THEN
      RAISE EXCEPTION 'VULNERABILIDADE_DETECTADA: Função vulnerável permitiu acesso cruzado sem bloqueio!';
    END IF;

  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_err_state = RETURNED_SQLSTATE, v_err_msg = MESSAGE_TEXT;
    IF v_err_msg ILIKE '%VULNERABILIDADE_DETECTADA%' THEN
      v_meta_test_detected_vuln := true;
    ELSE
      -- Erro anômalo no próprio meta-teste
      RAISE EXCEPTION 'Erro anômalo no meta-teste: % (SQLSTATE: %)', v_err_msg, v_err_state;
    END IF;
  END;

  -- 7.3 Comprovação: o harness DEVE ter detectado a vulnerabilidade
  IF NOT v_meta_test_detected_vuln THEN
    RAISE EXCEPTION 'FALHA DO MECANISMO DE AUDITORIA: O teste de segurança não detectou a função propositadamente vulnerável!';
  END IF;

  -- 7.4 Limpeza imediata da RPC mock
  EXECUTE 'DROP FUNCTION IF EXISTS public._tf_meta_test_vulnerable(TEXT)';

  v_tested_checks := v_tested_checks + 1;
  RAISE NOTICE '✓ [PASS] Meta-teste de auditoria: comprovado formalmente que função vulnerável faz o harness falhar';

  -- --------------------------------------------------------------------------
  -- TESTE 8: Permissões Reais das Roles PostgreSQL ('anon' e 'authenticated')
  -- --------------------------------------------------------------------------
  -- Utiliza SET LOCAL ROLE para testar sob os privilégios reais do PostgreSQL,
  -- comprovando que a camada nativa do banco bloqueia com SQLSTATE 42501
  -- qualquer consulta ou alteração direta nas tabelas privadas de tecniflow.*
  
  -- 8.1 Role 'anon': Tentativa de SELECT direto em tecniflow.clients
  EXECUTE 'SET LOCAL ROLE anon';
  v_denied := false;
  v_err_msg := '';
  v_err_state := '';
  BEGIN
    EXECUTE 'SELECT count(*) FROM tecniflow.clients';
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_err_state = RETURNED_SQLSTATE, v_err_msg = MESSAGE_TEXT;
    IF v_err_state = '42501' THEN
      v_denied := true;
    ELSE
      RAISE EXCEPTION 'Role anon: Erro inesperado ao consultar tecniflow.clients. SQLSTATE: %, Mensagem: %', v_err_state, v_err_msg;
    END IF;
  END;
  EXECUTE 'RESET ROLE';
  IF NOT v_denied THEN
    RAISE EXCEPTION 'FALHA CRÍTICA DE PRIVILÉGIOS: Role anon possui permissão de leitura direta em tecniflow.clients!';
  END IF;

  -- 8.2 Role 'anon': Tentativa de SELECT direto em tecniflow.companies
  EXECUTE 'SET LOCAL ROLE anon';
  v_denied := false;
  v_err_msg := '';
  v_err_state := '';
  BEGIN
    EXECUTE 'SELECT count(*) FROM tecniflow.companies';
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_err_state = RETURNED_SQLSTATE, v_err_msg = MESSAGE_TEXT;
    IF v_err_state = '42501' THEN
      v_denied := true;
    ELSE
      RAISE EXCEPTION 'Role anon: Erro inesperado ao consultar tecniflow.companies. SQLSTATE: %, Mensagem: %', v_err_state, v_err_msg;
    END IF;
  END;
  EXECUTE 'RESET ROLE';
  IF NOT v_denied THEN
    RAISE EXCEPTION 'FALHA CRÍTICA DE PRIVILÉGIOS: Role anon possui permissão de leitura direta em tecniflow.companies!';
  END IF;

  -- 8.3 Role 'authenticated': Tentativa de SELECT direto em tecniflow.clients
  EXECUTE 'SET LOCAL ROLE authenticated';
  v_denied := false;
  v_err_msg := '';
  v_err_state := '';
  BEGIN
    EXECUTE 'SELECT count(*) FROM tecniflow.clients';
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_err_state = RETURNED_SQLSTATE, v_err_msg = MESSAGE_TEXT;
    IF v_err_state = '42501' THEN
      v_denied := true;
    ELSE
      RAISE EXCEPTION 'Role authenticated: Erro inesperado ao consultar tecniflow.clients. SQLSTATE: %, Mensagem: %', v_err_state, v_err_msg;
    END IF;
  END;
  EXECUTE 'RESET ROLE';
  IF NOT v_denied THEN
    RAISE EXCEPTION 'FALHA CRÍTICA DE PRIVILÉGIOS: Role authenticated possui permissão de leitura direta em tecniflow.clients!';
  END IF;

  -- 8.4 Role 'authenticated': Tentativa de INSERT direto em tecniflow.companies
  EXECUTE 'SET LOCAL ROLE authenticated';
  v_denied := false;
  v_err_msg := '';
  v_err_state := '';
  BEGIN
    EXECUTE 'INSERT INTO tecniflow.companies (id, name) VALUES (''invasao_id'', ''Invasão'')';
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_err_state = RETURNED_SQLSTATE, v_err_msg = MESSAGE_TEXT;
    IF v_err_state = '42501' THEN
      v_denied := true;
    ELSE
      RAISE EXCEPTION 'Role authenticated: Erro inesperado ao tentar INSERT em tecniflow.companies. SQLSTATE: %, Mensagem: %', v_err_state, v_err_msg;
    END IF;
  END;
  EXECUTE 'RESET ROLE';
  IF NOT v_denied THEN
    RAISE EXCEPTION 'FALHA CRÍTICA DE PRIVILÉGIOS: Role authenticated possui permissão de escrita direta em tecniflow.companies!';
  END IF;

  -- 8.5 Role 'authenticated': Tentativa de UPDATE direto em tecniflow.orders
  EXECUTE 'SET LOCAL ROLE authenticated';
  v_denied := false;
  v_err_msg := '';
  v_err_state := '';
  BEGIN
    EXECUTE 'UPDATE tecniflow.orders SET status = ''finalizado'' WHERE false';
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_err_state = RETURNED_SQLSTATE, v_err_msg = MESSAGE_TEXT;
    IF v_err_state = '42501' THEN
      v_denied := true;
    ELSE
      RAISE EXCEPTION 'Role authenticated: Erro inesperado ao tentar UPDATE em tecniflow.orders. SQLSTATE: %, Mensagem: %', v_err_state, v_err_msg;
    END IF;
  END;
  EXECUTE 'RESET ROLE';
  IF NOT v_denied THEN
    RAISE EXCEPTION 'FALHA CRÍTICA DE PRIVILÉGIOS: Role authenticated possui permissão de escrita direta em tecniflow.orders!';
  END IF;

  v_tested_checks := v_tested_checks + 1;
  RAISE NOTICE '✓ [PASS] Privilégios reais de roles: SELECT, INSERT e UPDATE diretos bloqueados com SQLSTATE 42501 para anon e authenticated';

  -- --------------------------------------------------------------------------
  -- TESTE 9: Verificação Estática de Privilégios das Tabelas Privadas tecniflow.*
  -- --------------------------------------------------------------------------
  IF has_table_privilege('anon', 'tecniflow.companies', 'SELECT') OR
     has_table_privilege('authenticated', 'tecniflow.companies', 'SELECT') OR
     has_table_privilege('anon', 'tecniflow.clients', 'SELECT') OR
     has_table_privilege('authenticated', 'tecniflow.clients', 'SELECT') OR
     has_table_privilege('anon', 'tecniflow.orders', 'SELECT') OR
     has_table_privilege('authenticated', 'tecniflow.orders', 'SELECT') THEN
    RAISE EXCEPTION 'FALHA DE SEGURANÇA: has_table_privilege retornou true para anon ou authenticated em tabelas privadas!';
  END IF;

  v_tested_checks := v_tested_checks + 1;
  RAISE NOTICE '✓ [PASS] Schema tecniflow 100%% privado: sem concessão de SELECT direto em has_table_privilege';

  -- --------------------------------------------------------------------------
  -- TESTE 10: Auditoria de Convivência e Integridade do Projeto Compartilhado
  -- --------------------------------------------------------------------------
  -- Nota de Convivência: Inserções transitórias em auth.users podem acionar
  -- o trigger handle_new_user do controle de gastos durante a transação.
  -- A garantia estrita de preservação total do banco compartilhado é assegurada
  -- pela atomicidade ACID do encerramento com ROLLBACK incondicional.
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'profiles') THEN
    EXECUTE 'SELECT count(*) FROM public.profiles' INTO v_final_profiles_count;
    RAISE NOTICE 'Auditoria public.profiles: Inicial: %, Durante transação: % (disparos de trigger transitórios revertidos no ROLLBACK)',
      v_initial_profiles_count, v_final_profiles_count;
  END IF;

  v_tested_checks := v_tested_checks + 1;
  RAISE NOTICE '✓ [PASS] Compatibilidade com triggers do controle de gastos verificada; preservação assegurada por ROLLBACK';

  RAISE NOTICE '================================================================';
  RAISE NOTICE 'SUCESSO TOTAL: % baterias de auditoria aprovadas com louvor.', v_tested_checks;
  RAISE NOTICE 'Executando ROLLBACK obrigatório para garantir zero persistência.';
  RAISE NOTICE '================================================================';
END $audit$;

-- Encerramento OBRIGATÓRIO: reverte todas as inserções, identidades, mocks e testes
ROLLBACK;
