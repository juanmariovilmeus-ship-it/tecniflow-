-- ============================================================================
-- TECNIFLOW - SCHEMA DEDICADO POSTGRESQL (SUPABASE)
-- Schema: tecniflow
-- Executável de forma transacional, idempotente e sem dados de exemplo.
-- Isolamento multi-tenant estrito com chaves compostas (id, company_id).
-- Bloqueio total de acesso via Data API (anon, authenticated, PUBLIC) e RLS padrão.
-- ============================================================================

BEGIN;

-- 1. Criação do Schema Dedicado
CREATE SCHEMA IF NOT EXISTS tecniflow;

-- 2. Tabela de Empresas / Assistências Técnicas
CREATE TABLE IF NOT EXISTS tecniflow.companies (
  id VARCHAR(36) PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  document VARCHAR(50) NOT NULL DEFAULT '',
  phone VARCHAR(30) NOT NULL DEFAULT '',
  whatsapp VARCHAR(30) NOT NULL DEFAULT '',
  email VARCHAR(100) NOT NULL DEFAULT '',
  address VARCHAR(255) NOT NULL DEFAULT '',
  warranty_terms TEXT NOT NULL DEFAULT '',
  receipt_notes TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 3. Tabela de Usuários
CREATE TABLE IF NOT EXISTS tecniflow.users (
  id VARCHAR(36) PRIMARY KEY,
  company_id VARCHAR(36) NOT NULL REFERENCES tecniflow.companies(id) ON DELETE CASCADE,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL DEFAULT 'owner',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT uq_users_id_company UNIQUE (id, company_id)
);

-- 4. Tabela de Sessões de Usuário
CREATE TABLE IF NOT EXISTS tecniflow.sessions (
  id VARCHAR(36) PRIMARY KEY,
  user_id VARCHAR(36) NOT NULL,
  company_id VARCHAR(36) NOT NULL REFERENCES tecniflow.companies(id) ON DELETE CASCADE,
  token_hash VARCHAR(64) NOT NULL UNIQUE,
  csrf_token VARCHAR(64) NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  FOREIGN KEY (user_id, company_id) REFERENCES tecniflow.users(id, company_id) ON DELETE CASCADE
);

-- 5. Tabela de Tentativas de Login e Rate Limiting
CREATE TABLE IF NOT EXISTS tecniflow.login_attempts (
  identifier VARCHAR(150) PRIMARY KEY,
  attempts INTEGER NOT NULL DEFAULT 1,
  last_attempt_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  locked_until TIMESTAMPTZ
);

-- 6. Tabela de Clientes
CREATE TABLE IF NOT EXISTS tecniflow.clients (
  id VARCHAR(36) PRIMARY KEY,
  company_id VARCHAR(36) NOT NULL REFERENCES tecniflow.companies(id) ON DELETE CASCADE,
  name VARCHAR(100) NOT NULL,
  phone VARCHAR(30) NOT NULL,
  whatsapp VARCHAR(30) NOT NULL DEFAULT '',
  email VARCHAR(100) NOT NULL DEFAULT '',
  document VARCHAR(50) NOT NULL DEFAULT '',
  address VARCHAR(255) NOT NULL DEFAULT '',
  notes TEXT NOT NULL DEFAULT '',
  is_archived SMALLINT NOT NULL DEFAULT 0 CHECK (is_archived IN (0, 1)),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT uq_clients_id_company UNIQUE (id, company_id)
);

-- 7. Tabela de Itens de Estoque e Peças
CREATE TABLE IF NOT EXISTS tecniflow.inventory_items (
  id VARCHAR(36) PRIMARY KEY,
  company_id VARCHAR(36) NOT NULL REFERENCES tecniflow.companies(id) ON DELETE CASCADE,
  name VARCHAR(150) NOT NULL,
  sku VARCHAR(50) NOT NULL DEFAULT '',
  category VARCHAR(50) NOT NULL DEFAULT 'geral',
  quantity INTEGER NOT NULL DEFAULT 0 CHECK (quantity >= 0),
  min_quantity INTEGER NOT NULL DEFAULT 1 CHECK (min_quantity >= 0),
  cost_price_cents BIGINT NOT NULL DEFAULT 0 CHECK (cost_price_cents >= 0),
  sale_price_cents BIGINT NOT NULL DEFAULT 0 CHECK (sale_price_cents >= 0),
  is_archived SMALLINT NOT NULL DEFAULT 0 CHECK (is_archived IN (0, 1)),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT uq_inventory_items_id_company UNIQUE (id, company_id)
);

-- 8. Tabela de Ordens de Serviço (OS)
CREATE TABLE IF NOT EXISTS tecniflow.orders (
  id VARCHAR(36) PRIMARY KEY,
  company_id VARCHAR(36) NOT NULL REFERENCES tecniflow.companies(id) ON DELETE CASCADE,
  order_number INTEGER NOT NULL CHECK (order_number > 0),
  client_id VARCHAR(36) NOT NULL,
  device_type VARCHAR(50) NOT NULL,
  brand VARCHAR(50) NOT NULL,
  model VARCHAR(50) NOT NULL,
  serial_imei VARCHAR(50) NOT NULL DEFAULT '',
  defect_reported TEXT NOT NULL,
  accessories VARCHAR(255) NOT NULL DEFAULT '',
  entry_condition TEXT NOT NULL DEFAULT '',
  technical_diagnosis TEXT NOT NULL DEFAULT '',
  priority VARCHAR(20) NOT NULL DEFAULT 'normal',
  estimated_delivery VARCHAR(50) NOT NULL DEFAULT '',
  status VARCHAR(30) NOT NULL DEFAULT 'recebido',
  cancellation_reason TEXT NOT NULL DEFAULT '',
  budget_status VARCHAR(30) NOT NULL DEFAULT 'pendente',
  budget_approved_at TIMESTAMPTZ,
  budget_approved_by VARCHAR(100),
  total_services_cents BIGINT NOT NULL DEFAULT 0 CHECK (total_services_cents >= 0),
  total_parts_cents BIGINT NOT NULL DEFAULT 0 CHECK (total_parts_cents >= 0),
  total_amount_cents BIGINT NOT NULL DEFAULT 0 CHECK (total_amount_cents >= 0),
  received_amount_cents BIGINT NOT NULL DEFAULT 0 CHECK (received_amount_cents >= 0),
  payment_method VARCHAR(50) NOT NULL DEFAULT '',
  payment_date TIMESTAMPTZ,
  version INTEGER NOT NULL DEFAULT 1 CHECK (version >= 1),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ,
  FOREIGN KEY (client_id, company_id) REFERENCES tecniflow.clients(id, company_id),
  CONSTRAINT uq_orders_company_number UNIQUE (company_id, order_number),
  CONSTRAINT uq_orders_id_company UNIQUE (id, company_id)
);

-- 9. Tabela de Serviços da Ordem de Serviço
CREATE TABLE IF NOT EXISTS tecniflow.order_services (
  id VARCHAR(36) PRIMARY KEY,
  company_id VARCHAR(36) NOT NULL REFERENCES tecniflow.companies(id) ON DELETE CASCADE,
  order_id VARCHAR(36) NOT NULL,
  description VARCHAR(255) NOT NULL,
  unit_price_cents BIGINT NOT NULL CHECK (unit_price_cents >= 0),
  quantity INTEGER NOT NULL DEFAULT 1 CHECK (quantity > 0),
  total_cents BIGINT NOT NULL CHECK (total_cents >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  FOREIGN KEY (order_id, company_id) REFERENCES tecniflow.orders(id, company_id) ON DELETE CASCADE
);

-- 10. Tabela de Peças Aplicadas na Ordem de Serviço
CREATE TABLE IF NOT EXISTS tecniflow.order_parts (
  id VARCHAR(36) PRIMARY KEY,
  company_id VARCHAR(36) NOT NULL REFERENCES tecniflow.companies(id) ON DELETE CASCADE,
  order_id VARCHAR(36) NOT NULL,
  inventory_item_id VARCHAR(36),
  description VARCHAR(255) NOT NULL,
  unit_price_cents BIGINT NOT NULL CHECK (unit_price_cents >= 0),
  quantity INTEGER NOT NULL DEFAULT 1 CHECK (quantity > 0),
  total_cents BIGINT NOT NULL CHECK (total_cents >= 0),
  inventory_debited SMALLINT NOT NULL DEFAULT 0 CHECK (inventory_debited IN (0, 1)),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  FOREIGN KEY (order_id, company_id) REFERENCES tecniflow.orders(id, company_id) ON DELETE CASCADE,
  FOREIGN KEY (inventory_item_id, company_id) REFERENCES tecniflow.inventory_items(id, company_id)
);

-- 11. Tabela de Movimentações de Estoque
CREATE TABLE IF NOT EXISTS tecniflow.inventory_movements (
  id VARCHAR(36) PRIMARY KEY,
  company_id VARCHAR(36) NOT NULL REFERENCES tecniflow.companies(id) ON DELETE CASCADE,
  item_id VARCHAR(36) NOT NULL,
  type VARCHAR(30) NOT NULL,
  quantity INTEGER NOT NULL,
  previous_quantity INTEGER NOT NULL,
  new_quantity INTEGER NOT NULL,
  order_id VARCHAR(36),
  reason VARCHAR(255) NOT NULL,
  user_name VARCHAR(100) NOT NULL DEFAULT 'Sistema',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  FOREIGN KEY (item_id, company_id) REFERENCES tecniflow.inventory_items(id, company_id) ON DELETE CASCADE,
  FOREIGN KEY (order_id, company_id) REFERENCES tecniflow.orders(id, company_id)
);

-- 12. Tabela de Histórico e Linha do Tempo da OS
CREATE TABLE IF NOT EXISTS tecniflow.order_history (
  id VARCHAR(36) PRIMARY KEY,
  company_id VARCHAR(36) NOT NULL REFERENCES tecniflow.companies(id) ON DELETE CASCADE,
  order_id VARCHAR(36) NOT NULL,
  action VARCHAR(50) NOT NULL,
  description TEXT NOT NULL,
  user_name VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  FOREIGN KEY (order_id, company_id) REFERENCES tecniflow.orders(id, company_id) ON DELETE CASCADE
);

-- 13. Índices de Alta Eficiência
CREATE INDEX IF NOT EXISTS idx_users_company_id ON tecniflow.users(company_id);
CREATE INDEX IF NOT EXISTS idx_users_email ON tecniflow.users(email);
CREATE INDEX IF NOT EXISTS idx_sessions_token_hash ON tecniflow.sessions(token_hash);
CREATE INDEX IF NOT EXISTS idx_sessions_company_user ON tecniflow.sessions(company_id, user_id);
CREATE INDEX IF NOT EXISTS idx_clients_company_created ON tecniflow.clients(company_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_clients_company_search ON tecniflow.clients(company_id, name, phone);
CREATE INDEX IF NOT EXISTS idx_inventory_company_archived ON tecniflow.inventory_items(company_id, is_archived);
CREATE INDEX IF NOT EXISTS idx_inventory_company_name ON tecniflow.inventory_items(company_id, name);
CREATE INDEX IF NOT EXISTS idx_orders_company_status ON tecniflow.orders(company_id, status);
CREATE INDEX IF NOT EXISTS idx_orders_company_created ON tecniflow.orders(company_id, created_at);
CREATE INDEX IF NOT EXISTS idx_orders_company_completed ON tecniflow.orders(company_id, completed_at);
CREATE INDEX IF NOT EXISTS idx_order_services_order ON tecniflow.order_services(order_id, company_id);
CREATE INDEX IF NOT EXISTS idx_order_parts_order ON tecniflow.order_parts(order_id, company_id);
CREATE INDEX IF NOT EXISTS idx_inventory_movements_item ON tecniflow.inventory_movements(item_id, company_id);
CREATE INDEX IF NOT EXISTS idx_order_history_order ON tecniflow.order_history(order_id, company_id);

-- 14. Segurança e Isolamento: Bloqueio Total da Data API (Supabase PostgREST)
-- Revoga todos os acessos de PUBLIC, anon e authenticated no schema e suas tabelas
REVOKE ALL ON SCHEMA tecniflow FROM PUBLIC;
REVOKE ALL ON SCHEMA tecniflow FROM anon;
REVOKE ALL ON SCHEMA tecniflow FROM authenticated;

REVOKE ALL ON ALL TABLES IN SCHEMA tecniflow FROM PUBLIC;
REVOKE ALL ON ALL TABLES IN SCHEMA tecniflow FROM anon;
REVOKE ALL ON ALL TABLES IN SCHEMA tecniflow FROM authenticated;

REVOKE ALL ON ALL SEQUENCES IN SCHEMA tecniflow FROM PUBLIC;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA tecniflow FROM anon;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA tecniflow FROM authenticated;

REVOKE ALL ON ALL ROUTINES IN SCHEMA tecniflow FROM PUBLIC;
REVOKE ALL ON ALL ROUTINES IN SCHEMA tecniflow FROM anon;
REVOKE ALL ON ALL ROUTINES IN SCHEMA tecniflow FROM authenticated;

ALTER DEFAULT PRIVILEGES IN SCHEMA tecniflow REVOKE ALL ON TABLES FROM PUBLIC, anon, authenticated;
ALTER DEFAULT PRIVILEGES IN SCHEMA tecniflow REVOKE ALL ON SEQUENCES FROM PUBLIC, anon, authenticated;
ALTER DEFAULT PRIVILEGES IN SCHEMA tecniflow REVOKE ALL ON ROUTINES FROM PUBLIC, anon, authenticated;

-- 15. Habilitação de RLS Padrão (Default Deny) em Todas as Tabelas
ALTER TABLE tecniflow.companies ENABLE ROW LEVEL SECURITY;
ALTER TABLE tecniflow.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE tecniflow.sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE tecniflow.login_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE tecniflow.clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE tecniflow.inventory_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE tecniflow.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE tecniflow.order_services ENABLE ROW LEVEL SECURITY;
ALTER TABLE tecniflow.order_parts ENABLE ROW LEVEL SECURITY;
ALTER TABLE tecniflow.inventory_movements ENABLE ROW LEVEL SECURITY;
ALTER TABLE tecniflow.order_history ENABLE ROW LEVEL SECURITY;

COMMIT;
