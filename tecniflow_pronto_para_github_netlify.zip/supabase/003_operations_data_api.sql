-- ============================================================================
-- TECNIFLOW - MIGRAÇÃO INCREMENTAL 003: CAMADA OPERACIONAL COMPLETA EM NUVEM
-- Schema Privado: tecniflow
-- RPCs Públicas Explícitas: public.tf_* (SECURITY DEFINER, search_path = '')
-- Autorização Estrita: resolvida exclusivamente por auth.uid() e vínculo auth_user_id
-- Idempotente, transacional, sem DROP/TRUNCATE de dados preexistentes
-- ============================================================================

BEGIN;

-- 1. ADICIONAR COLUNA E ÍNDICE UNIQUE PARA VÍNCULO COM auth.users (SE NECESSÁRIO)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_schema = 'tecniflow' AND table_name = 'users' AND column_name = 'auth_user_id'
  ) THEN
    ALTER TABLE tecniflow.users ADD COLUMN auth_user_id UUID;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.schemata WHERE schema_name = 'auth') THEN
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.table_constraints
      WHERE constraint_schema = 'tecniflow' AND table_name = 'users' AND constraint_name = 'fk_users_auth_users'
    ) THEN
      ALTER TABLE tecniflow.users 
        ADD CONSTRAINT fk_users_auth_users 
        FOREIGN KEY (auth_user_id) REFERENCES auth.users(id) ON DELETE CASCADE;
    END IF;
  END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS idx_users_auth_user_id ON tecniflow.users(auth_user_id);

-- 2. FUNÇÕES INTERNAS DE RESOLUÇÃO DE IDENTIDADE E EMPRESA (SCHEMA tecniflow)
CREATE OR REPLACE FUNCTION tecniflow.current_company_id()
RETURNS VARCHAR(36)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_uid UUID;
  v_company_id VARCHAR(36);
BEGIN
  v_uid := (SELECT auth.uid());
  IF v_uid IS NULL THEN
    RETURN NULL;
  END IF;

  SELECT company_id INTO v_company_id
  FROM tecniflow.users
  WHERE auth_user_id = v_uid
  LIMIT 1;

  RETURN v_company_id;
END;
$$;

CREATE OR REPLACE FUNCTION tecniflow.current_user_name()
RETURNS VARCHAR(100)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_uid UUID;
  v_user_name VARCHAR(100);
BEGIN
  v_uid := (SELECT auth.uid());
  IF v_uid IS NULL THEN
    RETURN 'Sistema';
  END IF;

  SELECT name INTO v_user_name
  FROM tecniflow.users
  WHERE auth_user_id = v_uid
  LIMIT 1;

  RETURN COALESCE(v_user_name, 'Sistema');
END;
$$;

REVOKE ALL ON FUNCTION tecniflow.current_company_id() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION tecniflow.current_user_name() FROM PUBLIC, anon, authenticated;


CREATE OR REPLACE FUNCTION tecniflow.valid_phone(p text) RETURNS boolean
LANGUAGE plpgsql IMMUTABLE SET search_path='' AS $$
DECLARE d text; a text;
BEGIN
 IF p IS NULL OR p !~ '^[0-9+(). \-]+$' THEN RETURN false; END IF;
 d:=regexp_replace(p,'\D','','g');
 IF length(d) IN (12,13) AND left(d,2)='55' THEN d:=substring(d FROM 3); END IF;
 IF length(d) NOT IN (10,11) OR d ~ '^(\d)\1+$' THEN RETURN false; END IF;
 a:=left(d,2);
 IF NOT a=ANY(ARRAY['11','12','13','14','15','16','17','18','19','21','22','24','27','28','31','32','33','34','35','37','38','41','42','43','44','45','46','47','48','49','51','53','54','55','61','62','63','64','65','66','67','68','69','71','73','74','75','77','79','81','82','83','84','85','86','87','88','89','91','92','93','94','95','96','97','98','99']) THEN RETURN false; END IF;
 RETURN (length(d)=11 AND substring(d,3,1)='9') OR (length(d)=10 AND substring(d,3,1) BETWEEN '2' AND '5');
END; $$;
CREATE OR REPLACE FUNCTION tecniflow.valid_document(p text) RETURNS boolean
LANGUAGE plpgsql IMMUTABLE SET search_path='' AS $$
DECLARE d text; n int; z int; k int; i int; w int[];
BEGIN
 IF p IS NULL OR btrim(p)='' THEN RETURN true; END IF;
 IF upper(p) !~ '^[A-Z0-9./ \-]+$' THEN RETURN false; END IF;
 d:=regexp_replace(upper(p),'[./ \-]','','g');
 IF d ~ '^[0-9]{11}$' THEN
  IF d ~ '^(\d)\1+$' THEN RETURN false; END IF;
  FOR k IN 9..10 LOOP
   n:=0; FOR i IN 1..k LOOP n:=n+substring(d,i,1)::int*(k+2-i); END LOOP;
   z:=CASE WHEN n%11<2 THEN 0 ELSE 11-n%11 END;
   IF z<>substring(d,k+1,1)::int THEN RETURN false; END IF;
  END LOOP;
  RETURN true;
 END IF;
 IF d !~ '^[A-Z0-9]{12}[0-9]{2}$' OR d ~ '^(.)\1+$' THEN RETURN false; END IF;
 FOR k IN 12..13 LOOP
  w:=CASE WHEN k=12 THEN ARRAY[5,4,3,2,9,8,7,6,5,4,3,2] ELSE ARRAY[6,5,4,3,2,9,8,7,6,5,4,3,2] END;
  n:=0; FOR i IN 1..k LOOP n:=n+(ascii(substring(d,i,1))-48)*w[i]; END LOOP;
  z:=CASE WHEN n%11<2 THEN 0 ELSE 11-n%11 END;
  IF z<>substring(d,k+1,1)::int THEN RETURN false; END IF;
 END LOOP;
 RETURN true;
END; $$;
CREATE OR REPLACE FUNCTION tecniflow.validate_contacts(p_phone text,p_whatsapp text,p_document text,p_email text,p_phone_required boolean DEFAULT true)
RETURNS void LANGUAGE plpgsql SET search_path='' AS $$
BEGIN
 IF (p_phone_required OR coalesce(btrim(p_phone),'')<>'') AND NOT tecniflow.valid_phone(p_phone) THEN RAISE EXCEPTION 'Telefone inválido. Informe DDD e número brasileiro válido.'; END IF;
 IF coalesce(btrim(p_whatsapp),'')<>'' AND NOT tecniflow.valid_phone(p_whatsapp) THEN RAISE EXCEPTION 'WhatsApp inválido. Informe DDD e número válido.'; END IF;
 IF NOT tecniflow.valid_document(p_document) THEN RAISE EXCEPTION 'CPF/CNPJ inválido. Confira os caracteres e dígitos verificadores.'; END IF;
 IF length(coalesce(p_email,''))>100 OR (coalesce(btrim(p_email),'')<>'' AND p_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$') THEN RAISE EXCEPTION 'E-mail de contato inválido.'; END IF;
END; $$;
CREATE OR REPLACE FUNCTION tecniflow.validate_order(p_device text,p_brand text,p_model text,p_defect text,p_priority text,p_date text,p_accessories text,p_condition text)
RETURNS void LANGUAGE plpgsql SET search_path='' AS $$
DECLARE d date;
BEGIN
 IF p_device IS NULL OR p_device NOT IN('smartphone','notebook','computador','tablet','smartwatch','outro') THEN RAISE EXCEPTION 'Tipo de aparelho inválido.'; END IF;
 IF coalesce(btrim(p_brand),'')='' OR length(p_brand)>50 OR coalesce(btrim(p_model),'')='' OR length(p_model)>50 THEN RAISE EXCEPTION 'Marca e modelo são obrigatórios (até 50 caracteres).'; END IF;
 IF coalesce(btrim(p_defect),'')='' OR length(p_defect)>500 THEN RAISE EXCEPTION 'Informe o defeito relatado (até 500 caracteres).'; END IF;
 IF p_priority IS NULL OR p_priority NOT IN('baixa','normal','alta','urgente') THEN RAISE EXCEPTION 'Prioridade inválida.'; END IF;
 IF coalesce(p_date,'')<>'' THEN
  IF p_date !~ '^\d{4}-\d{2}-\d{2}$' THEN RAISE EXCEPTION 'Previsão inválida. Use uma data do calendário.'; END IF;
  d:=p_date::date;
  IF to_char(d,'YYYY-MM-DD')<>p_date THEN RAISE EXCEPTION 'Previsão inválida.'; END IF;
 END IF;
 IF length(coalesce(p_accessories,''))>255 OR length(coalesce(p_condition,''))>500 THEN RAISE EXCEPTION 'Acessórios ou condições excedem o tamanho permitido.'; END IF;
 IF p_condition ILIKE '%Liga normalmente%' AND p_condition ILIKE '%Não liga%' THEN RAISE EXCEPTION 'Condições de entrada contraditórias.'; END IF;
 IF p_accessories ILIKE '%Nenhum acessório%' AND btrim(p_accessories)<>'Nenhum acessório' THEN RAISE EXCEPTION 'Nenhum acessório não pode ser combinado com outros itens.'; END IF;
END; $$;

-- ============================================================================
-- 3. RPC: SINCRONIZAÇÃO E PROVISIONAMENTO IDEMPOTENTE DO USUÁRIO ATUAL
-- ============================================================================
CREATE OR REPLACE FUNCTION public.tf_sync_current_user()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_uid UUID;
  v_user RECORD;
  v_company RECORD;
  v_auth_email text;
  v_raw_meta jsonb;
  v_company_id VARCHAR(36);
  v_user_id VARCHAR(36);
  v_company_name VARCHAR(100);
  v_company_doc VARCHAR(50);
  v_company_phone VARCHAR(30);
  v_company_whatsapp VARCHAR(30);
  v_company_address VARCHAR(255);
  v_owner_name VARCHAR(100);
  v_existing_conflict VARCHAR(36);
BEGIN
  v_uid := (SELECT auth.uid());
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Não autenticado. Sessão inválida ou expirada no Supabase Auth.';
  END IF;

  -- Lock transacional no nível de sessão do auth.uid() para evitar corridas concorrentes
  PERFORM pg_advisory_xact_lock(hashtext(v_uid::text));

  -- 1. Verifica se já existe vínculo estabelecido para este auth.uid()
  SELECT u.id, u.company_id, u.name, u.email, u.role
  INTO v_user
  FROM tecniflow.users u
  WHERE u.auth_user_id = v_uid;

  IF FOUND THEN
    SELECT c.id, c.name, c.document, c.phone, c.whatsapp, c.email, c.address, c.warranty_terms, c.receipt_notes
    INTO v_company
    FROM tecniflow.companies c
    WHERE c.id = v_user.company_id;

    RETURN jsonb_build_object(
      'user', to_jsonb(v_user),
      'company', to_jsonb(v_company)
    );
  END IF;

  -- 2. Não encontrado: obter dados do auth.users para provisionamento atômico
  SELECT email, raw_user_meta_data
  INTO v_auth_email, v_raw_meta
  FROM auth.users
  WHERE id = v_uid;

  IF v_auth_email IS NULL OR trim(v_auth_email) = '' THEN
    RAISE EXCEPTION 'E-mail do usuário autenticado não encontrado no Supabase Auth.';
  END IF;

  v_auth_email := lower(trim(v_auth_email));
  IF length(v_auth_email) > 100 THEN
    RAISE EXCEPTION 'E-mail de autenticação excede o limite permitido de 100 caracteres.';
  END IF;

  -- 3. Prevenção estrita de invasão/mesclagem por e-mail com contas legadas
  SELECT id INTO v_existing_conflict
  FROM tecniflow.users
  WHERE lower(email) = v_auth_email AND (auth_user_id IS NULL OR auth_user_id != v_uid)
  LIMIT 1;

  IF v_existing_conflict IS NOT NULL THEN
    RAISE EXCEPTION 'Conflito de cadastro: já existe um usuário registrado com este e-mail no banco. Para segurança dos dados, a unificação requer procedimento de migração e não é realizada automaticamente.';
  END IF;

  -- 4. Criar empresa e usuário vinculados de forma atômica
  v_company_id := gen_random_uuid()::text;
  v_user_id := gen_random_uuid()::text;

  v_company_name := substring(COALESCE(trim(v_raw_meta->>'company_name'), 'Minha Assistência Técnica'), 1, 100);
  v_company_doc := substring(COALESCE(trim(v_raw_meta->>'company_document'), ''), 1, 50);
  v_company_phone := substring(COALESCE(trim(v_raw_meta->>'company_phone'), ''), 1, 30);
  v_company_whatsapp := substring(COALESCE(trim(v_raw_meta->>'company_whatsapp'), ''), 1, 30);
  v_company_address := substring(COALESCE(trim(v_raw_meta->>'company_address'), ''), 1, 255);
  v_owner_name := substring(COALESCE(trim(v_raw_meta->>'owner_name'), 'Proprietário'), 1, 100);

  INSERT INTO tecniflow.companies (
    id, name, document, phone, whatsapp, email, address, warranty_terms, receipt_notes, created_at
  ) VALUES (
    v_company_id, v_company_name, v_company_doc, v_company_phone, v_company_whatsapp, v_auth_email, v_company_address, '', '', now()
  );

  INSERT INTO tecniflow.users (
    id, company_id, name, email, password_hash, role, auth_user_id, created_at
  ) VALUES (
    v_user_id, v_company_id, v_owner_name, v_auth_email, '', 'owner', v_uid, now()
  );

  SELECT u.id, u.company_id, u.name, u.email, u.role
  INTO v_user
  FROM tecniflow.users u
  WHERE u.id = v_user_id;

  SELECT c.id, c.name, c.document, c.phone, c.whatsapp, c.email, c.address, c.warranty_terms, c.receipt_notes
  INTO v_company
  FROM tecniflow.companies c
  WHERE c.id = v_company_id;

  RETURN jsonb_build_object(
    'user', to_jsonb(v_user),
    'company', to_jsonb(v_company)
  );
END;
$$;

-- ============================================================================
-- 4. RPCs DE CLIENTES (CRUD + ARQUIVAMENTO + BUSCA)
-- ============================================================================
CREATE OR REPLACE FUNCTION public.tf_get_clients(p_search text DEFAULT '', p_include_archived boolean DEFAULT false)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = '' AS $$
DECLARE
 v_company_id varchar(36);
 result jsonb;
BEGIN
 v_company_id := tecniflow.current_company_id();
 IF v_company_id IS NULL THEN RAISE EXCEPTION 'Acesso não autorizado.'; END IF;
 
 SELECT coalesce(jsonb_agg(x.obj ORDER BY x.created_at DESC),'[]'::jsonb) INTO result FROM (
 SELECT to_jsonb(c)||jsonb_build_object('total_orders',(SELECT count(*) FROM tecniflow.orders o WHERE o.client_id=c.id AND o.company_id=v_company_id)) obj,c.created_at
 FROM tecniflow.clients c WHERE c.company_id=v_company_id AND (p_include_archived OR c.is_archived=0)
 AND (coalesce(p_search,'')='' OR concat_ws(' ',c.name,c.phone,c.whatsapp,c.document,c.email) ILIKE '%'||p_search||'%')) x;
 RETURN jsonb_build_object('clients',result);
 
END;
$$;

CREATE OR REPLACE FUNCTION public.tf_create_client(
  p_name text,
  p_phone text,
  p_whatsapp text DEFAULT '',
  p_email text DEFAULT '',
  p_document text DEFAULT '',
  p_address text DEFAULT '',
  p_notes text DEFAULT ''
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_company_id VARCHAR(36);
  v_client_id VARCHAR(36);
  v_client RECORD;
  v_clean_phone text;
BEGIN
  v_company_id := tecniflow.current_company_id();
  IF v_company_id IS NULL THEN
    RAISE EXCEPTION 'Acesso não autorizado.';
  END IF;

  IF p_name IS NULL OR trim(p_name) = '' THEN
    RAISE EXCEPTION 'O nome do cliente é obrigatório.';
  END IF;

  PERFORM tecniflow.validate_contacts(p_phone,p_whatsapp,p_document,p_email);
  IF length(p_name)>100 OR length(coalesce(p_address,''))>255 OR length(coalesce(p_notes,''))>5000 THEN RAISE EXCEPTION 'Dados do cliente excedem o tamanho permitido.'; END IF;


  v_client_id := gen_random_uuid()::text;

  INSERT INTO tecniflow.clients (
    id, company_id, name, phone, whatsapp, email, document, address, notes, is_archived, created_at, updated_at
  ) VALUES (
    v_client_id,
    v_company_id,
    substring(trim(p_name), 1, 100),
    substring(trim(p_phone), 1, 30),
    substring(COALESCE(trim(p_whatsapp), ''), 1, 30),
    substring(lower(COALESCE(trim(p_email), '')), 1, 100),
    substring(COALESCE(trim(p_document), ''), 1, 50),
    substring(COALESCE(trim(p_address), ''), 1, 255),
    COALESCE(trim(p_notes), ''),
    0,
    now(),
    now()
  )
  RETURNING * INTO v_client;

  RETURN jsonb_build_object('client', to_jsonb(v_client));
END;
$$;

CREATE OR REPLACE FUNCTION public.tf_update_client(
  p_id text,
  p_name text,
  p_phone text,
  p_whatsapp text DEFAULT '',
  p_email text DEFAULT '',
  p_document text DEFAULT '',
  p_address text DEFAULT '',
  p_notes text DEFAULT ''
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_company_id VARCHAR(36);
  v_client RECORD;
  v_clean_phone text;
BEGIN
  v_company_id := tecniflow.current_company_id();
  IF v_company_id IS NULL THEN
    RAISE EXCEPTION 'Acesso não autorizado.';
  END IF;

  IF p_name IS NULL OR trim(p_name) = '' THEN
    RAISE EXCEPTION 'O nome do cliente é obrigatório.';
  END IF;

  PERFORM tecniflow.validate_contacts(p_phone,p_whatsapp,p_document,p_email);
  IF length(p_name)>100 OR length(coalesce(p_address,''))>255 OR length(coalesce(p_notes,''))>5000 THEN RAISE EXCEPTION 'Dados do cliente excedem o tamanho permitido.'; END IF;


  UPDATE tecniflow.clients
  SET name = substring(trim(p_name), 1, 100),
      phone = substring(trim(p_phone), 1, 30),
      whatsapp = substring(COALESCE(trim(p_whatsapp), ''), 1, 30),
      email = substring(lower(COALESCE(trim(p_email), '')), 1, 100),
      document = substring(COALESCE(trim(p_document), ''), 1, 50),
      address = substring(COALESCE(trim(p_address), ''), 1, 255),
      notes = COALESCE(trim(p_notes), ''),
      updated_at = now()
  WHERE id = p_id AND company_id = v_company_id
  RETURNING * INTO v_client;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Cliente não encontrado ou não pertence a esta empresa.';
  END IF;

  RETURN jsonb_build_object('client', to_jsonb(v_client));
END;
$$;

CREATE OR REPLACE FUNCTION public.tf_archive_client(
  p_id text,
  p_archived integer
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_company_id VARCHAR(36);
  v_flag smallint;
BEGIN
  v_company_id := tecniflow.current_company_id();
  IF v_company_id IS NULL THEN
    RAISE EXCEPTION 'Acesso não autorizado.';
  END IF;

  v_flag := CASE WHEN p_archived = 1 THEN 1 ELSE 0 END;

  UPDATE tecniflow.clients
  SET is_archived = v_flag, updated_at = now()
  WHERE id = p_id AND company_id = v_company_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Cliente não encontrado.';
  END IF;

  RETURN jsonb_build_object('success', true, 'is_archived', v_flag);
END;
$$;

-- ============================================================================
-- 5. RPCs DE ESTOQUE E PEÇAS (CRUD + MOVIMENTAÇÕES COM LOCKS)
-- ============================================================================
CREATE OR REPLACE FUNCTION public.tf_get_inventory()
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_company_id VARCHAR(36);
  v_items jsonb;
  v_summary RECORD;
BEGIN
  v_company_id := tecniflow.current_company_id();
  IF v_company_id IS NULL THEN
    RAISE EXCEPTION 'Acesso não autorizado.';
  END IF;

  SELECT COALESCE(jsonb_agg(to_jsonb(i) ORDER BY i.name ASC), '[]'::jsonb)
  INTO v_items
  FROM tecniflow.inventory_items i
  WHERE i.company_id = v_company_id;

  SELECT 
    COUNT(*)::int AS total_items,
    COALESCE(SUM(CASE WHEN quantity <= min_quantity THEN 1 ELSE 0 END), 0)::int AS low_stock_count,
    COALESCE(SUM(quantity * cost_price_cents), 0)::bigint AS total_cost_value_cents,
    COALESCE(SUM(quantity * sale_price_cents), 0)::bigint AS total_sale_value_cents
  INTO v_summary
  FROM tecniflow.inventory_items
  WHERE company_id = v_company_id AND is_archived = 0;

  RETURN jsonb_build_object(
    'items', v_items,
    'summary', to_jsonb(v_summary)
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.tf_create_inventory_item(
  p_name text,
  p_sku text DEFAULT '',
  p_category text DEFAULT 'geral',
  p_quantity integer DEFAULT 0,
  p_min_quantity integer DEFAULT 1,
  p_cost_price_cents bigint DEFAULT 0,
  p_sale_price_cents bigint DEFAULT 0
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_company_id VARCHAR(36);
  v_item_id VARCHAR(36);
  v_item RECORD;
  v_user_name VARCHAR(100);
BEGIN
  v_company_id := tecniflow.current_company_id();
  IF v_company_id IS NULL THEN
    RAISE EXCEPTION 'Acesso não autorizado.';
  END IF;

  IF p_min_quantity IS NULL OR p_cost_price_cents IS NULL OR p_sale_price_cents IS NULL OR greatest(p_cost_price_cents,p_sale_price_cents)>9007199254740991 THEN RAISE EXCEPTION 'Valores de estoque inválidos ou fora do limite seguro.'; END IF;
  IF p_quantity IS NULL OR p_quantity::numeric*greatest(p_cost_price_cents,p_sale_price_cents)>9007199254740991 THEN RAISE EXCEPTION 'Valor total do estoque excede o limite seguro.'; END IF;
  IF p_name IS NULL OR trim(p_name) = '' THEN
    RAISE EXCEPTION 'O nome da peça/componente é obrigatório.';
  END IF;

  IF p_quantity < 0 OR p_min_quantity < 0 OR p_cost_price_cents < 0 OR p_sale_price_cents < 0 THEN
    RAISE EXCEPTION 'Quantidades e valores monetários não podem ser negativos.';
  END IF;

  v_item_id := gen_random_uuid()::text;
  v_user_name := tecniflow.current_user_name();

  INSERT INTO tecniflow.inventory_items (
    id, company_id, name, sku, category, quantity, min_quantity, cost_price_cents, sale_price_cents, is_archived, created_at, updated_at
  ) VALUES (
    v_item_id,
    v_company_id,
    substring(trim(p_name), 1, 150),
    substring(COALESCE(trim(p_sku), ''), 1, 50),
    substring(COALESCE(trim(p_category), 'geral'), 1, 50),
    p_quantity,
    p_min_quantity,
    p_cost_price_cents,
    p_sale_price_cents,
    0,
    now(),
    now()
  ) RETURNING * INTO v_item;

  IF p_quantity > 0 THEN
    INSERT INTO tecniflow.inventory_movements (
      id, company_id, item_id, type, quantity, previous_quantity, new_quantity, reason, user_name, created_at
    ) VALUES (
      gen_random_uuid()::text,
      v_company_id,
      v_item_id,
      'entrada',
      p_quantity,
      0,
      p_quantity,
      'Saldo inicial de estoque',
      v_user_name,
      now()
    );
  END IF;

  RETURN jsonb_build_object('item', to_jsonb(v_item));
END;
$$;

CREATE OR REPLACE FUNCTION public.tf_update_inventory_item(
  p_id text,
  p_name text,
  p_sku text DEFAULT '',
  p_category text DEFAULT 'geral',
  p_min_quantity integer DEFAULT 1,
  p_cost_price_cents bigint DEFAULT 0,
  p_sale_price_cents bigint DEFAULT 0
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_company_id VARCHAR(36);
  v_item RECORD;
BEGIN
  v_company_id := tecniflow.current_company_id();
  IF v_company_id IS NULL THEN
    RAISE EXCEPTION 'Acesso não autorizado.';
  END IF;

  IF p_min_quantity IS NULL OR p_cost_price_cents IS NULL OR p_sale_price_cents IS NULL OR greatest(p_cost_price_cents,p_sale_price_cents)>9007199254740991 THEN RAISE EXCEPTION 'Valores de estoque inválidos ou fora do limite seguro.'; END IF;
  IF p_name IS NULL OR trim(p_name) = '' THEN
    RAISE EXCEPTION 'O nome da peça/componente é obrigatório.';
  END IF;

  IF p_min_quantity < 0 OR p_cost_price_cents < 0 OR p_sale_price_cents < 0 THEN
    RAISE EXCEPTION 'Quantidades e valores monetários não podem ser negativos.';
  END IF;

  UPDATE tecniflow.inventory_items
  SET name = substring(trim(p_name), 1, 150),
      sku = substring(COALESCE(trim(p_sku), ''), 1, 50),
      category = substring(COALESCE(trim(p_category), 'geral'), 1, 50),
      min_quantity = p_min_quantity,
      cost_price_cents = p_cost_price_cents,
      sale_price_cents = p_sale_price_cents,
      updated_at = now()
  WHERE id = p_id AND company_id = v_company_id
  RETURNING * INTO v_item;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Peça/componente não encontrado.';
  END IF;

  RETURN jsonb_build_object('item', to_jsonb(v_item));
END;
$$;

CREATE OR REPLACE FUNCTION public.tf_adjust_inventory(
  p_id text,
  p_type text,
  p_quantity integer,
  p_reason text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_company_id VARCHAR(36);
  v_item RECORD;
  v_new_qty integer;
  v_user_name VARCHAR(100);
BEGIN
  v_company_id := tecniflow.current_company_id();
  IF v_company_id IS NULL THEN
    RAISE EXCEPTION 'Acesso não autorizado.';
  END IF;

  IF p_quantity IS NULL OR p_quantity <= 0 THEN
    RAISE EXCEPTION 'A quantidade da movimentação deve ser maior que zero.';
  END IF;

  IF p_reason IS NULL OR trim(p_reason) = '' THEN
    RAISE EXCEPTION 'Informe a justificativa da movimentação de estoque.';
  END IF;

  -- Lock pessimista na linha do item para evitar concorrência
  SELECT * INTO v_item
  FROM tecniflow.inventory_items
  WHERE id = p_id AND company_id = v_company_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Peça/componente não encontrado.';
  END IF;

  IF p_type = 'entrada' THEN
    v_new_qty := v_item.quantity + p_quantity;
  ELSIF p_type = 'saida_manual' THEN
    IF v_item.quantity < p_quantity THEN
      RAISE EXCEPTION 'Saldo insuficiente em estoque (disponível: %, solicitado: %).', v_item.quantity, p_quantity;
    END IF;
    v_new_qty := v_item.quantity - p_quantity;

  ELSE
    RAISE EXCEPTION 'Tipo de movimentação inválido ("%").', p_type;
  END IF;

  IF v_new_qty::numeric*greatest(v_item.cost_price_cents,v_item.sale_price_cents)>9007199254740991 THEN RAISE EXCEPTION 'Valor do estoque excede o limite seguro.'; END IF;
  v_user_name := tecniflow.current_user_name();

  UPDATE tecniflow.inventory_items
  SET quantity = v_new_qty, updated_at = now()
  WHERE id = p_id AND company_id = v_company_id;

  INSERT INTO tecniflow.inventory_movements (
    id, company_id, item_id, type, quantity, previous_quantity, new_quantity, reason, user_name, created_at
  ) VALUES (
    gen_random_uuid()::text,
    v_company_id,
    p_id,
    p_type,
    p_quantity,
    v_item.quantity,
    v_new_qty,
    substring(trim(p_reason), 1, 255),
    v_user_name,
    now()
  );

  RETURN jsonb_build_object(
    'success', true,
    'item_id', p_id,
    'previous_quantity', v_item.quantity,
    'new_quantity', v_new_qty
  );
END;
$$;

-- ============================================================================
-- 6. RPCs DE ORDENS DE SERVIÇO (CRIAÇÃO SOB LOCK, LISTAGEM, DETALHES, EDIÇÃO)
-- ============================================================================
CREATE OR REPLACE FUNCTION public.tf_get_orders(
  p_status text DEFAULT NULL,
  p_priority text DEFAULT NULL,
  p_search text DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_company_id VARCHAR(36);
  v_orders jsonb;
BEGIN
  v_company_id := tecniflow.current_company_id();
  IF v_company_id IS NULL THEN
    RAISE EXCEPTION 'Acesso não autorizado.';
  END IF;

  SELECT COALESCE(jsonb_agg(
    jsonb_build_object(
      'id', o.id,
      'company_id', o.company_id,
      'order_number', o.order_number,
      'client_id', o.client_id,
      'client_name', c.name,
      'client_phone', c.phone,
      'device_type', o.device_type,
      'brand', o.brand,
      'model', o.model,
      'serial_imei', o.serial_imei,
      'defect_reported', o.defect_reported,
      'accessories', o.accessories,
      'entry_condition', o.entry_condition,
      'technical_diagnosis', o.technical_diagnosis,
      'priority', o.priority,
      'estimated_delivery', o.estimated_delivery,
      'status', o.status,
      'budget_status', o.budget_status,
      'total_services_cents', o.total_services_cents,
      'total_parts_cents', o.total_parts_cents,
      'total_amount_cents', o.total_amount_cents,
      'version', o.version,
      'created_at', o.created_at,
      'updated_at', o.updated_at,
      'completed_at', o.completed_at
    ) ORDER BY o.order_number DESC
  ), '[]'::jsonb)
  INTO v_orders
  FROM tecniflow.orders o
  JOIN tecniflow.clients c ON c.id = o.client_id AND c.company_id = o.company_id
  WHERE o.company_id = v_company_id
    AND (p_status IS NULL OR p_status = '' OR p_status = 'todos' OR o.status = p_status)
    AND (p_priority IS NULL OR p_priority = '' OR p_priority = 'todas' OR o.priority = p_priority)
    AND (
      p_search IS NULL OR p_search = '' OR
      o.order_number::text ILIKE '%' || p_search || '%' OR
      o.brand ILIKE '%' || p_search || '%' OR
      o.model ILIKE '%' || p_search || '%' OR
      o.serial_imei ILIKE '%' || p_search || '%' OR
      c.name ILIKE '%' || p_search || '%' OR
      c.phone ILIKE '%' || p_search || '%'
    );

  RETURN jsonb_build_object('orders', v_orders);
END;
$$;

CREATE OR REPLACE FUNCTION public.tf_get_order_details(p_order_id text)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_company_id VARCHAR(36);
  v_order RECORD;
  v_client RECORD;
  v_services jsonb;
  v_parts jsonb;
  v_history jsonb;
BEGIN
  v_company_id := tecniflow.current_company_id();
  IF v_company_id IS NULL THEN
    RAISE EXCEPTION 'Acesso não autorizado.';
  END IF;

  SELECT * INTO v_order
  FROM tecniflow.orders
  WHERE id = p_order_id AND company_id = v_company_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Ordem de serviço não encontrada ou não pertence a esta empresa.';
  END IF;

  SELECT * INTO v_client
  FROM tecniflow.clients
  WHERE id = v_order.client_id AND company_id = v_company_id;

  SELECT COALESCE(jsonb_agg(to_jsonb(s) ORDER BY s.created_at ASC), '[]'::jsonb)
  INTO v_services
  FROM tecniflow.order_services s
  WHERE s.order_id = p_order_id AND s.company_id = v_company_id;

  SELECT COALESCE(jsonb_agg(to_jsonb(p) ORDER BY p.created_at ASC), '[]'::jsonb)
  INTO v_parts
  FROM tecniflow.order_parts p
  WHERE p.order_id = p_order_id AND p.company_id = v_company_id;

  SELECT COALESCE(jsonb_agg(to_jsonb(h) ORDER BY h.created_at DESC), '[]'::jsonb)
  INTO v_history
  FROM tecniflow.order_history h
  WHERE h.order_id = p_order_id AND h.company_id = v_company_id;

  RETURN jsonb_build_object(
    'order', to_jsonb(v_order)||jsonb_build_object('client_name',v_client.name,'client_phone',v_client.phone,'client_whatsapp',v_client.whatsapp,'client_email',v_client.email,'client_document',v_client.document,'client_address',v_client.address),
    'client', to_jsonb(v_client),
    'services', v_services,
    'parts', v_parts,
    'history', v_history
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.tf_create_order(
  p_client_id text,
  p_device_type text,
  p_brand text,
  p_model text,
  p_serial_imei text DEFAULT '',
  p_defect_reported text DEFAULT '',
  p_accessories text DEFAULT '',
  p_entry_condition text DEFAULT '',
  p_technical_diagnosis text DEFAULT '',
  p_priority text DEFAULT 'normal',
  p_estimated_delivery text DEFAULT ''
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_company_id VARCHAR(36);
  v_order_id VARCHAR(36);
  v_order_number integer;
  v_order RECORD;
  v_user_name VARCHAR(100);
BEGIN
  v_company_id := tecniflow.current_company_id();
  IF v_company_id IS NULL THEN
    RAISE EXCEPTION 'Acesso não autorizado.';
  END IF;

  PERFORM tecniflow.validate_order(p_device_type,p_brand,p_model,p_defect_reported,p_priority,p_estimated_delivery,p_accessories,p_entry_condition);
  -- Validação de pertencimento do cliente à mesma empresa
  IF NOT EXISTS (SELECT 1 FROM tecniflow.clients WHERE id = p_client_id AND company_id = v_company_id AND is_archived=0) THEN
    RAISE EXCEPTION 'Cliente inválido ou não pertence a esta empresa.';
  END IF;

  IF p_device_type IS NULL OR trim(p_device_type) = '' THEN
    RAISE EXCEPTION 'O tipo de dispositivo é obrigatório.';
  END IF;
  IF p_defect_reported IS NULL OR trim(p_defect_reported) = '' THEN
    RAISE EXCEPTION 'O defeito relatado é obrigatório.';
  END IF;

  -- Validações de exclusão mútua (Bug 2)
  IF p_entry_condition ILIKE '%Liga normalmente%' AND p_entry_condition ILIKE '%Não liga%' THEN
    RAISE EXCEPTION 'Condições de entrada contraditórias: o aparelho não pode ligar e não ligar simultaneamente.';
  END IF;

  IF p_accessories ILIKE '%Nenhum acessório%' AND (
    p_accessories ILIKE '%Carregador%' OR p_accessories ILIKE '%Cabo%' OR p_accessories ILIKE '%Capa%' OR p_accessories ILIKE '%Película%' OR p_accessories ILIKE '%Bolsa%'
  ) THEN
    RAISE EXCEPTION 'Não é permitido marcar "Nenhum acessório" em conjunto com acessórios específicos.';
  END IF;

  -- Lock transacional da empresa para geração de número sequencial estrito
  PERFORM pg_advisory_xact_lock(hashtext('company_order_num_' || v_company_id));

  SELECT COALESCE(MAX(order_number), 0) + 1
  INTO v_order_number
  FROM tecniflow.orders
  WHERE company_id = v_company_id;

  v_order_id := gen_random_uuid()::text;
  v_user_name := tecniflow.current_user_name();

  INSERT INTO tecniflow.orders (
    id, company_id, order_number, client_id, device_type, brand, model, serial_imei,
    defect_reported, accessories, entry_condition, technical_diagnosis, priority,
    estimated_delivery, status, cancellation_reason, budget_status, version, created_at, updated_at
  ) VALUES (
    v_order_id,
    v_company_id,
    v_order_number,
    p_client_id,
    substring(trim(p_device_type), 1, 50),
    substring(COALESCE(trim(p_brand), ''), 1, 50),
    substring(COALESCE(trim(p_model), ''), 1, 50),
    substring(COALESCE(trim(p_serial_imei), ''), 1, 50),
    trim(p_defect_reported),
    substring(COALESCE(trim(p_accessories), ''), 1, 255),
    COALESCE(trim(p_entry_condition), ''),
    COALESCE(trim(p_technical_diagnosis), ''),
    substring(COALESCE(trim(p_priority), 'normal'), 1, 20),
    substring(COALESCE(trim(p_estimated_delivery), ''), 1, 50),
    'recebido',
    '',
    'pendente',
    1,
    now(),
    now()
  ) RETURNING * INTO v_order;

  INSERT INTO tecniflow.order_history (
    id, company_id, order_id, action, description, user_name, created_at
  ) VALUES (
    gen_random_uuid()::text,
    v_company_id,
    v_order_id,
    'criacao',
    'Ordem de serviço cadastrada com status Recebido.',
    v_user_name,
    now()
  );

  RETURN jsonb_build_object('order', to_jsonb(v_order));
END;
$$;

CREATE OR REPLACE FUNCTION public.tf_update_order(
  p_order_id text,
  p_version integer,
  p_device_type text,
  p_brand text,
  p_model text,
  p_serial_imei text DEFAULT '',
  p_defect_reported text DEFAULT '',
  p_accessories text DEFAULT '',
  p_entry_condition text DEFAULT '',
  p_technical_diagnosis text DEFAULT '',
  p_priority text DEFAULT 'normal',
  p_estimated_delivery text DEFAULT ''
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_company_id VARCHAR(36);
  v_order RECORD;
  v_next_version integer;
  v_user_name VARCHAR(100);
BEGIN
  v_company_id := tecniflow.current_company_id();
  IF v_company_id IS NULL THEN
    RAISE EXCEPTION 'Acesso não autorizado.';
  END IF;

  PERFORM tecniflow.validate_order(p_device_type,p_brand,p_model,p_defect_reported,p_priority,p_estimated_delivery,p_accessories,p_entry_condition);
  SELECT * INTO v_order
  FROM tecniflow.orders
  WHERE id = p_order_id AND company_id = v_company_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Ordem de serviço não encontrada.';
  END IF;

  IF p_version IS NULL OR p_version <= 0 THEN RAISE EXCEPTION 'A versão deve ser um inteiro positivo.'; END IF;
  IF v_order.version IS DISTINCT FROM p_version THEN
    RAISE EXCEPTION 'Conflito de concorrência: a ordem de serviço foi modificada por outro processo. Recarregue a página.';
  END IF;

  IF v_order.status IN ('entregue', 'cancelado') THEN
    RAISE EXCEPTION 'Não é possível alterar dados de uma ordem de serviço em estado terminal.';
  END IF;

  v_next_version := v_order.version + 1;
  v_user_name := tecniflow.current_user_name();

  UPDATE tecniflow.orders
  SET device_type = substring(trim(p_device_type), 1, 50),
      brand = substring(COALESCE(trim(p_brand), ''), 1, 50),
      model = substring(COALESCE(trim(p_model), ''), 1, 50),
      serial_imei = substring(COALESCE(trim(p_serial_imei), ''), 1, 50),
      defect_reported = trim(p_defect_reported),
      accessories = substring(COALESCE(trim(p_accessories), ''), 1, 255),
      entry_condition = COALESCE(trim(p_entry_condition), ''),
      technical_diagnosis = COALESCE(trim(p_technical_diagnosis), ''),
      priority = substring(COALESCE(trim(p_priority), 'normal'), 1, 20),
      estimated_delivery = substring(COALESCE(trim(p_estimated_delivery), ''), 1, 50),
      version = v_next_version,
      updated_at = now()
  WHERE id = p_order_id AND company_id = v_company_id;

  INSERT INTO tecniflow.order_history (
    id, company_id, order_id, action, description, user_name, created_at
  ) VALUES (
    gen_random_uuid()::text,
    v_company_id,
    p_order_id,
    'edicao',
    'Dados da ordem de serviço atualizados.',
    v_user_name,
    now()
  );

  RETURN jsonb_build_object('success', true, 'version', v_next_version);
END;
$$;

-- ============================================================================
-- 7. RPCs DE ORÇAMENTO E DECISÃO (TRANSAÇÃO, CENTAVOS, BLOQUEIOS E REGRAS)
-- ============================================================================
CREATE OR REPLACE FUNCTION public.tf_save_budget(
  p_order_id text,
  p_version integer,
  p_services jsonb,
  p_parts jsonb
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_company_id VARCHAR(36);
  v_order RECORD;
  v_service RECORD;
  v_part RECORD;
  v_total_services bigint := 0;
  v_total_parts bigint := 0;
  v_total_amount bigint := 0;
  v_next_version integer;
  v_user_name VARCHAR(100);
BEGIN
  v_company_id := tecniflow.current_company_id();
  IF v_company_id IS NULL THEN
    RAISE EXCEPTION 'Acesso não autorizado.';
  END IF;

  SELECT * INTO v_order
  FROM tecniflow.orders
  WHERE id = p_order_id AND company_id = v_company_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Ordem de serviço não encontrada.';
  END IF;

  IF p_version IS NULL OR p_version <= 0 THEN RAISE EXCEPTION 'A versão deve ser um inteiro positivo.'; END IF;
  IF v_order.version IS DISTINCT FROM p_version THEN
    RAISE EXCEPTION 'Conflito de concorrência: a ordem de serviço foi modificada por outro processo. Recarregue a página.';
  END IF;

  IF v_order.status IN ('entregue', 'cancelado') THEN
    RAISE EXCEPTION 'Não é possível alterar orçamento de uma OS em estado terminal.';
  END IF;

  IF EXISTS (SELECT 1 FROM tecniflow.order_parts WHERE order_id = p_order_id AND company_id = v_company_id AND inventory_debited = 1) THEN
    RAISE EXCEPTION 'Não é possível alterar itens ou valores pois já existem peças baixadas no estoque para esta OS.';
  END IF;

  IF v_order.budget_status = 'aprovado' THEN
    RAISE EXCEPTION 'Este orçamento já está aprovado. Use o botão "Reabrir para Revisão" antes de modificar itens ou valores.';
  END IF;


 IF v_order.status NOT IN('recebido','diagnostico','aguardando_aprovacao') THEN RAISE EXCEPTION 'Orçamento não pode ser alterado após o início do reparo.'; END IF;
 IF jsonb_typeof(p_services) IS DISTINCT FROM 'array' OR jsonb_typeof(p_parts) IS DISTINCT FROM 'array' THEN RAISE EXCEPTION 'Serviços e peças devem ser listas.'; END IF;
 IF jsonb_array_length(p_services)+jsonb_array_length(p_parts)>200 THEN RAISE EXCEPTION 'O orçamento excede 200 itens.'; END IF;
 IF EXISTS(SELECT 1 FROM jsonb_array_elements(p_services||p_parts) j WHERE
 jsonb_typeof(j) IS DISTINCT FROM 'object' OR jsonb_typeof(j->'quantity') IS DISTINCT FROM 'number'
 OR coalesce(j->>'quantity','') !~ '^[1-9][0-9]*$' OR (j->>'quantity')::numeric>2147483647
 OR jsonb_typeof(j->'unit_price_cents') IS DISTINCT FROM 'number' OR coalesce(j->>'unit_price_cents','') !~ '^(0|[1-9][0-9]*)$'
 OR (j->>'unit_price_cents')::numeric*(j->>'quantity')::numeric>9007199254740991
 OR coalesce(btrim(j->>'description'),'')='' OR length(j->>'description')>255) THEN RAISE EXCEPTION 'Item inválido: descrição, quantidade e centavos inteiros são obrigatórios.'; END IF;

  -- Remove serviços e peças anteriores ainda não baixadas
  DELETE FROM tecniflow.order_services WHERE order_id = p_order_id AND company_id = v_company_id;
  DELETE FROM tecniflow.order_parts WHERE order_id = p_order_id AND company_id = v_company_id AND inventory_debited = 0;

  -- Processa serviços
  FOR v_service IN SELECT * FROM jsonb_to_recordset(COALESCE(p_services, '[]'::jsonb)) AS x(description text, unit_price_cents bigint, quantity integer)
  LOOP
    IF v_service.description IS NULL OR trim(v_service.description) = '' THEN
      RAISE EXCEPTION 'Descrição do serviço é obrigatória.';
    END IF;
    IF v_service.unit_price_cents < 0 THEN
      RAISE EXCEPTION 'O valor do serviço deve ser um número inteiro não negativo em centavos.';
    END IF;
    IF v_service.quantity <= 0 THEN
      RAISE EXCEPTION 'A quantidade do serviço deve ser um inteiro positivo.';
    END IF;

    v_total_services := v_total_services + (v_service.unit_price_cents * v_service.quantity);

    INSERT INTO tecniflow.order_services (
      id, company_id, order_id, description, unit_price_cents, quantity, total_cents, created_at
    ) VALUES (
      gen_random_uuid()::text,
      v_company_id,
      p_order_id,
      substring(trim(v_service.description), 1, 255),
      v_service.unit_price_cents,
      v_service.quantity,
      v_service.unit_price_cents * v_service.quantity,
      now()
    );
  END LOOP;

  -- Processa peças
  FOR v_part IN SELECT * FROM jsonb_to_recordset(COALESCE(p_parts, '[]'::jsonb)) AS x(inventory_item_id text, description text, unit_price_cents bigint, quantity integer)
  LOOP
    IF v_part.description IS NULL OR trim(v_part.description) = '' THEN
      RAISE EXCEPTION 'Descrição da peça é obrigatória.';
    END IF;
    IF v_part.unit_price_cents < 0 THEN
      RAISE EXCEPTION 'O valor da peça deve ser um número inteiro não negativo em centavos.';
    END IF;
    IF v_part.quantity <= 0 THEN
      RAISE EXCEPTION 'A quantidade da peça deve ser um inteiro positivo.';
    END IF;

    IF v_part.inventory_item_id IS NOT NULL AND v_part.inventory_item_id != '' THEN
      IF NOT EXISTS (SELECT 1 FROM tecniflow.inventory_items WHERE id = v_part.inventory_item_id AND company_id = v_company_id AND is_archived=0) THEN
        RAISE EXCEPTION 'Peça de estoque inválida ou não pertence a esta empresa.';
      END IF;
    END IF;

    v_total_parts := v_total_parts + (v_part.unit_price_cents * v_part.quantity);

    INSERT INTO tecniflow.order_parts (
      id, company_id, order_id, inventory_item_id, description, unit_price_cents, quantity, total_cents, inventory_debited, created_at
    ) VALUES (
      gen_random_uuid()::text,
      v_company_id,
      p_order_id,
      NULLIF(trim(v_part.inventory_item_id), ''),
      substring(trim(v_part.description), 1, 255),
      v_part.unit_price_cents,
      v_part.quantity,
      v_part.unit_price_cents * v_part.quantity,
      0,
      now()
    );
  END LOOP;

  v_total_amount := v_total_services + v_total_parts;
  IF v_total_amount>9007199254740991 THEN RAISE EXCEPTION 'Orçamento excede o limite monetário seguro.'; END IF;
  v_next_version := v_order.version + 1;
  v_user_name := tecniflow.current_user_name();

  UPDATE tecniflow.orders
  SET total_services_cents = v_total_services,
      total_parts_cents = v_total_parts,
      total_amount_cents = v_total_amount,
      version = v_next_version,
      updated_at = now()
  WHERE id = p_order_id AND company_id = v_company_id;

  INSERT INTO tecniflow.order_history (
    id, company_id, order_id, action, description, user_name, created_at
  ) VALUES (
    gen_random_uuid()::text,
    v_company_id,
    p_order_id,
    'orcamento',
    'Orçamento atualizado pelo servidor (Total: R$ ' || (v_total_amount / 100.0)::numeric(12,2) || ').',
    v_user_name,
    now()
  );

  RETURN jsonb_build_object(
    'success', true,
    'totals', jsonb_build_object(
      'total_services_cents', v_total_services,
      'total_parts_cents', v_total_parts,
      'total_amount_cents', v_total_amount
    ),
    'version', v_next_version
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.tf_decide_budget(
  p_order_id text,
  p_version integer,
  p_decision text,
  p_notes text DEFAULT ''
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_company_id VARCHAR(36);
  v_order RECORD;
  v_next_version integer;
  v_user_name VARCHAR(100);
  v_items_count integer;
BEGIN
  v_company_id := tecniflow.current_company_id();
  IF v_company_id IS NULL THEN
    RAISE EXCEPTION 'Acesso não autorizado.';
  END IF;

  IF p_decision IS NULL OR p_decision NOT IN ('aprovado', 'recusado') THEN
    RAISE EXCEPTION 'Decisão de orçamento inválida (deve ser "aprovado" ou "recusado").';
  END IF;

  SELECT * INTO v_order
  FROM tecniflow.orders
  WHERE id = p_order_id AND company_id = v_company_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Ordem de serviço não encontrada.';
  END IF;

  IF p_version IS NULL OR p_version <= 0 THEN RAISE EXCEPTION 'A versão deve ser um inteiro positivo.'; END IF;
  IF v_order.version IS DISTINCT FROM p_version THEN
    RAISE EXCEPTION 'Conflito de concorrência: a ordem de serviço foi modificada por outro processo. Recarregue a página.';
  END IF;

  IF v_order.status IN ('entregue', 'cancelado') THEN
    RAISE EXCEPTION 'Não é possível alterar a decisão de orçamento de uma OS em estado terminal.';
  END IF;

  IF v_order.status NOT IN('recebido','diagnostico','aguardando_aprovacao') OR v_order.budget_status<>'pendente' THEN RAISE EXCEPTION 'Decisão não permitida. Reabra o orçamento antes de alterar a aprovação.'; END IF;
  -- Regra Crítica (Bug 4): Proibir aprovação de orçamento vazio ou zerado (inclusive em bypass direto)
  IF p_decision = 'aprovado' THEN
    SELECT 
      (SELECT count(*) FROM tecniflow.order_services WHERE order_id = p_order_id AND company_id = v_company_id) +
      (SELECT count(*) FROM tecniflow.order_parts WHERE order_id = p_order_id AND company_id = v_company_id)
    INTO v_items_count;

    IF v_items_count = 0 OR v_order.total_amount_cents <= 0 THEN
      RAISE EXCEPTION 'Não é possível aprovar um orçamento sem itens ou com valor zerado. Adicione serviços ou peças antes de aprovar.';
    END IF;
  END IF;

  v_next_version := v_order.version + 1;
  v_user_name := tecniflow.current_user_name();

  UPDATE tecniflow.orders
  SET budget_status = p_decision,
      budget_approved_at = CASE WHEN p_decision = 'aprovado' THEN now() ELSE NULL END,
      budget_approved_by = CASE WHEN p_decision = 'aprovado' THEN v_user_name ELSE NULL END,
      version = v_next_version,
      updated_at = now()
  WHERE id = p_order_id AND company_id = v_company_id;

  INSERT INTO tecniflow.order_history (
    id, company_id, order_id, action, description, user_name, created_at
  ) VALUES (
    gen_random_uuid()::text,
    v_company_id,
    p_order_id,
    'decisao_orcamento',
    'Decisão informada pela assistência: orçamento ' || upper(p_decision) || '. ' || COALESCE(trim(p_notes), ''),
    v_user_name,
    now()
  );

  RETURN jsonb_build_object(
    'success', true,
    'budget_status', p_decision,
    'version', v_next_version
  );
END;
$$;

-- ============================================================================
-- 8. RPC DE TRANSIÇÃO DE STATUS E BAIXA ATÔMICA DE ESTOQUE
-- ============================================================================
CREATE OR REPLACE FUNCTION public.tf_transition_order_status(
  p_order_id text,
  p_version integer,
  p_status text,
  p_cancellation_reason text DEFAULT ''
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_company_id VARCHAR(36);
  v_order RECORD;
  v_part RECORD;
  v_item RECORD;
  v_next_version integer;
  v_user_name VARCHAR(100);
BEGIN
  v_company_id := tecniflow.current_company_id();
  IF v_company_id IS NULL THEN
    RAISE EXCEPTION 'Acesso não autorizado.';
  END IF;

  SELECT * INTO v_order
  FROM tecniflow.orders
  WHERE id = p_order_id AND company_id = v_company_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Ordem de serviço não encontrada.';
  END IF;

  IF p_version IS NULL OR p_version <= 0 THEN RAISE EXCEPTION 'A versão deve ser um inteiro positivo.'; END IF;
  IF v_order.version IS DISTINCT FROM p_version THEN
    RAISE EXCEPTION 'Conflito de concorrência: a ordem de serviço foi modificada por outro processo. Recarregue a página.';
  END IF;

  IF v_order.status IN ('entregue', 'cancelado') THEN
    RAISE EXCEPTION 'Ordem de serviço em estado terminal não pode sofrer nova transição de status.';
  END IF;

  IF p_status IS NULL OR p_status NOT IN('recebido','diagnostico','aguardando_aprovacao','reparo','pronto','entregue','cancelado') THEN RAISE EXCEPTION 'Status inválido.'; END IF;
  IF length(coalesce(p_cancellation_reason,''))>500 THEN RAISE EXCEPTION 'Motivo do cancelamento excede 500 caracteres.'; END IF;
  -- Máquina de estados canônica do TecniFlow
  IF v_order.status = 'recebido' AND p_status NOT IN ('diagnostico', 'cancelado') THEN
    RAISE EXCEPTION 'Transição inválida: não é permitido mudar de "recebido" diretamente para "%".', p_status;
  ELSIF v_order.status = 'diagnostico' AND p_status NOT IN ('aguardando_aprovacao', 'cancelado') THEN
    RAISE EXCEPTION 'Transição inválida: não é permitido mudar de "diagnostico" diretamente para "%".', p_status;
  ELSIF v_order.status = 'aguardando_aprovacao' AND p_status NOT IN ('reparo', 'cancelado') THEN
    RAISE EXCEPTION 'Transição inválida: não é permitido mudar de "aguardando_aprovacao" diretamente para "%".', p_status;
  ELSIF v_order.status = 'reparo' AND p_status NOT IN ('pronto', 'cancelado') THEN
    RAISE EXCEPTION 'Transição inválida: não é permitido mudar de "reparo" diretamente para "%".', p_status;
  ELSIF v_order.status = 'pronto' AND p_status NOT IN ('entregue', 'cancelado') THEN
    RAISE EXCEPTION 'Transição inválida: não é permitido mudar de "pronto" diretamente para "%".', p_status;
  END IF;

  IF p_status = 'cancelado' AND (p_cancellation_reason IS NULL OR trim(p_cancellation_reason) = '') THEN
    RAISE EXCEPTION 'É obrigatório informar uma justificativa clara para o cancelamento.';
  END IF;

  IF p_status = 'reparo' AND v_order.budget_status != 'aprovado' THEN
    RAISE EXCEPTION 'Não é permitido iniciar o reparo sem a aprovação prévia do orçamento pelo cliente.';
  END IF;

  v_next_version := v_order.version + 1;
  v_user_name := tecniflow.current_user_name();

  -- 1. Ao entrar em "reparo": Baixa atômica e exclusiva de estoque sob lock ordenado
  IF p_status = 'reparo' THEN
    -- Bloqueia todos os itens de estoque envolvidos em ordem estável para prevenir deadlocks
    PERFORM 1
    FROM tecniflow.inventory_items ii
    WHERE ii.id IN (
      SELECT op.inventory_item_id
      FROM tecniflow.order_parts op
      WHERE op.order_id = p_order_id AND op.company_id = v_company_id
        AND op.inventory_item_id IS NOT NULL AND op.inventory_debited = 0
    ) AND ii.company_id = v_company_id
    ORDER BY ii.id
    FOR UPDATE;

    -- Itera agrupando quantidades por peça
    FOR v_part IN
      SELECT op.inventory_item_id, SUM(op.quantity)::bigint AS required_qty, MAX(op.description) AS part_desc
      FROM tecniflow.order_parts op
      WHERE op.order_id = p_order_id AND op.company_id = v_company_id
        AND op.inventory_item_id IS NOT NULL AND op.inventory_debited = 0
      GROUP BY op.inventory_item_id
    LOOP
      SELECT * INTO v_item
      FROM tecniflow.inventory_items
      WHERE id = v_part.inventory_item_id AND company_id = v_company_id AND is_archived=0;
      IF NOT FOUND THEN RAISE EXCEPTION 'Peça indisponível ou arquivada.'; END IF;

      IF v_item.quantity < v_part.required_qty THEN
        RAISE EXCEPTION 'Estoque insuficiente para a peça "%": saldo atual (%), necessário (%).',
          v_item.name, v_item.quantity, v_part.required_qty;
      END IF;

      -- Decrementa o estoque
      UPDATE tecniflow.inventory_items
      SET quantity = quantity - v_part.required_qty, updated_at = now()
      WHERE id = v_part.inventory_item_id AND company_id = v_company_id;

      -- Registra movimentação de saída
      INSERT INTO tecniflow.inventory_movements (
        id, company_id, item_id, type, quantity, previous_quantity, new_quantity, order_id, reason, user_name, created_at
      ) VALUES (
        gen_random_uuid()::text,
        v_company_id,
        v_part.inventory_item_id,
        'saida_os',
        v_part.required_qty,
        v_item.quantity,
        v_item.quantity - v_part.required_qty,
        p_order_id,
        'Baixa para atendimento da OS #' || v_order.order_number,
        v_user_name,
        now()
      );
    END LOOP;

    -- Marca peças como baixadas
    UPDATE tecniflow.order_parts
    SET inventory_debited = 1
    WHERE order_id = p_order_id AND company_id = v_company_id AND inventory_item_id IS NOT NULL;
  END IF;

  -- Peças já aplicadas permanecem consumidas. Retorno físico exige ajuste manual justificado.
  -- 3. Atualiza status da OS
  UPDATE tecniflow.orders
  SET status = p_status,
      cancellation_reason = CASE WHEN p_status = 'cancelado' THEN trim(p_cancellation_reason) ELSE cancellation_reason END,
      completed_at = CASE WHEN p_status = 'entregue' THEN now() ELSE completed_at END,
      version = v_next_version,
      updated_at = now()
  WHERE id = p_order_id AND company_id = v_company_id;

  INSERT INTO tecniflow.order_history (
    id, company_id, order_id, action, description, user_name, created_at
  ) VALUES (
    gen_random_uuid()::text,
    v_company_id,
    p_order_id,
    'status_' || p_status,
    'Status alterado de ' || v_order.status || ' para ' || p_status || '.' || 
      CASE WHEN p_status = 'cancelado' THEN ' Motivo: ' || trim(p_cancellation_reason) ELSE '' END,
    v_user_name,
    now()
  );

  RETURN jsonb_build_object(
    'success', true,
    'status', p_status,
    'version', v_next_version
  );
END;
$$;

-- ============================================================================
-- 9. RPCs DE PAINEL, RELATÓRIOS E CONFIGURAÇÕES DA EMPRESA
-- ============================================================================
CREATE OR REPLACE FUNCTION public.tf_get_dashboard_stats()
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = '' AS $$
DECLARE
 v_company_id varchar(36);
 metrics jsonb; recent jsonb;
BEGIN
 v_company_id := tecniflow.current_company_id();
 IF v_company_id IS NULL THEN RAISE EXCEPTION 'Acesso não autorizado.'; END IF;
 
 SELECT jsonb_build_object(
 'inProgressCount',count(*) FILTER(WHERE status IN('recebido','diagnostico','aguardando_aprovacao','reparo')),
 'awaitingApprovalCount',count(*) FILTER(WHERE status='aguardando_aprovacao'),
 'readyForPickupCount',count(*) FILTER(WHERE status='pronto'),
 'deliveredCount',count(*) FILTER(WHERE status='entregue'),
 'cancelledCount',count(*) FILTER(WHERE status='cancelado'),
 'totalOrdersCount',count(*),'totalDeliveredCents',coalesce(sum(total_amount_cents) FILTER(WHERE status='entregue'),0),
 'totalBudgetedCents',coalesce(sum(total_amount_cents),0),
 'totalClients',(SELECT count(*) FROM tecniflow.clients WHERE company_id=v_company_id AND is_archived=0),
 'lowStockCount',(SELECT count(*) FROM tecniflow.inventory_items WHERE company_id=v_company_id AND is_archived=0 AND quantity<=min_quantity)) INTO metrics
 FROM tecniflow.orders WHERE company_id=v_company_id;
 SELECT coalesce(jsonb_agg(to_jsonb(o)||jsonb_build_object('client_name',c.name,'client_phone',c.phone) ORDER BY o.order_number DESC),'[]'::jsonb) INTO recent
 FROM(SELECT * FROM tecniflow.orders WHERE company_id=v_company_id ORDER BY order_number DESC LIMIT 6)o JOIN tecniflow.clients c ON c.id=o.client_id AND c.company_id=v_company_id;
 RETURN jsonb_build_object('metrics',metrics,'recentOrders',recent);
 
END;
$$;

CREATE OR REPLACE FUNCTION public.tf_get_reports(p_start_date text, p_end_date text)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = '' AS $$
DECLARE
 v_company_id varchar(36);
 ds date; de date; start_at timestamptz; end_at timestamptz; summary jsonb; statuses jsonb; devices jsonb; services jsonb; parts jsonb;
BEGIN
 v_company_id := tecniflow.current_company_id();
 IF v_company_id IS NULL THEN RAISE EXCEPTION 'Acesso não autorizado.'; END IF;
 
 IF p_start_date IS NULL OR p_end_date IS NULL OR p_start_date !~ '^\d{4}-\d{2}-\d{2}$' OR p_end_date !~ '^\d{4}-\d{2}-\d{2}$' THEN RAISE EXCEPTION 'Informe datas válidas AAAA-MM-DD.'; END IF;
 ds:=p_start_date::date; de:=p_end_date::date;
 IF ds>de OR ds<'1900-01-01'::date OR de>'2100-12-31'::date THEN RAISE EXCEPTION 'Intervalo de datas inválido.'; END IF;
 start_at:=ds::timestamp AT TIME ZONE 'America/Sao_Paulo'; end_at:=(de+1)::timestamp AT TIME ZONE 'America/Sao_Paulo';
 SELECT jsonb_build_object('totalOrders',count(*),'totalBudgetedCents',coalesce(sum(total_amount_cents),0),'cancelledCount',count(*) FILTER(WHERE status='cancelado')) INTO summary
 FROM tecniflow.orders WHERE company_id=v_company_id AND created_at>=start_at AND created_at<end_at;
 SELECT summary||jsonb_build_object('deliveredCount',count(*),'totalDeliveredCents',coalesce(sum(total_amount_cents),0),'avgHoursTurnaround',round(avg(extract(epoch FROM(completed_at-created_at))/3600),1)) INTO summary
 FROM tecniflow.orders WHERE company_id=v_company_id AND status='entregue' AND completed_at>=start_at AND completed_at<end_at;
 SELECT coalesce(jsonb_agg(to_jsonb(q)),'[]'::jsonb) INTO statuses FROM(SELECT status,count(*) count,coalesce(sum(total_amount_cents),0) amount_cents FROM tecniflow.orders WHERE company_id=v_company_id AND created_at>=start_at AND created_at<end_at GROUP BY status)q;
 SELECT coalesce(jsonb_agg(to_jsonb(q)),'[]'::jsonb) INTO devices FROM(SELECT device_type,count(*) count FROM tecniflow.orders WHERE company_id=v_company_id AND created_at>=start_at AND created_at<end_at GROUP BY device_type)q;
 SELECT coalesce(jsonb_agg(to_jsonb(q)),'[]'::jsonb) INTO services FROM(SELECT x.description,count(*) frequency,sum(x.quantity) total_qty,sum(x.total_cents) total_cents FROM tecniflow.order_services x JOIN tecniflow.orders o ON o.id=x.order_id AND o.company_id=x.company_id WHERE x.company_id=v_company_id AND o.status='entregue' AND o.completed_at>=start_at AND o.completed_at<end_at GROUP BY x.description ORDER BY frequency DESC LIMIT 10)q;
 SELECT coalesce(jsonb_agg(to_jsonb(q)),'[]'::jsonb) INTO parts FROM(SELECT x.description,count(*) frequency,sum(x.quantity) total_qty,sum(x.total_cents) total_cents FROM tecniflow.order_parts x JOIN tecniflow.orders o ON o.id=x.order_id AND o.company_id=x.company_id WHERE x.company_id=v_company_id AND o.status='entregue' AND o.completed_at>=start_at AND o.completed_at<end_at GROUP BY x.description ORDER BY frequency DESC LIMIT 10)q;
 RETURN jsonb_build_object('period',jsonb_build_object('startDate',p_start_date,'endDate',p_end_date),'summary',summary,'statusBreakdown',statuses,'deviceBreakdown',devices,'topServices',services,'topParts',parts);
 
END;
$$;

CREATE OR REPLACE FUNCTION public.tf_update_company(
  p_name text,
  p_document text DEFAULT '',
  p_phone text DEFAULT '',
  p_whatsapp text DEFAULT '',
  p_email text DEFAULT '',
  p_address text DEFAULT '',
  p_warranty_terms text DEFAULT '',
  p_receipt_notes text DEFAULT ''
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_company_id VARCHAR(36);
  v_company RECORD;
BEGIN
  v_company_id := tecniflow.current_company_id();
  IF v_company_id IS NULL THEN
    RAISE EXCEPTION 'Acesso não autorizado.';
  END IF;

  IF p_name IS NULL OR trim(p_name) = '' THEN
    RAISE EXCEPTION 'O nome da empresa é obrigatório.';
  END IF;

  PERFORM tecniflow.validate_contacts(p_phone,p_whatsapp,p_document,p_email,false);
  IF length(p_name)>100 OR length(coalesce(p_address,''))>255 THEN RAISE EXCEPTION 'Dados da empresa excedem o tamanho permitido.'; END IF;
  UPDATE tecniflow.companies
  SET name = substring(trim(p_name), 1, 100),
      document = substring(COALESCE(trim(p_document), ''), 1, 50),
      phone = substring(COALESCE(trim(p_phone), ''), 1, 30),
      whatsapp = substring(COALESCE(trim(p_whatsapp), ''), 1, 30),
      email = substring(lower(COALESCE(trim(p_email), '')), 1, 100),
      address = substring(COALESCE(trim(p_address), ''), 1, 255),
      warranty_terms = COALESCE(trim(p_warranty_terms), ''),
      receipt_notes = COALESCE(trim(p_receipt_notes), '')
  WHERE id = v_company_id
  RETURNING * INTO v_company;

  RETURN jsonb_build_object('company', to_jsonb(v_company));
END;
$$;

CREATE OR REPLACE FUNCTION public.tf_get_client_details(p_id text)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = '' AS $$
DECLARE
 v_company_id varchar(36);
 c record; os jsonb;
BEGIN
 v_company_id := tecniflow.current_company_id();
 IF v_company_id IS NULL THEN RAISE EXCEPTION 'Acesso não autorizado.'; END IF;
 
 SELECT * INTO c FROM tecniflow.clients WHERE id=p_id AND company_id=v_company_id;
 IF NOT FOUND THEN RAISE EXCEPTION 'Cliente não encontrado.'; END IF;
 SELECT coalesce(jsonb_agg(to_jsonb(o) ORDER BY o.order_number DESC),'[]'::jsonb) INTO os FROM tecniflow.orders o WHERE client_id=p_id AND company_id=v_company_id;
 RETURN jsonb_build_object('client',to_jsonb(c),'orders',os);
 
END;
$$;
CREATE OR REPLACE FUNCTION public.tf_get_inventory_details(p_id text)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = '' AS $$
DECLARE
 v_company_id varchar(36);
 i record; moves jsonb;
BEGIN
 v_company_id := tecniflow.current_company_id();
 IF v_company_id IS NULL THEN RAISE EXCEPTION 'Acesso não autorizado.'; END IF;
 
 SELECT * INTO i FROM tecniflow.inventory_items WHERE id=p_id AND company_id=v_company_id;
 IF NOT FOUND THEN RAISE EXCEPTION 'Peça não encontrada.'; END IF;
 SELECT coalesce(jsonb_agg(to_jsonb(m) ORDER BY m.created_at DESC),'[]'::jsonb) INTO moves FROM tecniflow.inventory_movements m WHERE item_id=p_id AND company_id=v_company_id;
 RETURN jsonb_build_object('item',to_jsonb(i),'movements',moves);
 
END;
$$;
CREATE OR REPLACE FUNCTION public.tf_get_company()
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = '' AS $$
DECLARE
 v_company_id varchar(36);
 c record;
BEGIN
 v_company_id := tecniflow.current_company_id();
 IF v_company_id IS NULL THEN RAISE EXCEPTION 'Acesso não autorizado.'; END IF;
 SELECT * INTO c FROM tecniflow.companies WHERE id=v_company_id; RETURN jsonb_build_object('company',to_jsonb(c));
END;
$$;
CREATE OR REPLACE FUNCTION public.tf_reopen_budget(p_order_id text,p_version integer)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
 v_company_id varchar(36);
 o record;
BEGIN
 v_company_id := tecniflow.current_company_id();
 IF v_company_id IS NULL THEN RAISE EXCEPTION 'Acesso não autorizado.'; END IF;
 
 IF p_version IS NULL OR p_version<1 THEN RAISE EXCEPTION 'Versão inválida.'; END IF;
 SELECT * INTO o FROM tecniflow.orders WHERE id=p_order_id AND company_id=v_company_id FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Ordem não encontrada.'; END IF;
 IF o.version IS DISTINCT FROM p_version THEN RAISE EXCEPTION 'A OS foi modificada por outro processo. Recarregue.'; END IF;
 IF o.status NOT IN('recebido','diagnostico','aguardando_aprovacao') OR EXISTS(SELECT 1 FROM tecniflow.order_parts WHERE order_id=p_order_id AND company_id=v_company_id AND inventory_debited=1) THEN RAISE EXCEPTION 'Não é possível reabrir após o início do reparo.'; END IF;
 IF o.budget_status='pendente' THEN RETURN jsonb_build_object('version',o.version); END IF;
 UPDATE tecniflow.orders SET budget_status='pendente',budget_approved_at=NULL,budget_approved_by=NULL,version=version+1,updated_at=now() WHERE id=p_order_id AND company_id=v_company_id;
 INSERT INTO tecniflow.order_history(id,company_id,order_id,action,description,user_name) VALUES(gen_random_uuid()::text,v_company_id,p_order_id,'revisao_orcamento','Orçamento reaberto para revisão.',tecniflow.current_user_name());
 RETURN jsonb_build_object('version',o.version+1,'budgetStatus','pendente');
 
END;
$$;

-- Somente as RPCs deste aplicativo são alteradas. Nenhuma função externa é revogada.
REVOKE ALL ON FUNCTION public.tf_sync_current_user() FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_sync_current_user() TO authenticated;
REVOKE ALL ON FUNCTION public.tf_get_clients(text,boolean) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_get_clients(text,boolean) TO authenticated;
REVOKE ALL ON FUNCTION public.tf_create_client(text,text,text,text,text,text,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_create_client(text,text,text,text,text,text,text) TO authenticated;
REVOKE ALL ON FUNCTION public.tf_update_client(text,text,text,text,text,text,text,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_update_client(text,text,text,text,text,text,text,text) TO authenticated;
REVOKE ALL ON FUNCTION public.tf_archive_client(text,integer) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_archive_client(text,integer) TO authenticated;
REVOKE ALL ON FUNCTION public.tf_get_inventory() FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_get_inventory() TO authenticated;
REVOKE ALL ON FUNCTION public.tf_create_inventory_item(text,text,text,integer,integer,bigint,bigint) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_create_inventory_item(text,text,text,integer,integer,bigint,bigint) TO authenticated;
REVOKE ALL ON FUNCTION public.tf_update_inventory_item(text,text,text,text,integer,bigint,bigint) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_update_inventory_item(text,text,text,text,integer,bigint,bigint) TO authenticated;
REVOKE ALL ON FUNCTION public.tf_adjust_inventory(text,text,integer,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_adjust_inventory(text,text,integer,text) TO authenticated;
REVOKE ALL ON FUNCTION public.tf_get_orders(text,text,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_get_orders(text,text,text) TO authenticated;
REVOKE ALL ON FUNCTION public.tf_get_order_details(text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_get_order_details(text) TO authenticated;
REVOKE ALL ON FUNCTION public.tf_create_order(text,text,text,text,text,text,text,text,text,text,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_create_order(text,text,text,text,text,text,text,text,text,text,text) TO authenticated;
REVOKE ALL ON FUNCTION public.tf_update_order(text,integer,text,text,text,text,text,text,text,text,text,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_update_order(text,integer,text,text,text,text,text,text,text,text,text,text) TO authenticated;
REVOKE ALL ON FUNCTION public.tf_save_budget(text,integer,jsonb,jsonb) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_save_budget(text,integer,jsonb,jsonb) TO authenticated;
REVOKE ALL ON FUNCTION public.tf_decide_budget(text,integer,text,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_decide_budget(text,integer,text,text) TO authenticated;
REVOKE ALL ON FUNCTION public.tf_transition_order_status(text,integer,text,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_transition_order_status(text,integer,text,text) TO authenticated;
REVOKE ALL ON FUNCTION public.tf_get_dashboard_stats() FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_get_dashboard_stats() TO authenticated;
REVOKE ALL ON FUNCTION public.tf_get_reports(text,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_get_reports(text,text) TO authenticated;
REVOKE ALL ON FUNCTION public.tf_update_company(text,text,text,text,text,text,text,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_update_company(text,text,text,text,text,text,text,text) TO authenticated;
REVOKE ALL ON FUNCTION public.tf_get_client_details(text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_get_client_details(text) TO authenticated;
REVOKE ALL ON FUNCTION public.tf_get_inventory_details(text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_get_inventory_details(text) TO authenticated;
REVOKE ALL ON FUNCTION public.tf_get_company() FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_get_company() TO authenticated;
REVOKE ALL ON FUNCTION public.tf_reopen_budget(text,integer) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_reopen_budget(text,integer) TO authenticated;
REVOKE ALL ON FUNCTION tecniflow.valid_phone(text) FROM PUBLIC,anon,authenticated;
REVOKE ALL ON FUNCTION tecniflow.valid_document(text) FROM PUBLIC,anon,authenticated;
REVOKE ALL ON FUNCTION tecniflow.validate_contacts(text,text,text,text,boolean) FROM PUBLIC,anon,authenticated;
REVOKE ALL ON FUNCTION tecniflow.validate_order(text,text,text,text,text,text,text,text) FROM PUBLIC,anon,authenticated;
-- Transferência incremental de clientes/estoque da mesma identidade Auth.
-- IDs de origem servem apenas para deduplicar; nunca decidem a empresa de destino.
CREATE TABLE IF NOT EXISTS tecniflow.legacy_imports (
 auth_user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 source_company_id varchar(36) NOT NULL,
 entity_kind text NOT NULL CHECK(entity_kind IN('client','inventory')),
 source_id varchar(36) NOT NULL,
 target_id varchar(36) NOT NULL,
 imported_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(auth_user_id,source_company_id,entity_kind,source_id)
);
ALTER TABLE tecniflow.legacy_imports ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE tecniflow.legacy_imports FROM PUBLIC,anon,authenticated;
CREATE OR REPLACE FUNCTION public.tf_import_legacy(p_payload jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE
 uid uuid:=auth.uid(); cid varchar(36); src text; entity jsonb; row_data jsonb; target text;
 kind text; v_source_id text; imported int:=0; skipped int:=0; failed jsonb:='[]'::jsonb;
BEGIN
 cid:=tecniflow.current_company_id();
 IF uid IS NULL OR cid IS NULL THEN RAISE EXCEPTION 'Acesso não autorizado.'; END IF;
 IF p_payload->>'format' IS DISTINCT FROM 'tecniflow-legacy-v1' OR p_payload->>'auth_user_id' IS DISTINCT FROM uid::text THEN RAISE EXCEPTION 'A transferência deve pertencer à mesma conta autenticada.'; END IF;
 src:=p_payload->>'source_company_id';
 IF src IS NULL OR src !~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' THEN RAISE EXCEPTION 'Identificador de origem inválido.'; END IF;
 IF jsonb_typeof(p_payload->'clients') IS DISTINCT FROM 'array' OR jsonb_typeof(p_payload->'inventory') IS DISTINCT FROM 'array' OR jsonb_typeof(p_payload->'orders') IS DISTINCT FROM 'array' THEN RAISE EXCEPTION 'Arquivo de transferência inválido.'; END IF;
 IF jsonb_array_length(p_payload->'orders')>0 THEN RAISE EXCEPTION 'Este arquivo contém ordens anteriores. Preserve a cópia e solicite a transferência assistida do histórico; nenhum registro será importado parcialmente.'; END IF;
 IF jsonb_array_length(p_payload->'clients')+jsonb_array_length(p_payload->'inventory')>5000 THEN RAISE EXCEPTION 'Transfira no máximo 5000 registros por arquivo.'; END IF;
 PERFORM pg_advisory_xact_lock(hashtext('tf_import_'||uid::text));
 FOREACH kind IN ARRAY ARRAY['client','inventory'] LOOP
  FOR entity IN SELECT value FROM jsonb_array_elements(CASE WHEN kind='client' THEN p_payload->'clients' ELSE p_payload->'inventory' END) LOOP
   v_source_id:=entity->>'id';
   BEGIN
    IF v_source_id IS NULL OR v_source_id !~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' THEN RAISE EXCEPTION 'Identificador do registro de origem inválido.'; END IF;
    IF EXISTS(SELECT 1 FROM tecniflow.legacy_imports x WHERE x.auth_user_id=uid AND x.source_company_id=src AND x.entity_kind=kind AND x.source_id=v_source_id) THEN skipped:=skipped+1; CONTINUE; END IF;
    IF coalesce((entity->>'is_archived')::int,0) NOT IN(0,1) THEN RAISE EXCEPTION 'Indicador de arquivamento inválido.'; END IF;
    IF kind='client' THEN
     row_data:=public.tf_create_client(entity->>'name',entity->>'phone',coalesce(entity->>'whatsapp',''),coalesce(entity->>'email',''),coalesce(entity->>'document',''),coalesce(entity->>'address',''),coalesce(entity->>'notes',''));
     target:=row_data->'client'->>'id';
     IF coalesce((entity->>'is_archived')::int,0)=1 THEN PERFORM public.tf_archive_client(target,1); END IF;
    ELSE
     row_data:=public.tf_create_inventory_item(entity->>'name',coalesce(entity->>'sku',''),coalesce(entity->>'category','geral'),(entity->>'quantity')::int,(entity->>'min_quantity')::int,(entity->>'cost_price_cents')::bigint,(entity->>'sale_price_cents')::bigint);
     target:=row_data->'item'->>'id';
     IF coalesce((entity->>'is_archived')::int,0)=1 THEN UPDATE tecniflow.inventory_items SET is_archived=1 WHERE id=target AND company_id=cid; END IF;
    END IF;
    INSERT INTO tecniflow.legacy_imports(auth_user_id,source_company_id,entity_kind,source_id,target_id) VALUES(uid,src,kind,v_source_id,target);
    imported:=imported+1;
   EXCEPTION WHEN OTHERS THEN
    failed:=failed||jsonb_build_array(jsonb_build_object('kind',kind,'source_id',v_source_id,'error',CASE WHEN SQLSTATE='P0001' THEN SQLERRM ELSE 'Dados inválidos. Revise os campos do registro antes de tentar novamente.' END));
   END;
  END LOOP;
 END LOOP;
 RETURN jsonb_build_object('imported',imported,'skipped',skipped,'failed',failed);
END; $$;
REVOKE ALL ON FUNCTION public.tf_import_legacy(jsonb) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tf_import_legacy(jsonb) TO authenticated;

COMMIT;
