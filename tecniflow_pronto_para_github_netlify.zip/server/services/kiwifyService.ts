import crypto from 'node:crypto';
import { parseKiwifyDate as parseSharedDate, validateKiwifyGrantPayload, isKiwifyCheckoutUrl } from '../../supabase/functions/_shared/kiwifyCommon.ts';

export interface KiwifyConfig {
  enabled: boolean;
  webhookSecret: string;
  checkoutUrl: string;
  allowedProductIds: string[];
  planId: string;
}

export interface KiwifyCheckoutIntent {
  checkoutUrl: string;
  opaqueToken: string;
  expiresAt: string;
}

export interface KiwifyParsedEvent {
  eventType: string;
  orderId: string;
  subscriptionId?: string;
  orderStatus: string;
  productId: string;
  planId: string;
  amountCents: number;
  currency: string;
  sck?: string;
  src?: string;
  accessUntil?: string;
  nextPayment?: string;
  approvedDate?: string;
  payloadHash: string;
}

export function parseKiwifyDate(dateStr?: string | null): Date | null {
  const parsed = parseSharedDate(dateStr);
  return parsed ? new Date(parsed) : null;
}

export class KiwifyService {
  private config: KiwifyConfig | null = null;

  constructor() {
    this.reloadConfig();
  }

  public reloadConfig(): void {
    // 1. Cobrança desativada por padrão nesta fase
    const enabled = process.env.KIWIFY_ENABLED === 'true';
    const webhookSecret = process.env.KIWIFY_WEBHOOK_SECRET?.trim() || '';
    const rawCheckoutUrl = process.env.KIWIFY_CHECKOUT_URL?.trim() || '';
    const rawAllowedProducts = process.env.KIWIFY_ALLOWED_PRODUCT_IDS?.trim() || '';
    const planId = process.env.KIWIFY_PLAN_ID?.trim() || '';

    // 2. Validação rigorosa da URL do checkout Kiwify:
    // Deve ser HTTPS e no host canônico pay.kiwify.com.br
    let checkoutUrl = '';
    try {
      if (rawCheckoutUrl.startsWith('https://pay.kiwify.com.br/')) {
        const parsed = new URL(rawCheckoutUrl);
        if (isKiwifyCheckoutUrl(rawCheckoutUrl)) {
          checkoutUrl = rawCheckoutUrl;
        }
      }
    } catch {}

    const allowedProductIds = rawAllowedProducts
      .split(',')
      .map((p) => p.trim())
      .filter((p) => p.length > 0 && !p.includes('...'));

    const isSecretReal = Boolean(webhookSecret && webhookSecret.length >= 8 && !webhookSecret.includes('...'));
    const isPlanReal = !planId.includes('...');
    const isCheckoutValid = Boolean(checkoutUrl);
    const hasProducts = allowedProductIds.length > 0;

    if (enabled && isSecretReal && isCheckoutValid && hasProducts && isPlanReal) {
      this.config = {
        enabled: true,
        webhookSecret,
        checkoutUrl,
        allowedProductIds,
        planId,
      };
    } else {
      this.config = null;
    }
  }

  public isConfigured(): boolean {
    return this.config !== null;
  }

  public getConfig(): KiwifyConfig | null {
    return this.config;
  }

  /**
   * Gera token opaco aleatório com 256 bits de entropia (64 hex chars)
   */
  public generateOpaqueToken(): string {
    return crypto.randomBytes(32).toString('hex');
  }

  /**
   * Constrói a URL do checkout Kiwify com o token opaco no parâmetro sck.
   * Não passa e-mail, nome, CPF ou company_id na URL.
   */
  public buildCheckoutUrl(opaqueToken: string): KiwifyCheckoutIntent {
    if (!this.isConfigured() || !this.config) {
      throw {
        code: 'billing_not_configured',
        message:
          'A contratação online está em fase de configuração pela administração. Entre em contato com o suporte para ativar sua assinatura.',
      };
    }

    const url = new URL(this.config.checkoutUrl);
    url.searchParams.set('sck', opaqueToken);

    // TTL de 24 horas no servidor
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();

    return {
      checkoutUrl: url.toString(),
      opaqueToken,
      expiresAt,
    };
  }

  /**
   * Valida a assinatura do webhook Kiwify conforme especificação oficial em "Segurança nos webhooks":
   * Assinatura enviada na querystring `?signature=...`
   * Calculada sobre o corpo original da requisição (UTF-8), sem reserializar o JSON.
   * Verifica em tempo constante e só então faz o parse do JSON.
   */
  public verifyWebhookSignature(signature: string | undefined | null, rawBodyText: string): boolean {
    if (!this.isConfigured() || !this.config) {
      return false;
    }
    if (!signature || typeof signature !== 'string') {
      return false;
    }

    const cleanSignature = signature.trim().toLowerCase();
    if (!/^[0-9a-f]{40}$/.test(cleanSignature)) {
      return false;
    }

    if (!rawBodyText || !rawBodyText.trim()) {
      return false;
    }

    const expectedHash = crypto
      .createHmac('sha1', this.config.webhookSecret)
      .update(rawBodyText, 'utf8')
      .digest('hex')
      .toLowerCase();

    try {
      if (!crypto.timingSafeEqual(
        Buffer.from(cleanSignature, 'hex'),
        Buffer.from(expectedHash, 'hex')
      )) return false;
    let parsed: any;
    try {
      parsed = JSON.parse(rawBodyText);
    } catch {
      return false;
    }

    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      return false;
    }

      return true;
    } catch {
      return false;
    }
  }

  /**
   * Valida e extrai os campos estruturados do payload do webhook Kiwify com política FAIL-CLOSED.
   * Para eventos de concessão (order_approved / subscription_renewed com status paid):
   *  - Exige Commissions.charge_amount inteiro estrito === 4990
   *  - Exige currency === 'BRL'
   *  - Exige Product.product_id em allowedProductIds
   *  - Exige Subscription.plan.id exatamente igual ao configurado em KIWIFY_PLAN_ID
   *  - Exige Subscription.plan.frequency === 'monthly'
   *  - Exige subscription_id não vazio e consistente
   *  - Exige datas de ciclo válidas (duração positiva de até 35 dias)
   */
  public validateAndExtractPayload(body: any, rawBodyText: string): KiwifyParsedEvent {
    if (!this.config) throw new Error('Kiwify não configurada no servidor.');
    const eventType = typeof body?.webhook_event_type === 'string' ? body.webhook_event_type.trim() : '';
    const orderId = typeof body?.order_id === 'string' ? body.order_id.trim() : '';
    if (!eventType || !orderId) throw new Error('webhook_event_type e order_id são obrigatórios.');
    const productId = body.Product?.product_id;
    if (typeof productId !== 'string' || !this.config.allowedProductIds.includes(productId.trim())) {
      throw new Error('Produto Kiwify não autorizado.');
    }
    const rootSub = body.subscription_id ? String(body.subscription_id).trim() : undefined;
    const objectSub = body.Subscription?.id ? String(body.Subscription.id).trim() : undefined;
    if (rootSub && objectSub && rootSub !== objectSub) throw new Error('Identificadores de assinatura inconsistentes.');
    const payloadHash = crypto.createHash('sha256').update(JSON.stringify(body)).digest('hex');
    const isGrant = ['order_approved', 'subscription_renewed'].includes(eventType) && body.order_status === 'paid';
    if (isGrant) {
      const validated = validateKiwifyGrantPayload(body, this.config);
      if (!validated.valid) throw new Error(validated.reason);
      return { ...validated.grantData, sck: validated.grantData.sck || undefined,
        nextPayment: validated.grantData.nextPayment || undefined, payloadHash };
    }
    return {
      eventType, orderId, orderStatus: String(body.order_status || ''), productId: productId.trim(),
      subscriptionId: rootSub || objectSub, planId: String(body.Subscription?.plan?.id || ''),
      amountCents: Number.isInteger(body.Commissions?.charge_amount) ? body.Commissions.charge_amount : 0,
      currency: typeof body.Commissions?.currency === 'string' ? body.Commissions.currency : '',
      sck: typeof body.TrackingParameters?.sck === 'string' ? body.TrackingParameters.sck : undefined,
      accessUntil: parseSharedDate(body.Subscription?.customer_access?.access_until) || undefined,
      nextPayment: parseSharedDate(body.Subscription?.next_payment) || undefined,
      approvedDate: parseSharedDate(body.approved_date) || undefined,
      payloadHash,
    };
  }
}

export const kiwifyService = new KiwifyService();

