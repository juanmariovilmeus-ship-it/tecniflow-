import {logger} from '../lib/logger.js';
export interface CriticalAlertPayload {area:string;code:string;severity:'error'|'fatal';correlationId:string;timestamp:string}
const destination=process.env.CRITICAL_ALERT_WEBHOOK_URL?.trim()||'';
export const ALERT_DESTINATION_CONFIGURED=Boolean(destination);
const lastSent=new Map<string,number>();
const hourly:number[]=[];
export async function dispatchCriticalAlert(payload:CriticalAlertPayload):Promise<{dispatched:boolean;reason?:string}> {
  if(!destination)return {dispatched:false,reason:'ALERT_DESTINATION_NOT_CONFIGURED'};
  if(!['INTERNAL_ERROR','SUPABASE_READINESS_FAILED','SERVER_START_FAILED'].includes(payload.code))return {dispatched:false,reason:'ALERT_CODE_REJECTED'};
  let url:URL;try {url=new URL(destination);}catch {return {dispatched:false,reason:'ALERT_DESTINATION_INVALID'};}
  if(url.protocol!=='https:'||url.username||url.password)return {dispatched:false,reason:'ALERT_DESTINATION_INVALID'};
  const now=Date.now();while(hourly.length&&hourly[0]<now-3600000)hourly.shift();
  if(hourly.length>=10||now-(lastSent.get(payload.code)||0)<60000)return {dispatched:false,reason:'ALERT_RATE_LIMITED'};
  lastSent.set(payload.code,now);hourly.push(now);
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),4000);
  try {
    const response=await fetch(url.toString(),{method:'POST',redirect:'error',headers:{'Content-Type':'application/json'},body:JSON.stringify({source:'TecniFlow',code:payload.code,severity:'error',timestamp:new Date(now).toISOString(),correlationId:/^[a-f0-9-]{36}$/i.test(payload.correlationId)?payload.correlationId:undefined}),signal:controller.signal});
    return response.ok?{dispatched:true}:{dispatched:false,reason:'ALERT_HTTP_FAILED'};
  } catch {logger.warn('Alert transport failed',{code:'ALERT_DISPATCH_FAILED'});return {dispatched:false,reason:'ALERT_TRANSPORT_FAILED'};}
  finally {clearTimeout(timer);}
}
