import crypto from 'node:crypto';

export type MercadoPagoMode = 'test' | 'production';

export interface MercadoPagoConfig {
  enabled: boolean;
  mode: MercadoPagoMode;
  accessToken: string;
  planId: string;
  webhookSecret: string;
  collectorId: string;
  appUrl: string;
}

export interface CheckoutResult {
  checkoutUrl: string;
  preapprovalId?: string;
  externalReference: string;
}

export interface VerifiedPayment {
  paymentId: string;
  preapprovalId?: string;
  companyId: string;
  amountCents: number;
  currency: string;
  status: 'approved' | 'pending' | 'rejected' | 'refunded' | 'charged_back';
  paymentDate: string;
}

export class MercadoPagoService {
  private config: MercadoPagoConfig | null = null;

  constructor() {
    this.reloadConfig();
  }

  public reloadConfig(): void {
    // 1. Cobrança explicitamente desligada por padrão nesta fase
    const enabled = process.env.MERCADO_PAGO_ENABLED === 'true';

    // 2. Modo explícito test ou production (nunca inferido pelo prefixo APP_USR segundo docs do MP)
    const rawMode = process.env.MERCADO_PAGO_MODE?.trim().toLowerCase();
    const mode: MercadoPagoMode | null = rawMode === 'production' || rawMode === 'test' ? rawMode : null;

    const accessToken = process.env.MERCADO_PAGO_ACCESS_TOKEN?.trim() || '';
    const planId = process.env.MERCADO_PAGO_PLAN_ID?.trim() || '';
    const webhookSecret = process.env.MERCADO_PAGO_WEBHOOK_SECRET?.trim() || '';
    const collectorId = process.env.MERCADO_PAGO_COLLECTOR_ID?.trim() || '';
    const rawAppUrl = process.env.APP_URL?.trim() || '';

    // 3. Validação rigorosa de URL: deve ser HTTPS válido sem fallback fictício
    let appUrl = '';
    try {
      if (rawAppUrl.startsWith('https://')) {
        const parsed = new URL(rawAppUrl);
        if (parsed.protocol === 'https:') {
          appUrl = parsed.origin;
        }
      }
    } catch {}

    // 4. Verificação de integridade de todos os parâmetros exigidos
    const isPlanReal = Boolean(planId && planId !== 'TECNIFLOW-MENSAL-4990' && !planId.includes('...'));
    const isTokenReal = Boolean(accessToken && !accessToken.includes('...'));
    const isSecretReal = Boolean(webhookSecret && !webhookSecret.includes('...'));
    const isCollectorReal = Boolean(collectorId && !collectorId.includes('...'));
    const isAppUrlValid = Boolean(appUrl);

    if (
      enabled &&
      mode &&
      isTokenReal &&
      isSecretReal &&
      isPlanReal &&
      isCollectorReal &&
      isAppUrlValid
    ) {
      this.config = {
        enabled,
        mode,
        accessToken,
        planId,
        webhookSecret,
        collectorId,
        appUrl,
      };
    } else {
      this.config = null;
    }
  }

  public isConfigured(): boolean {
    return this.config !== null && this.config.enabled === true;
  }

  public getConfig(): MercadoPagoConfig | null {
    return this.config;
  }

  /**
   * Valida a assinatura HMAC enviada pelo Mercado Pago no cabeçalho x-signature.
   * Formato esperado: ts=12345678,v1=hash_hexadecimal
   * Aplica comparação em tempo constante e janela de tolerância de 10 minutos.
   */
  public verifyWebhookSignature(
    signatureHeader: string | undefined,
    requestIdHeader: string | undefined,
    dataId: string
  ): boolean {
    if (!this.isConfigured() || !this.config || !this.config.webhookSecret) {
      return false;
    }

    if (!signatureHeader || !dataId) return false;

    // Extrair ts e v1
    const parts = signatureHeader.split(',');
    let ts: string | null = null;
    let v1: string | null = null;

    for (const part of parts) {
      const [k, v] = part.split('=').map((s) => s.trim());
      if (k === 'ts') ts = v;
      if (k === 'v1') v1 = v;
    }

    if (!ts || !v1) return false;

    // Janela de frescor estrita: rejeita se > 10 minutos para evitar replay attack
    const eventTime = parseInt(ts, 10);
    const nowSec = Math.floor(Date.now() / 1000);
    if (isNaN(eventTime) || Math.abs(nowSec - eventTime) > 600) {
      return false;
    }

    // Template canônico do Mercado Pago:
    // id:[data.id_url];request-id:[x-request-id_header];ts:[ts_header];
    const manifest = `id:${dataId};request-id:${requestIdHeader || ''};ts:${ts};`;
    const hmac = crypto.createHmac('sha256', this.config.webhookSecret);
    hmac.update(manifest);
    const calculatedHash = hmac.digest('hex');

    try {
      return crypto.timingSafeEqual(Buffer.from(calculatedHash, 'hex'), Buffer.from(v1, 'hex'));
    } catch {
      return false;
    }
  }

  /**
   * Valida o plano configurado na API oficial do Mercado Pago:
   * Deve ser mensal (1 mês), moeda BRL, R$ 49,90 e sem free trial configurado no MP.
   */
  public async validatePlanOnApi(planId: string): Promise<boolean> {
    if (!this.isConfigured() || !this.config) return false;

    try {
      const res = await fetch(`https://api.mercadopago.com/preapproval_plan/${planId}`, {
        headers: { Authorization: `Bearer ${this.config.accessToken}` },
      });
      if (!res.ok) return false;
      const data = await res.json();

      const amount = Number(data.auto_recurring?.transaction_amount);
      const currency = data.auto_recurring?.currency_id;
      const freq = data.auto_recurring?.frequency;
      const freqType = data.auto_recurring?.frequency_type;
      const freeTrial = data.auto_recurring?.free_trial;

      if (amount !== 49.9 && amount !== 49.90) return false;
      if (currency !== 'BRL') return false;
      if (freq !== 1 || freqType !== 'months') return false;
      if (freeTrial && freeTrial.frequency > 0) return false; // Sem trial no plano MP

      if (String(data.collector_id) !== String(this.config.collectorId)) {
        return false;
      }

      return true;
    } catch {
      return false;
    }
  }

  /**
   * Cria sessão de checkout (preapproval) vinculada exclusivamente ao companyId autenticado.
   */
  public async createPreapproval(params: {
    companyId: string;
    ownerEmail: string;
    companyName: string;
    backUrl?: string;
  }): Promise<CheckoutResult> {
    if (!this.isConfigured() || !this.config) {
      throw {
        code: 'billing_not_configured',
        message: 'A contratação online está em fase de configuração pela administração. Entre em contato com o suporte para ativar sua assinatura.'
      };
    }

    const backUrl = `${this.config.appUrl}/#subscription`;

    const payload = {
      preapproval_plan_id: this.config.planId,
      reason: 'TecniFlow Mensal - Assinatura da Assistência Técnica',
      external_reference: params.companyId,
      payer_email: params.ownerEmail,
      auto_recurring: {
        frequency: 1,
        frequency_type: 'months',
        transaction_amount: 49.9,
        currency_id: 'BRL',
      },
      back_url: backUrl,
      status: 'pending',
    };

    const response = await fetch('https://api.mercadopago.com/preapproval', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${this.config.accessToken}`,
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const errorBody = await response.text();
      console.error('[MercadoPago] Erro ao criar preapproval:', response.status, errorBody);
      throw new Error('Falha ao comunicar com o gateway de pagamento. Tente novamente mais tarde.');
    }

    const data = await response.json();
    return {
      checkoutUrl: data.init_point,
      preapprovalId: data.id,
      externalReference: params.companyId,
    };
  }

  /**
   * Consulta a API oficial do Mercado Pago para verificar a autenticidade e os dados reais de um pagamento.
   * NUNCA confia em dados passados diretamente no corpo do webhook por terceiros.
   */
  public async fetchAndVerifyPayment(paymentId: string): Promise<VerifiedPayment> {
    if (!this.isConfigured() || !this.config) {
      throw {
        code: 'billing_not_configured',
        message: 'Gateway de pagamento não configurado.'
      };
    }

    const response = await fetch(`https://api.mercadopago.com/v1/payments/${paymentId}`, {
      headers: {
        Authorization: `Bearer ${this.config.accessToken}`,
      },
    });

    if (!response.ok) {
      throw new Error(`Não foi possível validar o pagamento ${paymentId} na API do Mercado Pago.`);
    }

    const data = await response.json();

    // Validação estrita de moeda e valor (R$ 49,90 = 4990 centavos)
    if (data.currency_id !== 'BRL') {
      throw new Error(`Moeda ${data.currency_id} não autorizada.`);
    }

    const amountCents = Math.round(Number(data.transaction_amount) * 100);
    if (amountCents !== 4990) {
      throw new Error(`Valor de pagamento ${amountCents} centavos não corresponde ao plano canônico (4990 centavos).`);
    }

    // Validação estrita do collector
    if (String(data.collector_id) !== String(this.config.collectorId)) {
      throw new Error('Conta recebedora do pagamento divergente da conta oficial cadastrada.');
    }

    const companyId = data.external_reference;
    if (!companyId || typeof companyId !== 'string' || !companyId.trim()) {
      throw new Error('Pagamento sem vínculo com empresa (external_reference ausente).');
    }

    let status: VerifiedPayment['status'] = 'pending';
    if (data.status === 'approved') status = 'approved';
    else if (data.status === 'refunded') status = 'refunded';
    else if (data.status === 'charged_back') status = 'charged_back';
    else if (data.status === 'rejected' || data.status === 'cancelled') status = 'rejected';

    return {
      paymentId: String(data.id),
      preapprovalId: data.order?.id ? String(data.order.id) : undefined,
      companyId: companyId.trim(),
      amountCents,
      currency: 'BRL',
      status,
      paymentDate: data.date_approved || data.date_created || new Date().toISOString(),
    };
  }
}

export const mercadoPagoService = new MercadoPagoService();
