// ============================================================================
// TECNIFLOW - SERVIÇO DE ASSISTÊNCIA DE IA (HELP AI SERVICE)
// ============================================================================
// Integração server-side com Google GenAI SDK (@google/genai)
// Regras obrigatórias:
// 1. Modelo Flash-Lite, configurável apenas no servidor; saída limitada a 600 tokens.
// 2. config.abortSignal ligado ao controller.signal + httpOptions.timeout
// 3. Limpeza de timer com clearTimeout em bloco finally
// 4. Retries automáticos desativados (retryOptions: { attempts: 1 })
// 5. Zero log de mensagens de erro brutas (apenas códigos fixos seguros)
// 6. Não prometer que abortar elimina cobrança já iniciada
// ============================================================================

import { GoogleGenAI } from '@google/genai';
import { HELP_SYSTEM_KNOWLEDGE } from '../../src/data/helpKnowledge.js';

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
}

export interface HelpAiResponse {
  reply: string;
}

export interface AvailabilityResult {
  available: boolean;
  reason?: 'DISABLED' | 'KEY_NOT_CONFIGURED' | 'PROBE_TIMEOUT' | 'PROBE_ERROR' | 'AVAILABLE';
}

const REQUEST_TIMEOUT_MS = 15000;
const PROBE_TIMEOUT_MS = 5000;

// Opt-in explícito: sem chamadas externas por padrão, inclusive probes.
// Este interruptor não verifica o plano Google. Confirme Free Tier antes de ativar.
export function isHelpAiEnabled(): boolean {
  return process.env.HELP_AI_ENABLED === 'true' && Boolean(process.env.GEMINI_API_KEY?.trim());
}

function getAiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  return new GoogleGenAI({
    apiKey: apiKey || '',
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

/**
 * Verifica se o serviço de IA do Gemini está configurado e disponível.
 * Utiliza AbortController com abortSignal no SDK e timer limpo em bloco finally.
 */
export async function checkAvailability(): Promise<AvailabilityResult> {
  if (!isHelpAiEnabled()) return { available: false, reason: 'DISABLED' };
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || !apiKey.trim()) {
    return { available: false, reason: 'KEY_NOT_CONFIGURED' };
  }

  const controller = new AbortController();
  const timer = setTimeout(() => {
    controller.abort();
  }, PROBE_TIMEOUT_MS);

  try {
    const ai = getAiClient();
    // Chamada mínima de verificação com timeout e retries desativados
    await ai.models.generateContent({
      model: process.env.GEMINI_HELP_MODEL?.trim() || 'gemini-3.5-flash-lite',
      contents: 'ping',
      config: {
        maxOutputTokens: 16,
        automaticContinuation: false,
        abortSignal: controller.signal,
        httpOptions: {
          timeout: PROBE_TIMEOUT_MS,
          retryOptions: {
            attempts: 1, // Desativa retries automáticos
          },
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      },
    });

    return { available: true, reason: 'AVAILABLE' };
  } catch (err: any) {
    if (controller.signal.aborted || err?.name === 'AbortError') {
      console.error('[Help AI Error]', 'AI_PROBE_TIMEOUT');
      return { available: false, reason: 'PROBE_TIMEOUT' };
    }
    console.error('[Help AI Error]', 'AI_PROBE_ERROR');
    return { available: false, reason: 'PROBE_ERROR' };
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Gera a resposta de orientação com base na base curada de conhecimento do TecniFlow.
 * Envia config.abortSignal: controller.signal para o SDK e cancela em caso de timeout
 * ou desconexão do cliente HTTP.
 */
export async function generateHelpResponse(
  message: string,
  history: ChatMessage[] = [],
  clientAbortSignal?: AbortSignal
): Promise<HelpAiResponse> {
  if (!isHelpAiEnabled()) throw new Error('AI_SERVICE_UNAVAILABLE');
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || !apiKey.trim()) {
    console.error('[Help AI Error]', 'AI_KEY_NOT_CONFIGURED');
    throw new Error('AI_SERVICE_UNAVAILABLE');
  }

  const controller = new AbortController();

  // Cancelar se a conexão do cliente HTTP for interrompida
  const onClientAbort = () => controller.abort();
  if (clientAbortSignal) {
    if (clientAbortSignal.aborted) {
      controller.abort();
    } else {
      clientAbortSignal.addEventListener('abort', onClientAbort, { once: true });
    }
  }

  const timer = setTimeout(() => {
    controller.abort();
  }, REQUEST_TIMEOUT_MS);

  try {
    const ai = getAiClient();

    // Montar histórico estritamente formatado para o SDK
    const contents: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];

    for (const h of history) {
      contents.push({
        role: h.role,
        parts: [{ text: h.content }],
      });
    }

    // Pergunta atual do usuário
    contents.push({
      role: 'user',
      parts: [{ text: message }],
    });

    // Exatamente uma requisição por envio, sem fallback de modelo caro
    const response = await ai.models.generateContent({
      model: process.env.GEMINI_HELP_MODEL?.trim() || 'gemini-3.5-flash-lite',
      contents,
      config: {
        automaticContinuation: false,
        abortSignal: controller.signal,
        systemInstruction: HELP_SYSTEM_KNOWLEDGE,
        maxOutputTokens: 600,
        temperature: 0.2,
        httpOptions: {
          timeout: REQUEST_TIMEOUT_MS,
          retryOptions: {
            attempts: 1, // Desativa retries automáticos
          },
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      },
    });

    const replyText = response.text?.trim();
    if (!replyText) {
      console.error('[Help AI Error]', 'AI_EMPTY_RESPONSE');
      throw new Error('AI_INVALID_RESPONSE');
    }

    return { reply: replyText };
  } catch (err: any) {
    if (controller.signal.aborted || err?.name === 'AbortError') {
      console.error('[Help AI Error]', 'AI_TIMEOUT');
      throw new Error('AI_TIMEOUT');
    }

    const status = err?.status || err?.statusCode;
    if (status === 429) {
      console.error('[Help AI Error]', 'AI_RATE_LIMIT');
      throw new Error('AI_RATE_LIMIT');
    }

    if (status === 401 || status === 403) {
      console.error('[Help AI Error]', 'AI_AUTH_FAILED');
      throw new Error('AI_SERVICE_UNAVAILABLE');
    }

    console.error('[Help AI Error]', 'AI_UPSTREAM_ERROR');
    throw new Error('AI_UPSTREAM_ERROR');
  } finally {
    clearTimeout(timer);
    clientAbortSignal?.removeEventListener('abort', onClientAbort);
  }
}
