import { createDatabase, mainDb, DatabaseAdapter, SqliteAdapter, PostgresAdapter } from './db/index.js';

export * from './db/index.js';
export { createDatabase, mainDb };

// Safe startup logging: record counts only; never logs personal data, credentials or password hashes
if (mainDb.provider === 'sqlite' && typeof (mainDb as any).getRecordCounts === 'function') {
  const counts = (mainDb as any).getRecordCounts();
  console.info('[TecniFlow] SQLite local ativo; contagens de registros: ' + JSON.stringify(counts));
}
