import crypto from 'node:crypto';
import bcrypt from 'bcryptjs';
import { Request, Response, NextFunction } from 'express';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { mainDb, DatabaseAdapter, DatabaseExecutor } from './db.js';

const SUPABASE_URL = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL || 'https://aburknnkixeeqpvsyofc.supabase.co';
const SUPABASE_PUBLISHABLE_KEY = process.env.VITE_SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_PUBLISHABLE_KEY || process.env.VITE_SUPABASE_ANON_KEY || 'sb_publishable_nQu4lm4w3_Zq6a-18FvlsQ_johbNzzx';

let supabaseAuthClient: SupabaseClient = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    persistSession: false,
    autoRefreshToken: false,
  },
});

export function setSupabaseAuthClient(client: SupabaseClient) {
  supabaseAuthClient = client;
}

export function getSupabaseAuthClient(): SupabaseClient {
  return supabaseAuthClient;
}

export interface AuthUser {
  id: string;
  company_id: string;
  name: string;
  email: string;
  role: string;
}

export interface AuthCompany {
  id: string;
  name: string;
  document: string;
  phone: string;
  whatsapp: string;
  email: string;
  address: string;
  warranty_terms: string;
  receipt_notes: string;
  company_logo_data_url?: string | null;
}

export interface AuthenticatedRequest extends Request {
  user?: AuthUser;
  company?: AuthCompany;
  csrfToken?: string;
  db?: DatabaseAdapter;
}

export function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10);
}

export function comparePassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export function generateRandomToken(bytes = 32): string {
  return crypto.randomBytes(bytes).toString('hex');
}

export function hashToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

// Rate limiting for login
const MAX_LOGIN_ATTEMPTS = 5;
const LOCKOUT_MINUTES = 15;

export async function checkLoginRateLimit(identifier: string, db: DatabaseExecutor = mainDb): Promise<{ blocked: boolean; remainingMinutes?: number }> {
  const now = new Date();
  const row = await db.queryOne<{
    attempts: number;
    last_attempt_at: string;
    locked_until: string | null;
  }>('SELECT attempts, last_attempt_at, locked_until FROM login_attempts WHERE identifier = ?', [identifier]);

  if (!row) {
    return { blocked: false };
  }

  if (row.locked_until) {
    const lockedUntil = new Date(row.locked_until);
    if (lockedUntil > now) {
      const remainingMs = lockedUntil.getTime() - now.getTime();
      const remainingMinutes = Math.ceil(remainingMs / 60000);
      return { blocked: true, remainingMinutes };
    }
  }

  return { blocked: false };
}

export async function recordLoginFailure(identifier: string, db: DatabaseExecutor = mainDb): Promise<void> {
  const safeIdentifier = String(identifier).trim().slice(0, 150);
  const now = new Date();
  const nowIso = now.toISOString();
  const lockDateIso = new Date(now.getTime() + LOCKOUT_MINUTES * 60000).toISOString();

  // Atomic upsert: compatible with both SQLite 3.24+ and PostgreSQL 9.5+
  // Eliminates race conditions, duplicate PK conflicts, and lost updates under concurrency
  await db.execute(`
    INSERT INTO login_attempts (identifier, attempts, last_attempt_at, locked_until)
    VALUES (?, 1, ?, NULL)
    ON CONFLICT (identifier) DO UPDATE SET
      attempts = CASE
        WHEN login_attempts.locked_until IS NOT NULL AND login_attempts.locked_until <= excluded.last_attempt_at THEN 1
        ELSE login_attempts.attempts + 1
      END,
      last_attempt_at = excluded.last_attempt_at,
      locked_until = CASE
        WHEN (CASE
          WHEN login_attempts.locked_until IS NOT NULL AND login_attempts.locked_until <= excluded.last_attempt_at THEN 1
          ELSE login_attempts.attempts + 1
        END) >= ? THEN ?
        WHEN login_attempts.locked_until IS NOT NULL AND login_attempts.locked_until <= excluded.last_attempt_at THEN NULL
        ELSE login_attempts.locked_until
      END
  `, [safeIdentifier, nowIso, MAX_LOGIN_ATTEMPTS, lockDateIso]);
}

export async function clearLoginFailures(identifier: string, db: DatabaseExecutor = mainDb): Promise<void> {
  await db.execute('DELETE FROM login_attempts WHERE identifier = ?', [identifier]);
}

// Session expiration: 7 days
export const SESSION_DURATION_MS = 7 * 24 * 60 * 60 * 1000;

export async function createSession(userId: string, companyId: string, db: DatabaseExecutor = mainDb): Promise<{ sessionToken: string; csrfToken: string }> {
  const sessionToken = generateRandomToken(32);
  const csrfToken = generateRandomToken(24);
  const tokenHash = hashToken(sessionToken);
  const now = new Date();
  const expiresAt = new Date(now.getTime() + SESSION_DURATION_MS).toISOString();
  const sessionId = crypto.randomUUID();

  await db.execute(`
    INSERT INTO sessions (id, user_id, company_id, token_hash, csrf_token, expires_at, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `, [sessionId, userId, companyId, tokenHash, csrfToken, expiresAt, now.toISOString()]);

  return { sessionToken, csrfToken };
}

export function getSessionCookieOptions(req?: Request) {
  // In preview environments embedded in Google AI Studio iframes (cross-site)
  // or behind Cloud Run / Google front-end proxies, cookies must be
  // Secure + HttpOnly + SameSite=None + Partitioned (CHIPS) to persist sessions.
  const isHttps = req?.secure ||
    req?.headers['x-forwarded-proto'] === 'https' ||
    Boolean(process.env.APP_URL?.startsWith('https')) ||
    process.env.NODE_ENV === 'production';

  return {
    httpOnly: true,
    secure: isHttps || true,
    sameSite: 'none' as const,
    partitioned: true,
    maxAge: SESSION_DURATION_MS,
    path: '/'
  };
}

export function getClearCookieOptions(req?: Request) {
  const opts = getSessionCookieOptions(req);
  return {
    httpOnly: opts.httpOnly,
    secure: opts.secure,
    sameSite: opts.sameSite,
    partitioned: opts.partitioned,
    path: '/'
  };
}

export async function authenticateSession(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
  const db = req.db || mainDb;

  // Extract Bearer token from Authorization header
  const authHeader = req.headers.authorization || (req.headers['Authorization'] as string | undefined);
  let bearerToken: string | null = null;
  if (typeof authHeader === 'string' && authHeader.toLowerCase().startsWith('bearer ')) {
    bearerToken = authHeader.slice(7).trim();
  }

  if (!bearerToken) {
    res.status(401).json({ error: 'Token de autorização ausente ou inválido. Faça login pelo Supabase Auth.' });
    return;
  }

  try {
    // Validate JWT token with Supabase Auth getUser (validates signature, expiration, revocation remotely)
    const { data, error } = await supabaseAuthClient.auth.getUser(bearerToken);
    if (error || !data?.user) {
      res.status(401).json({ error: 'Sessão inválida ou expirada no Supabase Auth. Faça login novamente.' });
      return;
    }

    const authUser = data.user;
    const authUserId = authUser.id; // Supabase auth.users UUID

    // Resolve tenant locally by verified auth_user_id (UUID)
    let localUser = await db.queryOne<{
      id: string;
      company_id: string;
      name: string;
      email: string;
      role: string;
      auth_user_id: string | null;
      company_name: string;
      company_document: string;
      company_phone: string;
      company_whatsapp: string;
      company_email: string;
      company_address: string;
      company_warranty_terms: string;
      company_receipt_notes: string;
      company_logo_data_url: string | null;
    }>(`
      SELECT u.id, u.company_id, u.name, u.email, u.role, u.auth_user_id,
             c.name as company_name, c.document as company_document, c.phone as company_phone,
             c.whatsapp as company_whatsapp, c.email as company_email, c.address as company_address,
             c.warranty_terms as company_warranty_terms, c.receipt_notes as company_receipt_notes,
             c.company_logo_data_url as company_logo_data_url
      FROM users u
      JOIN companies c ON c.id = u.company_id
      WHERE u.auth_user_id = ?
    `, [authUserId]);

    if (!localUser) {
      // Transactional, idempotent provisioning strictly bound to verified auth_user_id
      // No email auto-merge, no password storage locally
      const meta = authUser.user_metadata || {};
      const companyId = crypto.randomUUID();
      const userId = crypto.randomUUID();
      const now = new Date().toISOString();

      // Strictly enforce column limits to prevent buffer/column truncation errors
      const safeCompanyName = (typeof meta.company_name === 'string' && meta.company_name.trim()
        ? meta.company_name.trim()
        : 'Minha Assistência Técnica').slice(0, 100);
      const safeDoc = (typeof meta.company_document === 'string' ? meta.company_document.trim() : '').slice(0, 50);
      const safePhone = (typeof meta.company_phone === 'string' ? meta.company_phone.trim() : '').slice(0, 30);
      const safeWhatsapp = (typeof meta.company_whatsapp === 'string' ? meta.company_whatsapp.trim() : '').slice(0, 30);
      const safeAddress = (typeof meta.company_address === 'string' ? meta.company_address.trim() : '').slice(0, 255);
      const safeOwnerName = (typeof meta.owner_name === 'string' && meta.owner_name.trim()
        ? meta.owner_name.trim()
        : 'Proprietário').slice(0, 100);
      // Validate email identity without truncating: must be valid email format and length <= 100
      const rawEmail = (authUser.email || '').trim().toLowerCase();
      const EMAIL_REGEX = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;
      if (!rawEmail || rawEmail.length > 100 || !EMAIL_REGEX.test(rawEmail)) {
        res.status(422).json({
          error: `E-mail de autenticação inválido ou excede o limite máximo permitido de 100 caracteres pelo schema do sistema ("${rawEmail}"). A identidade do usuário não pode ser mutilada.`
        });
        return;
      }
      const safeEmail = rawEmail; // Preserved completely without truncation

      // Check for conflict with legacy account possessing the same email but different/null auth_user_id
      const existingUserWithEmail = await db.queryOne<{ id: string; auth_user_id: string | null }>(
        'SELECT id, auth_user_id FROM users WHERE LOWER(email) = ?',
        [safeEmail]
      );

      if (existingUserWithEmail && existingUserWithEmail.auth_user_id !== authUserId) {
        res.status(409).json({
          error: 'Conflito de cadastro: já existe um usuário registrado com este e-mail no banco local. Para segurança dos dados, a unificação requer procedimento de migração e não é realizada automaticamente.'
        });
        return;
      }

      try {
        await db.withTransaction(async (tx) => {
          // Concurrency check inside transaction
          const existing = await tx.queryOne('SELECT id FROM users WHERE auth_user_id = ?', [authUserId]);
          if (existing) return;

          // Double check email uniqueness inside transaction
          const emailCheck = await tx.queryOne('SELECT id, auth_user_id FROM users WHERE LOWER(email) = ?', [safeEmail]);
          if (emailCheck && emailCheck.auth_user_id !== authUserId) {
            const err = new Error('EMAIL_CONFLICT');
            (err as any).code = 'EMAIL_CONFLICT';
            throw err;
          }

          await tx.execute(`
            INSERT INTO companies (id, name, document, phone, whatsapp, email, address, warranty_terms, receipt_notes, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, '', '', ?)
          `, [
            companyId,
            safeCompanyName,
            safeDoc,
            safePhone,
            safeWhatsapp,
            safeEmail,
            safeAddress,
            now
          ]);

          await tx.execute(`
            INSERT INTO users (id, company_id, name, email, password_hash, role, auth_user_id, created_at)
            VALUES (?, ?, ?, ?, '', 'owner', ?, ?)
          `, [
            userId,
            companyId,
            safeOwnerName,
            safeEmail,
            authUserId,
            now
          ]);
        });
      } catch (txErr: any) {
        const errMsg = String(txErr?.message || txErr || '');
        const errCode = String(txErr?.code || '');
        if (
          errCode === 'EMAIL_CONFLICT' ||
          errCode === 'SQLITE_CONSTRAINT_UNIQUE' ||
          errMsg.includes('UNIQUE constraint failed: users.email') ||
          errMsg.includes('uq_users')
        ) {
          res.status(409).json({
            error: 'Conflito de cadastro: já existe um usuário registrado com este e-mail no banco local. Para segurança dos dados, a unificação requer procedimento de migração e não é realizada automaticamente.'
          });
          return;
        }
        throw txErr;
      }

      localUser = await db.queryOne(`
        SELECT u.id, u.company_id, u.name, u.email, u.role, u.auth_user_id,
               c.name as company_name, c.document as company_document, c.phone as company_phone,
               c.whatsapp as company_whatsapp, c.email as company_email, c.address as company_address,
               c.warranty_terms as company_warranty_terms, c.receipt_notes as company_receipt_notes,
               c.company_logo_data_url as company_logo_data_url
        FROM users u
        JOIN companies c ON c.id = u.company_id
        WHERE u.auth_user_id = ?
      `, [authUserId]);
    }

    if (!localUser) {
      res.status(500).json({ error: 'Falha ao vincular conta e empresa para o usuário autenticado.' });
      return;
    }

    req.user = {
      id: localUser.id,
      company_id: localUser.company_id,
      name: localUser.name,
      email: localUser.email,
      role: localUser.role,
    };

    req.company = {
      id: localUser.company_id,
      name: localUser.company_name,
      document: localUser.company_document,
      phone: localUser.company_phone,
      whatsapp: localUser.company_whatsapp,
      email: localUser.company_email,
      address: localUser.company_address,
      warranty_terms: localUser.company_warranty_terms || '',
      receipt_notes: localUser.company_receipt_notes || '',
      company_logo_data_url: localUser.company_logo_data_url || null,
    };

    req.csrfToken = 'bearer_authorized';
    next();
  } catch (err) {
    next(err);
  }
}

// CSRF validation for mutating endpoints (POST, PUT, DELETE, PATCH)
export function requireCsrf(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const method = req.method.toUpperCase();
  if (['GET', 'HEAD', 'OPTIONS'].includes(method)) {
    return next();
  }

  // Requests authenticated with Bearer authorization header are not vulnerable to browser CSRF
  const authHeader = req.headers.authorization || (req.headers['Authorization'] as string | undefined);
  if (typeof authHeader === 'string' && authHeader.toLowerCase().startsWith('bearer ')) {
    return next();
  }

  const providedToken = req.headers['x-csrf-token'] || req.headers['x-xsrf-token'];

  if (!providedToken || typeof providedToken !== 'string') {
    res.status(403).json({ error: 'Requisição rejeitada: token CSRF ausente.' });
    return;
  }

  if (!req.csrfToken || providedToken !== req.csrfToken) {
    res.status(403).json({ error: 'Requisição rejeitada: token CSRF inválido.' });
    return;
  }

  next();
}

export function validateOrigin(req: Request, res: Response, next: NextFunction): void {
  const method = req.method.toUpperCase();
  if (['GET', 'HEAD', 'OPTIONS'].includes(method)) {
    return next();
  }

  const origin = req.headers['origin'] || req.headers['referer'];
  if (origin && typeof origin === 'string') {
    try {
      const originUrl = new URL(origin);
      const originHost = originUrl.host;
      const requestHost = req.headers['host'];

      const allowedHosts = new Set<string>();
      if (requestHost) allowedHosts.add(requestHost);
      if (process.env.APP_URL) {
        try {
          allowedHosts.add(new URL(process.env.APP_URL).host);
        } catch {}
      }
      // AI Studio preview embedder host
      allowedHosts.add('aistudio.google.com');

      if (!allowedHosts.has(originHost)) {
        res.status(403).json({ error: 'Requisição rejeitada: origem não autorizada.' });
        return;
      }
    } catch {
      res.status(403).json({ error: 'Requisição rejeitada: cabeçalho de origem inválido.' });
      return;
    }
  }

  next();
}
