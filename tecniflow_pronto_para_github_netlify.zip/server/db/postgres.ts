import pg from 'pg';
import fs from 'node:fs';
import { DatabaseAdapter, DatabaseExecutor, DatabaseResult } from './types.js';

const { Pool, types } = pg;

// Parse PostgreSQL BIGINT (OID 20) to standard JavaScript Number to match integer cents
// Strictly enforce Number.MAX_SAFE_INTEGER to prevent overflow/precision corruption
types.setTypeParser(20, (val: string) => {
  if (val === null || val === undefined) return 0;
  const num = Number(val);
  if (!Number.isSafeInteger(num)) {
    throw new Error(`[TecniFlow DB] Valor numérico excede o limite Number.MAX_SAFE_INTEGER: ${val}`);
  }
  return num;
});

// Parse PostgreSQL TIMESTAMPTZ (OID 1184) and TIMESTAMP (OID 1114) to canonical ISO strings
types.setTypeParser(1184, (val: string) => (val ? new Date(val).toISOString() : val));
types.setTypeParser(1114, (val: string) => (val ? new Date(val).toISOString() : val));

export function convertQuestionMarksToDollarNumbered(sql: string): string {
  let paramIndex = 1;
  let inString = false;
  let stringChar = '';
  let result = '';

  for (let i = 0; i < sql.length; i++) {
    const char = sql[i];
    if (inString) {
      result += char;
      if (char === stringChar) {
        if (i + 1 < sql.length && sql[i + 1] === stringChar) {
          result += sql[++i];
        } else {
          inString = false;
        }
      }
    } else {
      if (char === "'" || char === '"') {
        inString = true;
        stringChar = char;
        result += char;
      } else if (char === '?') {
        result += `$${paramIndex++}`;
      } else {
        result += char;
      }
    }
  }
  return result;
}

export const REQUIRED_TECNIFLOW_TABLES = [
  'companies',
  'users',
  'sessions',
  'login_attempts',
  'clients',
  'inventory_items',
  'orders',
  'order_services',
  'order_parts',
  'inventory_movements',
  'order_history'
] as const;

export const SSL_PARAMS_TO_REMOVE = [
  'sslmode',
  'sslrootcert',
  'sslcert',
  'sslkey',
  'ssl',
  'uselibpqcompat',
  'sslpassword',
  'sslcompression',
  'sslresponse',
  'sslca',
  'sslcapath',
  'sslcrl',
  'sslcrldir'
] as const;

export class PostgresAdapter implements DatabaseAdapter {
  public readonly provider = 'postgres' as const;
  private pool: pg.Pool;
  private poolConfig: pg.PoolConfig;

  constructor(databaseUrl?: string) {
    const rawUrl = databaseUrl || process.env.DATABASE_URL;
    if (!rawUrl || !rawUrl.trim()) {
      throw new Error(
        '[TecniFlow DB] DB_PROVIDER=postgres configurado, mas DATABASE_URL está ausente ou vazia. ' +
        'Configure a variável DATABASE_URL com a connection string do Supabase no ambiente seguro do servidor.'
      );
    }

    // TLS configuration: strict certificate validation required by Supabase
    // URL parameters like sslmode=disable, sslcert, or sslkey must NOT weaken security
    let caCert: string | undefined = undefined;
    if (process.env.DB_CA_CERT) {
      caCert = process.env.DB_CA_CERT;
    } else if (process.env.SUPABASE_CA_CERT) {
      caCert = process.env.SUPABASE_CA_CERT;
    } else if (process.env.DB_CA_FILE && fs.existsSync(process.env.DB_CA_FILE)) {
      caCert = fs.readFileSync(process.env.DB_CA_FILE, 'utf8');
    }

    // Sanitize connection URL: parse to ensure valid format without exposing credentials in logs
    let parsedUrl: URL;
    try {
      parsedUrl = new URL(rawUrl.trim());
    } catch {
      throw new Error('[TecniFlow DB] DATABASE_URL informada não possui um formato de URL válido.');
    }

    // Prevent URL query params from overriding or weakening TLS verification
    for (const param of SSL_PARAMS_TO_REMOVE) {
      parsedUrl.searchParams.delete(param);
    }

    const sslConfig: pg.ConnectionConfig['ssl'] = caCert
      ? { ca: caCert, rejectUnauthorized: true }
      : { rejectUnauthorized: true };

    this.poolConfig = {
      connectionString: parsedUrl.toString(),
      ssl: sslConfig,
      max: 10,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 10000
    };

    this.pool = new Pool(this.poolConfig);

    // Ensure dedicated tecniflow schema is always the search path for all pool clients
    this.pool.on('connect', (client) => {
      client.query('SET search_path TO tecniflow, public;').catch((err) => {
        console.error('[TecniFlow DB] Falha ao definir search_path do PostgreSQL:', err.message);
      });
    });

    this.pool.on('error', (err) => {
      console.error('[TecniFlow DB] Erro inesperado no pool do PostgreSQL:', err.message);
    });
  }

  async testConnection(): Promise<{ tableCount: number; tables: string[] }> {
    let client: pg.PoolClient | null = null;
    try {
      client = await this.pool.connect();
      await client.query('SET search_path TO tecniflow, public;');

      // 1. Verify schema exists
      const schemaCheck = await client.query(
        "SELECT schema_name FROM information_schema.schemata WHERE schema_name = 'tecniflow';"
      );
      if (schemaCheck.rows.length === 0) {
        throw new Error(
          "O schema 'tecniflow' não existe no banco PostgreSQL. " +
          "Execute o arquivo supabase/tecniflow_schema.sql no SQL Editor do Supabase antes de iniciar."
        );
      }

      // 2. Verify all required tables exist
      const tablesCheck = await client.query(
        "SELECT table_name FROM information_schema.tables WHERE table_schema = 'tecniflow';"
      );
      const existingTables = new Set(tablesCheck.rows.map((r: any) => r.table_name));
      const missing = REQUIRED_TECNIFLOW_TABLES.filter((t) => !existingTables.has(t));

      if (missing.length > 0) {
        throw new Error(
          `O schema 'tecniflow' está incompleto no PostgreSQL. Tabelas ausentes: ${missing.join(', ')}. ` +
          "Execute o arquivo supabase/tecniflow_schema.sql completo no SQL Editor do Supabase."
        );
      }

      return {
        tableCount: existingTables.size,
        tables: Array.from(existingTables)
      };
    } catch (err: any) {
      throw new Error(
        `[TecniFlow DB] Falha na conexão/validação do PostgreSQL do Supabase: ${err.message || 'Erro de rede ou autenticação'}.`
      );
    } finally {
      if (client) {
        client.release();
      }
    }
  }

  async query<T = any>(sql: string, params: any[] = []): Promise<T[]> {
    const pgSql = convertQuestionMarksToDollarNumbered(sql);
    const res = await this.pool.query(pgSql, params);
    return res.rows as T[];
  }

  async queryOne<T = any>(sql: string, params: any[] = []): Promise<T | null> {
    const rows = await this.query<T>(sql, params);
    return rows.length > 0 ? rows[0] : null;
  }

  async execute(sql: string, params: any[] = []): Promise<DatabaseResult> {
    const pgSql = convertQuestionMarksToDollarNumbered(sql);
    const res = await this.pool.query(pgSql, params);
    return {
      changes: res.rowCount ?? 0
    };
  }

  async withTransaction<T>(fn: (tx: DatabaseExecutor) => Promise<T>): Promise<T> {
    const client = await this.pool.connect();
    try {
      await client.query('SET search_path TO tecniflow, public;');
      await client.query('BEGIN;');

      const txExecutor: DatabaseExecutor = {
        query: async <R = any>(sql: string, params: any[] = []): Promise<R[]> => {
          const pgSql = convertQuestionMarksToDollarNumbered(sql);
          const res = await client.query(pgSql, params);
          return res.rows as R[];
        },
        queryOne: async <R = any>(sql: string, params: any[] = []): Promise<R | null> => {
          const pgSql = convertQuestionMarksToDollarNumbered(sql);
          const res = await client.query(pgSql, params);
          return res.rows.length > 0 ? (res.rows[0] as R) : null;
        },
        execute: async (sql: string, params: any[] = []): Promise<DatabaseResult> => {
          const pgSql = convertQuestionMarksToDollarNumbered(sql);
          const res = await client.query(pgSql, params);
          return {
            changes: res.rowCount ?? 0
          };
        }
      };

      const result = await fn(txExecutor);
      await client.query('COMMIT;');
      return result;
    } catch (err) {
      try {
        await client.query('ROLLBACK;');
      } catch {}
      throw err;
    } finally {
      client.release();
    }
  }

  prepare(sql: string): any {
    throw new Error('[TecniFlow DB] Método prepare síncrono é exclusivo do SQLite. Use query/queryOne/execute assíncronos no PostgreSQL.');
  }

  exec(sql: string): any {
    return this.execute(sql);
  }

  public getPoolConfig(): Readonly<pg.PoolConfig> {
    return { ...this.poolConfig };
  }

  async close(): Promise<void> {
    await this.pool.end();
  }
}
