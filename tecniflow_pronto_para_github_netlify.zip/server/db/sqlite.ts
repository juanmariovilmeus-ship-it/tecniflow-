import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import { DatabaseAdapter, DatabaseExecutor, DatabaseResult } from './types.js';

function stripForUpdate(sql: string): string {
  // SQLite does not support FOR UPDATE concurrency locking clause
  return sql.replace(/\s+FOR\s+UPDATE(\s+OF\s+[\w\s,]+)?/gi, '');
}

export class SqliteAdapter implements DatabaseAdapter {
  public readonly provider = 'sqlite' as const;
  public readonly rawDb: DatabaseSync;
  private gateMutex: Promise<void> = Promise.resolve();

  constructor(dbFilePath: string = path.resolve(process.cwd(), 'data', 'tecniflow.db')) {
    if (dbFilePath !== ':memory:') {
      const dir = path.dirname(dbFilePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    }

    this.rawDb = new DatabaseSync(dbFilePath);
    this.rawDb.exec('PRAGMA foreign_keys = ON;');
    this.rawDb.exec('PRAGMA journal_mode = WAL;');
    this.initSchema();
  }

  private initSchema(): void {
    this.rawDb.exec(`
      CREATE TABLE IF NOT EXISTS companies (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        document TEXT DEFAULT '',
        phone TEXT DEFAULT '',
        whatsapp TEXT DEFAULT '',
        email TEXT DEFAULT '',
        address TEXT DEFAULT '',
        warranty_terms TEXT DEFAULT '',
        receipt_notes TEXT DEFAULT '',
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        company_id TEXT NOT NULL,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'owner',
        auth_user_id TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS sessions (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        company_id TEXT NOT NULL,
        token_hash TEXT NOT NULL UNIQUE,
        csrf_token TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS login_attempts (
        identifier TEXT PRIMARY KEY,
        attempts INTEGER NOT NULL DEFAULT 1,
        last_attempt_at TEXT NOT NULL,
        locked_until TEXT
      );

      CREATE TABLE IF NOT EXISTS clients (
        id TEXT PRIMARY KEY,
        company_id TEXT NOT NULL,
        name TEXT NOT NULL,
        phone TEXT NOT NULL,
        whatsapp TEXT DEFAULT '',
        email TEXT DEFAULT '',
        document TEXT DEFAULT '',
        address TEXT DEFAULT '',
        notes TEXT DEFAULT '',
        is_archived INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS inventory_items (
        id TEXT PRIMARY KEY,
        company_id TEXT NOT NULL,
        name TEXT NOT NULL,
        sku TEXT DEFAULT '',
        category TEXT NOT NULL DEFAULT 'geral',
        quantity INTEGER NOT NULL DEFAULT 0,
        min_quantity INTEGER NOT NULL DEFAULT 1,
        cost_price_cents INTEGER NOT NULL DEFAULT 0,
        sale_price_cents INTEGER NOT NULL DEFAULT 0,
        is_archived INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS orders (
        id TEXT PRIMARY KEY,
        company_id TEXT NOT NULL,
        order_number INTEGER NOT NULL,
        client_id TEXT NOT NULL,
        device_type TEXT NOT NULL,
        brand TEXT NOT NULL,
        model TEXT NOT NULL,
        serial_imei TEXT DEFAULT '',
        defect_reported TEXT NOT NULL,
        accessories TEXT DEFAULT '',
        entry_condition TEXT DEFAULT '',
        technical_diagnosis TEXT DEFAULT '',
        priority TEXT NOT NULL DEFAULT 'normal',
        estimated_delivery TEXT DEFAULT '',
        status TEXT NOT NULL DEFAULT 'recebido',
        cancellation_reason TEXT DEFAULT '',
        budget_status TEXT NOT NULL DEFAULT 'pendente',
        budget_approved_at TEXT,
        budget_approved_by TEXT,
        total_services_cents INTEGER NOT NULL DEFAULT 0,
        total_parts_cents INTEGER NOT NULL DEFAULT 0,
        total_amount_cents INTEGER NOT NULL DEFAULT 0,
        received_amount_cents INTEGER NOT NULL DEFAULT 0,
        payment_method TEXT DEFAULT '',
        payment_date TEXT,
        version INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        completed_at TEXT,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
        FOREIGN KEY (client_id) REFERENCES clients(id)
      );

      CREATE UNIQUE INDEX IF NOT EXISTS idx_orders_company_number ON orders(company_id, order_number);

      CREATE TABLE IF NOT EXISTS order_services (
        id TEXT PRIMARY KEY,
        company_id TEXT NOT NULL,
        order_id TEXT NOT NULL,
        description TEXT NOT NULL,
        unit_price_cents INTEGER NOT NULL,
        quantity INTEGER NOT NULL DEFAULT 1,
        total_cents INTEGER NOT NULL,
        created_at TEXT NOT NULL DEFAULT '',
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
        FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS order_parts (
        id TEXT PRIMARY KEY,
        company_id TEXT NOT NULL,
        order_id TEXT NOT NULL,
        inventory_item_id TEXT,
        description TEXT NOT NULL,
        unit_price_cents INTEGER NOT NULL,
        quantity INTEGER NOT NULL DEFAULT 1,
        total_cents INTEGER NOT NULL,
        inventory_debited INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT '',
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
        FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
        FOREIGN KEY (inventory_item_id) REFERENCES inventory_items(id)
      );

      CREATE TABLE IF NOT EXISTS inventory_movements (
        id TEXT PRIMARY KEY,
        company_id TEXT NOT NULL,
        item_id TEXT NOT NULL,
        type TEXT NOT NULL,
        quantity INTEGER NOT NULL,
        previous_quantity INTEGER NOT NULL,
        new_quantity INTEGER NOT NULL,
        order_id TEXT,
        reason TEXT NOT NULL,
        user_name TEXT DEFAULT 'Sistema',
        created_at TEXT NOT NULL,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
        FOREIGN KEY (item_id) REFERENCES inventory_items(id) ON DELETE CASCADE,
        FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS order_history (
        id TEXT PRIMARY KEY,
        company_id TEXT NOT NULL,
        order_id TEXT NOT NULL,
        action TEXT NOT NULL,
        description TEXT NOT NULL,
        user_name TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
        FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS company_subscriptions (
        company_id TEXT PRIMARY KEY,
        status TEXT NOT NULL DEFAULT 'trial',
        plan_code TEXT NOT NULL DEFAULT 'TECNIFLOW-MENSAL-4990',
        amount_cents INTEGER NOT NULL DEFAULT 4990,
        currency TEXT NOT NULL DEFAULT 'BRL',
        billing_cycle TEXT NOT NULL DEFAULT 'monthly',
        trial_starts_at TEXT NOT NULL,
        trial_ends_at TEXT NOT NULL,
        current_period_starts_at TEXT,
        current_period_ends_at TEXT,
        cancel_at_period_end INTEGER NOT NULL DEFAULT 0,
        mp_preapproval_id TEXT,
        mp_payer_id TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS billing_payments (
        id TEXT PRIMARY KEY,
        company_id TEXT NOT NULL,
        mp_payment_id TEXT NOT NULL UNIQUE,
        mp_preapproval_id TEXT,
        amount_cents INTEGER NOT NULL,
        currency TEXT NOT NULL DEFAULT 'BRL',
        status TEXT NOT NULL,
        payment_date TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS billing_events (
        id TEXT PRIMARY KEY,
        company_id TEXT,
        mp_event_id TEXT UNIQUE,
        kiwify_event_id TEXT UNIQUE,
        event_type TEXT NOT NULL,
        payload TEXT NOT NULL,
        processed_at TEXT NOT NULL,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS billing_intents (
        id TEXT PRIMARY KEY,
        company_id TEXT NOT NULL,
        provider TEXT NOT NULL DEFAULT 'kiwify',
        product_id TEXT NOT NULL,
        plan_id TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        consumed_by_order_id TEXT,
        consumed_by_subscription_id TEXT,
        expires_at TEXT NOT NULL,
        created_at TEXT NOT NULL,
        consumed_at TEXT,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS help_ai_usage (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id TEXT NOT NULL,
        auth_user_id TEXT NOT NULL,
        usage_date TEXT NOT NULL,
        usage_minute TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
      );

      CREATE INDEX IF NOT EXISTS idx_help_ai_usage_comp_date ON help_ai_usage(company_id, usage_date);
      CREATE INDEX IF NOT EXISTS idx_help_ai_usage_user_min ON help_ai_usage(auth_user_id, usage_minute);
    `);

    // Inspect users table columns via PRAGMA table_info
    const userColumns = this.rawDb.prepare('PRAGMA table_info(users)').all() as Array<{ name: string }>;
    const hasAuthUserId = userColumns.some((col) => col.name === 'auth_user_id');
    if (!hasAuthUserId) {
      // SQLite does not support UNIQUE constraint in ALTER TABLE ADD COLUMN.
      // Column is added as TEXT and the UNIQUE INDEX is created separately below.
      this.rawDb.exec('ALTER TABLE users ADD COLUMN auth_user_id TEXT;');
    }

    // Ensure UNIQUE INDEX on auth_user_id exists idempotently
    this.rawDb.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_users_auth_user_id ON users(auth_user_id);');

    // Inspect orders table columns via PRAGMA table_info
    const orderColumns = this.rawDb.prepare('PRAGMA table_info(orders)').all() as Array<{ name: string }>;
    const hasVersion = orderColumns.some((col) => col.name === 'version');
    if (!hasVersion) {
      this.rawDb.exec('ALTER TABLE orders ADD COLUMN version INTEGER NOT NULL DEFAULT 1;');
    }

    // Inspect companies table columns via PRAGMA table_info
    const companyColumns = this.rawDb.prepare('PRAGMA table_info(companies)').all() as Array<{ name: string }>;
    const hasCompanyLogo = companyColumns.some((col) => col.name === 'company_logo_data_url');
    if (!hasCompanyLogo) {
      this.rawDb.exec('ALTER TABLE companies ADD COLUMN company_logo_data_url TEXT;');
    }

    // Inspect company_subscriptions table columns for Kiwify
    const subColumns = this.rawDb.prepare('PRAGMA table_info(company_subscriptions)').all() as Array<{ name: string }>;
    if (!subColumns.some((col) => col.name === 'kiwify_subscription_id')) {
      this.rawDb.exec('ALTER TABLE company_subscriptions ADD COLUMN kiwify_subscription_id TEXT;');
      this.rawDb.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_subs_kiwify_sub ON company_subscriptions(kiwify_subscription_id);');
    }
    if (!subColumns.some((col) => col.name === 'kiwify_order_id')) {
      this.rawDb.exec('ALTER TABLE company_subscriptions ADD COLUMN kiwify_order_id TEXT;');
    }

    // Inspect billing_payments table columns for Kiwify
    const payColumns = this.rawDb.prepare('PRAGMA table_info(billing_payments)').all() as Array<{ name: string }>;
    if (!payColumns.some((col) => col.name === 'kiwify_order_id')) {
      this.rawDb.exec('ALTER TABLE billing_payments ADD COLUMN kiwify_order_id TEXT;');
      this.rawDb.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_payments_kiwify_order ON billing_payments(kiwify_order_id);');
    }
    if (!payColumns.some((col) => col.name === 'kiwify_subscription_id')) {
      this.rawDb.exec('ALTER TABLE billing_payments ADD COLUMN kiwify_subscription_id TEXT;');
    }
    if (!payColumns.some((col) => col.name === 'period_starts_at')) {
      this.rawDb.exec('ALTER TABLE billing_payments ADD COLUMN period_starts_at TEXT;');
    }
    if (!payColumns.some((col) => col.name === 'period_ends_at')) {
      this.rawDb.exec('ALTER TABLE billing_payments ADD COLUMN period_ends_at TEXT;');
    }

    // Inspect billing_events table columns for Kiwify
    const eventColumns = this.rawDb.prepare('PRAGMA table_info(billing_events)').all() as Array<{ name: string }>;
    if (!eventColumns.some((col) => col.name === 'kiwify_event_id')) {
      this.rawDb.exec('ALTER TABLE billing_events ADD COLUMN kiwify_event_id TEXT;');
      this.rawDb.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_events_kiwify_event ON billing_events(kiwify_event_id);');
    }
  }

  private async acquireLock(): Promise<() => void> {
    let release: () => void;
    const prev = this.gateMutex;
    this.gateMutex = new Promise<void>((resolve) => {
      release = resolve;
    });
    await prev;
    return release!;
  }

  private rawQuery<T = any>(sql: string, params: any[] = []): T[] {
    const cleanSql = stripForUpdate(sql);
    const stmt = this.rawDb.prepare(cleanSql);
    return stmt.all(...params) as T[];
  }

  private rawQueryOne<T = any>(sql: string, params: any[] = []): T | null {
    const cleanSql = stripForUpdate(sql);
    const stmt = this.rawDb.prepare(cleanSql);
    const result = stmt.get(...params);
    return (result as T) ?? null;
  }

  private rawExecute(sql: string, params: any[] = []): DatabaseResult {
    const cleanSql = stripForUpdate(sql);
    const stmt = this.rawDb.prepare(cleanSql);
    const res = stmt.run(...params);
    return {
      changes: Number(res.changes || 0),
      lastInsertRowid: res.lastInsertRowid
    };
  }

  async query<T = any>(sql: string, params: any[] = []): Promise<T[]> {
    const release = await this.acquireLock();
    try {
      return this.rawQuery<T>(sql, params);
    } finally {
      release();
    }
  }

  async queryOne<T = any>(sql: string, params: any[] = []): Promise<T | null> {
    const release = await this.acquireLock();
    try {
      return this.rawQueryOne<T>(sql, params);
    } finally {
      release();
    }
  }

  async execute(sql: string, params: any[] = []): Promise<DatabaseResult> {
    const release = await this.acquireLock();
    try {
      return this.rawExecute(sql, params);
    } finally {
      release();
    }
  }

  async withTransaction<T>(fn: (tx: DatabaseExecutor) => Promise<T>): Promise<T> {
    // Acquire the shared gate so NO external queries or executes can interleave into the transaction
    const release = await this.acquireLock();
    this.rawDb.exec('BEGIN IMMEDIATE TRANSACTION;');
    try {
      // Internal txExecutor calls raw methods directly without deadlock
      const txExecutor: DatabaseExecutor = {
        query: async (sql, params) => this.rawQuery(sql, params),
        queryOne: async (sql, params) => this.rawQueryOne(sql, params),
        execute: async (sql, params) => this.rawExecute(sql, params)
      };
      const result = await fn(txExecutor);
      this.rawDb.exec('COMMIT;');
      return result;
    } catch (err) {
      try {
        this.rawDb.exec('ROLLBACK;');
      } catch {}
      throw err;
    } finally {
      release();
    }
  }

  async close(): Promise<void> {
    const release = await this.acquireLock();
    try {
      this.rawDb.close();
    } finally {
      release();
    }
  }

  prepare(sql: string): any {
    return this.rawDb.prepare(stripForUpdate(sql));
  }

  exec(sql: string): any {
    return this.rawDb.exec(stripForUpdate(sql));
  }

  getRecordCounts(): Record<string, number> {
    const tables = [
      'companies',
      'users',
      'sessions',
      'login_attempts',
      'clients',
      'inventory_items',
      'orders',
      'order_services',
      'order_parts',
      'inventory_movements',
      'order_history'
    ] as const;

    const counts: Record<string, number> = {};
    for (const table of tables) {
      try {
        const row = this.rawDb.prepare(`SELECT COUNT(*) as c FROM ${table}`).get() as { c: number };
        counts[table] = Number(row?.c || 0);
      } catch {
        counts[table] = 0;
      }
    }
    return counts;
  }
}
