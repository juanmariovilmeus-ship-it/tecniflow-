export interface DatabaseResult {
  changes: number;
  lastInsertRowid?: number | bigint;
}

export interface DatabaseExecutor {
  query<T = any>(sql: string, params?: any[]): Promise<T[]>;
  queryOne<T = any>(sql: string, params?: any[]): Promise<T | null>;
  execute(sql: string, params?: any[]): Promise<DatabaseResult>;
}

export interface DatabaseAdapter extends DatabaseExecutor {
  readonly provider: 'sqlite' | 'postgres';
  withTransaction<T>(fn: (tx: DatabaseExecutor) => Promise<T>): Promise<T>;
  close(): Promise<void>;
  prepare(sql: string): any;
  exec(sql: string): any;
}
