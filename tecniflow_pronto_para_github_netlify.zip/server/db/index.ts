import { DatabaseAdapter } from './types.js';
import { SqliteAdapter } from './sqlite.js';
import { PostgresAdapter } from './postgres.js';

export * from './types.js';
export { SqliteAdapter } from './sqlite.js';
export { PostgresAdapter } from './postgres.js';

export function createDatabase(customPath?: string): DatabaseAdapter {
  const provider = (process.env.DB_PROVIDER || 'sqlite').toLowerCase();

  if (provider === 'postgres') {
    const adapter = new PostgresAdapter();
    return adapter;
  }

  return new SqliteAdapter(customPath);
}

// Singleton database instance used by the application
export const mainDb: DatabaseAdapter = createDatabase();
