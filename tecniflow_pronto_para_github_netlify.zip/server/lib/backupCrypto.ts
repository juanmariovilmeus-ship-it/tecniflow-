import crypto from 'node:crypto';
import fs from 'node:fs';
import { pipeline } from 'node:stream/promises';

export const BACKUP_MAGIC = Buffer.from('TFBK');
export const BACKUP_VERSION = 1;
export const IV_LENGTH = 12;
export const TAG_LENGTH = 16;
const HEADER_SIZE = 4 + 1 + IV_LENGTH + TAG_LENGTH;
export interface BackupManifest {
  manifestVersion: '1.0'; backupId: string; createdAt: string;
  databaseEngine: 'PostgreSQL'; schemasIncluded: string[]; tablesExplicit: string[];
  storageObjectsIncluded: false; storageBackupNote: string;
  encryption: {algorithm:'aes-256-gcm';keySource:'ENV_BACKUP_ENCRYPTION_KEY'};
  integrity: {sha256:string;fileSizeBytes:number;fileName:string};
  dumpFormat?: 'custom';
}

export function parseEncryptionKey(rawKey: string): Buffer {
  const value = rawKey.trim();
  if (/^[a-fA-F0-9]{64}$/.test(value)) return Buffer.from(value,'hex');
  if (/^[A-Za-z0-9+/]{43}=$/.test(value)) {
    const key = Buffer.from(value,'base64');
    if (key.length === 32 && key.toString('base64') === value) return key;
  }
  throw new Error('BACKUP_ENCRYPTION_KEY_INVALID');
}

export async function hashFile(file: string): Promise<string> {
  const hash = crypto.createHash('sha256');
  for await (const chunk of fs.createReadStream(file)) hash.update(chunk);
  return hash.digest('hex');
}

// Bounded streaming; a unique staging file is published only after GCM finalizes.
// The caller uses a .pending destination until pg_dump has also exited with code 0.
export async function encryptBackupStream(input: NodeJS.ReadableStream, outputPath: string, key: Buffer): Promise<{sha256:string;fileSizeBytes:number}> {
  const onSourceError = () => {};
  input.on('error',onSourceError);
  const temp = outputPath + '.tmp.' + crypto.randomUUID();
  const iv = crypto.randomBytes(IV_LENGTH);
  const prefix = Buffer.concat([BACKUP_MAGIC,Buffer.from([BACKUP_VERSION]),iv]);
  const cipher = crypto.createCipheriv('aes-256-gcm',key,iv);
  cipher.setAAD(prefix);
  try {
    await fs.promises.writeFile(temp,Buffer.concat([prefix,Buffer.alloc(TAG_LENGTH)]),{flag:'wx',mode:0o600});
    await pipeline(input,cipher,fs.createWriteStream(temp,{flags:'r+',start:HEADER_SIZE}));
    const handle = await fs.promises.open(temp,'r+');
    try { await handle.write(cipher.getAuthTag(),0,TAG_LENGTH,prefix.length); await handle.sync(); }
    finally { await handle.close(); }
    const sha256 = await hashFile(temp);
    const stat = await fs.promises.stat(temp);
    // link is atomic and refuses to overwrite any existing backup.
    await fs.promises.link(temp,outputPath);
    await fs.promises.unlink(temp);
    return {sha256,fileSizeBytes:stat.size};
  } catch {
    await fs.promises.unlink(temp).catch(()=>{});
    throw new Error('BACKUP_ENCRYPTION_FAILED');
  } finally { input.removeListener('error',onSourceError); }
}

// Authentication finishes before any decrypted archive is sent to a restore tool.
export async function decryptBackupFile(file: string,key: Buffer): Promise<Buffer> {
  const stat = await fs.promises.stat(file);
  if (stat.size < HEADER_SIZE || stat.size > 1024*1024*1024) throw new Error('BACKUP_SIZE_INVALID');
  const data = await fs.promises.readFile(file);
  if (!data.subarray(0,4).equals(BACKUP_MAGIC) || data[4] !== BACKUP_VERSION) throw new Error('BACKUP_FORMAT_INVALID');
  const prefix = data.subarray(0,5+IV_LENGTH);
  const decipher = crypto.createDecipheriv('aes-256-gcm',key,data.subarray(5,5+IV_LENGTH));
  decipher.setAAD(prefix);
  decipher.setAuthTag(data.subarray(prefix.length,HEADER_SIZE));
  try { return Buffer.concat([decipher.update(data.subarray(HEADER_SIZE)),decipher.final()]); }
  catch { throw new Error('BACKUP_AUTHENTICATION_FAILED'); }
}
