export type LogLevel='info'|'warn'|'error';
export interface StructuredLogContext {requestId?:string;method?:string;path?:string;status?:number;code?:string;durationMs?:number;[key:string]:unknown}
const codes=new Set(['INVALID_JSON_BODY','LEGACY_ROUTE_BLOCKED','SUPABASE_READINESS_FAILED','READINESS_PROBE_EXCEPTION','INTERNAL_ERROR','ALERT_DISPATCH_FAILED','ALERT_DESTINATION_NOT_CONFIGURED','ALERT_DISPATCHED','ALERT_REJECTED','SERVER_START_FAILED']);
const methods=new Set(['GET','POST','PUT','PATCH','DELETE','OPTIONS','HEAD']);
const areas=new Set(['auth','billing','orders','inventory','clients','help','health','company']);
export function logStructured(level:LogLevel,_message:string,context:StructuredLogContext={}):void {
  const entry:Record<string,unknown>={timestamp:new Date().toISOString(),level,code:codes.has(context.code||'')?context.code:'INTERNAL_ERROR'};
  if(typeof context.requestId==='string'&&/^[a-f0-9-]{36}$/i.test(context.requestId))entry.requestId=context.requestId;
  if(context.method&&methods.has(context.method))entry.method=context.method;
  if(typeof context.status==='number'&&Number.isInteger(context.status)&&context.status>=100&&context.status<=599)entry.status=context.status;
  for(const key of ['durationMs','latencyMs']){const v=context[key];if(typeof v==='number'&&Number.isFinite(v)&&v>=0&&v<=3600000)entry[key]=Math.round(v);}
  if(typeof context.path==='string'){
    const parts=context.path.toLowerCase().split(/[/?]/).filter(Boolean);
    const category=parts[0]==='api'?parts[1]:parts[0];
    entry.area=areas.has(category)?category:'system';
  }
  if(typeof context.area==='string'&&areas.has(context.area))entry.area=context.area;
  // Discard arbitrary message, URL, body, error object and every unrecognized field.
  const output=JSON.stringify(entry);
  if(level==='error')console.error(output);else if(level==='warn')console.warn(output);else console.log(output);
}
export const logger={info:(m:string,c?:StructuredLogContext)=>logStructured('info',m,c),warn:(m:string,c?:StructuredLogContext)=>logStructured('warn',m,c),error:(m:string,c?:StructuredLogContext)=>logStructured('error',m,c)};
