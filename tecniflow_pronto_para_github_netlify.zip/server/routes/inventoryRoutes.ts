import { Router, Response } from 'express';
import crypto from 'node:crypto';
import { AuthenticatedRequest, authenticateSession, requireCsrf } from '../auth.js';
import { mainDb } from '../db.js';
import { asyncHandler } from './asyncHandler.js';

export const inventoryRouter = Router();

inventoryRouter.use(authenticateSession);

// List inventory items with search & low stock filter
inventoryRouter.get('/', asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const companyId = req.company!.id;
  const search = typeof req.query.search === 'string' ? req.query.search.trim() : '';
  const category = typeof req.query.category === 'string' ? req.query.category.trim() : '';
  const lowStockOnly = req.query.lowStock === 'true';

  let query = 'SELECT * FROM inventory_items WHERE company_id = ? AND is_archived = 0';
  const params: any[] = [companyId];

  if (category && category !== 'todos') {
    query += ' AND category = ?';
    params.push(category);
  }

  if (lowStockOnly) {
    query += ' AND quantity <= min_quantity';
  }

  if (search) {
    query += ' AND (name LIKE ? OR sku LIKE ?)';
    const searchPattern = `%${search}%`;
    params.push(searchPattern, searchPattern);
  }

  query += ' ORDER BY name ASC';

  const items = await db.query(query, params);

  // Summary counts
  const summary = await db.queryOne(`
    SELECT 
      COUNT(*) as total_items,
      SUM(CASE WHEN quantity <= min_quantity THEN 1 ELSE 0 END) as low_stock_count,
      SUM(quantity * cost_price_cents) as total_cost_value_cents,
      SUM(quantity * sale_price_cents) as total_sale_value_cents
    FROM inventory_items
    WHERE company_id = ? AND is_archived = 0
  `, [companyId]) as any;

  res.json({
    items,
    summary: {
      totalItems: Number(summary?.total_items || 0),
      lowStockCount: Number(summary?.low_stock_count || 0),
      totalCostValueCents: Number(summary?.total_cost_value_cents || 0),
      totalSaleValueCents: Number(summary?.total_sale_value_cents || 0)
    }
  });
}));

// Get single inventory item with its movement history
inventoryRouter.get('/:id', asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const companyId = req.company!.id;
  const itemId = req.params.id;

  const item = await db.queryOne('SELECT * FROM inventory_items WHERE id = ? AND company_id = ?', [itemId, companyId]);
  if (!item) {
    res.status(404).json({ error: 'Item de estoque não encontrado.' });
    return;
  }

  const movements = await db.query(`
    SELECT * FROM inventory_movements
    WHERE item_id = ? AND company_id = ?
    ORDER BY created_at DESC
    LIMIT 50
  `, [itemId, companyId]);

  res.json({ item, movements });
}));

// Create inventory item
inventoryRouter.post('/', requireCsrf, asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const companyId = req.company!.id;

  if (!req.body || typeof req.body !== 'object' || Array.isArray(req.body)) {
    res.status(400).json({ error: 'Corpo da requisição inválido.' });
    return;
  }

  const {
    name,
    sku,
    category,
    minQuantity,
    costPriceCents,
    salePriceCents
  } = req.body;
  const rawQty = req.body.initialQuantity !== undefined ? req.body.initialQuantity : req.body.quantity;

  if (!name || typeof name !== 'string' || !name.trim() || name.trim().length > 150) {
    res.status(400).json({ error: 'O nome da peça/componente é obrigatório (máximo 150 caracteres).' });
    return;
  }

  const parsedQty = parseInt(rawQty, 10);
  if (isNaN(parsedQty) || parsedQty < 0 || parsedQty > 1000000) {
    res.status(400).json({ error: 'A quantidade inicial deve ser um número inteiro não negativo válido.' });
    return;
  }

  const parsedMinQty = parseInt(minQuantity, 10);
  if (isNaN(parsedMinQty) || parsedMinQty < 0 || parsedMinQty > 1000000) {
    res.status(400).json({ error: 'A quantidade mínima deve ser um número inteiro não negativo válido.' });
    return;
  }

  const parsedCost = parseInt(costPriceCents, 10);
  if (isNaN(parsedCost) || parsedCost < 0 || parsedCost > Number.MAX_SAFE_INTEGER) {
    res.status(400).json({ error: 'O preço de custo em centavos deve ser um inteiro não negativo válido.' });
    return;
  }

  const parsedSale = parseInt(salePriceCents, 10);
  if (isNaN(parsedSale) || parsedSale < 0 || parsedSale > Number.MAX_SAFE_INTEGER) {
    res.status(400).json({ error: 'O preço de venda em centavos deve ser um inteiro não negativo válido.' });
    return;
  }

  const itemId = crypto.randomUUID();
  const now = new Date().toISOString();

  try {
    await db.withTransaction(async (tx) => {
      await tx.execute(`
        INSERT INTO inventory_items (
          id, company_id, name, sku, category, quantity, min_quantity,
          cost_price_cents, sale_price_cents, is_archived, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)
      `, [
        itemId,
        companyId,
        name.trim(),
        sku ? String(sku).trim().slice(0, 50) : '',
        category ? String(category).trim().toLowerCase().slice(0, 50) : 'geral',
        parsedQty,
        parsedMinQty,
        parsedCost,
        parsedSale,
        now,
        now
      ]);

      if (parsedQty > 0) {
        await tx.execute(`
          INSERT INTO inventory_movements (
            id, company_id, item_id, type, quantity, previous_quantity, new_quantity, reason, user_name, created_at
          ) VALUES (?, ?, ?, 'entrada', ?, 0, ?, 'Saldo inicial no cadastro', ?, ?)
        `, [
          crypto.randomUUID(),
          companyId,
          itemId,
          parsedQty,
          parsedQty,
          req.user?.name || 'Sistema',
          now
        ]);
      }
    });

    const created = await db.queryOne('SELECT * FROM inventory_items WHERE id = ?', [itemId]);
    res.status(201).json({ message: 'Peça cadastrada no estoque com sucesso.', item: created });
  } catch (err) {
    throw err;
  }
}));

// Update inventory item details
inventoryRouter.put('/:id', requireCsrf, asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const companyId = req.company!.id;
  const itemId = req.params.id;

  if (!req.body || typeof req.body !== 'object' || Array.isArray(req.body)) {
    res.status(400).json({ error: 'Corpo da requisição inválido.' });
    return;
  }

  const { name, sku, category, minQuantity, costPriceCents, salePriceCents } = req.body;

  if (!name || typeof name !== 'string' || !name.trim() || name.trim().length > 150) {
    res.status(400).json({ error: 'O nome da peça é obrigatório (máximo 150 caracteres).' });
    return;
  }

  const parsedMinQty = parseInt(minQuantity, 10);
  if (isNaN(parsedMinQty) || parsedMinQty < 0) {
    res.status(400).json({ error: 'Estoque mínimo deve ser um número inteiro não negativo.' });
    return;
  }

  const parsedCost = parseInt(costPriceCents, 10);
  if (isNaN(parsedCost) || parsedCost < 0 || parsedCost > Number.MAX_SAFE_INTEGER) {
    res.status(400).json({ error: 'Preço de custo em centavos deve ser um inteiro não negativo.' });
    return;
  }

  const parsedSale = parseInt(salePriceCents, 10);
  if (isNaN(parsedSale) || parsedSale < 0 || parsedSale > Number.MAX_SAFE_INTEGER) {
    res.status(400).json({ error: 'Preço de venda em centavos deve ser um inteiro não negativo.' });
    return;
  }

  const existing = await db.queryOne('SELECT id FROM inventory_items WHERE id = ? AND company_id = ?', [itemId, companyId]);
  if (!existing) {
    res.status(404).json({ error: 'Item de estoque não encontrado.' });
    return;
  }

  const now = new Date().toISOString();
  await db.execute(`
    UPDATE inventory_items
    SET name = ?, sku = ?, category = ?, min_quantity = ?, cost_price_cents = ?, sale_price_cents = ?, updated_at = ?
    WHERE id = ? AND company_id = ?
  `, [
    name.trim(),
    sku ? String(sku).trim().slice(0, 50) : '',
    category ? String(category).trim().toLowerCase().slice(0, 50) : 'geral',
    parsedMinQty,
    parsedCost,
    parsedSale,
    now,
    itemId,
    companyId
  ]);

  const updated = await db.queryOne('SELECT * FROM inventory_items WHERE id = ?', [itemId]);
  res.json({ message: 'Item atualizado com sucesso.', item: updated });
}));

// Manual inventory movement (Entrada ou Saída manual) with atomic conditional deduction
inventoryRouter.post('/:id/movement', requireCsrf, asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const companyId = req.company!.id;
  const itemId = req.params.id;

  if (!req.body || typeof req.body !== 'object' || Array.isArray(req.body)) {
    res.status(400).json({ error: 'Corpo da requisição inválido.' });
    return;
  }

  const { type, quantity, reason } = req.body;

  if (!type || !['entrada', 'saida_manual'].includes(type)) {
    res.status(400).json({ error: 'Tipo de movimentação inválido. Use entrada ou saida_manual.' });
    return;
  }

  const qty = parseInt(quantity, 10);
  if (isNaN(qty) || qty <= 0 || !Number.isInteger(qty) || qty > 1000000) {
    res.status(400).json({ error: 'A quantidade movimentada deve ser um número inteiro positivo maior que zero.' });
    return;
  }

  if (!reason || typeof reason !== 'string' || !reason.trim() || reason.trim().length > 255) {
    res.status(400).json({ error: 'Informe a justificativa ou motivo da movimentação (máximo 255 caracteres).' });
    return;
  }

  let errorResponse: { status: number; message: string } | null = null;
  let updatedItem: any = null;

  try {
    await db.withTransaction(async (tx) => {
      const item = await tx.queryOne<{
        id: string;
        name: string;
        quantity: number;
      }>('SELECT id, name, quantity FROM inventory_items WHERE id = ? AND company_id = ? AND is_archived = 0 FOR UPDATE', [itemId, companyId]);

      if (!item) {
        errorResponse = { status: 404, message: 'Item de estoque não encontrado ou inativo.' };
        throw new Error('NOT_FOUND');
      }

      const currentQty = item.quantity;
      const now = new Date().toISOString();
      let newQty = currentQty;

      if (type === 'saida_manual') {
        const updateResult = await tx.execute(`
          UPDATE inventory_items
          SET quantity = quantity - ?, updated_at = ?
          WHERE id = ? AND company_id = ? AND quantity >= ?
        `, [qty, now, itemId, companyId, qty]);

        if (updateResult.changes === 0) {
          errorResponse = {
            status: 400,
            message: `Saldo insuficiente em estoque! Saldo atual de "${item.name}": ${currentQty} unidade(s). Quantidade solicitada: ${qty} unidade(s). Operação bloqueada.`
          };
          throw new Error('INSUFFICIENT_STOCK');
        }
        newQty = currentQty - qty;
      } else {
        await tx.execute(`
          UPDATE inventory_items
          SET quantity = quantity + ?, updated_at = ?
          WHERE id = ? AND company_id = ?
        `, [qty, now, itemId, companyId]);
        newQty = currentQty + qty;
      }

      await tx.execute(`
        INSERT INTO inventory_movements (
          id, company_id, item_id, type, quantity, previous_quantity, new_quantity, reason, user_name, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        crypto.randomUUID(),
        companyId,
        itemId,
        type,
        qty,
        currentQty,
        newQty,
        reason.trim(),
        req.user?.name || 'Sistema',
        now
      ]);

      updatedItem = await tx.queryOne('SELECT * FROM inventory_items WHERE id = ?', [itemId]);
    });

    res.json({ message: 'Movimentação registrada com sucesso.', item: updatedItem });
  } catch (err: any) {
    if (errorResponse !== null) {
      const errObj: { status: number; message: string } = errorResponse;
      res.status(errObj.status).json({ error: errObj.message });
      return;
    }
    throw err;
  }
}));
