import { Router, Response } from 'express';
import crypto from 'node:crypto';
import { AuthenticatedRequest, authenticateSession, requireCsrf } from '../auth.js';
import { mainDb } from '../db.js';
import { asyncHandler } from './asyncHandler.js';

export const orderRouter = Router();

orderRouter.use(authenticateSession);

const ALLOWED_TRANSITIONS: Record<string, string[]> = {
  recebido: ['diagnostico', 'cancelado'],
  diagnostico: ['aguardando_aprovacao', 'cancelado'],
  aguardando_aprovacao: ['reparo', 'cancelado'],
  reparo: ['pronto', 'cancelado'],
  pronto: ['entregue', 'cancelado'],
  entregue: [],
  cancelado: []
};

function isInvalidBody(body: any): boolean {
  return !body || typeof body !== 'object' || Array.isArray(body);
}

function parseAndValidateVersion(rawVersion: any): { valid: true; version: number } | { valid: false; error: string } {
  if (rawVersion === undefined || rawVersion === null) {
    return { valid: false, error: 'O campo version é obrigatório e deve ser um número inteiro.' };
  }
  if (typeof rawVersion !== 'number' || !Number.isInteger(rawVersion) || rawVersion <= 0) {
    return { valid: false, error: 'O campo version deve ser um número inteiro positivo.' };
  }
  return { valid: true, version: rawVersion };
}

// List orders with filters (status, client, priority, search)
orderRouter.get('/', asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const companyId = req.company!.id;
  const status = typeof req.query.status === 'string' ? req.query.status.trim() : '';
  const search = typeof req.query.search === 'string' ? req.query.search.trim() : '';
  const priority = typeof req.query.priority === 'string' ? req.query.priority.trim() : '';

  let query = `
    SELECT o.*, c.name as client_name, c.phone as client_phone
    FROM orders o
    JOIN clients c ON c.id = o.client_id AND c.company_id = o.company_id
    WHERE o.company_id = ?
  `;
  const params: any[] = [companyId];

  if (status && status !== 'todos') {
    query += ' AND o.status = ?';
    params.push(status);
  }

  if (priority && priority !== 'todas') {
    query += ' AND o.priority = ?';
    params.push(priority);
  }

  if (search) {
    query += ' AND (o.order_number::text LIKE ? OR o.brand LIKE ? OR o.model LIKE ? OR o.serial_imei LIKE ? OR c.name LIKE ? OR c.phone LIKE ?)';
    // Note: in SQLite order_number::text might fail, so let's use CAST(o.order_number AS TEXT)
    // which is 100% ANSI standard in both Postgres and SQLite!
  }

  // Use ANSI standard CAST(o.order_number AS TEXT)
  let standardQuery = `
    SELECT o.*, c.name as client_name, c.phone as client_phone
    FROM orders o
    JOIN clients c ON c.id = o.client_id AND c.company_id = o.company_id
    WHERE o.company_id = ?
  `;
  const stdParams: any[] = [companyId];

  if (status && status !== 'todos') {
    standardQuery += ' AND o.status = ?';
    stdParams.push(status);
  }

  if (priority && priority !== 'todas') {
    standardQuery += ' AND o.priority = ?';
    stdParams.push(priority);
  }

  if (search) {
    standardQuery += ' AND (CAST(o.order_number AS TEXT) LIKE ? OR o.brand LIKE ? OR o.model LIKE ? OR o.serial_imei LIKE ? OR c.name LIKE ? OR c.phone LIKE ?)';
    const searchPattern = `%${search}%`;
    stdParams.push(searchPattern, searchPattern, searchPattern, searchPattern, searchPattern, searchPattern);
  }

  standardQuery += ' ORDER BY o.order_number DESC';

  const orders = await db.query(standardQuery, stdParams);
  res.json({ orders });
}));

// Get single order with client details, services, parts, and history
orderRouter.get('/:id', asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const companyId = req.company!.id;
  const orderId = req.params.id;

  const order = await db.queryOne(`
    SELECT o.*, 
           c.name as client_name, c.phone as client_phone, c.whatsapp as client_whatsapp,
           c.email as client_email, c.document as client_document, c.address as client_address
    FROM orders o
    JOIN clients c ON c.id = o.client_id AND c.company_id = o.company_id
    WHERE o.id = ? AND o.company_id = ?
  `, [orderId, companyId]);

  if (!order) {
    res.status(404).json({ error: 'Ordem de serviço não encontrada.' });
    return;
  }

  const services = await db.query(`
    SELECT * FROM order_services WHERE order_id = ? AND company_id = ? ORDER BY id ASC
  `, [orderId, companyId]);

  // Protected join with company_id on both sides
  const parts = await db.query(`
    SELECT op.*, ii.name as inventory_item_name, ii.quantity as current_stock_quantity
    FROM order_parts op
    LEFT JOIN inventory_items ii ON ii.id = op.inventory_item_id AND ii.company_id = op.company_id
    WHERE op.order_id = ? AND op.company_id = ?
    ORDER BY op.id ASC
  `, [orderId, companyId]);

  const history = await db.query(`
    SELECT * FROM order_history WHERE order_id = ? AND company_id = ? ORDER BY created_at DESC
  `, [orderId, companyId]);

  res.json({ order, services, parts, history });
}));

// Create new order
orderRouter.post('/', requireCsrf, asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const companyId = req.company!.id;

  if (isInvalidBody(req.body)) {
    res.status(400).json({ error: 'Corpo da requisição inválido.' });
    return;
  }

  const {
    clientId,
    deviceType,
    brand,
    model,
    serialImei,
    defectReported,
    accessories,
    entryCondition,
    priority,
    estimatedDelivery
  } = req.body;

  if (!clientId || typeof clientId !== 'string') {
    res.status(400).json({ error: 'Selecione um cliente válido para a ordem de serviço.' });
    return;
  }

  // Strictly verify client belongs to company and is active
  const client = await db.queryOne('SELECT id, name FROM clients WHERE id = ? AND company_id = ? AND is_archived = 0', [clientId, companyId]);
  if (!client) {
    res.status(400).json({ error: 'Cliente não encontrado ou inativo nesta assistência técnica.' });
    return;
  }

  if (!brand || typeof brand !== 'string' || !brand.trim() || brand.trim().length > 50) {
    res.status(400).json({ error: 'A marca do aparelho é obrigatória (máximo 50 caracteres).' });
    return;
  }

  if (!model || typeof model !== 'string' || !model.trim() || model.trim().length > 50) {
    res.status(400).json({ error: 'O modelo do aparelho é obrigatório (máximo 50 caracteres).' });
    return;
  }

  if (!defectReported || typeof defectReported !== 'string' || !defectReported.trim() || defectReported.trim().length > 500) {
    res.status(400).json({ error: 'Informe o defeito relatado pelo cliente (máximo 500 caracteres).' });
    return;
  }

  const validDeviceTypes = ['smartphone', 'notebook', 'computador', 'tablet', 'smartwatch', 'outro'];
  const sanitizedDeviceType = validDeviceTypes.includes(deviceType) ? deviceType : 'smartphone';

  const validPriorities = ['baixa', 'normal', 'alta', 'urgente'];
  const sanitizedPriority = validPriorities.includes(priority) ? priority : 'normal';

  const orderId = crypto.randomUUID();
  const now = new Date().toISOString();
  let createdOrder: any = null;

  try {
    await db.withTransaction(async (tx) => {
      // Concurrency lock on company row to serialize order sequence generation safely
      await tx.query('SELECT id FROM companies WHERE id = ? FOR UPDATE', [companyId]);

      const maxNumRow = await tx.queryOne<{ max_num: number }>(
        'SELECT COALESCE(MAX(order_number), 0) as max_num FROM orders WHERE company_id = ?',
        [companyId]
      );
      const nextOrderNumber = Number(maxNumRow?.max_num || 0) + 1;

      await tx.execute(`
        INSERT INTO orders (
          id, company_id, order_number, client_id, device_type, brand, model,
          serial_imei, defect_reported, accessories, entry_condition, technical_diagnosis,
          priority, estimated_delivery, status, budget_status, total_services_cents,
          total_parts_cents, total_amount_cents, version, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '', ?, ?, 'recebido', 'pendente', 0, 0, 0, 1, ?, ?)
      `, [
        orderId,
        companyId,
        nextOrderNumber,
        clientId,
        sanitizedDeviceType,
        brand.trim(),
        model.trim(),
        serialImei ? String(serialImei).trim().slice(0, 50) : '',
        defectReported.trim(),
        accessories ? String(accessories).trim().slice(0, 255) : '',
        entryCondition ? String(entryCondition).trim().slice(0, 500) : '',
        sanitizedPriority,
        estimatedDelivery ? String(estimatedDelivery).trim().slice(0, 30) : '',
        now,
        now
      ]);

      await tx.execute(`
        INSERT INTO order_history (id, company_id, order_id, action, description, user_name, created_at)
        VALUES (?, ?, ?, 'criacao', ?, ?, ?)
      `, [
        crypto.randomUUID(),
        companyId,
        orderId,
        `Ordem de serviço #${String(nextOrderNumber).padStart(4, '0')} aberta com status "Recebido".`,
        req.user?.name || 'Sistema',
        now
      ]);

      createdOrder = await tx.queryOne('SELECT * FROM orders WHERE id = ?', [orderId]);
    });

    res.status(201).json({ message: 'Ordem de serviço criada com sucesso.', order: createdOrder });
  } catch (err) {
    throw err;
  }
}));

// Update order general details (diagnosis, priority, device info, estimated delivery)
orderRouter.put('/:id', requireCsrf, asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const companyId = req.company!.id;
  const orderId = req.params.id;

  if (isInvalidBody(req.body)) {
    res.status(400).json({ error: 'Corpo da requisição inválido.' });
    return;
  }

  const versionValidation = parseAndValidateVersion(req.body.version);
  if (!versionValidation.valid) {
    res.status(400).json({ error: versionValidation.error });
    return;
  }
  const version = versionValidation.version;

  const {
    deviceType,
    brand,
    model,
    serialImei,
    defectReported,
    accessories,
    entryCondition,
    technicalDiagnosis,
    priority,
    estimatedDelivery
  } = req.body;

  let errorResponse: { status: number; body: any } | null = null;
  let updatedOrder: any = null;

  try {
    await db.withTransaction(async (tx) => {
      // Lock order record inside transaction to prevent concurrency race window
      const existing = await tx.queryOne<any>(
        'SELECT * FROM orders WHERE id = ? AND company_id = ? FOR UPDATE',
        [orderId, companyId]
      );

      if (!existing) {
        errorResponse = { status: 404, body: { error: 'Ordem de serviço não encontrada.' } };
        throw new Error('NOT_FOUND');
      }

      if (existing.version !== version) {
        errorResponse = {
          status: 409,
          body: {
            error: 'A ordem de serviço foi modificada por outro processo. Recarregue a página.',
            currentVersion: existing.version
          }
        };
        throw new Error('VERSION_CONFLICT');
      }

      if (existing.status === 'entregue' || existing.status === 'cancelado') {
        errorResponse = {
          status: 400,
          body: { error: 'Não é possível alterar dados de uma ordem de serviço em estado terminal.' }
        };
        throw new Error('TERMINAL_STATE');
      }

      const validDeviceTypes = ['smartphone', 'notebook', 'computador', 'tablet', 'smartwatch', 'outro'];
      const sanitizedDeviceType = deviceType && validDeviceTypes.includes(deviceType) ? deviceType : existing.device_type;

      const validPriorities = ['baixa', 'normal', 'alta', 'urgente'];
      const sanitizedPriority = priority && validPriorities.includes(priority) ? priority : existing.priority;

      const nextVersion = existing.version + 1;
      const now = new Date().toISOString();

      const updateResult = await tx.execute(`
        UPDATE orders
        SET device_type = ?, brand = ?, model = ?, serial_imei = ?, defect_reported = ?,
            accessories = ?, entry_condition = ?, technical_diagnosis = ?, priority = ?,
            estimated_delivery = ?, version = ?, updated_at = ?
        WHERE id = ? AND company_id = ? AND version = ?
      `, [
        sanitizedDeviceType,
        brand ? String(brand).trim().slice(0, 50) : existing.brand,
        model ? String(model).trim().slice(0, 50) : existing.model,
        serialImei !== undefined ? String(serialImei).trim().slice(0, 50) : existing.serial_imei,
        defectReported ? String(defectReported).trim().slice(0, 500) : existing.defect_reported,
        accessories !== undefined ? String(accessories).trim().slice(0, 255) : existing.accessories,
        entryCondition !== undefined ? String(entryCondition).trim().slice(0, 500) : existing.entry_condition,
        technicalDiagnosis !== undefined ? String(technicalDiagnosis).trim().slice(0, 1000) : existing.technical_diagnosis,
        sanitizedPriority,
        estimatedDelivery !== undefined ? String(estimatedDelivery).trim().slice(0, 30) : existing.estimated_delivery,
        nextVersion,
        now,
        orderId,
        companyId,
        version
      ]);

      if (updateResult.changes === 0) {
        errorResponse = {
          status: 409,
          body: {
            error: 'A ordem de serviço foi modificada por outro processo. Recarregue a página.',
            currentVersion: existing.version
          }
        };
        throw new Error('VERSION_CONFLICT');
      }

      if (technicalDiagnosis && technicalDiagnosis.trim() !== (existing.technical_diagnosis || '').trim()) {
        await tx.execute(`
          INSERT INTO order_history (id, company_id, order_id, action, description, user_name, created_at)
          VALUES (?, ?, ?, 'diagnostico', 'Diagnóstico técnico atualizado.', ?, ?)
        `, [
          crypto.randomUUID(),
          companyId,
          orderId,
          req.user?.name || 'Sistema',
          now
        ]);
      }

      updatedOrder = await tx.queryOne('SELECT * FROM orders WHERE id = ?', [orderId]);
    });

    res.json({ message: 'Dados da ordem de serviço atualizados.', order: updatedOrder });
  } catch (err: any) {
    if (errorResponse !== null) {
      const errObj: { status: number; body: any } = errorResponse;
      res.status(errObj.status).json(errObj.body);
      return;
    }
    throw err;
  }
}));

// Explicit budget revision endpoint
orderRouter.post('/:id/budget/revise', requireCsrf, asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const companyId = req.company!.id;
  const orderId = req.params.id;

  if (isInvalidBody(req.body)) {
    res.status(400).json({ error: 'Corpo da requisição inválido.' });
    return;
  }

  const versionValidation = parseAndValidateVersion(req.body.version);
  if (!versionValidation.valid) {
    res.status(400).json({ error: versionValidation.error });
    return;
  }
  const version = versionValidation.version;

  let errorResponse: { status: number; body: any } | null = null;
  let updatedOrder: any = null;

  try {
    await db.withTransaction(async (tx) => {
      // Lock order inside transaction
      const order = await tx.queryOne<any>(
        'SELECT * FROM orders WHERE id = ? AND company_id = ? FOR UPDATE',
        [orderId, companyId]
      );

      if (!order) {
        errorResponse = { status: 404, body: { error: 'Ordem de serviço não encontrada.' } };
        throw new Error('NOT_FOUND');
      }

      if (order.version !== version) {
        errorResponse = {
          status: 409,
          body: {
            error: 'A ordem de serviço foi alterada por outro usuário ou processo. Recarregue a página.',
            currentVersion: order.version
          }
        };
        throw new Error('VERSION_CONFLICT');
      }

      const debitedParts = await tx.queryOne<{ c: number }>(
        'SELECT COUNT(*) as c FROM order_parts WHERE order_id = ? AND company_id = ? AND inventory_debited = 1',
        [orderId, companyId]
      );
      if (debitedParts && Number(debitedParts.c) > 0) {
        errorResponse = {
          status: 400,
          body: { error: 'Não é possível revisar o orçamento pois já existem peças debitadas no estoque.' }
        };
        throw new Error('PARTS_DEBITED');
      }

      if (['reparo', 'pronto', 'entregue', 'cancelado'].includes(order.status)) {
        errorResponse = {
          status: 400,
          body: { error: `Não é possível revisar o orçamento com status "${order.status}".` }
        };
        throw new Error('INVALID_STATUS');
      }

      const now = new Date().toISOString();
      const nextVersion = order.version + 1;
      const userName = req.user?.name || 'Sistema';

      const updateResult = await tx.execute(`
        UPDATE orders
        SET budget_status = 'pendente', budget_approved_at = NULL, budget_approved_by = NULL,
            version = ?, updated_at = ?
        WHERE id = ? AND company_id = ? AND version = ?
      `, [nextVersion, now, orderId, companyId, version]);

      if (updateResult.changes === 0) {
        errorResponse = {
          status: 409,
          body: {
            error: 'A ordem de serviço foi alterada por outro usuário ou processo. Recarregue a página.',
            currentVersion: order.version
          }
        };
        throw new Error('VERSION_CONFLICT');
      }

      await tx.execute(`
        INSERT INTO order_history (id, company_id, order_id, action, description, user_name, created_at)
        VALUES (?, ?, ?, 'revisao_orcamento', 'Orçamento reaberto para revisão de itens e valores.', ?, ?)
      `, [crypto.randomUUID(), companyId, orderId, userName, now]);

      updatedOrder = await tx.queryOne('SELECT * FROM orders WHERE id = ?', [orderId]);
    });

    res.json({ message: 'Orçamento reaberto para revisão com sucesso.', order: updatedOrder });
  } catch (err: any) {
    if (errorResponse !== null) {
      const errObj: { status: number; body: any } = errorResponse;
      res.status(errObj.status).json(errObj.body);
      return;
    }
    throw err;
  }
}));

// Update budget items (services and parts) with strict item ownership validation and no float errors
orderRouter.put('/:id/budget', requireCsrf, asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const companyId = req.company!.id;
  const orderId = req.params.id;

  if (isInvalidBody(req.body)) {
    res.status(400).json({ error: 'Corpo da requisição inválido.' });
    return;
  }

  const versionValidation = parseAndValidateVersion(req.body.version);
  if (!versionValidation.valid) {
    res.status(400).json({ error: versionValidation.error });
    return;
  }
  const version = versionValidation.version;

  const { services, parts } = req.body;

  if (!Array.isArray(services)) {
    res.status(400).json({ error: 'A lista de serviços deve ser um array.' });
    return;
  }

  if (!Array.isArray(parts)) {
    res.status(400).json({ error: 'A lista de peças deve ser um array.' });
    return;
  }

  let totalServicesCents = 0;
  const sanitizedServices: Array<{ id: string; description: string; unit_price_cents: number; quantity: number; total_cents: number }> = [];

  for (let i = 0; i < services.length; i++) {
    const s = services[i];
    if (!s || typeof s !== 'object') {
      res.status(400).json({ error: `Item de serviço na posição ${i + 1} é inválido.` });
      return;
    }

    const desc = typeof s.description === 'string' ? s.description.trim() : '';
    if (!desc || desc.length > 200) {
      res.status(400).json({ error: `A descrição do serviço #${i + 1} é obrigatória (máximo 200 caracteres).` });
      return;
    }

    const qty = s.quantity;
    if (!Number.isInteger(qty) || qty <= 0 || qty > 1000) {
      res.status(400).json({ error: `A quantidade do serviço "${desc}" deve ser um número inteiro positivo.` });
      return;
    }

    const unitCents = s.unit_price_cents;
    if (!Number.isInteger(unitCents) || unitCents < 0 || unitCents > Number.MAX_SAFE_INTEGER) {
      res.status(400).json({ error: `O valor do serviço "${desc}" deve ser um número inteiro não negativo em centavos.` });
      return;
    }

    const lineTotal = unitCents * qty;
    if (lineTotal > Number.MAX_SAFE_INTEGER) {
      res.status(400).json({ error: `O total do serviço "${desc}" excede o limite numérico seguro.` });
      return;
    }

    totalServicesCents += lineTotal;
    sanitizedServices.push({
      id: crypto.randomUUID(),
      description: desc,
      unit_price_cents: unitCents,
      quantity: qty,
      total_cents: lineTotal
    });
  }

  // Validate parts and verify strict company ownership
  let totalPartsCents = 0;
  const sanitizedParts: Array<{ id: string; inventory_item_id: string | null; description: string; unit_price_cents: number; quantity: number; total_cents: number }> = [];

  for (let i = 0; i < parts.length; i++) {
    const p = parts[i];
    if (!p || typeof p !== 'object') {
      res.status(400).json({ error: `Item de peça na posição ${i + 1} é inválido.` });
      return;
    }

    const desc = typeof p.description === 'string' ? p.description.trim() : '';
    if (!desc || desc.length > 200) {
      res.status(400).json({ error: `A descrição da peça #${i + 1} é obrigatória (máximo 200 caracteres).` });
      return;
    }

    const qty = p.quantity;
    if (!Number.isInteger(qty) || qty <= 0 || qty > 10000) {
      res.status(400).json({ error: `A quantidade da peça "${desc}" deve ser um número inteiro positivo.` });
      return;
    }

    const unitCents = p.unit_price_cents;
    if (!Number.isInteger(unitCents) || unitCents < 0 || unitCents > Number.MAX_SAFE_INTEGER) {
      res.status(400).json({ error: `O valor da peça "${desc}" deve ser um número inteiro não negativo em centavos.` });
      return;
    }

    let invItemId: string | null = null;
    if (p.inventory_item_id) {
      if (typeof p.inventory_item_id !== 'string') {
        res.status(400).json({ error: `ID de item de estoque inválido na peça "${desc}".` });
        return;
      }

      // Strictly validate inventory item ownership and active status
      const invItem = await db.queryOne('SELECT id, name FROM inventory_items WHERE id = ? AND company_id = ? AND is_archived = 0', [p.inventory_item_id, companyId]);
      if (!invItem) {
        res.status(400).json({ error: `A peça "${desc}" vinculada a estoque não pertence à sua assistência técnica ou está inativa.` });
        return;
      }
      invItemId = invItem.id;
    }

    const lineTotal = unitCents * qty;
    if (lineTotal > Number.MAX_SAFE_INTEGER) {
      res.status(400).json({ error: `O total da peça "${desc}" excede o limite numérico seguro.` });
      return;
    }

    totalPartsCents += lineTotal;
    sanitizedParts.push({
      id: crypto.randomUUID(),
      inventory_item_id: invItemId,
      description: desc,
      unit_price_cents: unitCents,
      quantity: qty,
      total_cents: lineTotal
    });
  }

  const totalAmountCents = totalServicesCents + totalPartsCents;
  if (totalAmountCents > Number.MAX_SAFE_INTEGER) {
    res.status(400).json({ error: 'O valor total do orçamento excede o limite suportado.' });
    return;
  }

  let errorResponse: { status: number; body: any } | null = null;
  let nextVersion = version + 1;

  try {
    await db.withTransaction(async (tx) => {
      // Lock order record inside transaction
      const order = await tx.queryOne<any>(
        'SELECT * FROM orders WHERE id = ? AND company_id = ? FOR UPDATE',
        [orderId, companyId]
      );

      if (!order) {
        errorResponse = { status: 404, body: { error: 'Ordem de serviço não encontrada.' } };
        throw new Error('NOT_FOUND');
      }

      if (['reparo', 'pronto', 'entregue', 'cancelado'].includes(order.status)) {
        errorResponse = { status: 400, body: { error: `Não é possível alterar o orçamento de uma OS em "${order.status}".` } };
        throw new Error('INVALID_STATUS');
      }

      const debitedCheck = await tx.queryOne<{ c: number }>(
        'SELECT COUNT(*) as c FROM order_parts WHERE order_id = ? AND company_id = ? AND inventory_debited = 1',
        [orderId, companyId]
      );
      if (debitedCheck && Number(debitedCheck.c) > 0) {
        errorResponse = {
          status: 400,
          body: { error: 'Não é possível alterar itens ou valores pois já existem peças baixadas no estoque para esta OS.' }
        };
        throw new Error('PARTS_DEBITED');
      }

      if (order.budget_status === 'aprovado') {
        errorResponse = {
          status: 400,
          body: { error: 'Este orçamento já está aprovado. Use o botão "Reabrir para Revisão" antes de modificar itens ou valores.' }
        };
        throw new Error('BUDGET_APPROVED');
      }

      if (order.version !== version) {
        errorResponse = {
          status: 409,
          body: {
            error: 'A ordem de serviço foi modificada por outro processo. Recarregue a página.',
            currentVersion: order.version
          }
        };
        throw new Error('VERSION_CONFLICT');
      }

      const now = new Date().toISOString();
      nextVersion = (order.version || 1) + 1;

      // Remove existing services and un-debited parts
      await tx.execute('DELETE FROM order_services WHERE order_id = ? AND company_id = ?', [orderId, companyId]);
      await tx.execute('DELETE FROM order_parts WHERE order_id = ? AND company_id = ? AND inventory_debited = 0', [orderId, companyId]);

      // Insert sanitized services
      for (const s of sanitizedServices) {
        await tx.execute(`
          INSERT INTO order_services (id, company_id, order_id, description, unit_price_cents, quantity, total_cents)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `, [s.id, companyId, orderId, s.description, s.unit_price_cents, s.quantity, s.total_cents]);
      }

      // Insert sanitized parts
      for (const p of sanitizedParts) {
        await tx.execute(`
          INSERT INTO order_parts (id, company_id, order_id, inventory_item_id, description, unit_price_cents, quantity, total_cents, inventory_debited)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)
        `, [p.id, companyId, orderId, p.inventory_item_id, p.description, p.unit_price_cents, p.quantity, p.total_cents]);
      }

      // Update order totals and version
      const updateResult = await tx.execute(`
        UPDATE orders
        SET total_services_cents = ?, total_parts_cents = ?, total_amount_cents = ?, version = ?, updated_at = ?
        WHERE id = ? AND company_id = ? AND version = ?
      `, [totalServicesCents, totalPartsCents, totalAmountCents, nextVersion, now, orderId, companyId, version]);

      if (updateResult.changes === 0) {
        errorResponse = {
          status: 409,
          body: {
            error: 'A ordem de serviço foi modificada por outro processo. Recarregue a página.',
            currentVersion: order.version
          }
        };
        throw new Error('VERSION_CONFLICT');
      }

      // Record budget history
      const formattedTotal = (totalAmountCents / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
      await tx.execute(`
        INSERT INTO order_history (id, company_id, order_id, action, description, user_name, created_at)
        VALUES (?, ?, ?, 'orcamento', ?, ?, ?)
      `, [
        crypto.randomUUID(),
        companyId,
        orderId,
        `Orçamento atualizado para ${formattedTotal} (${sanitizedServices.length} serviço(s) e ${sanitizedParts.length} peça(s)).`,
        req.user?.name || 'Sistema',
        now
      ]);
    });

    res.json({
      message: 'Orçamento atualizado e calculado pelo servidor com sucesso.',
      totals: {
        totalServicesCents,
        totalPartsCents,
        totalAmountCents
      },
      version: nextVersion
    });
  } catch (err: any) {
    if (errorResponse !== null) {
      const errObj: { status: number; body: any } = errorResponse;
      res.status(errObj.status).json(errObj.body);
      return;
    }
    throw err;
  }
}));

// Manual approval or rejection of budget (Does NOT transition status or debit stock directly)
orderRouter.post('/:id/budget/decision', requireCsrf, asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const companyId = req.company!.id;
  const orderId = req.params.id;

  if (isInvalidBody(req.body)) {
    res.status(400).json({ error: 'Corpo da requisição inválido.' });
    return;
  }

  const versionValidation = parseAndValidateVersion(req.body.version);
  if (!versionValidation.valid) {
    res.status(400).json({ error: versionValidation.error });
    return;
  }
  const version = versionValidation.version;

  const { decision, notes } = req.body;

  if (!decision || !['aprovado', 'recusado'].includes(decision)) {
    res.status(400).json({ error: 'Decisão de orçamento inválida. Escolha "aprovado" ou "recusado".' });
    return;
  }

  let errorResponse: { status: number; body: any } | null = null;
  let nextVersion = version + 1;

  try {
    await db.withTransaction(async (tx) => {
      // Lock order inside transaction
      const order = await tx.queryOne<any>(
        'SELECT * FROM orders WHERE id = ? AND company_id = ? FOR UPDATE',
        [orderId, companyId]
      );

      if (!order) {
        errorResponse = { status: 404, body: { error: 'Ordem de serviço não encontrada.' } };
        throw new Error('NOT_FOUND');
      }

      if (order.status === 'entregue' || order.status === 'cancelado') {
        errorResponse = { status: 400, body: { error: 'Não é possível alterar a decisão de orçamento de uma OS em estado terminal.' } };
        throw new Error('TERMINAL_STATE');
      }

      if (order.budget_status !== 'pendente') {
        errorResponse = {
          status: 400,
          body: { error: `O orçamento já possui uma decisão registrada ("${order.budget_status}"). Solicite revisão caso necessário.` }
        };
        throw new Error('ALREADY_DECIDED');
      }

      // Concurrency check
      if (order.version !== version) {
        errorResponse = {
          status: 409,
          body: {
            error: 'A ordem de serviço foi modificada por outro processo. Recarregue a página.',
            currentVersion: order.version
          }
        };
        throw new Error('VERSION_CONFLICT');
      }

      const now = new Date().toISOString();
      const userName = req.user?.name || 'Sistema';
      nextVersion = order.version + 1;

      const updateResult = await tx.execute(`
        UPDATE orders
        SET budget_status = ?, budget_approved_at = ?, budget_approved_by = ?, version = ?, updated_at = ?
        WHERE id = ? AND company_id = ? AND version = ?
      `, [decision, now, userName, nextVersion, now, orderId, companyId, version]);

      if (updateResult.changes === 0) {
        errorResponse = {
          status: 409,
          body: {
            error: 'A ordem de serviço foi modificada por outro processo. Recarregue a página.',
            currentVersion: order.version
          }
        };
        throw new Error('VERSION_CONFLICT');
      }

      const desc = decision === 'aprovado'
        ? `Orçamento APROVADO pelo cliente (registrado por ${userName}). ${notes ? 'Obs: ' + String(notes).slice(0, 200) : ''}`
        : `Orçamento RECUSADO pelo cliente (registrado por ${userName}). ${notes ? 'Motivo: ' + String(notes).slice(0, 200) : ''}`;

      await tx.execute(`
        INSERT INTO order_history (id, company_id, order_id, action, description, user_name, created_at)
        VALUES (?, ?, ?, 'decisao_orcamento', ?, ?, ?)
      `, [crypto.randomUUID(), companyId, orderId, desc, userName, now]);
    });

    res.json({ message: `Orçamento registrado como ${decision}.`, budgetStatus: decision, version: nextVersion });
  } catch (err: any) {
    if (errorResponse !== null) {
      const errObj: { status: number; body: any } = errorResponse;
      res.status(errObj.status).json(errObj.body);
      return;
    }
    throw err;
  }
}));

// Update order status with centralized state transitions and aggregated atomic stock deduction
orderRouter.post('/:id/status', requireCsrf, asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const companyId = req.company!.id;
  const orderId = req.params.id;

  if (isInvalidBody(req.body)) {
    res.status(400).json({ error: 'Corpo da requisição inválido.' });
    return;
  }

  const versionValidation = parseAndValidateVersion(req.body.version);
  if (!versionValidation.valid) {
    res.status(400).json({ error: versionValidation.error });
    return;
  }
  const version = versionValidation.version;

  const { status, cancellationReason } = req.body;

  const validStatuses = ['recebido', 'diagnostico', 'aguardando_aprovacao', 'reparo', 'pronto', 'entregue', 'cancelado'];
  if (!status || !validStatuses.includes(status)) {
    res.status(400).json({ error: 'Status de ordem de serviço inválido.' });
    return;
  }

  // Cancellation requires non-empty reason
  if (status === 'cancelado') {
    if (!cancellationReason || typeof cancellationReason !== 'string' || !cancellationReason.trim() || cancellationReason.trim().length > 500) {
      res.status(400).json({ error: 'É obrigatório informar uma justificativa clara para o cancelamento (máximo 500 caracteres).' });
      return;
    }
  }

  let errorResponse: { status: number; body: any } | null = null;
  let updatedOrder: any = null;

  try {
    await db.withTransaction(async (tx) => {
      // Lock order inside transaction to eliminate race window
      const order = await tx.queryOne<any>(
        'SELECT * FROM orders WHERE id = ? AND company_id = ? FOR UPDATE',
        [orderId, companyId]
      );

      if (!order) {
        errorResponse = { status: 404, body: { error: 'Ordem de serviço não encontrada.' } };
        throw new Error('NOT_FOUND');
      }

      // Concurrency check inside lock
      if (order.version !== version) {
        errorResponse = {
          status: 409,
          body: {
            error: 'A ordem de serviço foi modificada por outro processo. Recarregue a página.',
            currentVersion: order.version
          }
        };
        throw new Error('VERSION_CONFLICT');
      }

      // Terminal state check
      if (order.status === 'entregue' || order.status === 'cancelado') {
        errorResponse = {
          status: 400,
          body: { error: 'Ordem de serviço em estado terminal (entregue ou cancelado) não pode sofrer nova transição de status.' }
        };
        throw new Error('TERMINAL_STATE');
      }

      // Permitted transition check
      const allowed = ALLOWED_TRANSITIONS[order.status] || [];
      if (!allowed.includes(status)) {
        errorResponse = {
          status: 400,
          body: { error: `Transição inválida: não é permitido mudar de "${order.status}" diretamente para "${status}".` }
        };
        throw new Error('INVALID_TRANSITION');
      }

      // Block repair without approved budget
      if (status === 'reparo' && order.budget_status !== 'aprovado') {
        errorResponse = {
          status: 400,
          body: { error: 'Não é permitido iniciar o reparo sem a aprovação prévia do orçamento pelo cliente.' }
        };
        throw new Error('BUDGET_NOT_APPROVED');
      }

      const now = new Date().toISOString();
      const userName = req.user?.name || 'Sistema';
      const nextVersion = (order.version || 1) + 1;

      // When starting reparo: Aggregate parts by inventory_item_id and perform conditional atomic deduction
      if (status === 'reparo') {
        const undebitedParts = await tx.query<{
          id: string;
          inventory_item_id: string;
          quantity: number;
          description: string;
        }>(`
          SELECT op.id, op.inventory_item_id, op.quantity, op.description
          FROM order_parts op
          WHERE op.order_id = ? AND op.company_id = ? AND op.inventory_debited = 0 AND op.inventory_item_id IS NOT NULL
        `, [orderId, companyId]);

        if (undebitedParts.length > 0) {
          // Aggregate required quantity by item to prevent overselling across multiple lines of the same part
          const aggregateMap = new Map<string, number>();
          for (const p of undebitedParts) {
            const currentTotal = aggregateMap.get(p.inventory_item_id) || 0;
            aggregateMap.set(p.inventory_item_id, currentTotal + p.quantity);
          }

          // Order lock acquisition consistently by item ID (alphabetical) to prevent deadlocks across concurrent orders
          const sortedItemIds = Array.from(aggregateMap.keys()).sort();

          for (const itemId of sortedItemIds) {
            const totalRequired = aggregateMap.get(itemId)!;

            // Lock inventory item row
            const itemBefore = await tx.queryOne<any>(
              'SELECT name, quantity FROM inventory_items WHERE id = ? AND company_id = ? AND is_archived = 0 FOR UPDATE',
              [itemId, companyId]
            );

            if (!itemBefore) {
              errorResponse = { status: 400, body: { error: 'Item de estoque associado à OS não foi encontrado ou está inativo.' } };
              throw new Error('ITEM_NOT_FOUND');
            }

            const updateResult = await tx.execute(`
              UPDATE inventory_items
              SET quantity = quantity - ?, updated_at = ?
              WHERE id = ? AND company_id = ? AND quantity >= ?
            `, [totalRequired, now, itemId, companyId, totalRequired]);

            if (updateResult.changes === 0) {
              errorResponse = {
                status: 400,
                body: {
                  error: `Estoque insuficiente para "${itemBefore.name}"! Saldo disponível: ${itemBefore.quantity}, quantidade total necessária na OS: ${totalRequired}. A operação foi bloqueada.`
                }
              };
              throw new Error('INSUFFICIENT_STOCK');
            }

            const newStock = itemBefore.quantity - totalRequired;

            await tx.execute(`
              INSERT INTO inventory_movements (
                id, company_id, item_id, type, quantity, previous_quantity, new_quantity, order_id, reason, user_name, created_at
              ) VALUES (?, ?, ?, 'saida_os', ?, ?, ?, ?, ?, ?, ?)
            `, [
              crypto.randomUUID(),
              companyId,
              itemId,
              totalRequired,
              itemBefore.quantity,
              newStock,
              orderId,
              `Baixa por aplicação na OS #${String(order.order_number).padStart(4, '0')}`,
              userName,
              now
            ]);
          }

          // Mark all parts as debited
          await tx.execute(
            'UPDATE order_parts SET inventory_debited = 1 WHERE order_id = ? AND company_id = ?',
            [orderId, companyId]
          );
        }
      }

      let completedAt = order.completed_at;
      if (status === 'entregue') {
        completedAt = now;
      }

      const updateResult = await tx.execute(`
        UPDATE orders
        SET status = ?, cancellation_reason = ?, completed_at = ?, version = ?, updated_at = ?
        WHERE id = ? AND company_id = ? AND version = ?
      `, [
        status,
        status === 'cancelado' ? cancellationReason.trim() : order.cancellation_reason,
        completedAt,
        nextVersion,
        now,
        orderId,
        companyId,
        version
      ]);

      if (updateResult.changes === 0) {
        errorResponse = {
          status: 409,
          body: {
            error: 'A ordem de serviço foi modificada por outro processo. Recarregue a página.',
            currentVersion: order.version
          }
        };
        throw new Error('VERSION_CONFLICT');
      }

      const statusLabels: Record<string, string> = {
        recebido: 'Recebido',
        diagnostico: 'Diagnóstico',
        aguardando_aprovacao: 'Aguardando aprovação',
        reparo: 'Em reparo',
        pronto: 'Pronto para entrega',
        entregue: 'Entregue ao cliente',
        cancelado: 'Cancelado'
      };

      let desc = `Status alterado de "${statusLabels[order.status] || order.status}" para "${statusLabels[status]}".`;
      if (status === 'cancelado') {
        desc += ` Motivo do cancelamento: ${cancellationReason.trim()}. (Política: peças já consumidas requerem análise técnica presencial).`;
      }

      await tx.execute(`
        INSERT INTO order_history (id, company_id, order_id, action, description, user_name, created_at)
        VALUES (?, ?, ?, 'mudanca_status', ?, ?, ?)
      `, [crypto.randomUUID(), companyId, orderId, desc, userName, now]);

      updatedOrder = await tx.queryOne('SELECT * FROM orders WHERE id = ?', [orderId]);
    });

    res.json({ message: 'Status da OS atualizado com sucesso.', order: updatedOrder });
  } catch (err: any) {
    if (errorResponse !== null) {
      const errObj: { status: number; body: any } = errorResponse;
      res.status(errObj.status).json(errObj.body);
      return;
    }
    throw err;
  }
}));
