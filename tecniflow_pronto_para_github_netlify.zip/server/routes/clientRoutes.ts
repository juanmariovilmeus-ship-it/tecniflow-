import { Router, Response } from 'express';
import crypto from 'node:crypto';
import { AuthenticatedRequest, authenticateSession, requireCsrf } from '../auth.js';
import { mainDb } from '../db.js';
import { asyncHandler } from './asyncHandler.js';

export const clientRouter = Router();

// Apply auth to all client endpoints
clientRouter.use(authenticateSession);

// List clients with search and filter
clientRouter.get('/', asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const companyId = req.company!.id;
  const search = typeof req.query.search === 'string' ? req.query.search.trim() : '';
  const includeArchived = req.query.includeArchived === 'true';

  let query = `
    SELECT c.*, 
      (SELECT COUNT(*) FROM orders o WHERE o.client_id = c.id AND o.company_id = c.company_id) as total_orders
    FROM clients c
    WHERE c.company_id = ?
  `;
  const params: any[] = [companyId];

  if (!includeArchived) {
    query += ' AND c.is_archived = 0';
  }

  if (search) {
    query += ' AND (c.name LIKE ? OR c.phone LIKE ? OR c.document LIKE ? OR c.email LIKE ?)';
    const searchPattern = `%${search}%`;
    params.push(searchPattern, searchPattern, searchPattern, searchPattern);
  }

  query += ' ORDER BY c.created_at DESC';

  const clients = await db.query(query, params);
  res.json({ clients });
}));

// Get client by ID with their work orders
clientRouter.get('/:id', asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const companyId = req.company!.id;
  const clientId = req.params.id;

  const client = await db.queryOne(`
    SELECT * FROM clients WHERE id = ? AND company_id = ?
  `, [clientId, companyId]);

  if (!client) {
    res.status(404).json({ error: 'Cliente não encontrado.' });
    return;
  }

  const orders = await db.query(`
    SELECT id, order_number, device_type, brand, model, status, priority, 
           total_amount_cents, created_at, updated_at
    FROM orders
    WHERE client_id = ? AND company_id = ?
    ORDER BY created_at DESC
  `, [clientId, companyId]);

  res.json({ client, orders });
}));

// Create client
clientRouter.post('/', requireCsrf, asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const companyId = req.company!.id;

  if (!req.body || typeof req.body !== 'object' || Array.isArray(req.body)) {
    res.status(400).json({ error: 'Corpo da requisição inválido.' });
    return;
  }

  const { name, phone, whatsapp, email, document, address, notes } = req.body;

  if (!name || typeof name !== 'string' || !name.trim()) {
    res.status(400).json({ error: 'O nome do cliente é obrigatório.' });
    return;
  }

  if (!phone || typeof phone !== 'string' || !phone.trim()) {
    res.status(400).json({ error: 'O telefone principal do cliente é obrigatório.' });
    return;
  }

  const clientId = crypto.randomUUID();
  const now = new Date().toISOString();

  await db.execute(`
    INSERT INTO clients (id, company_id, name, phone, whatsapp, email, document, address, notes, is_archived, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)
  `, [
    clientId,
    companyId,
    name.trim(),
    phone.trim(),
    whatsapp ? String(whatsapp).trim() : '',
    email ? String(email).trim().toLowerCase() : '',
    document ? String(document).trim() : '',
    address ? String(address).trim() : '',
    notes ? String(notes).trim() : '',
    now,
    now
  ]);

  const created = await db.queryOne('SELECT * FROM clients WHERE id = ?', [clientId]);
  res.status(201).json({ message: 'Cliente cadastrado com sucesso.', client: created });
}));

// Update client
clientRouter.put('/:id', requireCsrf, asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const companyId = req.company!.id;
  const clientId = req.params.id;

  if (!req.body || typeof req.body !== 'object' || Array.isArray(req.body)) {
    res.status(400).json({ error: 'Corpo da requisição inválido.' });
    return;
  }

  const { name, phone, whatsapp, email, document, address, notes } = req.body;

  if (!name || typeof name !== 'string' || !name.trim()) {
    res.status(400).json({ error: 'O nome do cliente é obrigatório.' });
    return;
  }

  if (!phone || typeof phone !== 'string' || !phone.trim()) {
    res.status(400).json({ error: 'O telefone do cliente é obrigatório.' });
    return;
  }

  const existing = await db.queryOne('SELECT id FROM clients WHERE id = ? AND company_id = ?', [clientId, companyId]);
  if (!existing) {
    res.status(404).json({ error: 'Cliente não encontrado.' });
    return;
  }

  const now = new Date().toISOString();

  await db.execute(`
    UPDATE clients
    SET name = ?, phone = ?, whatsapp = ?, email = ?, document = ?, address = ?, notes = ?, updated_at = ?
    WHERE id = ? AND company_id = ?
  `, [
    name.trim(),
    phone.trim(),
    whatsapp ? String(whatsapp).trim() : '',
    email ? String(email).trim().toLowerCase() : '',
    document ? String(document).trim() : '',
    address ? String(address).trim() : '',
    notes ? String(notes).trim() : '',
    now,
    clientId,
    companyId
  ]);

  const updated = await db.queryOne('SELECT * FROM clients WHERE id = ?', [clientId]);
  res.json({ message: 'Cliente atualizado com sucesso.', client: updated });
}));

// Archive client (soft-delete)
clientRouter.post('/:id/archive', requireCsrf, asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const companyId = req.company!.id;
  const clientId = req.params.id;

  const existing = await db.queryOne('SELECT id FROM clients WHERE id = ? AND company_id = ?', [clientId, companyId]);
  if (!existing) {
    res.status(404).json({ error: 'Cliente não encontrado.' });
    return;
  }

  const now = new Date().toISOString();
  await db.execute('UPDATE clients SET is_archived = 1, updated_at = ? WHERE id = ? AND company_id = ?', [now, clientId, companyId]);

  res.json({ message: 'Cliente arquivado com sucesso.' });
}));

// Unarchive client
clientRouter.post('/:id/unarchive', requireCsrf, asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const companyId = req.company!.id;
  const clientId = req.params.id;

  const existing = await db.queryOne('SELECT id FROM clients WHERE id = ? AND company_id = ?', [clientId, companyId]);
  if (!existing) {
    res.status(404).json({ error: 'Cliente não encontrado.' });
    return;
  }

  const now = new Date().toISOString();
  await db.execute('UPDATE clients SET is_archived = 0, updated_at = ? WHERE id = ? AND company_id = ?', [now, clientId, companyId]);

  res.json({ message: 'Cliente desarquivado com sucesso.' });
}));
