// ============================================================================
// TECNIFLOW - ROTAS DA CENTRAL DE AJUDA E ASSISTENTE DE IA
// ============================================================================
// Regras obrigatórias:
// 1. SEM req.db, SEM SQLite local, SEM cookies auth, SEM service-role.
// 2. Cliente Supabase criado POR REQUISIÇÃO com token Bearer do chamador.
// 3. auth.getUser(token) valida identidade (401 para token inválido).
// 4. public.tf_get_company() valida vínculo com empresa (403 sem vínculo).
// 5. Cotas geridas exclusivamente via RPCs public.tf_reserve_help_ai_quota()
//    e public.tf_get_help_ai_quota_status().
// 6. Validação estrita de corpo, limites de 16KB UTF-8, rejeição de chaves extras
//    e alternância obrigatória no histórico (inicia em user, alterna, termina em model).
// 7. Zero vazamento de stack/env ou dados confidenciais de banco.
// ============================================================================

import express, { Request, Response } from 'express';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { generateHelpResponse, isHelpAiEnabled, ChatMessage } from '../services/helpAiService.js';

export const helpRouter = express.Router();
helpRouter.use((_req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });

function getCallerToken(req: Request): string | null {
  const authHeader = req.headers.authorization;
  if (!authHeader || typeof authHeader !== 'string') {
    return null;
  }
  const parts = authHeader.split(' ');
  if (parts.length !== 2 || parts[0] !== 'Bearer' || !parts[1].trim()) {
    return null;
  }
  return parts[1].trim();
}

function createPerRequestSupabaseClient(token: string): SupabaseClient | null {
  const supabaseUrl = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || 'https://aburknnkixeeqpvsyofc.supabase.co';
  const supabaseAnonKey = process.env.SUPABASE_PUBLISHABLE_KEY || process.env.VITE_SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY || 'sb_publishable_nQu4lm4w3_Zq6a-18FvlsQ_johbNzzx';

  if (!supabaseUrl || !supabaseAnonKey) {
    return null;
  }

  try { return createClient(supabaseUrl, supabaseAnonKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
      detectSessionInUrl: false,
    },
    global: {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    },
  }); } catch { return null; }
}

/**
 * GET /api/help/quota
 * Retorna o status atual de cota diária do assistente virtual para a empresa do chamador.
 */
helpRouter.get('/quota', async (req: Request, res: Response): Promise<void> => {
  const token = getCallerToken(req);
  if (!token) {
    res.status(401).json({ error: 'Não autenticado.' });
    return;
  }

  const supabase = createPerRequestSupabaseClient(token);
  if (!supabase) {
    res.status(503).json({ error: 'Infraestrutura indisponível no momento.' });
    return;
  }

  try {
    // 1. Validar identidade do chamador via Supabase Auth
    const { data: userData, error: userError } = await supabase.auth.getUser(token);
    if (userError || !userData?.user?.id) {
      if (userError && ((userError.status || 0) >= 500 || userError.name?.includes('Fetch'))) { res.status(503).json({error:'Não foi possível verificar a sessão agora.'}); return; }
      res.status(401).json({ error: 'Token inválido ou expirado.' });
      return;
    }

    // 2. Validar vínculo com a empresa via RPC tf_get_company()
    const { data: compData, error: compError } = await supabase.rpc('tf_get_company');
    if (compError || !compData?.company?.id) {
      if (compError && compError.code !== '42501' && !compError.message?.includes('Acesso não autorizado')) { res.status(503).json({error:'Não foi possível verificar o vínculo agora.'}); return; }
      res.status(403).json({ error: 'Vínculo com empresa não encontrado.' });
      return;
    }

    // 3. Consultar status de cota da empresa via RPC tf_get_help_ai_quota_status()
    const { data: quotaStatus, error: quotaError } = await supabase.rpc('tf_get_help_ai_quota_status');
    if (quotaError || !quotaStatus || typeof quotaStatus.remaining !== 'number') {
      console.error('[Help Quota Error]', 'QUOTA_STATUS_FAILED');
      res.status(503).json({ error: 'Falha ao consultar limites de atendimento.' });
      return;
    }

    res.json({
      quota: {
        used: quotaStatus?.used ?? 0,
        limit: quotaStatus?.limit ?? 10,
        remaining: quotaStatus?.remaining ?? 10,
        allowed: quotaStatus?.allowed ?? true,
      },
      aiAvailable: isHelpAiEnabled(),
    });
  } catch {
    console.error('[Help Quota Error]', 'INTERNAL_ERROR');
    res.status(503).json({ error: 'Falha ao processar consulta de cota.' });
  }
});

/**
 * POST /api/help/chat
 * Envia mensagem ao assistente de IA após validar estritamente o corpo, autenticar o chamador,
 * confirmar vínculo com empresa e reservar a cota diária com trava serializada.
 */
helpRouter.post('/chat', async (req: Request, res: Response): Promise<void> => {
  // 1. Limite estrito de tamanho UTF-8 (16KB)
  const rawBodyText = (req as any).rawBody || JSON.stringify(req.body || {});
  const bodyBytes = Buffer.byteLength(rawBodyText, 'utf8');
  if (bodyBytes > 16384) {
    res.status(400).json({ error: 'Tamanho da mensagem excede o limite permitido (16KB).' });
    return;
  }

  // 2. Validação estrita do corpo (rejeita chaves extras no nível superior)
  if (!req.body || typeof req.body !== 'object' || Array.isArray(req.body)) {
    res.status(400).json({ error: 'Corpo da requisição inválido.' });
    return;
  }

  const topKeys = Object.keys(req.body);
  const hasExtraTopKeys = topKeys.some((k) => k !== 'message' && k !== 'history');
  if (hasExtraTopKeys) {
    res.status(400).json({ error: 'Parâmetros não permitidos no corpo da requisição.' });
    return;
  }

  // 3. Validação do campo message
  if (typeof req.body.message !== 'string') {
    res.status(400).json({ error: 'Mensagem inválida.' });
    return;
  }
  const trimmedMessage = req.body.message.trim();
  if (!trimmedMessage || trimmedMessage.length > 1500) {
    res.status(400).json({ error: 'A mensagem deve conter entre 1 e 1500 caracteres.' });
    return;
  }

  // 4. Validação estrita do campo history (caso fornecido)
  const history: ChatMessage[] = [];
  if (req.body.history !== undefined) {
    if (!Array.isArray(req.body.history)) {
      res.status(400).json({ error: 'O histórico deve ser uma lista.' });
      return;
    }

    if (req.body.history.length > 6) {
      res.status(400).json({ error: 'O histórico excede o limite permitido de turnos.' });
      return;
    }

    if (req.body.history.length > 0) {
      // Regra 1: Primeiro item DEVE ser do usuário
      if (req.body.history[0]?.role !== 'user') {
        res.status(400).json({ error: 'O histórico deve iniciar com mensagem do usuário.' });
        return;
      }

      for (let i = 0; i < req.body.history.length; i++) {
        const item = req.body.history[i];
        if (!item || typeof item !== 'object' || Array.isArray(item)) {
          res.status(400).json({ error: 'Item do histórico inválido.' });
          return;
        }

        // Rejeitar chaves extras dentro do item de histórico
        const itemKeys = Object.keys(item);
        if (itemKeys.some((k) => k !== 'role' && k !== 'content')) {
          res.status(400).json({ error: 'Item do histórico contém parâmetros não permitidos.' });
          return;
        }

        if (item.role !== 'user' && item.role !== 'model') {
          res.status(400).json({ error: 'Papel de mensagem inválido no histórico.' });
          return;
        }

        if (typeof item.content !== 'string' || !item.content.trim() || item.content.length > 1000) {
          res.status(400).json({ error: 'Conteúdo de mensagem inválido no histórico.' });
          return;
        }

        // Regra 2: Alternância obrigatória (user -> model -> user -> model...)
        if (i > 0 && item.role === req.body.history[i - 1].role) {
          res.status(400).json({ error: 'O histórico deve alternar estritamente entre usuário e modelo.' });
          return;
        }

        history.push({
          role: item.role,
          content: item.content.trim(),
        });
      }

      // Regra 3: Último item do histórico DEVE ser do modelo antes da pergunta atual
      if (history[history.length - 1].role !== 'model') {
        res.status(400).json({ error: 'O histórico deve terminar com resposta do modelo antes da pergunta atual.' });
        return;
      }
    }
  }

  // 5. Autenticação por token Bearer do chamador
  const token = getCallerToken(req);
  if (!token) {
    res.status(401).json({ error: 'Não autenticado.' });
    return;
  }

  const supabase = createPerRequestSupabaseClient(token);
  if (!supabase) {
    res.status(503).json({ error: 'Infraestrutura indisponível no momento.' });
    return;
  }

  try {
    // 6. Validar identidade no Supabase Auth
    const { data: userData, error: userError } = await supabase.auth.getUser(token);
    if (userError || !userData?.user?.id) {
      if (userError && ((userError.status || 0) >= 500 || userError.name?.includes('Fetch'))) { res.status(503).json({error:'Não foi possível verificar a sessão agora.'}); return; }
      res.status(401).json({ error: 'Token inválido ou expirado.' });
      return;
    }

    // 7. Validar vínculo com empresa via RPC tf_get_company()
    const { data: compData, error: compError } = await supabase.rpc('tf_get_company');
    if (compError || !compData?.company?.id) {
      if (compError && compError.code !== '42501' && !compError.message?.includes('Acesso não autorizado')) { res.status(503).json({error:'Não foi possível verificar o vínculo agora.'}); return; }
      res.status(403).json({ error: 'Vínculo com empresa não encontrado.' });
      return;
    }

    if (!isHelpAiEnabled()) { res.status(503).json({error:'O assistente está temporariamente indisponível. Consulte as Perguntas Frequentes.'}); return; }

    // 8. Reservar cota no banco via RPC tf_reserve_help_ai_quota() sob trava serializada
    const { data: quotaRes, error: quotaErr } = await supabase.rpc('tf_reserve_help_ai_quota');
    if (quotaErr || !quotaRes || typeof quotaRes.allowed !== 'boolean') {
      console.error('[Help Quota Error]', 'QUOTA_RESERVATION_FAILED');
      res.status(503).json({ error: 'Falha ao validar limite de atendimento no momento.' });
      return;
    }

    if (!quotaRes?.allowed) {
      if (quotaRes?.reason === 'quota_exceeded') {
        res.status(429).json({
          error: 'Limite diário de 10 consultas do assistente atingido. O limite renova à meia-noite, no horário de Brasília.',
          quota: quotaRes,
        });
        return;
      }
      if (quotaRes?.reason === 'rate_limit') {
        res.status(429).json({
          error: 'Muitas mensagens em pouco tempo. Aguarde um instante antes de enviar nova pergunta.',
          quota: quotaRes,
        });
        return;
      }
      res.status(429).json({
        error: 'Limite de consultas do assistente atingido no momento.',
        quota: quotaRes,
      });
      return;
    }

    // 9. Propagar desconexão HTTP do chamador para cancelar a chamada ao modelo
    const abortController = new AbortController();
    const onClose = () => { if (!res.writableEnded) abortController.abort(); };
    res.once('close', onClose);
    if (req.aborted) abortController.abort();

    // 10. Chamar o modelo Gemini (sem enviar dados de clientes ou empresa)
    try {
      const aiResponse = await generateHelpResponse(trimmedMessage, history, abortController.signal);

      res.json({
        reply: aiResponse.reply,
        quota: {
          used: quotaRes.used,
          limit: quotaRes.limit,
          remaining: quotaRes.remaining,
        },
      });
    } catch (aiErr: any) {
      const errCode = aiErr?.message || '';
      if (errCode === 'AI_TIMEOUT') {
        res.status(504).json({ error: 'O assistente demorou para responder. Tente novamente com uma pergunta mais direta.' });
        return;
      }
      if (errCode === 'AI_RATE_LIMIT') {
        res.status(429).json({ error: 'O assistente está com alta demanda no momento. Aguarde alguns instantes.' });
        return;
      }
      res.status(503).json({ error: 'O assistente está temporariamente indisponível. Consulte o FAQ e os artigos da Central de Ajuda.' });
    } finally {
      res.off('close', onClose);
    }
  } catch {
    console.error('[Help Quota Error]', 'INTERNAL_ERROR');
    res.status(503).json({ error: 'Falha ao processar atendimento no momento.' });
  }
});
