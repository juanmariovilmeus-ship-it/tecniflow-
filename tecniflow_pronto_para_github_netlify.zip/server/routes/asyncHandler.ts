import { Request, Response, NextFunction, RequestHandler } from 'express';

/**
 * Wraps asynchronous Express route handlers and middleware
 * to guarantee that any rejected Promise is forwarded to next(err).
 * Prevents unhandled rejections and server crashes in Express 4.
 */
export function asyncHandler(
  fn: (req: any, res: Response, next: NextFunction) => Promise<any>
): RequestHandler {
  return (req: Request, res: Response, next: NextFunction): void => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}
