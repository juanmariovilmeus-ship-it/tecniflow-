import { Router, Response } from 'express';
import crypto from 'node:crypto';
import {
  AuthenticatedRequest,
  authenticateSession,
  requireCsrf,
  validateOrigin,
  hashPassword,
  comparePassword,
  checkLoginRateLimit,
  recordLoginFailure,
  clearLoginFailures,
  createSession,
  hashToken,
  getSessionCookieOptions,
  getClearCookieOptions
} from '../auth.js';
import { mainDb } from '../db.js';
import { asyncHandler } from './asyncHandler.js';

export const authRouter = Router();

const EMAIL_REGEX = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;

// Register endpoint: deactivated for local password reception, directed to Supabase Auth
authRouter.post('/register', validateOrigin, (_req: AuthenticatedRequest, res: Response): void => {
  res.status(400).json({
    error: 'Cadastro local com senha desativado. O cadastro de contas e senhas é gerenciado exclusivamente pelo Supabase Auth (auth.signUp).'
  });
});

// Login endpoint: deactivated for local password reception, directed to Supabase Auth
authRouter.post('/login', validateOrigin, (_req: AuthenticatedRequest, res: Response): void => {
  res.status(400).json({
    error: 'Login local com senha desativado. A autenticação é realizada diretamente pelo Supabase Auth (auth.signInWithPassword).'
  });
});

// Logout endpoint
authRouter.post('/logout', validateOrigin, asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const sessionToken = req.cookies?.tecniflow_session;

  if (sessionToken) {
    const tokenHash = hashToken(sessionToken);
    await db.execute('DELETE FROM sessions WHERE token_hash = ?', [tokenHash]);
  }

  res.clearCookie('tecniflow_session', getClearCookieOptions(req));
  res.json({ message: 'Sessão encerrada com sucesso.' });
}));

// Current session validation via Supabase Auth Bearer token
authRouter.get('/me', authenticateSession, (req: AuthenticatedRequest, res: Response): void => {
  res.json({
    user: req.user,
    company: req.company,
    csrfToken: req.csrfToken
  });
});

// Transferência explícita: nunca exporta senhas, sessões ou dados de outra empresa.
authRouter.get('/export-legacy', authenticateSession, asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  if (req.user?.role !== 'owner' || !req.company) {
    res.status(403).json({ error: 'Somente o proprietário pode preparar a transferência.' });
    return;
  }
  const db = req.db || mainDb;
  const companyId = req.company.id;
  const exported = await db.withTransaction(async tx => {
    const identity = await tx.queryOne<{ auth_user_id: string }>(
      'SELECT auth_user_id FROM users WHERE id = ? AND company_id = ?', [req.user!.id, companyId]
    );
    if (!identity?.auth_user_id) throw new Error('Vínculo de autenticação ausente. Transferência interrompida.');
    const company = await tx.queryOne('SELECT id,name,document,phone,whatsapp,email,address,warranty_terms,receipt_notes FROM companies WHERE id = ?', [companyId]);
    const clients = await tx.query('SELECT id,name,phone,whatsapp,email,document,address,notes,is_archived,created_at,updated_at FROM clients WHERE company_id = ?', [companyId]);
    const inventory = await tx.query('SELECT id,name,sku,category,quantity,min_quantity,cost_price_cents,sale_price_cents,is_archived,created_at,updated_at FROM inventory_items WHERE company_id = ?', [companyId]);
    const orders = await tx.query('SELECT id,order_number,client_id,device_type,brand,model,serial_imei,defect_reported,accessories,entry_condition,technical_diagnosis,priority,estimated_delivery,status,cancellation_reason,budget_status,budget_approved_at,budget_approved_by,total_services_cents,total_parts_cents,total_amount_cents,version,created_at,updated_at,completed_at FROM orders WHERE company_id = ?', [companyId]);
    // O SQLite original não tinha created_at nos itens de orçamento.
    const services = await tx.query('SELECT id,order_id,description,unit_price_cents,quantity,total_cents FROM order_services WHERE company_id = ?', [companyId]);
    const parts = await tx.query('SELECT id,order_id,inventory_item_id,description,unit_price_cents,quantity,total_cents,inventory_debited FROM order_parts WHERE company_id = ?', [companyId]);
    const movements = await tx.query('SELECT id,item_id,type,quantity,previous_quantity,new_quantity,order_id,reason,user_name,created_at FROM inventory_movements WHERE company_id = ?', [companyId]);
    const history = await tx.query('SELECT id,order_id,action,description,user_name,created_at FROM order_history WHERE company_id = ?', [companyId]);
    return { format:'tecniflow-legacy-v1', auth_user_id:identity.auth_user_id, source_company_id:companyId, exported_at:new Date().toISOString(), company, clients, inventory, orders, services, parts, movements, history };
  });
  res.setHeader('Cache-Control','no-store');
  res.json(exported);
}));

