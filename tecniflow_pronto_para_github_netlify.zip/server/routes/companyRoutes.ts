import { Router, Response } from 'express';
import { AuthenticatedRequest, authenticateSession, requireCsrf } from '../auth.js';
import { mainDb } from '../db.js';
import { asyncHandler } from './asyncHandler.js';

export const companyRouter = Router();

companyRouter.use(authenticateSession);

// Get company configuration
companyRouter.get('/', asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const companyId = req.company!.id;

  const company = await db.queryOne('SELECT * FROM companies WHERE id = ?', [companyId]);
  if (!company) {
    res.status(404).json({ error: 'Empresa não encontrada.' });
    return;
  }

  res.json({ company });
}));

// Update company configuration
companyRouter.put('/', requireCsrf, asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const companyId = req.company!.id;

  if (!req.body || typeof req.body !== 'object' || Array.isArray(req.body)) {
    res.status(400).json({ error: 'Corpo da requisição inválido.' });
    return;
  }

  const {
    name,
    document,
    phone,
    whatsapp,
    email,
    address,
    warrantyTerms,
    receiptNotes
  } = req.body;

  if (!name || typeof name !== 'string' || !name.trim()) {
    res.status(400).json({ error: 'O nome da empresa/assistência técnica é obrigatório.' });
    return;
  }

  await db.execute(`
    UPDATE companies
    SET name = ?, document = ?, phone = ?, whatsapp = ?, email = ?, address = ?,
        warranty_terms = ?, receipt_notes = ?
    WHERE id = ?
  `, [
    name.trim(),
    document !== undefined ? String(document).trim() : '',
    phone !== undefined ? String(phone).trim() : '',
    whatsapp !== undefined ? String(whatsapp).trim() : '',
    email !== undefined ? String(email).trim().toLowerCase() : '',
    address !== undefined ? String(address).trim().slice(0, 255) : '',
    warrantyTerms !== undefined ? String(warrantyTerms).trim().slice(0, 2000) : '',
    receiptNotes !== undefined ? String(receiptNotes).trim().slice(0, 1000) : '',
    companyId
  ]);

  const updated = await db.queryOne('SELECT * FROM companies WHERE id = ?', [companyId]);
  res.json({ message: 'Configurações da empresa atualizadas com sucesso.', company: updated });
}));

// Update company logo dedicated endpoint
companyRouter.put('/logo', requireCsrf, asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const companyId = req.company!.id;

  if (!req.body || typeof req.body !== 'object' || Array.isArray(req.body)) {
    res.status(400).json({ error: 'Corpo da requisição inválido.' });
    return;
  }

  const { logo_data_url } = req.body;

  if (logo_data_url !== null && logo_data_url !== undefined && typeof logo_data_url === 'string' && logo_data_url.trim() !== '') {
    const cleanLogo = logo_data_url.trim();

    if (cleanLogo.length > 307200) {
      res.status(400).json({ error: 'O logotipo excede o tamanho máximo permitido de 300KB no banco de dados.' });
      return;
    }

    const regex = /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/;
    if (!regex.test(cleanLogo)) {
      res.status(400).json({ error: 'Formato de logotipo inválido. Utilize exclusivamente imagens JPEG, PNG ou WebP codificadas em base64.' });
      return;
    }

    await db.execute('UPDATE companies SET company_logo_data_url = ? WHERE id = ?', [cleanLogo, companyId]);
  } else {
    await db.execute('UPDATE companies SET company_logo_data_url = NULL WHERE id = ?', [companyId]);
  }

  const updated = await db.queryOne('SELECT * FROM companies WHERE id = ?', [companyId]);
  res.json({ message: 'Logotipo atualizado com sucesso.', company: updated });
}));

