import { Router, Response } from 'express';
import { mainDb as db } from '../db.js';
import { AuthenticatedRequest, authenticateSession } from '../auth.js';
import { asyncHandler } from './asyncHandler.js';

export const billingRouter = Router();

// 1. Obter status detalhado da assinatura e pagamentos da empresa
billingRouter.get(
  '/status',
  authenticateSession,
  asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    const companyId = req.company!.id;
    const isOwner = req.user?.role === 'owner';
    const now = new Date();

    // Buscar registro de assinatura da empresa
    let sub = await db.queryOne(
      'SELECT * FROM company_subscriptions WHERE company_id = ?',
      [companyId]
    );

    if (!sub) {
      res.status(503).json({ error: 'billing_unavailable', message: 'Não foi possível confirmar seu acesso neste momento.' });
      return;
    }

    const trialEnds = new Date(sub.trial_ends_at);
    const periodEnds = sub.current_period_ends_at ? new Date(sub.current_period_ends_at) : null;
    const periodStarts = sub.current_period_starts_at ? new Date(sub.current_period_starts_at) : null;

    let effectiveStatus = sub.status;
    let isActive = false;
    let daysRemaining = 0;

    if (sub.status === 'trial') {
      if (now.getTime() < trialEnds.getTime()) {
        effectiveStatus = 'trial';
        isActive = true;
        const diffMs = trialEnds.getTime() - now.getTime();
        daysRemaining = Math.max(0, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));
      } else {
        effectiveStatus = 'expired';
        isActive = false;
        daysRemaining = 0;
      }
    } else if (sub.status === 'active' || sub.status === 'canceled') {
      if (periodStarts && periodEnds && periodStarts.getTime() <= now.getTime() && now.getTime() < periodEnds.getTime()) {
        effectiveStatus = sub.status;
        isActive = true;
      } else {
        effectiveStatus = 'expired';
        isActive = false;
      }
    } else {
      effectiveStatus = sub.status;
      isActive = false;
    }

    // Buscar pagamentos recentes da empresa
    const payments = await db.query(
      `SELECT id, amount_cents, currency, status, payment_date
       FROM billing_payments
       WHERE company_id = ?
       ORDER BY payment_date DESC LIMIT 20`,
      [companyId]
    );

    res.json({
      is_owner: isOwner,
      status: effectiveStatus,
      raw_status: sub.status,
      is_active: isActive,
      can_operate: isActive,
      plan_code: sub.plan_code || 'TECNIFLOW-MENSAL-4990',
      plan_name: 'TecniFlow Mensal',
      amount_cents: sub.amount_cents || 4990,
      currency: sub.currency || 'BRL',
      billing_cycle: sub.billing_cycle || 'monthly',
      trial_starts_at: sub.trial_starts_at,
      trial_ends_at: sub.trial_ends_at,
      trial_days_remaining: daysRemaining,
      current_period_starts_at: sub.current_period_starts_at,
      current_period_ends_at: sub.current_period_ends_at,
      cancel_at_period_end: Boolean(sub.cancel_at_period_end),
      payments: payments || [],
      server_time: now.toISOString(),
    });
  })
);

// A cobrança de produção usa exclusivamente as Edge Functions do Supabase.
// Este servidor local não grava aprovações nem cria checkouts paralelos.
billingRouter.post('/create-checkout', authenticateSession, asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  if (req.user?.role !== 'owner') {
    res.status(403).json({ error: 'Apenas o proprietário pode gerenciar a assinatura.' });
    return;
  }
  res.status(503).json({ error: 'billing_not_configured', message: 'A contratação online está em fase de configuração pela administração.' });
}));

billingRouter.post('/webhook', asyncHandler(async (_req, res): Promise<void> => {
  res.status(503).json({ error: 'billing_not_configured' });
}));

billingRouter.post('/webhook-mercadopago', asyncHandler(async (_req, res): Promise<void> => {
  res.status(503).json({ error: 'billing_not_configured', message: 'Provedor legado desativado.' });
}));
