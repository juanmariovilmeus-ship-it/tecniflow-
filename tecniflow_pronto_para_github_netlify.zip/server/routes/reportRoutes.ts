import { Router, Response } from 'express';
import { AuthenticatedRequest, authenticateSession } from '../auth.js';
import { mainDb } from '../db.js';
import { asyncHandler } from './asyncHandler.js';

export const reportRouter = Router();

reportRouter.use(authenticateSession);

const DATE_REGEX = /^\d{4}-\d{2}-\d{2}$/;

function isValidCalendarDate(dateStr: string): boolean {
  if (!DATE_REGEX.test(dateStr)) return false;
  const parts = dateStr.split('-');
  const year = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10);
  const day = parseInt(parts[2], 10);

  if (year < 1900 || year > 2100) return false;
  if (month < 1 || month > 12) return false;

  const daysInMonth = new Date(Date.UTC(year, month, 0)).getUTCDate();
  if (day < 1 || day > daysInMonth) return false;

  return true;
}

// Dashboard overview metrics (0 when empty, strictly calculated from DB)
reportRouter.get('/dashboard', asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const companyId = req.company!.id;

  // Counts by status
  const countsRow = await db.queryOne(`
    SELECT
      COUNT(CASE WHEN status IN ('recebido', 'diagnostico', 'aguardando_aprovacao', 'reparo') THEN 1 END) as in_progress,
      COUNT(CASE WHEN status = 'aguardando_aprovacao' THEN 1 END) as awaiting_approval,
      COUNT(CASE WHEN status = 'pronto' THEN 1 END) as ready_for_pickup,
      COUNT(CASE WHEN status = 'entregue' THEN 1 END) as delivered,
      COUNT(CASE WHEN status = 'cancelado' THEN 1 END) as cancelled,
      COUNT(*) as total_orders,
      COALESCE(SUM(CASE WHEN status = 'entregue' THEN total_amount_cents ELSE 0 END), 0) as total_delivered_cents,
      COALESCE(SUM(total_amount_cents), 0) as total_budgeted_cents
    FROM orders
    WHERE company_id = ?
  `, [companyId]) as any;

  // Total clients
  const clientCountRow = await db.queryOne(`
    SELECT COUNT(*) as total_clients FROM clients WHERE company_id = ? AND is_archived = 0
  `, [companyId]) as any;

  // Low stock alert count
  const lowStockRow = await db.queryOne(`
    SELECT COUNT(*) as low_stock_count FROM inventory_items WHERE company_id = ? AND is_archived = 0 AND quantity <= min_quantity
  `, [companyId]) as any;

  // 6 most recent orders
  const recentOrders = await db.query(`
    SELECT o.id, o.order_number, o.device_type, o.brand, o.model, o.status, o.priority,
           o.total_amount_cents, o.created_at, c.name as client_name, c.phone as client_phone
    FROM orders o
    JOIN clients c ON c.id = o.client_id AND c.company_id = o.company_id
    WHERE o.company_id = ?
    ORDER BY o.order_number DESC
    LIMIT 6
  `, [companyId]);

  res.json({
    metrics: {
      inProgressCount: Number(countsRow?.in_progress || 0),
      awaitingApprovalCount: Number(countsRow?.awaiting_approval || 0),
      readyForPickupCount: Number(countsRow?.ready_for_pickup || 0),
      deliveredCount: Number(countsRow?.delivered || 0),
      cancelledCount: Number(countsRow?.cancelled || 0),
      totalOrdersCount: Number(countsRow?.total_orders || 0),
      totalDeliveredCents: Number(countsRow?.total_delivered_cents || 0),
      totalBudgetedCents: Number(countsRow?.total_budgeted_cents || 0),
      totalClients: Number(clientCountRow?.total_clients || 0),
      lowStockCount: Number(lowStockRow?.low_stock_count || 0)
    },
    recentOrders
  });
}));

// Period reports with explicit separation between budgeted vs delivered amounts
reportRouter.get('/period', asyncHandler(async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const db = req.db || mainDb;
  const companyId = req.company!.id;
  const rawStartDate = typeof req.query.startDate === 'string' ? req.query.startDate.trim() : '';
  const rawEndDate = typeof req.query.endDate === 'string' ? req.query.endDate.trim() : '';

  if (rawStartDate && !isValidCalendarDate(rawStartDate)) {
    res.status(400).json({ error: 'Data inicial com formato ou calendário inválido. Use AAAA-MM-DD com uma data real do calendário.' });
    return;
  }

  if (rawEndDate && !isValidCalendarDate(rawEndDate)) {
    res.status(400).json({ error: 'Data final com formato ou calendário inválido. Use AAAA-MM-DD com uma data real do calendário.' });
    return;
  }

  // Timezone America/Sao_Paulo (UTC-3)
  const defaultEnd = new Date().toISOString().slice(0, 10);
  const d30 = new Date();
  d30.setDate(d30.getDate() - 30);
  const defaultStart = d30.toISOString().slice(0, 10);

  const startDateStr = rawStartDate || defaultStart;
  const endDateStr = rawEndDate || defaultEnd;

  // Validate interval AFTER resolving default dates
  if (startDateStr > endDateStr) {
    res.status(400).json({ error: 'A data inicial não pode ser superior à data final.' });
    return;
  }

  // Timezone America/Sao_Paulo (UTC-3) day boundaries converted to canonical UTC ISO strings
  const startIso = new Date(`${startDateStr}T00:00:00.000-03:00`).toISOString();
  const endIso = new Date(`${endDateStr}T23:59:59.999-03:00`).toISOString();

  // 1. Aberturas de OS no período (usam strictly created_at)
  const createdSummary = await db.queryOne(`
    SELECT
      COUNT(*) as total_orders,
      COALESCE(SUM(total_amount_cents), 0) as total_budgeted_cents,
      COUNT(CASE WHEN status = 'cancelado' THEN 1 END) as cancelled_count
    FROM orders
    WHERE company_id = ? AND created_at >= ? AND created_at <= ?
  `, [companyId, startIso, endIso]) as any;

  // 2. Entregas concluídas no período (usam strictly completed_at!)
  const deliveredSummary = await db.queryOne(`
    SELECT
      COUNT(*) as delivered_count,
      COALESCE(SUM(total_amount_cents), 0) as total_delivered_cents
    FROM orders
    WHERE company_id = ? AND status = 'entregue' AND completed_at IS NOT NULL
      AND completed_at >= ? AND completed_at <= ?
  `, [companyId, startIso, endIso]) as any;

  // 3. Distribuição de status no período (aberturas)
  const statusBreakdown = await db.query(`
    SELECT status, COUNT(*) as count, COALESCE(SUM(total_amount_cents), 0) as amount_cents
    FROM orders
    WHERE company_id = ? AND created_at >= ? AND created_at <= ?
    GROUP BY status
  `, [companyId, startIso, endIso]);

  // Format count and amount_cents to Numbers
  const formattedStatusBreakdown = statusBreakdown.map((s: any) => ({
    status: s.status,
    count: Number(s.count || 0),
    amount_cents: Number(s.amount_cents || 0)
  }));

  // 4. Distribuição por tipo de aparelho (aberturas)
  const deviceBreakdown = await db.query(`
    SELECT device_type, COUNT(*) as count
    FROM orders
    WHERE company_id = ? AND created_at >= ? AND created_at <= ?
    GROUP BY device_type
    ORDER BY count DESC
  `, [companyId, startIso, endIso]);

  const formattedDeviceBreakdown = deviceBreakdown.map((d: any) => ({
    device_type: d.device_type,
    count: Number(d.count || 0)
  }));

  // 5. Ranking de serviços executados (apenas de ordens concluídas/entregues no período, excluindo cancelados)
  const topServices = await db.query(`
    SELECT os.description, COUNT(*) as frequency, SUM(os.quantity) as total_qty, SUM(os.total_cents) as total_cents
    FROM order_services os
    JOIN orders o ON o.id = os.order_id AND o.company_id = os.company_id
    WHERE os.company_id = ? AND o.status = 'entregue'
      AND o.completed_at >= ? AND o.completed_at <= ?
    GROUP BY os.description
    ORDER BY frequency DESC
    LIMIT 10
  `, [companyId, startIso, endIso]);

  const formattedTopServices = topServices.map((ts: any) => ({
    description: ts.description,
    frequency: Number(ts.frequency || 0),
    total_qty: Number(ts.total_qty || 0),
    total_cents: Number(ts.total_cents || 0)
  }));

  // 6. Ranking de peças utilizadas (apenas de ordens concluídas/entregues no período, excluindo cancelados)
  const topParts = await db.query(`
    SELECT op.description, COUNT(*) as frequency, SUM(op.quantity) as total_qty, SUM(op.total_cents) as total_cents
    FROM order_parts op
    JOIN orders o ON o.id = op.order_id AND o.company_id = op.company_id
    WHERE op.company_id = ? AND o.status = 'entregue'
      AND o.completed_at >= ? AND o.completed_at <= ?
    GROUP BY op.description
    ORDER BY frequency DESC
    LIMIT 10
  `, [companyId, startIso, endIso]);

  const formattedTopParts = topParts.map((tp: any) => ({
    description: tp.description,
    frequency: Number(tp.frequency || 0),
    total_qty: Number(tp.total_qty || 0),
    total_cents: Number(tp.total_cents || 0)
  }));

  // 7. Tempo médio de atendimento (em horas, de ordens entregues no período por completed_at)
  const turnaroundOrders = await db.query<{ created_at: string; completed_at: string }>(`
    SELECT created_at, completed_at
    FROM orders
    WHERE company_id = ? AND status = 'entregue' AND completed_at IS NOT NULL
      AND completed_at >= ? AND completed_at <= ?
  `, [companyId, startIso, endIso]);

  let avgHoursTurnaround = 0;
  if (turnaroundOrders.length > 0) {
    const totalHours = turnaroundOrders.reduce((acc, curr) => {
      const diffMs = new Date(curr.completed_at).getTime() - new Date(curr.created_at).getTime();
      return acc + (diffMs / (1000 * 60 * 60));
    }, 0);
    avgHoursTurnaround = Math.round((totalHours / turnaroundOrders.length) * 10) / 10;
  }

  res.json({
    period: {
      startDate: startDateStr,
      endDate: endDateStr
    },
    summary: {
      totalOrders: Number(createdSummary?.total_orders || 0),
      totalBudgetedCents: Number(createdSummary?.total_budgeted_cents || 0),
      deliveredCount: Number(deliveredSummary?.delivered_count || 0),
      totalDeliveredCents: Number(deliveredSummary?.total_delivered_cents || 0),
      cancelledCount: Number(createdSummary?.cancelled_count || 0),
      avgHoursTurnaround
    },
    statusBreakdown: formattedStatusBreakdown,
    deviceBreakdown: formattedDeviceBreakdown,
    topServices: formattedTopServices,
    topParts: formattedTopParts
  });
}));
