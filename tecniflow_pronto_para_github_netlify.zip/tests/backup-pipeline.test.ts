import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { Readable } from 'node:stream';
import {
  parseEncryptionKey,
  encryptBackupStream,
  decryptBackupFile,
  BACKUP_MAGIC,
} from '../server/lib/backupCrypto.js';
import { assertSafeRestoreTarget } from '../scripts/restore-check-supabase.js';
import { validateBackupConfig } from '../scripts/backup-supabase.js';

let passed = 0;
const check = (condition: boolean, label: string) => {
  assert.ok(condition, label);
  passed++;
  console.log(`  ✓ [PASS] ${label}`);
};

console.log('================================================================');
console.log('  TECNIFLOW: TESTES DO PIPELINE DE BACKUP E RESTAURAÇÃO SEGURA');
console.log('================================================================\n');

// 1. Validação de chaves de criptografia AES-256-GCM
console.log('--- 1. Validação de Chaves de Criptografia (256 bits) ---');
const validHexKey = crypto.randomBytes(32).toString('hex');
const validBase64Key = crypto.randomBytes(32).toString('base64');
const parsedHex = parseEncryptionKey(validHexKey);
check(parsedHex.length === 32, 'Chave Hexadecimal de 64 caracteres convertida em 32 bytes exatos');

const parsedBase64 = parseEncryptionKey(validBase64Key);
check(parsedBase64.length === 32, 'Chave Base64 convertida em 32 bytes exatos');

assert.throws(
  () => parseEncryptionKey('chave_curta_invalida'),
  /BACKUP_ENCRYPTION_KEY_INVALID/,
  'Chave curta inválida rejeitada com erro explícito'
);
passed++;
console.log('  ✓ [PASS] Chave curta inválida rejeitada com erro explícito');

// 2. Criptografia e Decriptografia com AES-256-GCM (Roundtrip)
console.log('\n--- 2. Criptografia Autenticada e Integridade (Roundtrip) ---');
const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'tf-backup-test-'));
const backupFilePath = path.join(tmpDir, 'test-dump.enc.tfbak');

const sampleDumpSql = `-- PostgreSQL database dump
-- Tecniflow isolated test dump
CREATE SCHEMA tecniflow;
CREATE TABLE tecniflow.test (id int);
INSERT INTO tecniflow.test VALUES (42);
`;

const inputStream = Readable.from(Buffer.from(sampleDumpSql, 'utf8'));
const encResult = await encryptBackupStream(inputStream, backupFilePath, parsedHex);

check(fs.existsSync(backupFilePath), 'Arquivo de backup cifrado criado no destino');
check(encResult.fileSizeBytes > 0, 'Tamanho do arquivo cifrado maior que zero');
check(encResult.sha256.length === 64, 'Checksum SHA-256 de 64 caracteres hexadecimais gerado');

const decryptedBuf = await decryptBackupFile(backupFilePath, parsedHex);
check(decryptedBuf.toString('utf8') === sampleDumpSql, 'Decriptografia recupera exatamente o payload original');

// 3. Detecção de Adulteração e Corrupção (Tamper Resistance)
console.log('\n--- 3. Detecção de Adulteração e Chave Incorreta ---');
const corruptedFilePath = path.join(tmpDir, 'corrupted-dump.enc.tfbak');
const originalBytes = fs.readFileSync(backupFilePath);
// Adulterar 1 byte no ciphertext
const corruptedBytes = Buffer.from(originalBytes);
corruptedBytes[corruptedBytes.length - 5] ^= 0xff;
fs.writeFileSync(corruptedFilePath, corruptedBytes);

await assert.rejects(
  async () => decryptBackupFile(corruptedFilePath, parsedHex),
  /BACKUP_AUTHENTICATION_FAILED/,
  'Arquivo com 1 byte adulterado rejeitado na autenticação GCM'
);
passed++;
console.log('  ✓ [PASS] Arquivo com 1 byte adulterado rejeitado na autenticação GCM');

// Teste de decriptografia com chave errada
const wrongKey = crypto.randomBytes(32);
await assert.rejects(
  async () => decryptBackupFile(backupFilePath, wrongKey),
  /BACKUP_AUTHENTICATION_FAILED/,
  'Decriptografia com chave diferente rejeitada'
);
passed++;
console.log('  ✓ [PASS] Decriptografia com chave diferente rejeitada');

// 4. Trava de Segurança Contra Restauração em Produção
console.log('\n--- 4. Trava de Segurança Contra Restauração em Produção ---');
assert.throws(
  () => assertSafeRestoreTarget('postgres://postgres:pass@db.aburknnkixeeqpvsyofc.supabase.co:5432/postgres'),
  /RESTORE_PRODUCTION_TARGET_BLOCKED/,
  'Tentativa de restauração direcionada a domínio supabase.co abortada fatalmente'
);
passed++;
console.log('  ✓ [PASS] Tentativa de restauração direcionada a domínio supabase.co abortada fatalmente');

assert.throws(
  () => assertSafeRestoreTarget(undefined, 'aws.rds.amazonaws.com', 'tecniflow_prod'),
  /RESTORE_PRODUCTION_TARGET_BLOCKED/,
  'Tentativa de restauração em host remoto de nuvem abortada fatalmente'
);
passed++;
console.log('  ✓ [PASS] Tentativa de restauração em host remoto de nuvem abortada fatalmente');

assert.doesNotThrow(
  () => assertSafeRestoreTarget('postgres://postgres:pass@localhost:5432/tecniflow_restore_check'),
  'Restauração em localhost DB com sufixo _restore_check autorizada com segurança'
);
passed++;
console.log('  ✓ [PASS] Restauração em localhost DB com sufixo _restore_check autorizada com segurança');

// 5. Validação de Configuração e Preflight Fail-Closed
console.log('\n--- 5. Validação de Configuração e Preflight Fail-Closed ---');
const missingConfig = validateBackupConfig({
  outputDir: tmpDir,
  isDryRun: false,
});
check(!missingConfig.valid, 'Configuração sem chave e sem banco é inválida fail-closed');
check(missingConfig.errors.length >= 2, 'Erros explícitos detalham ausência de chave e credenciais');

// Limpeza de arquivos de teste
fs.rmSync(tmpDir, { recursive: true, force: true });

console.log('================================================================');
console.log(`  RESULTADO: ${passed} verificações do pipeline de backup aprovadas!`);
console.log('================================================================');
