import { PGlite } from '@electric-sql/pglite';
import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';
import http from 'node:http';
import { AddressInfo } from 'node:net';
import { createApp } from '../server.js';
import { setSupabaseAuthClient } from '../server/auth.js';

let passed = 0;
const check = (condition: boolean, label: string) => {
  assert.ok(condition, label);
  passed++;
  console.log(`  ✓ [PASS] ${label}`);
};

console.log('================================================================');
console.log('  TECNIFLOW: TESTES ADVERSARIAIS DE SEGURANÇA E ISOLAMENTO (PGLITE)');
console.log('================================================================\n');

// 1. Inicialização do Banco PostgreSQL Isolado
const db = new PGlite();

await db.exec(`
  CREATE ROLE anon;
  CREATE ROLE authenticated;
  CREATE ROLE service_role;
  CREATE SCHEMA IF NOT EXISTS auth;
  CREATE TABLE IF NOT EXISTS auth.users(
    id uuid PRIMARY KEY,
    email text,
    raw_user_meta_data jsonb
  );
  CREATE OR REPLACE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $$
    SELECT nullif(current_setting('request.jwt.claim.sub', true), '')::uuid
  $$;
`);

// 2. Aplicação de todas as migrações na ordem oficial
await db.exec(readFileSync('supabase/tecniflow_schema.sql', 'utf8'));
await db.exec(readFileSync('supabase/003_operations_data_api.sql', 'utf8'));
await db.exec(readFileSync('supabase/005_company_logo.sql', 'utf8'));
await db.exec(readFileSync('supabase/006_billing_trial.sql', 'utf8'));
await db.exec(readFileSync('supabase/008_kiwify_billing.sql', 'utf8'));
await db.exec(readFileSync('supabase/009_help_ai_quota.sql', 'utf8'));
await db.exec(readFileSync('supabase/010_telemetry_and_hardening.sql', 'utf8'));
check(true, 'Todas as 7 migrations aplicadas com sucesso no PostgreSQL (PGlite)');

// Helper de execução sob identidade do Supabase
async function asUser(uid: string | null) {
  await db.exec('RESET ROLE');
  if (uid) {
    await db.query("SELECT set_config('request.jwt.claim.sub', $1, false)", [uid]);
    await db.exec('SET ROLE authenticated');
  } else {
    await db.query("SELECT set_config('request.jwt.claim.sub', '', false)");
    await db.exec('SET ROLE anon');
  }
}

async function callRpc(name: string, params: Record<string, any> = {}): Promise<any> {
  const keys = Object.keys(params);
  const argsSql = keys.map((k, i) => `${k} => $${i + 1}`).join(', ');
  const sql = `SELECT public.tf_${name}(${argsSql}) AS data`;
  const values = Object.values(params).map(v => (Array.isArray(v) || (typeof v === 'object' && v !== null)) ? JSON.stringify(v) : v);
  const res = await db.query(sql, values);
  return (res.rows[0] as any).data;
}

async function rejectRpc(name: string, params: Record<string, any> = {}, expectedMatch?: string | RegExp): Promise<void> {
  let error: any = null;
  try {
    await callRpc(name, params);
  } catch (err: any) {
    error = err;
  }
  assert.ok(error, `Esperava rejeição da RPC tf_${name}`);
  if (expectedMatch) {
    const msg = error.message || String(error);
    if (typeof expectedMatch === 'string') {
      assert.ok(msg.includes(expectedMatch), `Mensagem "${msg}" deve conter "${expectedMatch}"`);
    } else {
      assert.ok(expectedMatch.test(msg), `Mensagem "${msg}" deve casar com regex ${expectedMatch}`);
    }
  }
}

// 3. Setup dos dois tenants e papéis (Owner e Staff)
console.log('\n--- 1. Provisionamento de Dois Tenants e Papéis (Owner / Staff) ---');
const uidOwnerA = '11111111-1111-4000-8000-000000000001';
const uidStaffA = '11111111-1111-4000-8000-000000000002';
const uidOwnerB = '22222222-2222-4000-8000-000000000001';
const uidStaffB = '22222222-2222-4000-8000-000000000002';

await db.exec('RESET ROLE');
await db.query(`
  INSERT INTO auth.users (id, email, raw_user_meta_data) VALUES
  ($1, 'ownerA@empresa-a.com.br', '{"company_name":"Assistência A","owner_name":"Dono A"}'::jsonb),
  ($2, 'staffA@empresa-a.com.br', '{"company_name":"Assistência A","owner_name":"Tecnico A"}'::jsonb),
  ($3, 'ownerB@empresa-b.com.br', '{"company_name":"Assistência B","owner_name":"Dono B"}'::jsonb),
  ($4, 'staffB@empresa-b.com.br', '{"company_name":"Assistência B","owner_name":"Tecnico B"}'::jsonb)
`, [uidOwnerA, uidStaffA, uidOwnerB, uidStaffB]);

// Provisiona Owner A
await asUser(uidOwnerA);
const syncA = await callRpc('sync_current_user');
const compAId = syncA.company.id;
check(Boolean(compAId), 'Empresa A provisionada via tf_sync_current_user');

// Cria Staff A na mesma empresa A com papel 'collaborator'
await db.exec('RESET ROLE');
await db.query(`
  INSERT INTO tecniflow.users (id, company_id, name, email, password_hash, role, auth_user_id, created_at)
  VALUES ('user_staff_a', $1, 'Tecnico Staff A', 'staffA@empresa-a.com.br', '', 'collaborator', $2, now())
`, [compAId, uidStaffA]);

// Provisiona Owner B
await asUser(uidOwnerB);
const syncB = await callRpc('sync_current_user');
const compBId = syncB.company.id;
check(Boolean(compBId) && compBId !== compAId, 'Empresa B provisionada com ID isolado de A');

// Cria Staff B na mesma empresa B com papel 'collaborator'
await db.exec('RESET ROLE');
await db.query(`
  INSERT INTO tecniflow.users (id, company_id, name, email, password_hash, role, auth_user_id, created_at)
  VALUES ('user_staff_b', $1, 'Tecnico Staff B', 'staffB@empresa-b.com.br', '', 'collaborator', $2, now())
`, [compBId, uidStaffB]);

// 4. Testes de Tentativas de Acesso Cruzado (Cross-Tenant)
console.log('\n--- 2. Testes de Tentativas de Acesso Cruzado entre Tenants ---');
// Owner A cria cliente, item de estoque e ordem de serviço na Empresa A
await asUser(uidOwnerA);
const clientA = (await callRpc('create_client', { p_name: 'Cliente Empresa A', p_phone: '11988887777' })).client;
const itemA = (await callRpc('create_inventory_item', { p_name: 'Tela iPhone A', p_quantity: 10, p_cost_price_cents: 10000, p_sale_price_cents: 25000 })).item;
const orderA = (await callRpc('create_order', {
  p_client_id: clientA.id,
  p_device_type: 'smartphone',
  p_brand: 'Apple',
  p_model: 'iPhone 13',
  p_defect_reported: 'Tela quebrada',
})).order;

check(Boolean(clientA.id && itemA.id && orderA.id), 'Registros criados com sucesso na Empresa A');

// Agora usuário da Empresa B (Owner B ou Staff B) tenta ler e alterar dados da Empresa A
await asUser(uidOwnerB);
await rejectRpc('get_client_details', { p_id: clientA.id }, 'Cliente não encontrado');
check(true, 'Tenant B impedido de ler detalhes de cliente da Empresa A');

await rejectRpc('update_client', { p_id: clientA.id, p_name: 'Tentativa Invasão', p_phone: '11988887777' }, 'Cliente não encontrado');
check(true, 'Tenant B impedido de alterar cliente da Empresa A');

await rejectRpc('archive_client', { p_id: clientA.id, p_archived: 1 }, 'Cliente não encontrado');
check(true, 'Tenant B impedido de arquivar cliente da Empresa A');

await rejectRpc('create_order', {
  p_client_id: clientA.id, // Passa ID de cliente da empresa A
  p_device_type: 'smartphone',
  p_brand: 'Apple',
  p_model: 'iPhone 13',
  p_defect_reported: 'Invasão',
}, 'Cliente inválido ou não pertence a esta empresa');
check(true, 'Tenant B impedido de criar OS com cliente da Empresa A');

await rejectRpc('get_inventory_details', { p_id: itemA.id }, 'Peça não encontrada');
check(true, 'Tenant B impedido de consultar item de estoque da Empresa A');

await rejectRpc('adjust_inventory', { p_id: itemA.id, p_type: 'saida_manual', p_quantity: 1, p_reason: 'Ataque' });
check(true, 'Tenant B impedido de alterar estoque da Empresa A');

await rejectRpc('get_order_details', { p_order_id: orderA.id }, 'Ordem de serviço não encontrada');
check(true, 'Tenant B impedido de ler detalhes de OS da Empresa A');

await rejectRpc('transition_order_status', { p_order_id: orderA.id, p_version: 1, p_status: 'diagnostico' }, 'Ordem de serviço não encontrada');
check(true, 'Tenant B impedido de alterar status de OS da Empresa A');

const reportsB = await callRpc('get_reports', { p_start_date: '2020-01-01', p_end_date: '2030-01-01' });
check(reportsB.summary.totalOrders === 0 && reportsB.summary.totalDeliveredCents === 0, 'Relatórios da Empresa B retornam zero receitas e zero OSs da Empresa A');

// 5. Hardening de Papel (Owner vs Staff / Collaborator)
console.log('\n--- 3. Restrição de Operações Administrativas a Owner (Role Hardening) ---');
// Staff A tenta alterar dados cadastrais da empresa
await asUser(uidStaffA);
await rejectRpc('update_company', { p_name: 'Tentativa Staff' }, 'Apenas o proprietário da assistência técnica pode alterar dados cadastrais');
check(true, 'Staff impedido de alterar dados cadastrais da empresa');

// Staff A tenta alterar o logotipo da empresa
await rejectRpc('update_company_logo', { p_logo_data_url: null }, 'Apenas o proprietário da assistência técnica pode alterar o logotipo');
check(true, 'Staff impedido de alterar logotipo da empresa');

// Staff A tenta iniciar checkout / contratação
await rejectRpc('create_billing_intent', {}, 'Apenas o proprietário da assistência técnica pode iniciar contratações');
check(true, 'Staff impedido de iniciar contratação ou checkout de assinatura');

// Owner A altera dados cadastrais com sucesso
await asUser(uidOwnerA);
const updatedComp = await callRpc('update_company', { p_name: 'Assistência A Oficial', p_phone: '11988887777' });
check(updatedComp.company.name === 'Assistência A Oficial', 'Owner autorizado a alterar dados cadastrais');

// 6. Tentativas de Autoativação e Escalada de Privilégios
console.log('\n--- 4. Bloqueio de Autoativação e Escalada de Privilégios ---');
// Usuário autenticado tenta invocar a função interna de processamento de pagamento
await asUser(uidOwnerA);
await rejectRpc('process_billing_payment', {
  p_event_id: 'fake_evt',
  p_company_id: compAId,
  p_order_id: 'fake_order',
  p_amount_cents: 4990,
  p_plan_id: 'plan_1',
  p_subscription_id: 'sub_1',
  p_start_date: new Date().toISOString(),
}, /does not exist|permission denied|Acesso negado/);
check(true, 'Tentativa de autoativação de pagamento por authenticated rejeitada (apenas service_role)');

// Usuário autenticado tenta fazer UPDATE direto nas tabelas protegidas via SQL
await db.exec('SET ROLE authenticated');
let directUpdateBlocked = false;
try {
  await db.query("UPDATE tecniflow.users SET role = 'owner' WHERE auth_user_id = $1", [uidStaffA]);
} catch (e: any) {
  directUpdateBlocked = true;
}
check(directUpdateBlocked, 'UPDATE direto em tecniflow.users bloqueado por RLS/REVOKE padrão');

let subscriptionTamperBlocked = false;
try {
  await db.query("UPDATE tecniflow.company_subscriptions SET status = 'active' WHERE company_id = $1", [compAId]);
} catch (e: any) {
  subscriptionTamperBlocked = true;
}
check(subscriptionTamperBlocked, 'UPDATE direto em tecniflow.company_subscriptions bloqueado');

// 7. Bloqueio por Assinatura Expirada (Assert Active Subscription)
console.log('\n--- 5. Bloqueio por Assinatura ou Trial Expirado ---');
// Força expiração do trial da Empresa A diretamente como administrador
await db.exec('RESET ROLE');
await db.query(`
  UPDATE tecniflow.company_subscriptions
  SET status = 'expired', trial_ends_at = now() - INTERVAL '1 hour'
  WHERE company_id = $1
`, [compAId]);

await asUser(uidOwnerA);
await rejectRpc('create_client', { p_name: 'Cliente Bloqueado', p_phone: '11999998888' }, 'ASSINATURA_EXPIRADA');
check(true, 'Criação de cliente bloqueada com ASSINATURA_EXPIRADA quando trial vence');

await rejectRpc('create_inventory_item', { p_name: 'Item Bloqueado' }, 'ASSINATURA_EXPIRADA');
check(true, 'Criação de item bloqueada com ASSINATURA_EXPIRADA quando trial vence');

// Restaura trial para próximos testes
await db.exec('RESET ROLE');
await db.query(`
  UPDATE tecniflow.company_subscriptions
  SET status = 'trial', trial_ends_at = now() + INTERVAL '7 days'
  WHERE company_id = $1
`, [compAId]);

// 8. Replay de Requisição Concorrente
console.log('\n--- 6. Replay e Controle de Concorrência Otimista (Stale Version) ---');
await asUser(uidOwnerA);
await rejectRpc('transition_order_status', { p_order_id: orderA.id, p_version: 999, p_status: 'diagnostico' }, 'Conflito de concorrência');
check(true, 'Requisição com versão desatualizada (stale version) rejeitada para evitar concorrência descontrolada');

// 9. Chamada sem Autenticação / JWT Inválido
console.log('\n--- 7. Rejeição de Requisições Desautenticadas ---');
await asUser(null);
await rejectRpc('get_clients', {}, /permission denied|Acesso não autorizado/);
check(true, 'Acesso anônimo/sem JWT a tf_get_clients rejeitado');

// 10. Telemetria de Falhas e Rate Limiting
console.log('\n--- 8. Telemetria Segura de Falhas e Limite de Taxa ---');
await asUser(uidOwnerA);
const correlationId = '33333333-3333-4000-8000-000000000001';
const telRes1 = await callRpc('record_error_telemetry', {
  p_area: 'network',
  p_code: 'NETWORK_FAILURE',
  p_severity: 'warn',
  p_correlation_id: correlationId,
});
check(telRes1.recorded === true, 'Primeiro evento de telemetria registrado com sucesso');

// Deduplicação: mesmo usuário, área e código nos últimos 60s é descartado
const telResDup = await callRpc('record_error_telemetry', {
  p_area: 'network',
  p_code: 'NETWORK_FAILURE',
  p_severity: 'warn',
  p_correlation_id: crypto.randomUUID(),
});
check(telResDup.recorded === false && telResDup.reason === 'deduplicated', 'Evento idêntico nos últimos 60s deduplicado com recorded=false');

// Validação de formato: código inválido com caracteres especiais é rejeitado
await rejectRpc('record_error_telemetry', {
  p_area: 'network',
  p_code: 'error<script>',
  p_severity: 'warn',
  p_correlation_id: crypto.randomUUID(),
}, 'Código de telemetria inválido');
check(true, 'Código com formato fora do padrão rejeitado');

// Probe de saúde (readiness)
const probeRes = await callRpc('health_probe');
check(probeRes.status === 'ok' && probeRes.ready === true && !('service' in probeRes), 'RPC tf_health_probe retorna status ok sem expor dados');

// 11. Validação do Servidor Node: Preflight Fail-Closed para Modo Cloud
console.log('\n--- 9. Servidor Node: Preflight Fail-Closed para Rotas Legadas em Modo Cloud ---');
const prevCloudEnv = process.env.CLOUD_OPERATIONS_ENABLED;
process.env.CLOUD_OPERATIONS_ENABLED = 'true';

const app = createApp();
const server = http.createServer(app);
await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', () => resolve()));
const address = server.address() as AddressInfo;
const baseUrl = `http://127.0.0.1:${address.port}`;

try {
  // O padrão é cloud-only: a rota legada retorna 410 independentemente da flag antiga.
  const legRes = await fetch(`${baseUrl}/api/clients`);
  check(legRes.status === 410, 'Acesso direto a /api/clients é recusado por padrão com HTTP 410 (fail-closed)');
  const legBody = await legRes.json();
  check(legBody.code === 'CLOUD_OPERATIONS_ONLY', 'Corpo da resposta informa código CLOUD_OPERATIONS_ONLY');

  // Liveness probe /api/health retorna 200 com requestId
  const healthRes = await fetch(`${baseUrl}/api/health`);
  check(healthRes.status === 200, 'Liveness probe /api/health retorna HTTP 200');
  check(Boolean(healthRes.headers.get('x-request-id')), 'Header X-Request-Id retornado na resposta');
} finally {
  server.close();
  process.env.CLOUD_OPERATIONS_ENABLED = prevCloudEnv;
}

console.log('================================================================');
console.log(`  RESULTADO: ${passed} testes adversariais e de segurança aprovados!`);
console.log('================================================================');
process.exit(0);
