import { PGlite } from '@electric-sql/pglite';
import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const db = new PGlite();
let passed = 0;
const check = (condition, label) => {
  assert.ok(condition, label);
  passed++;
  console.log('PASS', label);
};

console.log('================================================================');
console.log('  TECNIFLOW: TESTE COMPLETO DE BILLING, TRIAL 7D E GATEWAY (PGLITE)');
console.log('================================================================\n');

// 1. Setup mock Supabase environment
await db.exec(`
  CREATE ROLE anon;
  CREATE ROLE authenticated;
  CREATE ROLE service_role;
  CREATE SCHEMA IF NOT EXISTS auth;
  CREATE TABLE IF NOT EXISTS auth.users(
    id uuid PRIMARY KEY,
    email text,
    raw_user_meta_data jsonb
  );
  CREATE OR REPLACE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $$
    SELECT nullif(current_setting('request.jwt.claim.sub', true), '')::uuid
  $$;

  CREATE TABLE IF NOT EXISTS public.profiles (
    id uuid PRIMARY KEY,
    email text,
    created_at timestamp with time zone DEFAULT now()
  );
`);

// 2. Load schemas and migrations
await db.exec(readFileSync('supabase/tecniflow_schema.sql', 'utf8'));
await db.exec(readFileSync('supabase/003_operations_data_api.sql', 'utf8'));
await db.exec(readFileSync('supabase/005_company_logo.sql', 'utf8'));

// Snapshot definitions of operational functions BEFORE migration 006
const allowlist = [
  'tf_get_clients', 'tf_create_client', 'tf_update_client', 'tf_archive_client', 'tf_get_client_details',
  'tf_get_inventory', 'tf_get_inventory_details', 'tf_create_inventory_item', 'tf_update_inventory_item',
  'tf_adjust_inventory', 'tf_get_orders', 'tf_get_order_details', 'tf_create_order', 'tf_update_order',
  'tf_save_budget', 'tf_decide_budget', 'tf_reopen_budget', 'tf_transition_order_status',
  'tf_get_dashboard_stats', 'tf_get_reports', 'tf_import_legacy'
];

const originalDefs = new Map();
for (const fn of allowlist) {
  const row = (await db.query(`
    SELECT pg_get_functiondef(p.oid) as def
    FROM pg_proc p
    WHERE p.pronamespace = 'public'::regnamespace AND p.proname = $1
  `, [fn])).rows[0];
  originalDefs.set(fn, row.def);
}

// Snapshot non-operational functions (tf_update_company, tf_update_company_logo, tf_get_company)
const nonOpFns = ['tf_update_company', 'tf_update_company_logo', 'tf_get_company'];
const nonOpOriginalDefs = new Map();
for (const fn of nonOpFns) {
  const row = (await db.query(`
    SELECT pg_get_functiondef(p.oid) as def
    FROM pg_proc p
    WHERE p.pronamespace = 'public'::regnamespace AND p.proname = $1
  `, [fn])).rows[0];
  nonOpOriginalDefs.set(fn, row.def);
}

// 3. Load migration 006_billing_trial.sql and verify idempotency
await db.exec(readFileSync('supabase/006_billing_trial.sql', 'utf8'));
await db.exec(readFileSync('supabase/006_billing_trial.sql', 'utf8'));
check(true, '006_billing_trial.sql parseia e reexecuta com 100% de idempotência');

// 4. Metadata test: compare definitions before and after, removing only the assert guard
for (const fn of allowlist) {
  const row = (await db.query(`
    SELECT pg_get_functiondef(p.oid) as def
    FROM pg_proc p
    WHERE p.pronamespace = 'public'::regnamespace AND p.proname = $1
  `, [fn])).rows[0];
  
  const modifiedDef = row.def;
  assert.ok(modifiedDef.includes('PERFORM tecniflow.assert_active_subscription();'), `${fn} deve conter a assert`);
  
  // Normalizar removendo a injeção da assert
  const stripped = modifiedDef.replace(/PERFORM tecniflow\.assert_active_subscription\(\);\s*/g, '');
  const original = originalDefs.get(fn).replace(/PERFORM tecniflow\.assert_active_subscription\(\);\s*/g, '');
  
  // Normalizar espaços para comparação
  const normStripped = stripped.replace(/\s+/g, ' ').trim();
  const normOriginal = original.replace(/\s+/g, ' ').trim();
  assert.equal(normStripped, normOriginal, `Definição de ${fn} deve ser idêntica à 003`);
}
check(true, 'Todas as 21 RPCs operacionais têm contratos e código 100% preservados da 003');

// Verificar que funções não-operacionais não foram alteradas
for (const fn of nonOpFns) {
  const row = (await db.query(`
    SELECT pg_get_functiondef(p.oid) as def
    FROM pg_proc p
    WHERE p.pronamespace = 'public'::regnamespace AND p.proname = $1
  `, [fn])).rows[0];
  assert.equal(row.def.replace(/\s+/g, ' ').trim(), nonOpOriginalDefs.get(fn).replace(/\s+/g, ' ').trim());
}
check(true, 'Configurações e logo (005) permanecem 100% intactos');

const scalar = async (sql, args = []) => Object.values((await db.query(sql, args)).rows[0])[0];

// 5. Role execution and RLS privileges
check(
  !await scalar("SELECT has_function_privilege('anon', 'public.tf_get_billing_status()', 'EXECUTE')"),
  'anon não possui permissão de EXECUTE em public.tf_get_billing_status'
);
check(
  await scalar("SELECT has_function_privilege('authenticated', 'public.tf_get_billing_status()', 'EXECUTE')"),
  'authenticated possui permissão de EXECUTE em public.tf_get_billing_status'
);
check(
  !await scalar("SELECT has_table_privilege('authenticated', 'tecniflow.company_subscriptions', 'SELECT')"),
  'authenticated não tem SELECT direto em company_subscriptions'
);
check(
  !await scalar("SELECT has_table_privilege('authenticated', 'tecniflow.billing_payments', 'SELECT')"),
  'authenticated não tem SELECT direto em billing_payments'
);
check(
  !await scalar("SELECT has_function_privilege('anon', 'public.tf_process_billing_payment(varchar,varchar,varchar,integer,varchar,varchar,timestamptz)', 'EXECUTE')"),
  'anon não tem EXECUTE em tf_process_billing_payment'
);
check(
  !await scalar("SELECT has_function_privilege('authenticated', 'public.tf_process_billing_payment(varchar,varchar,varchar,integer,varchar,varchar,timestamptz)', 'EXECUTE')"),
  'authenticated não tem EXECUTE em tf_process_billing_payment'
);
check(
  await scalar("SELECT has_function_privilege('service_role', 'public.tf_process_billing_payment(varchar,varchar,varchar,integer,varchar,varchar,timestamptz)', 'EXECUTE')"),
  'service_role possui EXECUTE em tf_process_billing_payment'
);

// Contar tabelas antes de rodar 007
const subsBefore = Number(await scalar("SELECT count(*) FROM tecniflow.company_subscriptions"));
const paymentsBefore = Number(await scalar("SELECT count(*) FROM tecniflow.billing_payments"));

// 6. Executar script de auditoria transacional 007_billing_verification_rollback.sql
console.log('\nExecutando supabase/007_billing_verification_rollback.sql...');
const sql007 = readFileSync('supabase/007_billing_verification_rollback.sql', 'utf8');
try {
  await db.exec(sql007);
  check(true, '007_billing_verification_rollback.sql executou todas as 26 baterias com louvor');
} catch (err) {
  console.error('ERROR in 007 execution:');
  console.error(err.message || err);
  throw err;
}

// 7. Validar que o ROLLBACK reverteu tudo (zero fixtures persistidas)
const subsAfter = Number(await scalar("SELECT count(*) FROM tecniflow.company_subscriptions"));
check(subsAfter === subsBefore, 'Zero assinaturas de teste persistidas após ROLLBACK');

const paymentsAfter = Number(await scalar("SELECT count(*) FROM tecniflow.billing_payments"));
check(paymentsAfter === paymentsBefore, 'Zero pagamentos de teste persistidos após ROLLBACK');

console.log(`\n================================================================`);
console.log(`  RESULTADO: TODOS OS ${passed} TESTES DE BANCO E SEGURANÇA PASSARAM!`);
console.log(`================================================================\n`);
