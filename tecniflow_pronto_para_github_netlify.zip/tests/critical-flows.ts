import http from 'node:http';
import { AddressInfo } from 'node:net';
import crypto from 'node:crypto';
import { createApp } from '../server.js';
import { createDatabase, mainDb } from '../server/db.js';
import { recordLoginFailure } from '../server/auth.js';

interface HttpResponse {
  status: number;
  headers: Headers;
  body: any;
  rawText: string;
}

class TestClient {
  public baseUrl: string;
  public cookies: string[] = [];

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl;
  }

  setCookie(cookieStr: string) {
    this.cookies = [cookieStr];
  }

  clearCookie() {
    this.cookies = [];
  }

  getCookie(): string {
    return this.cookies.join('; ');
  }

  async request(path: string, options: {
    method?: string;
    body?: any;
    rawBody?: boolean;
    headers?: Record<string, string>;
  } = {}): Promise<HttpResponse> {
    const method = options.method || 'GET';
    const reqHeaders: Record<string, string> = {
      ...options.headers
    };

    if (this.cookies.length > 0) {
      reqHeaders['cookie'] = this.getCookie();
    }

    let payload: string | undefined = undefined;
    if (options.body !== undefined) {
      if (options.rawBody) {
        reqHeaders['content-type'] = 'application/json';
        payload = String(options.body);
      } else {
        reqHeaders['content-type'] = 'application/json';
        payload = JSON.stringify(options.body);
      }
    }

    const res = await fetch(`${this.baseUrl}${path}`, {
      method,
      headers: reqHeaders,
      body: payload
    });

    const setCookie = res.headers.get('set-cookie');
    if (setCookie) {
      if (setCookie.includes('tecniflow_session=;') || setCookie.includes('Max-Age=0')) {
        this.cookies = [];
      } else {
        const match = setCookie.match(/tecniflow_session=[^;]+/);
        if (match) {
          this.cookies = [match[0]];
        }
      }
    }

    const rawText = await res.text();
    let body: any = null;
    try {
      body = JSON.parse(rawText);
    } catch {
      body = rawText;
    }

    return {
      status: res.status,
      headers: res.headers,
      body,
      rawText
    };
  }
}

async function runTestSuite() {
  console.log('================================================================');
  console.log('  TECNIFLOW - SUÍTE DE TESTES REAIS HTTP EM BANCO ISOLADO');
  console.log('================================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string, detail?: string) {
    if (condition) {
      console.log(`  ✓ [PASS] ${testName}`);
      passed++;
    } else {
      console.error(`  ✗ [FAIL] ${testName}${detail ? ` -> ${detail}` : ''}`);
      failed++;
    }
  }

  // 1. Create separate in-memory SQLite database
  const isolatedDb = createDatabase(':memory:');
  const app = createApp(isolatedDb);

  // 2. Start HTTP server on random free port
  const server = http.createServer(app);
  await new Promise<void>((resolve) => {
    server.listen(0, '127.0.0.1', () => resolve());
  });

  const port = (server.address() as AddressInfo).port;
  const baseUrl = `http://127.0.0.1:${port}`;
  console.log(`[Test Server] Servidor de testes HTTP ativo em: ${baseUrl}\n`);

  try {
    const clientA = new TestClient(baseUrl);
    const clientB = new TestClient(baseUrl);

    // ==========================================
    // 1. Endpoint de saúde e integridade básica
    // ==========================================
    const health = await clientA.request('/api/health');
    assert(health.status === 200 && health.body.app === 'TecniFlow', '1. Endpoint de saúde (/api/health) responde status 200');

    // ==========================================
    // 2. Validação de senha: min 12 caracteres (não bytes), max 72 bytes
    // ==========================================
    // 4 emojis: 4 caracteres Unicode, mas 16 bytes em UTF-8 -> deve rejeitar por ter menos de 12 caracteres!
    const emojiPwd = await clientA.request('/api/auth/register', {
      method: 'POST',
      body: {
        companyName: 'Assistência Tec Alfa',
        ownerName: 'Carlos Proprietário',
        email: 'alfa@tecniflow.com.br',
        password: '🔑🔐🛠️⚡'
      }
    });
    assert(emojiPwd.status === 400 && emojiPwd.body.error.includes('12 caracteres'), '2. Registro rejeita senha com 4 emojis (16 bytes, mas apenas 4 caracteres)');

    // Senha com mais de 72 bytes
    const longBytePwd = 'A'.repeat(73);
    const longByteRes = await clientA.request('/api/auth/register', {
      method: 'POST',
      body: {
        companyName: 'Assistência Tec Alfa',
        ownerName: 'Carlos Proprietário',
        email: 'alfa@tecniflow.com.br',
        password: longBytePwd
      }
    });
    assert(longByteRes.status === 400 && longByteRes.body.error.includes('72 bytes'), '3. Registro rejeita senha excedendo 72 bytes (limite do bcrypt)');

    // ==========================================
    // 3. Validação de corpo nulo / inválido (sem 500)
    // ==========================================
    const nullBodyRes = await clientA.request('/api/auth/register', {
      method: 'POST',
      body: 'null',
      rawBody: true
    });
    assert(nullBodyRes.status === 400 && nullBodyRes.body.error.includes('inválido'), '4. Corpo nulo/inválido em /api/auth/register rejeitado com HTTP 400 (sem erro 500)');

    const stringBodyLogin = await clientA.request('/api/auth/login', {
      method: 'POST',
      body: '"apenas_uma_string"',
      rawBody: true
    });
    assert(stringBodyLogin.status === 400, '5. Corpo string em /api/auth/login rejeitado com HTTP 400');

    // ==========================================
    // 4. Registro bem-sucedido com senha Unicode válida
    // ==========================================
    const registerA = await clientA.request('/api/auth/register', {
      method: 'POST',
      body: {
        companyName: 'Assistência Tec Alfa',
        ownerName: 'Carlos Proprietário',
        email: 'alfa@tecniflow.com.br',
        password: 'SenhaForte123áéíóú' // 18 caracteres Unicode válidos, < 72 bytes
      }
    });
    assert(registerA.status === 201 && registerA.body.csrfToken, '6. Empresa Alfa registrada com sucesso e cookie de sessão retornado');
    const csrfA = registerA.body.csrfToken;
    const companyAId = registerA.body.company.id;

    const registerB = await clientB.request('/api/auth/register', {
      method: 'POST',
      body: {
        companyName: 'Assistência Tec Beta',
        ownerName: 'Bruno Proprietário',
        email: 'beta@tecniflow.com.br',
        password: 'OutraSenhaSuperSegura456!'
      }
    });
    assert(registerB.status === 201 && registerB.body.csrfToken, '7. Empresa Beta registrada com sucesso');
    const csrfB = registerB.body.csrfToken;

    // ==========================================
    // 5. Testes de /auth/me, /auth/login e /auth/logout
    // ==========================================
    // Acessar /auth/me com sessão ativa
    const meRes = await clientA.request('/api/auth/me');
    assert(meRes.status === 200 && meRes.body.user.email === 'alfa@tecniflow.com.br', '8. Endpoint /api/auth/me retorna dados da sessão ativa corretamente');

    // Logout
    const logoutRes = await clientA.request('/api/auth/logout', {
      method: 'POST',
      headers: { 'X-CSRF-Token': csrfA }
    });
    assert(logoutRes.status === 200 && logoutRes.body.message.includes('encerrada'), '9. Endpoint /api/auth/logout finaliza sessão com sucesso e limpa cookie');

    // Após logout, /api/auth/me deve retornar 401
    const meAfterLogout = await clientA.request('/api/auth/me');
    assert(meAfterLogout.status === 401, '10. Acesso a /api/auth/me após logout é rejeitado com HTTP 401');

    // Login com senha incorreta
    const wrongLogin = await clientA.request('/api/auth/login', {
      method: 'POST',
      body: { email: 'alfa@tecniflow.com.br', password: 'SenhaTotalmenteErrada!' }
    });
    assert(wrongLogin.status === 401 && wrongLogin.body.error.includes('inválidas'), '11. Login com senha errada rejeitado com HTTP 401');

    // Login com sucesso
    const correctLogin = await clientA.request('/api/auth/login', {
      method: 'POST',
      body: { email: 'alfa@tecniflow.com.br', password: 'SenhaForte123áéíóú' }
    });
    assert(correctLogin.status === 200 && correctLogin.body.csrfToken, '12. Login com credenciais válidas reautentica com sucesso');
    const newCsrfA = correctLogin.body.csrfToken;

    // Teste de expiração de sessão
    const expiredTokenHash = crypto.createHash('sha256').update(clientA.getCookie().replace('tecniflow_session=', '')).digest('hex');
    isolatedDb.prepare("UPDATE sessions SET expires_at = '2000-01-01T00:00:00.000Z' WHERE token_hash = ?").run(expiredTokenHash);
    const expiredReq = await clientA.request('/api/auth/me');
    assert(expiredReq.status === 401, '13. Sessão expirada no banco é rejeitada com HTTP 401');

    // Relogar para continuar os testes com Empresa Alfa
    const relogin = await clientA.request('/api/auth/login', {
      method: 'POST',
      body: { email: 'alfa@tecniflow.com.br', password: 'SenhaForte123áéíóú' }
    });
    const currentCsrfA = relogin.body.csrfToken;

    // ==========================================
    // 6. CSRF em mutações
    // ==========================================
    const noCsrfReq = await clientA.request('/api/clients', {
      method: 'POST',
      body: { name: 'Cliente Teste Sem CSRF', phone: '11999990001' }
    });
    assert(noCsrfReq.status === 403 && noCsrfReq.body.error.includes('token CSRF ausente'), '14. Requisição sem X-CSRF-Token é bloqueada (HTTP 403)');

    const invalidCsrfReq = await clientA.request('/api/clients', {
      method: 'POST',
      headers: { 'X-CSRF-Token': 'falso_123' },
      body: { name: 'Cliente Teste CSRF Inválido', phone: '11999990001' }
    });
    assert(invalidCsrfReq.status === 403 && invalidCsrfReq.body.error.includes('token CSRF inválido'), '15. Requisição com X-CSRF-Token forjado é bloqueada (HTTP 403)');

    // ==========================================
    // 7. Isolamento Multi-tenant e criação de clientes / peças
    // ==========================================
    const createClientA = await clientA.request('/api/clients', {
      method: 'POST',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: { name: 'Maria Silva Alfa', phone: '11988881111', email: 'maria@alfa.com' }
    });
    assert(createClientA.status === 201, '16. Empresa Alfa cadastra cliente com sucesso');
    const clientAId = createClientA.body.client.id;

    const createClientB = await clientB.request('/api/clients', {
      method: 'POST',
      headers: { 'X-CSRF-Token': csrfB },
      body: { name: 'Jose Souza Beta', phone: '11977772222', email: 'jose@beta.com' }
    });
    assert(createClientB.status === 201, '17. Empresa Beta cadastra cliente com sucesso');
    const clientBId = createClientB.body.client.id;

    const crossClientGet = await clientB.request(`/api/clients/${clientAId}`);
    assert(crossClientGet.status === 404, '18. Isolamento Multi-tenant: Empresa Beta não pode ler cliente da Empresa Alfa (HTTP 404)');

    const createPartA = await clientA.request('/api/inventory', {
      method: 'POST',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: {
        name: 'Tela OLED iPhone 13 Alfa',
        quantity: 10,
        minQuantity: 2,
        costPriceCents: 15000,
        salePriceCents: 35000
      }
    });
    assert(createPartA.status === 201, '19. Peça cadastrada na Empresa Alfa com saldo inicial 10');
    const partAId = createPartA.body.item.id;

    // Empresa B tenta criar OS com cliente da Alfa -> 400
    const crossClientOrder = await clientB.request('/api/orders', {
      method: 'POST',
      headers: { 'X-CSRF-Token': csrfB },
      body: {
        clientId: clientAId,
        deviceType: 'smartphone',
        brand: 'Apple',
        model: 'iPhone 13',
        defectReported: 'Tela quebrada'
      }
    });
    assert(crossClientOrder.status === 400, '20. Empresa Beta impedida de criar OS com cliente da Empresa Alfa (HTTP 400)');

    // Empresa B cria OS com cliente próprio
    const orderBCreated = await clientB.request('/api/orders', {
      method: 'POST',
      headers: { 'X-CSRF-Token': csrfB },
      body: {
        clientId: clientBId,
        deviceType: 'notebook',
        brand: 'Dell',
        model: 'Inspiron 15',
        defectReported: 'Nao liga'
      }
    });
    assert(orderBCreated.status === 201 && orderBCreated.body.order.order_number === 1, '21. Primeira OS da Empresa Beta recebe sequencial #1 independente');
    const orderBId = orderBCreated.body.order.id;

    // Empresa B tenta colocar peça da Empresa A no orçamento -> 400
    const crossInventoryBudget = await clientB.request(`/api/orders/${orderBId}/budget`, {
      method: 'PUT',
      headers: { 'X-CSRF-Token': csrfB },
      body: {
        version: 1,
        services: [{ description: 'Reparo placa', unit_price_cents: 20000, quantity: 1 }],
        parts: [{ inventory_item_id: partAId, description: 'Tela da Alfa', unit_price_cents: 35000, quantity: 1 }]
      }
    });
    assert(crossInventoryBudget.status === 400 && crossInventoryBudget.body.error.includes('não pertence à sua assistência'), '22. Isolamento Multi-tenant: Bloqueio de peça alheia no orçamento (HTTP 400)');

    // Empresa A cria OS #1
    const orderACreated = await clientA.request('/api/orders', {
      method: 'POST',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: {
        clientId: clientAId,
        deviceType: 'smartphone',
        brand: 'Apple',
        model: 'iPhone 13',
        defectReported: 'Bateria estufada'
      }
    });
    assert(orderACreated.status === 201 && orderACreated.body.order.order_number === 1, '23. Primeira OS da Empresa Alfa recebe sequencial #1');
    const orderAId = orderACreated.body.order.id;

    // ==========================================
    // 8. Validações estritas de version (ausente, string, float, null, negativo)
    // ==========================================
    const noVersionBudget = await clientA.request(`/api/orders/${orderAId}/budget`, {
      method: 'PUT',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: {
        services: [{ description: 'Servico', unit_price_cents: 1000, quantity: 1 }],
        parts: []
        // version ausente!
      }
    });
    assert(noVersionBudget.status === 400 && noVersionBudget.body.error.includes('version é obrigatório'), '24. Mutação de orçamento sem campo version é rejeitada com HTTP 400');

    const stringVersionBudget = await clientA.request(`/api/orders/${orderAId}/budget`, {
      method: 'PUT',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: {
        version: '1', // string!
        services: [{ description: 'Servico', unit_price_cents: 1000, quantity: 1 }],
        parts: []
      }
    });
    assert(stringVersionBudget.status === 400 && stringVersionBudget.body.error.includes('número inteiro'), '25. Version como string ("1") rejeitada com HTTP 400');

    const floatVersionBudget = await clientA.request(`/api/orders/${orderAId}/budget`, {
      method: 'PUT',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: {
        version: 1.5, // float!
        services: [{ description: 'Servico', unit_price_cents: 1000, quantity: 1 }],
        parts: []
      }
    });
    assert(floatVersionBudget.status === 400, '26. Version com número não inteiro (1.5) rejeitada com HTTP 400');

    const nullVersionBudget = await clientA.request(`/api/orders/${orderAId}/budget`, {
      method: 'PUT',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: {
        version: null,
        services: [{ description: 'Servico', unit_price_cents: 1000, quantity: 1 }],
        parts: []
      }
    });
    assert(nullVersionBudget.status === 400, '27. Version null rejeitada com HTTP 400');

    // ==========================================
    // 9. Máquina de estados e avanço de etapas
    // ==========================================
    const jumpToRepair = await clientA.request(`/api/orders/${orderAId}/status`, {
      method: 'POST',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: { status: 'reparo', version: 1 }
    });
    assert(jumpToRepair.status === 400 && jumpToRepair.body.error.includes('Transição inválida'), '28. Salto direto de "recebido" para "reparo" é rejeitado (HTTP 400)');

    const stepToDiag = await clientA.request(`/api/orders/${orderAId}/status`, {
      method: 'POST',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: { status: 'diagnostico', version: 1 }
    });
    assert(stepToDiag.status === 200, '29. Transição válida de "recebido" para "diagnostico" aceita (version incrementada para 2)');

    const stepToAwaiting = await clientA.request(`/api/orders/${orderAId}/status`, {
      method: 'POST',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: { status: 'aguardando_aprovacao', version: 2 }
    });
    assert(stepToAwaiting.status === 200, '30. Transição de "diagnostico" para "aguardando_aprovacao" aceita (version = 3)');

    // Iniciar reparo sem orçamento aprovado -> 400
    const repairWithoutApproval = await clientA.request(`/api/orders/${orderAId}/status`, {
      method: 'POST',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: { status: 'reparo', version: 3 }
    });
    assert(repairWithoutApproval.status === 400 && repairWithoutApproval.body.error.includes('sem a aprovação prévia'), '31. Bloqueio estrito de início de reparo sem aprovação prévia do orçamento (HTTP 400)');

    // ==========================================
    // 10. Agregação de peças repetidas e baixa condicional atômica
    // ==========================================
    // Inserir orçamento com 2 linhas da mesma peça partA (saldo 10): 6 unidades + 5 unidades = 11 unidades (> 10)
    const overstockBudget = await clientA.request(`/api/orders/${orderAId}/budget`, {
      method: 'PUT',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: {
        version: 3,
        services: [{ description: 'Mão de obra', unit_price_cents: 10000, quantity: 1 }],
        parts: [
          { inventory_item_id: partAId, description: 'Tela iPhone Linha 1', unit_price_cents: 35000, quantity: 6 },
          { inventory_item_id: partAId, description: 'Tela iPhone Linha 2', unit_price_cents: 35000, quantity: 5 }
        ]
      }
    });
    assert(overstockBudget.status === 200, '32. Orçamento com 2 linhas da mesma peça configurado (total 11 unidades, version = 4)');

    // Aprovar orçamento
    const approveBudget = await clientA.request(`/api/orders/${orderAId}/budget/decision`, {
      method: 'POST',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: { decision: 'aprovado', version: 4 }
    });
    assert(approveBudget.status === 200, '33. Orçamento aprovado com sucesso (version = 5)');

    // Tentar ir para reparo com 11 peças quando só há 10 em estoque -> BLOQUEIO ATÔMICO
    const overstockRepair = await clientA.request(`/api/orders/${orderAId}/status`, {
      method: 'POST',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: { status: 'reparo', version: 5 }
    });
    assert(overstockRepair.status === 400 && overstockRepair.body.error.includes('Estoque insuficiente'), '34. Agregação atômica bloqueia baixa quando soma das linhas (11) excede saldo (10)');

    // Conferir que estoque não foi debitado parcialmente
    const checkStockStill10 = isolatedDb.prepare('SELECT quantity FROM inventory_items WHERE id = ?').get(partAId) as any;
    assert(checkStockStill10.quantity === 10, '35. Saldo mantido íntegro em 10 (rollback atômico completo)');

    // Reabrir orçamento para revisão (version = 5)
    const reviseBudget = await clientA.request(`/api/orders/${orderAId}/budget/revise`, {
      method: 'POST',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: { version: 5 }
    });
    assert(reviseBudget.status === 200 && reviseBudget.body.order.budget_status === 'pendente', '36. Orçamento reaberto para revisão com sucesso (version = 6)');

    // Ajustar quantidades para 4 + 3 = 7 unidades (<= 10)
    await clientA.request(`/api/orders/${orderAId}/budget`, {
      method: 'PUT',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: {
        version: 6,
        services: [{ description: 'Mão de obra', unit_price_cents: 10000, quantity: 1 }],
        parts: [
          { inventory_item_id: partAId, description: 'Tela iPhone Linha 1', unit_price_cents: 35000, quantity: 4 },
          { inventory_item_id: partAId, description: 'Tela iPhone Linha 2', unit_price_cents: 35000, quantity: 3 }
        ]
      }
    });

    // Reaprovar (version = 7)
    await clientA.request(`/api/orders/${orderAId}/budget/decision`, {
      method: 'POST',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: { decision: 'aprovado', version: 7 }
    });

    // Iniciar reparo (version = 8) -> DEVE SUCEDER
    const validRepair = await clientA.request(`/api/orders/${orderAId}/status`, {
      method: 'POST',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: { status: 'reparo', version: 8 }
    });
    assert(validRepair.status === 200, '37. Transição para "reparo" conclui baixa atômica de 7 unidades (version = 9)');

    const checkStockNow3 = isolatedDb.prepare('SELECT quantity FROM inventory_items WHERE id = ?').get(partAId) as any;
    assert(checkStockNow3.quantity === 3, '38. Saldo de estoque reduzido com exatidão para 3 unidades');

    // Tentar revisar orçamento após peças debitadas -> 400
    const reviseAfterDebited = await clientA.request(`/api/orders/${orderAId}/budget/revise`, {
      method: 'POST',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: { version: 9 }
    });
    assert(reviseAfterDebited.status === 400 && reviseAfterDebited.body.error.includes('já existem peças debitadas'), '39. Bloqueio de revisão de orçamento após baixa de peças executada (HTTP 400)');

    // ==========================================
    // 11. Concorrência real via Promise.all (duas requisições com mesma versão)
    // ==========================================
    const [conc1, conc2] = await Promise.all([
      clientA.request(`/api/orders/${orderAId}/status`, {
        method: 'POST',
        headers: { 'X-CSRF-Token': currentCsrfA },
        body: { status: 'pronto', version: 9 }
      }),
      clientA.request(`/api/orders/${orderAId}/status`, {
        method: 'POST',
        headers: { 'X-CSRF-Token': currentCsrfA },
        body: { status: 'pronto', version: 9 }
      })
    ]);
    const onePassed = (conc1.status === 200 && conc2.status === 409) || (conc1.status === 409 && conc2.status === 200);
    assert(onePassed, '40. Concorrência (Promise.all): Exatamente uma requisição é aceita (200) e a outra recebe 409 Conflict');

    // Repetição de requisição com versão desatualizada (stale version) -> 409
    const replayStale = await clientA.request(`/api/orders/${orderAId}/status`, {
      method: 'POST',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: { status: 'entregue', version: 9 } // stale! Atual é 10
    });
    assert(replayStale.status === 409 && replayStale.body.currentVersion === 10, '41. Repetição de requisição com versão defasada rejeitada com HTTP 409 Conflict');

    // Avançar para entregue com version correta (10)
    const deliverOrderA = await clientA.request(`/api/orders/${orderAId}/status`, {
      method: 'POST',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: { status: 'entregue', version: 10 }
    });
    assert(deliverOrderA.status === 200, '42. Ordem entregue ao cliente com completed_at registrado');

    // ==========================================
    // 12. Duas baixas concorrentes no estoque via Promise.all (sem saldo negativo)
    // ==========================================
    // Criar um novo item de estoque com saldo 5
    const concItemId = crypto.randomUUID();
    isolatedDb.prepare(`
      INSERT INTO inventory_items (id, company_id, name, quantity, min_quantity, cost_price_cents, sale_price_cents, is_archived, created_at, updated_at)
      VALUES (?, ?, 'Conector Concorrente', 5, 1, 1000, 3000, 0, datetime('now'), datetime('now'))
    `).run(concItemId, companyAId);

    // Duas saídas manuais simultâneas de 4 unidades cada (4 + 4 = 8 > 5)
    const [mv1, mv2] = await Promise.all([
      clientA.request(`/api/inventory/${concItemId}/movement`, {
        method: 'POST',
        headers: { 'X-CSRF-Token': currentCsrfA },
        body: { type: 'saida_manual', quantity: 4, reason: 'Saída simultânea 1' }
      }),
      clientA.request(`/api/inventory/${concItemId}/movement`, {
        method: 'POST',
        headers: { 'X-CSRF-Token': currentCsrfA },
        body: { type: 'saida_manual', quantity: 4, reason: 'Saída simultânea 2' }
      })
    ]);
    const stockRaceConditionBlocked = (mv1.status === 200 && mv2.status === 400) || (mv1.status === 400 && mv2.status === 200);
    const finalStockItem = isolatedDb.prepare('SELECT quantity FROM inventory_items WHERE id = ?').get(concItemId) as any;
    assert(stockRaceConditionBlocked && finalStockItem.quantity === 1, '43. Baixas concorrentes simultâneas (Promise.all): uma aceita, outra bloqueada, saldo final exato 1 (sem saldo negativo)');

    // ==========================================
    // 13. Cancelamento exigindo justificativa e estado terminal
    // ==========================================
    const newOrderForCancel = await clientA.request('/api/orders', {
      method: 'POST',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: {
        clientId: clientAId,
        deviceType: 'tablet',
        brand: 'Samsung',
        model: 'Tab A8',
        defectReported: 'Display quebrado'
      }
    });
    const cancelOrderId = newOrderForCancel.body.order.id;

    const emptyCancel = await clientA.request(`/api/orders/${cancelOrderId}/status`, {
      method: 'POST',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: { status: 'cancelado', cancellationReason: '   ', version: 1 }
    });
    assert(emptyCancel.status === 400 && emptyCancel.body.error.includes('justificativa'), '44. Cancelamento com justificativa vazia rejeitado com HTTP 400');

    const validCancel = await clientA.request(`/api/orders/${cancelOrderId}/status`, {
      method: 'POST',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: { status: 'cancelado', cancellationReason: 'Aparelho sem conserto por placa queimada.', version: 1 }
    });
    assert(validCancel.status === 200, '45. Cancelamento com justificativa gravada aceito com sucesso');

    const terminalAttempt = await clientA.request(`/api/orders/${cancelOrderId}/status`, {
      method: 'POST',
      headers: { 'X-CSRF-Token': currentCsrfA },
      body: { status: 'diagnostico', version: 2 }
    });
    assert(terminalAttempt.status === 400 && terminalAttempt.body.error.includes('estado terminal'), '46. Ordem de serviço em estado terminal (cancelado) bloqueia novas transições (HTTP 400)');

    // ==========================================
    // 14. Relatório por período com datas inválidas, intervalo invertido e DELTAS EXATOS
    // ==========================================
    // Validação de datas
    const badStart = await clientA.request('/api/reports/period?startDate=data-invalida');
    assert(badStart.status === 400 && badStart.body.error.includes('formato ou calendário inválido'), '47. Data inicial inválida no relatório rejeitada com HTTP 400');

    const badEnd = await clientA.request('/api/reports/period?endDate=2026/10/31');
    assert(badEnd.status === 400 && badEnd.body.error.includes('formato ou calendário inválido'), '48. Data final com formato inválido rejeitada com HTTP 400');

    const badCalendarFeb = await clientA.request('/api/reports/period?startDate=2026-02-31');
    assert(badCalendarFeb.status === 400 && badCalendarFeb.body.error.includes('calendário inválido'), '48b. Data com dia inexistente no calendário (31/02) rejeitada com HTTP 400');

    const badCalendarMonth = await clientA.request('/api/reports/period?startDate=2026-13-01');
    assert(badCalendarMonth.status === 400 && badCalendarMonth.body.error.includes('calendário inválido'), '48c. Data com mês inexistente (13) rejeitada com HTTP 400');

    const invertedInterval = await clientA.request('/api/reports/period?startDate=2026-10-31&endDate=2026-10-01');
    assert(invertedInterval.status === 400 && invertedInterval.body.error.includes('superior'), '49. Intervalo de datas invertido (início > fim) rejeitado com HTTP 400');

    const futureStartOnly = await clientA.request('/api/reports/period?startDate=2099-01-01');
    assert(futureStartOnly.status === 400 && futureStartOnly.body.error.includes('superior'), '49b. Data inicial futura sem data final rejeitada após resolver padrão atual (início > fim padrão)');

    // Obter métricas ANTES da fixture de setembro
    const reportBefore = await clientA.request('/api/reports/period?startDate=2026-10-01&endDate=2026-10-31');
    const beforeCreated = reportBefore.body.summary.totalOrders;
    const beforeDelivered = reportBefore.body.summary.deliveredCount;
    const beforeDeliveredAmount = reportBefore.body.summary.totalDeliveredCents;

    // Fixture: OS criada em SETEMBRO (2026-09-12), mas concluída/entregue em OUTUBRO (2026-10-14) por R$ 350,00 (35000 centavos)
    const septOrderId = crypto.randomUUID();
    const septCreatedAt = '2026-09-12T14:30:00.000Z';
    const octCompletedAt = '2026-10-14T18:00:00.000Z';
    isolatedDb.prepare(`
      INSERT INTO orders (
        id, company_id, order_number, client_id, device_type, brand, model, defect_reported,
        status, budget_status, total_services_cents, total_parts_cents, total_amount_cents,
        version, created_at, updated_at, completed_at
      ) VALUES (?, ?, 77, ?, 'smartphone', 'Xiaomi', 'Redmi Note 12', 'Troca conector',
        'entregue', 'aprovado', 20000, 15000, 35000, 5, ?, ?, ?)
    `).run(septOrderId, companyAId, clientAId, septCreatedAt, octCompletedAt, octCompletedAt);

    // Obter métricas DEPOIS da fixture para o mês de outubro (2026-10-01 a 2026-10-31)
    const reportAfter = await clientA.request('/api/reports/period?startDate=2026-10-01&endDate=2026-10-31');
    const afterCreated = reportAfter.body.summary.totalOrders;
    const afterDelivered = reportAfter.body.summary.deliveredCount;
    const afterDeliveredAmount = reportAfter.body.summary.totalDeliveredCents;

    const deltaCreated = afterCreated - beforeCreated;
    const deltaDelivered = afterDelivered - beforeDelivered;
    const deltaDeliveredAmount = afterDeliveredAmount - beforeDeliveredAmount;

    assert(deltaCreated === 0, '50. Relatório: OS aberta em setembro NÃO altera o número de aberturas de outubro (deltaCreated === 0)');
    assert(deltaDelivered === 1, '51. Relatório: OS concluída em outubro incrementa exatamente +1 nas entregas (deltaDelivered === 1)');
    assert(deltaDeliveredAmount === 35000, '52. Relatório: Valor entregue incrementa exatamente +35000 centavos (R$ 350,00)');

    // ==========================================
    // 15. Validação de Email no Login e Concorrência Atômica
    // ==========================================
    // 53. Validação de email longo (>100 chars) no Login antes de consultar o banco
    const longEmail = 'a'.repeat(95) + '@dominio.com.br'; // 110 caracteres
    const resLongEmail = await clientA.request('/api/auth/login', {
      method: 'POST',
      body: { email: longEmail, password: 'SenhaQualquer#123' }
    });
    assert(
      resLongEmail.status === 400 && resLongEmail.body?.error?.includes('máximo 100 caracteres'),
      '53. Login rejeita e-mail longo (>100 caracteres) com HTTP 400 antes de consultar o banco'
    );

    // 54. Validação de email com formato inválido no Login
    const resInvalidEmail = await clientA.request('/api/auth/login', {
      method: 'POST',
      body: { email: 'not-a-valid-email', password: 'SenhaQualquer#123' }
    });
    assert(
      resInvalidEmail.status === 400 && resInvalidEmail.body?.error?.includes('e-mail válido'),
      '54. Login rejeita e-mail com formato inválido com HTTP 400 antes de consultar o banco'
    );

    // 55 & 56. Cadastro simultâneo do mesmo e-mail: conflito HTTP 409 e rollback da empresa perdedora
    const dupEmail = 'proprietario.concorrente@teste.com';
    const regPayload1 = {
      companyName: 'Assistencia Alpha Concorrente',
      ownerName: 'Proprietario 1',
      ownerEmail: dupEmail,
      password: 'SenhaMuitoForte#12345'
    };
    const regPayload2 = {
      companyName: 'Assistencia Beta Concorrente',
      ownerName: 'Proprietario 2',
      ownerEmail: dupEmail,
      password: 'SenhaMuitoForte#12345'
    };

    const [reg1, reg2] = await Promise.all([
      clientA.request('/api/auth/register', { method: 'POST', body: regPayload1 }),
      clientB.request('/api/auth/register', { method: 'POST', body: regPayload2 })
    ]);

    const regStatuses = [reg1.status, reg2.status].sort();
    assert(
      regStatuses[0] === 201 && regStatuses[1] === 409,
      '55. Cadastro simultâneo do mesmo e-mail: exatamente um 201 e um conflito 409',
      `Status obtidos: ${regStatuses.join(', ')}`
    );

    const dupUserCount = isolatedDb.prepare('SELECT COUNT(*) as c FROM users WHERE email = ?').get(dupEmail) as { c: number };
    const compAlpha = isolatedDb.prepare("SELECT COUNT(*) as c FROM companies WHERE name = 'Assistencia Alpha Concorrente'").get() as { c: number };
    const compBeta = isolatedDb.prepare("SELECT COUNT(*) as c FROM companies WHERE name = 'Assistencia Beta Concorrente'").get() as { c: number };
    assert(
      dupUserCount.c === 1 && (compAlpha.c + compBeta.c === 1),
      '56. Rollback transacional da empresa no cadastro com e-mail duplicado concorrente (apenas 1 empresa persistida)'
    );

    // 57. Incremento atômico de falhas de login (login_attempts) sob falhas simultâneas
    const targetEmailFailure = 'alvo.concorrente@teste.com';
    await Promise.all([
      recordLoginFailure(targetEmailFailure, isolatedDb),
      recordLoginFailure(targetEmailFailure, isolatedDb),
      recordLoginFailure(targetEmailFailure, isolatedDb)
    ]);
    const attemptRow = isolatedDb.prepare('SELECT attempts, locked_until FROM login_attempts WHERE identifier = ?').get(targetEmailFailure) as { attempts: number; locked_until: string | null };
    assert(
      attemptRow.attempts === 3,
      '57. Incremento atômico de login_attempts sem perda de contagem sob falhas simultâneas (attempts === 3)'
    );

    // 57b. Expiração de bloqueio em login_attempts: 1ª falha após expiração reseta attempts para 1 e limpa locked_until (null)
    const expiredTarget = 'expirado.lockout@teste.com';
    const pastDate = new Date(Date.now() - 30 * 60000).toISOString();
    const pastLock = new Date(Date.now() - 15 * 60000).toISOString();
    isolatedDb.prepare('INSERT INTO login_attempts (identifier, attempts, last_attempt_at, locked_until) VALUES (?, 5, ?, ?)').run(
      expiredTarget,
      pastDate,
      pastLock
    );

    await recordLoginFailure(expiredTarget, isolatedDb);
    const postExpiryRow1 = isolatedDb.prepare('SELECT attempts, locked_until FROM login_attempts WHERE identifier = ?').get(expiredTarget) as { attempts: number; locked_until: string | null };
    assert(
      postExpiryRow1.attempts === 1 && postExpiryRow1.locked_until === null,
      '57b. Bloqueio expirado: 1ª falha inicia nova janela com attempts = 1 e locked_until limpo (null)'
    );

    // Falhas 2, 3 e 4: incrementam normalmente com locked_until permanecendo null
    await recordLoginFailure(expiredTarget, isolatedDb);
    await recordLoginFailure(expiredTarget, isolatedDb);
    await recordLoginFailure(expiredTarget, isolatedDb);
    const postExpiryRow4 = isolatedDb.prepare('SELECT attempts, locked_until FROM login_attempts WHERE identifier = ?').get(expiredTarget) as { attempts: number; locked_until: string | null };
    assert(
      postExpiryRow4.attempts === 4 && postExpiryRow4.locked_until === null,
      '57c. Falhas subsequentes no novo ciclo incrementam para 4 mantendo locked_until nulo'
    );

    // 5ª falha: atinge MAX_LOGIN_ATTEMPTS e volta a bloquear a conta
    await recordLoginFailure(expiredTarget, isolatedDb);
    const postExpiryRow5 = isolatedDb.prepare('SELECT attempts, locked_until FROM login_attempts WHERE identifier = ?').get(expiredTarget) as { attempts: number; locked_until: string | null };
    assert(
      postExpiryRow5.attempts === 5 && typeof postExpiryRow5.locked_until === 'string' && new Date(postExpiryRow5.locked_until) > new Date(),
      '57d. 5ª falha no novo ciclo reativa com sucesso o bloqueio temporário (locked_until no futuro)'
    );

    // 58. Mutex SQLite impede operação avulsa (query) de se intercalar durante transação ativa
    let txStarted = false;
    let txFinished = false;
    let queryRanDuringTx = false;

    const txPromise = isolatedDb.withTransaction(async () => {
      txStarted = true;
      await new Promise((r) => setTimeout(r, 60));
      txFinished = true;
      return 'ok';
    });

    const queryPromise = isolatedDb.query('SELECT 1 as val').then(() => {
      if (!txFinished) {
        queryRanDuringTx = true;
      }
    });

    await Promise.all([txPromise, queryPromise]);
    assert(
      txStarted && txFinished && !queryRanDuringTx,
      '58. Mutex SQLite: leitura/escrita avulsa aguarda conclusão de transação ativa antes de executar'
    );

    // 59 & 60. Tolerância a falhas assíncronas do banco com error handler e health check contínuo
    const faultDb = {
      provider: 'sqlite' as const,
      query: async () => { throw new Error('DB_SIMULATED_QUERY_ERROR'); },
      queryOne: async () => { throw new Error('DB_SIMULATED_QUERYONE_ERROR'); },
      execute: async () => { throw new Error('DB_SIMULATED_EXECUTE_ERROR'); },
      withTransaction: async () => { throw new Error('DB_SIMULATED_TX_ERROR'); },
      prepare: () => { throw new Error('NOT_IMPLEMENTED'); },
      exec: () => { throw new Error('NOT_IMPLEMENTED'); }
    };
    const faultApp = createApp(faultDb as any);
    const faultServer = http.createServer(faultApp);
    await new Promise<void>((r) => faultServer.listen(0, '127.0.0.1', () => r()));
    const faultPort = (faultServer.address() as AddressInfo).port;
    const faultClient = new TestClient(`http://127.0.0.1:${faultPort}`);

    try {
      const faultRes = await faultClient.request('/api/auth/register', {
        method: 'POST',
        body: {
          companyName: 'Falha Teste',
          ownerName: 'Dono Teste',
          ownerEmail: 'dono.fault@teste.com',
          password: 'SenhaMuitoForte#123'
        }
      });

      assert(
        faultRes.status === 500 &&
        faultRes.body?.error === 'Erro interno no servidor ao processar a requisição.' &&
        !JSON.stringify(faultRes.body).includes('DB_SIMULATED') &&
        !JSON.stringify(faultRes.body).includes('stack'),
        '59. Rejeição assíncrona do banco capturada pelo middleware /api: responde 500 com JSON genérico seguro'
      );

      const healthRes = await faultClient.request('/api/health');
      assert(
        healthRes.status === 200 && healthRes.body?.status === 'ok',
        '60. Servidor Express permanece íntegro e endpoint /api/health continua respondendo 200'
      );
    } finally {
      await new Promise<void>((r) => faultServer.close(() => r()));
    }

    // ==========================================
    // 16. Verificação rigorosa do banco de dados principal (data/tecniflow.db)
    // ==========================================
    const tablesToCheck = [
      'companies', 'users', 'sessions', 'clients', 'inventory_items',
      'orders', 'order_services', 'order_parts', 'inventory_movements', 'order_history'
    ];
    let realDbClean = true;
    for (const t of tablesToCheck) {
      const row = mainDb.prepare(`SELECT COUNT(*) as c FROM ${t}`).get() as { c: number };
      if (row.c !== 0) {
        realDbClean = false;
        console.error(`Tabela real ${t} contém ${row.c} registros!`);
      }
    }
    assert(realDbClean === true, '61. BANCO PRINCIPAL REAL (data/tecniflow.db) PERMANECE COM RIGOROSAMENTE ZERO REGISTROS');

  } finally {
    await new Promise<void>((resolve) => {
      server.close(() => resolve());
    });
    console.log('[Test Server] Servidor de testes finalizado com sucesso.');
  }

  console.log(`\n================================================================`);
  console.log(`  RESULTADO DOS TESTES: ${passed} passaram, ${failed} falharam.`);
  console.log(`================================================================\n`);

  if (failed > 0) {
    process.exit(1);
  }
}

runTestSuite().catch((err) => {
  console.error('Erro fatal ao executar suíte de testes:', err);
  process.exit(1);
});
