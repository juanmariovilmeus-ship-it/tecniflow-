import assert from 'node:assert/strict';
import React, { act } from 'react';
import TestRenderer from 'react-test-renderer';
import {
  getSafeRedirectUrl,
  isIframeOrPreview,
  validateRedirectOverride,
  resolveRecoveryRedirectUrl,
  isRecoveryUrl,
  isUrlExpiredOrError,
  cleanAuthUrl,
} from '../src/lib/sessionCoordinator.ts';
import { supabase } from '../src/lib/supabase.ts';
import { AuthProvider, useAuth } from '../src/context/AuthContext.tsx';
import * as apiModule from '../src/lib/api.ts';

(globalThis as any).IS_REACT_ACT_ENVIRONMENT = true;

let passed = 0;
function check(condition: unknown, label: string) {
  assert.ok(Boolean(condition), label);
  passed++;
  console.log(`  ✓ [PASS] ${label}`);
}

console.log('================================================================');
console.log('  TECNIFLOW - SUÍTE COMPLETA: RECUPERAÇÃO DE SENHA DO USUÁRIO');
console.log('================================================================\n');

// ----------------------------------------------------------------------------
// 1. Validação de Overrides de Redirecionamento e Ambientes
// ----------------------------------------------------------------------------
console.log('--- 1. Validação de Overrides de Redirecionamento ---');

const emptyOverride = validateRedirectOverride('');
check(!emptyOverride.valid, 'Override vazio é rejeitado');

const spacesOverride = validateRedirectOverride('   ');
check(!spacesOverride.valid, 'Override contendo apenas espaços é rejeitado');

const malformedOverride = validateRedirectOverride('://url-invalida');
check(!malformedOverride.valid, 'URL malformada é rejeitada');

const credsOverride = validateRedirectOverride('https://admin:senha123@app.tecniflow.com.br/?auth=recovery');
check(!credsOverride.valid && credsOverride.reason?.includes('credenciais'), 'URL com credenciais de usuário embutidas é rejeitada');

const insecureRemoteOverride = validateRedirectOverride('http://app.tecniflow.com.br/?auth=recovery');
check(!insecureRemoteOverride.valid && insecureRemoteOverride.reason?.includes('HTTPS'), 'URL HTTP em domínio remoto é rejeitada');

// Localhost override em ambiente de produção deve ser rejeitado
const origNodeEnv = process.env.NODE_ENV;
process.env.NODE_ENV = 'production';
const localOverrideInProd = validateRedirectOverride('http://localhost:3000/?auth=recovery');
check(!localOverrideInProd.valid && localOverrideInProd.reason?.includes('desenvolvimento'), 'Override local em produção é estritamente rejeitado');
process.env.NODE_ENV = 'development';

const validLocalHttpOverride = validateRedirectOverride('http://localhost:3000/?auth=recovery');
check(validLocalHttpOverride.valid, 'URL HTTP em localhost é permitida em desenvolvimento local');

const valid127HttpOverride = validateRedirectOverride('http://127.0.0.1:3000/?auth=recovery');
check(valid127HttpOverride.valid, 'URL HTTP em 127.0.0.1 é permitida em desenvolvimento local');

const validHttpsOverride = validateRedirectOverride('https://app.tecniflow.com.br/?auth=recovery');
check(validHttpsOverride.valid && validHttpsOverride.normalized === 'https://app.tecniflow.com.br/?auth=recovery', 'URL HTTPS válida em produção é aceita e normalizada');

process.env.NODE_ENV = origNodeEnv;

// ----------------------------------------------------------------------------
// 2. Detecção de Iframe e Ambientes de Preview
// ----------------------------------------------------------------------------
console.log('\n--- 2. Detecção de Iframe e Ambientes de Preview ---');

const mockStandaloneWindow = {
  self: {},
  location: { hostname: 'app.tecniflow.com.br', origin: 'https://app.tecniflow.com.br' },
} as any;
mockStandaloneWindow.top = mockStandaloneWindow.self;
check(!isIframeOrPreview(mockStandaloneWindow), 'Janela standalone em domínio de produção não é identificada como iframe/preview');

const mockIframeWindow = {
  self: {},
  top: {}, // Diferente de self -> iframe
  location: { hostname: 'localhost', origin: 'http://localhost:3000' },
} as any;
check(isIframeOrPreview(mockIframeWindow), 'Janela com self !== top é corretamente detectada como iframe');

const mockRunAppWindow = {
  self: {},
  location: { hostname: 'applet-xyz-abcdef.run.app', origin: 'https://applet-xyz-abcdef.run.app' },
} as any;
mockRunAppWindow.top = mockRunAppWindow.self;
check(isIframeOrPreview(mockRunAppWindow), 'Host .run.app de preview é identificado como ambiente de preview');

const mockAiStudioWindow = {
  self: {},
  location: { hostname: 'tecniflow.ai.studio', origin: 'https://tecniflow.ai.studio' },
} as any;
mockAiStudioWindow.top = mockAiStudioWindow.self;
check(isIframeOrPreview(mockAiStudioWindow), 'Host ai.studio é identificado como ambiente de preview');

// ----------------------------------------------------------------------------
// 3. Resolução Segura de URL de Recuperação (Sem Fallback Inventado)
// ----------------------------------------------------------------------------
console.log('\n--- 3. Resolução Segura de URL de Recuperação ---');

// Falha caso não haja janela nem origem confiável
assert.throws(
  () => resolveRecoveryRedirectUrl(undefined, undefined),
  /Origem de redirecionamento não configurada/,
  'resolveRecoveryRedirectUrl falha sem janela ou origem (sem fallback inventado para localhost)'
);
check(true, 'Eliminação de fallback inventado quando !win comprovada');

// Falha em preview sem override
assert.throws(
  () => resolveRecoveryRedirectUrl(undefined, mockIframeWindow),
  /Não foi possível enviar o link agora\. Tente novamente mais tarde\./
);
check(true, 'Disparo de recuperação em iframe sem override público configurado é bloqueado');

// Em preview com override explícito válido, deve utilizar o override
const previewWithOverride = resolveRecoveryRedirectUrl('https://app.tecniflow.com.br/?auth=recovery', mockIframeWindow);
check(previewWithOverride === 'https://app.tecniflow.com.br/?auth=recovery', 'Preview com override válido utiliza a URL autorizada de produção');

// Standalone em produção com HTTP público deve falhar (exige HTTPS)
const mockInsecurePublicWindow = {
  self: {},
  location: { hostname: 'app.tecniflow.com.br', origin: 'http://app.tecniflow.com.br' },
} as any;
mockInsecurePublicWindow.top = mockInsecurePublicWindow.self;
assert.throws(
  () => resolveRecoveryRedirectUrl(undefined, mockInsecurePublicWindow),
  /HTTPS/
);
check(true, 'Origem pública HTTP sem HTTPS é rejeitada');

// Standalone local em DEV mode resolve para rota canônica /?auth=recovery
process.env.NODE_ENV = 'development';
const mockStandaloneLocal = {
  self: {},
  location: { hostname: 'localhost', origin: 'http://localhost:3000' },
} as any;
mockStandaloneLocal.top = mockStandaloneLocal.self;
const localResolved = resolveRecoveryRedirectUrl(undefined, mockStandaloneLocal);
check(localResolved === 'http://localhost:3000/?auth=recovery', 'Standalone local resolve para rota canônica /?auth=recovery');
process.env.NODE_ENV = origNodeEnv;

// Standalone em produção utiliza origin público seguro
const prodResolved = resolveRecoveryRedirectUrl(undefined, mockStandaloneWindow);
check(prodResolved === 'https://app.tecniflow.com.br/?auth=recovery', 'Standalone em produção resolve para rota canônica com HTTPS');

// Preservação retrocompatível de getSafeRedirectUrl
(globalThis as any).window = { location: { origin: 'https://tecniflow.app' } };
const legacyResetUrl = getSafeRedirectUrl('/#reset-password');
check(legacyResetUrl === 'https://tecniflow.app/#reset-password', 'getSafeRedirectUrl permanece 100% retrocompatível com testes existentes');

// ----------------------------------------------------------------------------
// 4. Detecção Exata de Callback de Recuperação e Tratamento de URIError (100%25)
// ----------------------------------------------------------------------------
console.log('\n--- 4. Detecção Exata de Callback e Robustez de Erros URL ---');

// Parsing exato via URLSearchParams
check(isRecoveryUrl({ search: '?auth=recovery', hash: '' }), 'URL com query auth=recovery é reconhecida');
check(!isRecoveryUrl({ search: '?other=auth=recovery', hash: '' }), 'URL com chave diferente não confunde com auth=recovery');
check(!isRecoveryUrl({ search: '?auth=recovery_other', hash: '' }), 'URL com valor parcial auth=recovery_other é rejeitada');
check(isRecoveryUrl({ search: '', hash: '#reset-password' }), 'Hash legado #reset-password é reconhecido');
check(isRecoveryUrl({ search: '', hash: '#access_token=xyz&type=recovery' }), 'Hash Supabase com type=recovery é reconhecido');
check(!isRecoveryUrl({ search: '', hash: '#other=type=recovery' }), 'Hash com chave diferente não confunde com type=recovery');
check(!isRecoveryUrl({ search: '?tab=orders', hash: '' }), 'URL operacional comum não é classificada como recuperação');

// Bug 1: 100%25 ou percentuais malformados NÃO devem lançar URIError
let threwPercentError = false;
try {
  const percentCheck = isUrlExpiredOrError({
    hash: '#error=access_denied&error_description=100%25',
  });
  check(percentCheck.isError && percentCheck.description === '100%', 'URL com 100%25 não lança URIError e retorna descrição decodificada');
} catch (e) {
  threwPercentError = true;
}
check(!threwPercentError, 'isUrlExpiredOrError não lança exceção ao receber 100%25');

const malformedPercentCheck = isUrlExpiredOrError({
  hash: '#error=access_denied&error_description=50%invalid%ZZ',
});
check(malformedPercentCheck.isError && malformedPercentCheck.description?.includes('50%'), 'Percentuais malformados tratados com segurança sem throw');

const expiredCheck = isUrlExpiredOrError({
  hash: '#error=access_denied&error_code=otp_expired&error_description=Email+link+is+invalid+or+has+expired',
});
check(expiredCheck.isError && expiredCheck.code === 'otp_expired', 'Erro de otp_expired no fragmento hash é detectado');
check(expiredCheck.description?.includes('Email link is invalid or has expired'), 'Descrição do erro no hash é decodificada corretamente');

const validLinkCheck = isUrlExpiredOrError({
  hash: '#access_token=jwt_valido&refresh_token=rt_valido&type=recovery',
});
check(!validLinkCheck.isError, 'Token válido sem parâmetros de erro é aceito');

// ----------------------------------------------------------------------------
// 5. Limpeza de URL e Histórico
// ----------------------------------------------------------------------------
console.log('\n--- 5. Limpeza de URL e Histórico ---');

let replacedState = false;
let replacedPath = '';
const mockHistoryWindow = {
  location: { pathname: '/', search: '?auth=recovery', hash: '#access_token=xyz' },
  history: {
    replaceState: (_state: any, _title: string, path: string) => {
      replacedState = true;
      replacedPath = path;
    },
  },
  document: { title: 'TecniFlow' },
} as any;

cleanAuthUrl(mockHistoryWindow);
check(replacedState && replacedPath === '/', 'cleanAuthUrl remove parâmetros temporários e hash da URL via replaceState');

// ----------------------------------------------------------------------------
// 6. Regras de Validação de E-mail e Senha
// ----------------------------------------------------------------------------
console.log('\n--- 6. Regras de Validação de E-mail e Senha ---');

function validateEmail(email: string): { valid: boolean; normalized: string } {
  const normalized = email.trim().toLowerCase();
  const valid = Boolean(normalized && normalized.length <= 100 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalized));
  return { valid, normalized };
}

check(validateEmail('  Usuario@Exemplo.COM.br  ').normalized === 'usuario@exemplo.com.br', 'E-mail é normalizado com trim e minúsculas');
check(!validateEmail('email_sem_arroba').valid, 'E-mail sem @ é rejeitado');
check(!validateEmail('a'.repeat(95) + '@dominio.com.br').valid, 'E-mail superior a 100 caracteres é rejeitado');
check(validateEmail('tecnico@assistencia.com').valid, 'E-mail válido é aceito');

function validatePasswordRule(pwd: string): { valid: boolean; reason?: string } {
  if (!pwd || pwd.length < 12) {
    return { valid: false, reason: 'A nova senha deve conter no mínimo 12 caracteres.' };
  }
  return { valid: true };
}

check(!validatePasswordRule('12345678901').valid, 'Senha com 11 caracteres é rejeitada');
check(validatePasswordRule('123456789012').valid, 'Senha com 12 caracteres exatos é aceita');

const passphraseWithSpaces = '  senha com espacos  ';
check(passphraseWithSpaces.length > 12 && validatePasswordRule(passphraseWithSpaces).valid, 'Espaços intencionais em passphrases são rigorosamente preservados sem trim');

// ----------------------------------------------------------------------------
// 7. Mapeamento de Mensagens de Erro em Português
// ----------------------------------------------------------------------------
console.log('\n--- 7. Mapeamento e Tradução Contextual de Erros ---');

function mapResetError(sbError: { message?: string; status?: number; code?: string }): string {
  const msg = sbError.message || '';
  const status = sbError.status;
  const code = sbError.code || '';

  if (
    code === 'email_address_not_authorized' ||
    msg.toLowerCase().includes('email_address_not_authorized') ||
    msg.toLowerCase().includes('not authorized')
  ) {
    return 'O envio de e-mails está indisponível no momento. Tente novamente mais tarde ou entre em contato com o suporte.';
  }
  if (
    status === 429 ||
    msg.toLowerCase().includes('rate limit') ||
    msg.toLowerCase().includes('too many requests') ||
    msg.toLowerCase().includes('over_email_send_rate_limit')
  ) {
    return 'Muitas tentativas em pouco tempo. Aguarde alguns minutos antes de tentar novamente.';
  }
  if (msg.toLowerCase().includes('network') || msg.toLowerCase().includes('fetch') || msg.toLowerCase().includes('failed to fetch')) {
    return 'Falha de conexão. Verifique sua internet e tente novamente.';
  }
  if (
    status === 500 ||
    msg.toLowerCase().includes('smtp') ||
    msg.toLowerCase().includes('internal server error') ||
    msg.toLowerCase().includes('error sending')
  ) {
    return 'Erro no servidor de envio de e-mails. Tente novamente mais tarde.';
  }
  return msg || 'Falha ao solicitar recuperação de senha.';
}

const unauthEmailMsg = mapResetError({ code: 'email_address_not_authorized', message: 'Email address not authorized' });
check(unauthEmailMsg === 'O envio de e-mails está indisponível no momento. Tente novamente mais tarde ou entre em contato com o suporte.', 'Código email_address_not_authorized traduzido para mensagem amigável de indisponibilidade');

const rateLimitMsg = mapResetError({ status: 429, message: 'over_email_send_rate_limit' });
check(rateLimitMsg === 'Muitas tentativas em pouco tempo. Aguarde alguns minutos antes de tentar novamente.', 'Erro 429 traduzido para aviso amigável de rate limit');

const networkMsg = mapResetError({ message: 'Failed to fetch' });
check(networkMsg === 'Falha de conexão. Verifique sua internet e tente novamente.', 'Erro de rede traduzido para mensagem amigável de conexão');

const smtpMsg = mapResetError({ status: 500, message: 'Error sending recovery email: SMTP connection failed' });
check(smtpMsg === 'Erro no servidor de envio de e-mails. Tente novamente mais tarde.', 'Erro 500 de SMTP traduzido com segurança para o usuário');

// ----------------------------------------------------------------------------
// 8. Mensagem Neutra e Proteção Anti-Enumeração
// ----------------------------------------------------------------------------
console.log('\n--- 8. Mensagem Neutra e Proteção Anti-Enumeração ---');

const neutralMessage = 'Se existir uma conta com este e-mail, você receberá as instruções de recuperação. Confira também o spam.';
check(neutralMessage.includes('Se existir uma conta') && neutralMessage.includes('spam'), 'Mensagem neutra não revela se o e-mail está previamente cadastrado');

// ============================================================================
// 9. TESTES DE COMPORTAMENTO COM REACT 19 + TEST RENDERER + AUTHPROVIDER
// ============================================================================
console.log('\n--- 9. Testes de Comportamento React 19: Precedência de Erro e signOut com Falha ---');

// Mock harness para inspecionar chamadas à API (/api/auth/me via RPC ou fetch)
let authMeCallCount = 0;
const originalRpc = supabase.rpc;
(supabase as any).rpc = async (name: string, params: any) => {
  if (name === 'tf_sync_current_user') {
    authMeCallCount++;
    return {
      data: {
        user: { id: 'user-mock-me', name: 'Usuário Inesperado', role: 'owner' },
        company: { id: 'comp-mock-1', name: 'Empresa Teste' },
      },
      error: null,
    };
  }
  if (typeof originalRpc === 'function') {
    return (originalRpc as any).call(supabase, name, params);
  }
  return { data: {}, error: null };
};

const originalFetch = globalThis.fetch;
globalThis.fetch = async (input: any, init?: any) => {
  const urlStr = String(input);
  if (urlStr.includes('/api/auth/me')) {
    authMeCallCount++;
    return new Response(
      JSON.stringify({
        user: { id: 'user-mock-me', name: 'Usuário Inesperado', role: 'owner' },
        company: { id: 'comp-mock-1', name: 'Empresa Teste' },
      }),
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    );
  }
  if (typeof originalFetch === 'function') {
    return originalFetch(input, init);
  }
  return new Response('{}', { status: 200 });
};

// Componente consumidor para inspecionar AuthContext
let capturedAuth: any = null;
const AuthInspector: React.FC = () => {
  capturedAuth = useAuth();
  return React.createElement('div', { id: 'auth-inspector' });
};

// Setup mock window environment
const originalWindow = (globalThis as any).window;

// ----------------------------------------------------------------------------
// Cenário A (Bug 2): Erro explícito de URL prevalece sobre sessão válida prévia
// ----------------------------------------------------------------------------
console.log('\n  [Cenário A: Precedência permanente de erro em /?auth=recovery#error=...]');

authMeCallCount = 0;
(globalThis as any).window = {
  location: {
    origin: 'https://app.tecniflow.com.br',
    pathname: '/',
    search: '?auth=recovery',
    hash: '#error=access_denied&error_code=otp_expired&error_description=Email+link+is+invalid+or+has+expired',
  },
  history: { replaceState: () => {} },
  document: { title: 'TecniFlow' },
};

// Mock do Supabase Auth: getSession retorna sessão prévia existente e válida
let authListenerCallback: any = null;
(supabase.auth as any).getSession = async () => ({
  data: {
    session: {
      access_token: 'valid-old-token-xyz',
      user: { id: 'old-valid-user-123', email: 'antigo@assistencia.com.br' },
    },
  },
  error: null,
});
(supabase.auth as any).getUser = async () => ({
  data: { user: { id: 'old-valid-user-123' } },
  error: null,
});
(supabase.auth as any).onAuthStateChange = (cb: any) => {
  authListenerCallback = cb;
  return { data: { subscription: { unsubscribe: () => {} } } };
};

let rendererA: any;
await act(async () => {
  rendererA = TestRenderer.create(
    React.createElement(AuthProvider, null, React.createElement(AuthInspector))
  );
});

// Aguardar ticks assíncronos
await act(async () => {
  await new Promise((r) => setTimeout(r, 50));
});

check(capturedAuth.isRecoveryMode === true, 'isRecoveryMode ativado pela URL de recuperação com erro');
check(capturedAuth.recoveryState === 'expired_or_invalid', 'recoveryState permanece expired_or_invalid apesar de getSession() retornar sessão válida');
check(capturedAuth.user === null, 'capturedAuth.user permanece nulo (zero vazamento de sessão antiga)');
check(authMeCallCount === 0, 'ZERO chamadas a /api/auth/me ao abrir link com erro explícito');

// Simular evento INITIAL_SESSION ou TOKEN_REFRESHED do Supabase Auth
await act(async () => {
  if (authListenerCallback) {
    authListenerCallback('TOKEN_REFRESHED', {
      access_token: 'novo-token-refresh',
      user: { id: 'old-valid-user-123' },
    });
  }
});

check(capturedAuth.recoveryState === 'expired_or_invalid', 'TOKEN_REFRESHED ou INITIAL_SESSION não sobrescreve o erro explícito de URL');
check(authMeCallCount === 0, 'Chamadas a /api/auth/me continuam estritamente bloqueadas');

// Tentar salvar senha no estado expired_or_invalid deve falhar
let updateUserBlocked: any = false;
await act(async () => {
  try {
    await capturedAuth.updatePassword('NovaSenha123456');
  } catch (e: any) {
    if (e.message.includes('expirada ou inválida') || e.message.includes('Abra um link de recuperação válido')) {
      updateUserBlocked = true;
    }
  }
});
check(Boolean(updateUserBlocked), 'updatePassword é estritamente bloqueado no estado expired_or_invalid');

rendererA.unmount();

// ----------------------------------------------------------------------------
// Cenário B (Bug 3): updateUser sucede, mas signOut falha ({ error: 503 })
// ----------------------------------------------------------------------------
console.log('\n  [Cenário B: Falha no signOut após updateUser não exibe dashboard nem desativa recovery]');

authMeCallCount = 0;
(globalThis as any).window = {
  location: {
    origin: 'https://app.tecniflow.com.br',
    pathname: '/',
    search: '?auth=recovery',
    hash: '#access_token=token-recovery-ok&type=recovery',
  },
  history: { replaceState: () => {} },
  document: { title: 'TecniFlow' },
};

const recoveryUserId = 'user-rec-789';
(supabase.auth as any).getSession = async () => ({
  data: {
    session: {
      access_token: 'token-recovery-ok',
      user: { id: recoveryUserId, email: 'recuperando@assistencia.com.br' },
    },
  },
  error: null,
});
(supabase.auth as any).getUser = async () => ({
  data: { user: { id: recoveryUserId } },
  error: null,
});

let updatedPasswordCalled: any = false;
(supabase.auth as any).updateUser = async (params: any) => {
  updatedPasswordCalled = true;
  return { data: { user: { id: recoveryUserId } }, error: null };
};

// Simular falha de rede retornada pelo signOut do Supabase (código 503 retornado)
let signOutCallCount = 0;
let shouldSignOutFail = true;
(supabase.auth as any).signOut = async () => {
  signOutCallCount++;
  if (shouldSignOutFail) {
    return { error: { status: 503, message: 'Network unavailable' } };
  }
  return { error: null };
};

let rendererB: any;
await act(async () => {
  rendererB = TestRenderer.create(
    React.createElement(AuthProvider, null, React.createElement(AuthInspector))
  );
});

// Aguardar verificação assíncrona
await act(async () => {
  await new Promise((r) => setTimeout(r, 50));
});

check(capturedAuth.recoveryState === 'ready', 'recoveryState atinge ready após validação de token e getUser');

// Usuário executa a troca de senha
let updatePasswordErrorCaught: any = false;
await act(async () => {
  try {
    await capturedAuth.updatePassword('MinhaNovaSenhaForte123!');
  } catch (err: any) {
    updatePasswordErrorCaught = true;
  }
});

check(Boolean(updatedPasswordCalled), 'updateUser foi chamado com sucesso com a nova senha');
check(Boolean(updatePasswordErrorCaught), 'updatePassword sinaliza erro ao usuário sobre a falha de encerramento da sessão');
check(capturedAuth.recoveryState === 'password_updated_signout_pending', 'recoveryState transita para password_updated_signout_pending');
check(capturedAuth.isRecoveryMode === true, 'isRecoveryMode permanece ATIVADO para bloquear exibição do dashboard');
check(capturedAuth.user === null, 'capturedAuth.user permanece nulo (zero vazamento de sessão de recovery)');
check(authMeCallCount === 0, 'ZERO chamadas a /api/auth/me após falha de signOut (dashboard nunca é exibido)');

// Tentar salvar senha novamente no mesmo ciclo deve ser rejeitado
let reSavingBlocked: any = false;
await act(async () => {
  try {
    await capturedAuth.updatePassword('OutraSenha123456');
  } catch (e: any) {
    if (e.message.includes('já foi alterada com sucesso') || e.message.includes('Abra um link de recuperação válido')) {
      reSavingBlocked = true;
    }
  }
});
check(Boolean(reSavingBlocked), 'Segunda tentativa de salvar senha é bloqueada enquanto encerramento da sessão estiver pendente');

// Tentativa de sair enquanto a rede ainda falha é rejeitada sem desativar a proteção
let exitResultFailed: any;
await act(async () => {
  exitResultFailed = await capturedAuth.exitRecoveryMode();
});
check(exitResultFailed.success === false, 'exitRecoveryMode retorna success=false quando signOut falha');
check(capturedAuth.isRecoveryMode === true, 'isRecoveryMode permanece ativo enquanto signOut falhar');

// Rede restabelecida: agora signOut sucede
shouldSignOutFail = false;
let exitResultSuccess: any;
await act(async () => {
  exitResultSuccess = await capturedAuth.exitRecoveryMode();
});

check(exitResultSuccess.success === true, 'exitRecoveryMode conclui com success=true após signOut bem-sucedido');
check(capturedAuth.recoveryState === 'idle', 'recoveryState retorna para idle após signOut com sucesso');
check(capturedAuth.isRecoveryMode === false, 'isRecoveryMode desativado somente após encerramento efetivo da sessão');
check(capturedAuth.user === null, 'Usuário limpo e pronto para login normal');
check(authMeCallCount === 0, 'Zero chamadas indevidas a /api/auth/me durante todo o ciclo');

rendererB.unmount();

// ----------------------------------------------------------------------------
// Cenário C: PASSWORD_RECOVERY sem sessão não ativa ready
// ----------------------------------------------------------------------------
console.log('\n  [Cenário C: PASSWORD_RECOVERY sem sessão não ativa ready]');

(globalThis as any).window = {
  location: { origin: 'https://app.tecniflow.com.br', pathname: '/', search: '', hash: '' },
  history: { replaceState: () => {} },
  document: { title: 'TecniFlow' },
};

(supabase.auth as any).getSession = async () => ({ data: { session: null }, error: null });

let rendererC: any;
await act(async () => {
  rendererC = TestRenderer.create(
    React.createElement(AuthProvider, null, React.createElement(AuthInspector))
  );
});

// Disparar evento PASSWORD_RECOVERY com session null
await act(async () => {
  if (authListenerCallback) {
    authListenerCallback('PASSWORD_RECOVERY', null);
  }
});

check(capturedAuth.recoveryState === 'expired_or_invalid', 'PASSWORD_RECOVERY sem sessão válida não vira ready');

rendererC.unmount();

// Restaurar mocks
(supabase as any).rpc = originalRpc;
globalThis.fetch = originalFetch;
(globalThis as any).window = originalWindow;

console.log('\n================================================================');
console.log(`  RESULTADO: ${passed} verificações da suíte de recuperação aprovadas!`);
console.log('================================================================\n');
