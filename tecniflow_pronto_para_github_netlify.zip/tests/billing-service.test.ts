import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { MercadoPagoService } from '../server/services/mercadoPagoService.js';

let passed = 0;
const check = (cond: boolean, label: string) => {
  assert.ok(cond, label);
  passed++;
  console.log(`  ✓ [PASS] ${label}`);
};

console.log('================================================================');
console.log('  TECNIFLOW: TESTES DO SERVIÇO MERCADO PAGO E POLÍTICA DE COBRANÇA');
console.log('================================================================\n');

// 1. Instância sem credenciais (estado padrão de segurança com cobrança desligada)
delete process.env.MERCADO_PAGO_ENABLED;
delete process.env.MERCADO_PAGO_MODE;
delete process.env.MERCADO_PAGO_ACCESS_TOKEN;
delete process.env.MERCADO_PAGO_WEBHOOK_SECRET;
delete process.env.MERCADO_PAGO_PLAN_ID;
delete process.env.MERCADO_PAGO_COLLECTOR_ID;
delete process.env.APP_URL;

const service = new MercadoPagoService();
check(!service.isConfigured(), 'Serviço detecta ausência de credenciais e flag desligada (isConfigured = false)');

// 2. Criação de checkout sem credenciais ou desabilitado retorna erro estruturado billing_not_configured
let fetchCallCount = 0;
const countingFetch = async () => {
  fetchCallCount++;
  return new Response('{}', { status: 200 });
};
const originalGlobalFetch = globalThis.fetch;
globalThis.fetch = countingFetch as any;

await assert.rejects(
  async () => service.createPreapproval({
    companyId: 'comp-1',
    ownerEmail: 'dono@teste.com',
    companyName: 'Minha Assistência',
    backUrl: 'https://tecniflow.app/#subscription'
  }),
  (err: any) => {
    check(err.code === 'billing_not_configured', 'Tentativa de checkout sem credenciais/desligado lança billing_not_configured');
    check(err.message.includes('configuração pela administração') || err.message.includes('desativada'), 'Mensagem amigável para o cliente sem vazar detalhes técnicos');
    return true;
  }
);
check(fetchCallCount === 0, 'Zero chamadas à API do Mercado Pago quando desabilitado ou incompleto');
globalThis.fetch = originalGlobalFetch;

// 3. Validação de cada parâmetro exigido
// A. Falta MERCADO_PAGO_ENABLED=true
process.env.MERCADO_PAGO_ENABLED = 'false';
process.env.MERCADO_PAGO_MODE = 'test';
process.env.MERCADO_PAGO_ACCESS_TOKEN = 'APP_USR-1234567890';
process.env.MERCADO_PAGO_WEBHOOK_SECRET = 'segredo_webhook_teste_12345';
process.env.MERCADO_PAGO_PLAN_ID = '2c938084729384729384729384729384';
process.env.MERCADO_PAGO_COLLECTOR_ID = '123456789';
process.env.APP_URL = 'https://tecniflow.app';
service.reloadConfig();
check(!service.isConfigured(), 'MERCADO_PAGO_ENABLED=false mantém serviço desabilitado');

// B. Falta MERCADO_PAGO_MODE explícito (test ou production)
process.env.MERCADO_PAGO_ENABLED = 'true';
delete process.env.MERCADO_PAGO_MODE;
service.reloadConfig();
check(!service.isConfigured(), 'Modo ausente recusa configuração (não infere via APP_USR)');

process.env.MERCADO_PAGO_MODE = 'invalid_mode';
service.reloadConfig();
check(!service.isConfigured(), 'Modo inválido recusa configuração');

// C. Falta MERCADO_PAGO_COLLECTOR_ID
process.env.MERCADO_PAGO_MODE = 'test';
delete process.env.MERCADO_PAGO_COLLECTOR_ID;
service.reloadConfig();
check(!service.isConfigured(), 'Ausência de MERCADO_PAGO_COLLECTOR_ID recusa configuração');

// D. APP_URL HTTP (não HTTPS) é rejeitada
process.env.MERCADO_PAGO_COLLECTOR_ID = '123456789';
process.env.APP_URL = 'http://tecniflow.app'; // Inseguro!
service.reloadConfig();
check(!service.isConfigured(), 'APP_URL sem protocolo HTTPS válido é rejeitada');

// E. Rejeição de planId igual ao código interno ou com placeholder
process.env.APP_URL = 'https://tecniflow.app';
process.env.MERCADO_PAGO_PLAN_ID = 'TECNIFLOW-MENSAL-4990';
service.reloadConfig();
check(!service.isConfigured(), 'PlanId igual ao código interno TECNIFLOW-MENSAL-4990 é recusado (exige ID real do MP)');

// 4. Reconhece configuração completa e válida
process.env.MERCADO_PAGO_PLAN_ID = '2c938084729384729384729384729384';
service.reloadConfig();
check(service.isConfigured(), 'Serviço reconhece credenciais completas e válidas (enabled, mode, token, secret, plan, collector, https)');

// 5. Validação de assinatura HMAC com segredo real
const dataId = 'pay_998877';
const reqId = 'req_12345';
const ts = Math.floor(Date.now() / 1000).toString();

const manifest = `id:${dataId};request-id:${reqId};ts:${ts};`;
const legitimateHash = crypto.createHmac('sha256', 'segredo_webhook_teste_12345').update(manifest).digest('hex');
const legitimateHeader = `ts=${ts},v1=${legitimateHash}`;

check(
  service.verifyWebhookSignature(legitimateHeader, reqId, dataId) === true,
  'Assinatura legítima do Mercado Pago verificada com sucesso via HMAC SHA256'
);

// 6. Assinatura forjada ou adulterada é rejeitada
const forgedHeader = `ts=${ts},v1=deadbeef1234567890abcdefdeadbeef1234567890abcdefdeadbeef1234567890ab`;
check(
  service.verifyWebhookSignature(forgedHeader, reqId, dataId) === false,
  'Assinatura forjada é rejeitada com segurança (retorna false)'
);

// 7. Replay attack: timestamp com mais de 10 minutos no passado é rejeitado
const oldTs = (Math.floor(Date.now() / 1000) - 700).toString(); // 11 minutos atrás
const oldManifest = `id:${dataId};request-id:${reqId};ts:${oldTs};`;
const oldHash = crypto.createHmac('sha256', 'segredo_webhook_teste_12345').update(oldManifest).digest('hex');
const oldHeader = `ts=${oldTs},v1=${oldHash}`;
check(
  service.verifyWebhookSignature(oldHeader, reqId, dataId) === false,
  'Replay attack evitado: evento com timestamp defasado (> 10min) é rejeitado'
);

// 8. Teste de consulta e validação de pagamento na API com mock do fetch
const originalFetch = globalThis.fetch;

globalThis.fetch = async (url: any) => {
  const urlStr = url.toString();

  // Cenário de validação de plano no MP
  if (urlStr.includes('/preapproval_plan/plan_legit')) {
    return new Response(JSON.stringify({
      id: 'plan_legit',
      collector_id: 123456789,
      auto_recurring: {
        frequency: 1,
        frequency_type: 'months',
        transaction_amount: 49.9,
        currency_id: 'BRL',
        free_trial: null,
      }
    }), { status: 200, headers: { 'Content-Type': 'application/json' } });
  }

  if (urlStr.includes('/preapproval_plan/plan_with_trial')) {
    return new Response(JSON.stringify({
      id: 'plan_with_trial',
      auto_recurring: {
        frequency: 1,
        frequency_type: 'months',
        transaction_amount: 49.9,
        currency_id: 'BRL',
        free_trial: { frequency: 7, frequency_type: 'days' }, // Não permitido no MP
      }
    }), { status: 200, headers: { 'Content-Type': 'application/json' } });
  }

  // Pagamento legítimo de R$ 49,90 (4990 centavos) com external_reference vinculada
  if (urlStr.includes('/v1/payments/pay_legit')) {
    return new Response(JSON.stringify({
      id: 12345678,
      status: 'approved',
      transaction_amount: 49.90,
      currency_id: 'BRL',
      collector_id: 123456789,
      external_reference: 'company-uuid-1234',
      date_approved: '2026-10-29T12:00:00Z',
    }), { status: 200, headers: { 'Content-Type': 'application/json' } });
  }

  // Fraude com recebedor divergente
  if (urlStr.includes('/v1/payments/pay_wrong_collector')) {
    return new Response(JSON.stringify({
      id: 777,
      status: 'approved',
      transaction_amount: 49.90,
      currency_id: 'BRL',
      collector_id: 999999999,
      external_reference: 'company-uuid-1234',
    }), { status: 200, headers: { 'Content-Type': 'application/json' } });
  }

  // Fraude com valor diferente (R$ 10,00)
  if (urlStr.includes('/v1/payments/pay_underpaid')) {
    return new Response(JSON.stringify({
      id: 999,
      status: 'approved',
      transaction_amount: 10.00,
      currency_id: 'BRL',
      collector_id: 123456789,
      external_reference: 'company-uuid-1234',
    }), { status: 200, headers: { 'Content-Type': 'application/json' } });
  }

  // Fraude em moeda estrangeira (USD)
  if (urlStr.includes('/v1/payments/pay_usd')) {
    return new Response(JSON.stringify({
      id: 888,
      status: 'approved',
      transaction_amount: 49.90,
      currency_id: 'USD',
      collector_id: 123456789,
      external_reference: 'company-uuid-1234',
    }), { status: 200, headers: { 'Content-Type': 'application/json' } });
  }

  return new Response('Not Found', { status: 404 });
};

// 9. Validação do plano do Mercado Pago
check(
  await service.validatePlanOnApi('plan_legit') === true,
  'Validação do plano MP: aceita plano R$ 49,90 mensal BRL sem free trial'
);
check(
  await service.validatePlanOnApi('plan_with_trial') === false,
  'Validação do plano MP: rejeita plano que possua free trial configurado no Mercado Pago'
);

// 10. Pagamento legítimo verificado
const verified = await service.fetchAndVerifyPayment('pay_legit');
check(verified.status === 'approved', 'Pagamento legítimo verificado com status approved');
check(verified.amountCents === 4990, 'Valor verificado exatamente como 4990 centavos (R$ 49,90)');
check(verified.companyId === 'company-uuid-1234', 'Vínculo do pagamento conferido com o company_id');

// Fraude de recebedor divergente
await assert.rejects(
  async () => service.fetchAndVerifyPayment('pay_wrong_collector'),
  /Conta recebedora do pagamento divergente/,
  'Pagamento recebido em conta divergente da conta oficial é rejeitado'
);

// Fraude de valor
await assert.rejects(
  async () => service.fetchAndVerifyPayment('pay_underpaid'),
  /não corresponde ao plano canônico/,
  'Pagamento com valor abaixo de 4990 centavos é rejeitado'
);

// Fraude de moeda
await assert.rejects(
  async () => service.fetchAndVerifyPayment('pay_usd'),
  /Moeda USD não autorizada/,
  'Pagamento em moeda não-BRL é rejeitado'
);

// Restaura fetch
globalThis.fetch = originalFetch;

console.log(`\n================================================================`);
console.log(`  RESULTADO: ${passed} verificações do serviço Mercado Pago aprovadas!`);
console.log('================================================================\n');
