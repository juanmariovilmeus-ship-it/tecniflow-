import { PGlite } from '@electric-sql/pglite';
import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const db = new PGlite();

console.log('Testing supabase/004_test_verification_rollback.sql execution in realistic shared-database environment...');

// 1. Setup base mock environment with auth, anon/authenticated roles, and shared public.profiles
await db.exec(`
  CREATE ROLE anon;
  CREATE ROLE authenticated;
  CREATE SCHEMA IF NOT EXISTS auth;
  
  CREATE TABLE IF NOT EXISTS auth.users(
    id uuid PRIMARY KEY,
    email text,
    raw_user_meta_data jsonb
  );

  CREATE OR REPLACE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $$
    SELECT nullif(current_setting('request.jwt.claim.sub', true), '')::uuid
  $$;

  -- Tabela preexistente do projeto compartilhado (controle de gastos)
  CREATE TABLE IF NOT EXISTS public.profiles (
    id uuid PRIMARY KEY,
    email text,
    created_at timestamp with time zone DEFAULT now()
  );

  -- Trigger real do Supabase compartilhado que insere em public.profiles
  CREATE OR REPLACE FUNCTION public.handle_new_user()
  RETURNS trigger
  LANGUAGE plpgsql
  SECURITY DEFINER
  AS $$
  BEGIN
    INSERT INTO public.profiles (id, email)
    VALUES (NEW.id, NEW.email);
    RETURN NEW;
  END;
  $$;

  DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
  CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
`);

// 2. Inserir dados pré-existentes simulando usuários do controle de gastos
const preexistingUserId = '11111111-1111-1111-1111-111111111111';
await db.exec(`
  INSERT INTO auth.users (id, email, raw_user_meta_data)
  VALUES ('${preexistingUserId}', 'dono_gastos@empresa.com', '{"full_name": "Usuário Controle de Gastos"}');
`);

// Conferir que o trigger inseriu o profile preexistente
const initialProfiles = await db.query('SELECT count(*) as c FROM public.profiles');
assert.equal(Number(initialProfiles.rows[0].c), 1, 'Profile pré-existente deve existir no banco antes do teste');

// 3. Carregar schemas TecniFlow e migration 003
await db.exec(readFileSync('supabase/tecniflow_schema.sql', 'utf8'));
await db.exec(readFileSync('supabase/003_operations_data_api.sql', 'utf8'));

// 4. Garantir que as roles anon e authenticated não possuem privilégios no schema privado tecniflow
await db.exec(`
  REVOKE ALL ON SCHEMA tecniflow FROM anon, authenticated, public;
  REVOKE ALL ON ALL TABLES IN SCHEMA tecniflow FROM anon, authenticated, public;
  REVOKE ALL ON ALL SEQUENCES IN SCHEMA tecniflow FROM anon, authenticated, public;
`);

// 5. Contagens pré-auditoria
const initialAuthUsers = await db.query('SELECT count(*) as c FROM auth.users');
assert.equal(Number(initialAuthUsers.rows[0].c), 1);

const initialTecniCompanies = await db.query('SELECT count(*) as c FROM tecniflow.companies');
assert.equal(Number(initialTecniCompanies.rows[0].c), 0);

// 6. Executar o script exato 004_test_verification_rollback.sql
console.log('Executando supabase/004_test_verification_rollback.sql...');
const script004 = readFileSync('supabase/004_test_verification_rollback.sql', 'utf8');
await db.exec(script004);

// 7. Verificações POST-ROLLBACK: garantia formal de zero persistência e preservação integral
console.log('Validando estado pós-ROLLBACK...');

const postProfiles = await db.query('SELECT count(*) as c, min(email) as email FROM public.profiles');
assert.equal(Number(postProfiles.rows[0].c), 1, 'Tabela public.profiles deve retornar exatamente ao count inicial (1)');
assert.equal(postProfiles.rows[0].email, 'dono_gastos@empresa.com', 'Registro original de public.profiles inalterado');

const postAuthUsers = await db.query('SELECT count(*) as c FROM auth.users');
assert.equal(Number(postAuthUsers.rows[0].c), 1, 'auth.users deve conter apenas o usuário pré-existente (sem usuários de teste)');

const postCompanies = await db.query('SELECT count(*) as c FROM tecniflow.companies');
assert.equal(Number(postCompanies.rows[0].c), 0, 'Zero empresas de auditoria persistidas em tecniflow.companies');

const postUsers = await db.query('SELECT count(*) as c FROM tecniflow.users');
assert.equal(Number(postUsers.rows[0].c), 0, 'Zero usuários persistidos em tecniflow.users');

const postClients = await db.query('SELECT count(*) as c FROM tecniflow.clients');
assert.equal(Number(postClients.rows[0].c), 0, 'Zero clientes persistidos em tecniflow.clients');

const postOrders = await db.query('SELECT count(*) as c FROM tecniflow.orders');
assert.equal(Number(postOrders.rows[0].c), 0, 'Zero ordens persistidas em tecniflow.orders');

console.log('✅ SUCESSO: 004_test_verification_rollback.sql executou todas as 11 baterias de testes com louvor!');
console.log('✅ Preservação comprovada: public.profiles e auth.users 100% restaurados pelo ROLLBACK!');
