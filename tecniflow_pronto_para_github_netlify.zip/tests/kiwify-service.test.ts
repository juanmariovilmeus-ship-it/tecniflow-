import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { KiwifyService, parseKiwifyDate } from '../server/services/kiwifyService.js';
import {
  verifyKiwifyWebhookSignature,
  validateKiwifyGrantPayload,
  parseKiwifyDate as parseKiwifyDateShared,
} from '../supabase/functions/_shared/kiwifyCommon.js';

let passed = 0;
const check = (cond: boolean, label: string) => {
  assert.ok(cond, label);
  passed++;
  console.log(`  ✓ [PASS] ${label}`);
};

console.log('================================================================');
console.log('  TECNIFLOW: TESTES DO SERVIÇO KIWIFY E POLÍTICA DE COBRANÇA');
console.log('================================================================\n');

// 1. Estado inicial seguro: sem credenciais (cobrança desligada)
delete process.env.KIWIFY_ENABLED;
delete process.env.KIWIFY_WEBHOOK_SECRET;
delete process.env.KIWIFY_CHECKOUT_URL;
delete process.env.KIWIFY_ALLOWED_PRODUCT_IDS;
delete process.env.KIWIFY_PLAN_ID;

const service = new KiwifyService();
check(!service.isConfigured(), 'Serviço detecta ausência de configuração e flag desligada (isConfigured = false)');

// 2. Tentativa de checkout sem configuração lança billing_not_configured
assert.throws(
  () => service.buildCheckoutUrl('token_teste_123'),
  (err: any) => {
    check(err.code === 'billing_not_configured', 'Tentativa de checkout desabilitado lança billing_not_configured');
    check(err.message.includes('fase de configuração'), 'Mensagem amigável para o cliente sem detalhes técnicos');
    return true;
  }
);

// 3. Validação rigorosa de cada parâmetro exigido
// A. KIWIFY_ENABLED='false'
process.env.KIWIFY_ENABLED = 'false';
process.env.KIWIFY_CHECKOUT_URL = 'https://pay.kiwify.com.br/Tao519J';
process.env.KIWIFY_WEBHOOK_SECRET = 'segredo_webhook_kiwify_12345';
process.env.KIWIFY_ALLOWED_PRODUCT_IDS = 'fe3f16c0-d5f4-11f1-bd40-b570d8dc84fc';
process.env.KIWIFY_PLAN_ID = 'plan_mensal_4990';
service.reloadConfig();
check(!service.isConfigured(), 'KIWIFY_ENABLED=false mantém serviço desligado');

// B. URL insegura (HTTP ou fora do host pay.kiwify.com.br) é rejeitada
process.env.KIWIFY_ENABLED = 'true';
process.env.KIWIFY_CHECKOUT_URL = 'http://pay.kiwify.com.br/Tao519J'; // Não HTTPS
service.reloadConfig();
check(!service.isConfigured(), 'URL não HTTPS é rejeitada');

process.env.KIWIFY_CHECKOUT_URL = 'https://site-falso.com/checkout'; // Host não autorizado
service.reloadConfig();
check(!service.isConfigured(), 'Host fora de pay.kiwify.com.br é rejeitado');

// C. Lista de produtos vazia é rejeitada
process.env.KIWIFY_CHECKOUT_URL = 'https://pay.kiwify.com.br/Tao519J';
process.env.KIWIFY_ALLOWED_PRODUCT_IDS = '';
service.reloadConfig();
check(!service.isConfigured(), 'Lista de produtos autorizados vazia recusa configuração');

// D. Segredo curto ou com placeholder é rejeitado
process.env.KIWIFY_ALLOWED_PRODUCT_IDS = 'fe3f16c0-d5f4-11f1-bd40-b570d8dc84fc';
process.env.KIWIFY_WEBHOOK_SECRET = 'abc...';
service.reloadConfig();
check(!service.isConfigured(), 'Segredo com placeholder reticências é recusado');

// E. KIWIFY_PLAN_ID com placeholder reticências é recusado
process.env.KIWIFY_WEBHOOK_SECRET = 'segredo_webhook_kiwify_12345';
process.env.KIWIFY_PLAN_ID = 'SEU_PLAN_ID_UUID_AQUI...';
service.reloadConfig();
check(!service.isConfigured(), 'KIWIFY_PLAN_ID com placeholder é recusado (fail-closed)');

// 4. Reconhece configuração completa e válida
process.env.KIWIFY_PLAN_ID = 'plan_mensal_4990';
service.reloadConfig();
check(service.isConfigured(), 'Serviço reconhece configuração completa e válida da Kiwify');

// 5. Geração de checkout intent com sck opaco
const opaqueToken = service.generateOpaqueToken();
check(opaqueToken.length === 64, 'Token opaco possui 256 bits de entropia (64 hex chars)');
const intent = service.buildCheckoutUrl(opaqueToken);
check(intent.checkoutUrl.startsWith('https://pay.kiwify.com.br/Tao519J?sck=' + opaqueToken), 'URL de checkout contém exclusivamente o token em sck');
check(!intent.checkoutUrl.includes('email=') && !intent.checkoutUrl.includes('company_id='), 'URL não expõe e-mail, CPF, nome ou company_id');

// 6. Validação criptográfica de assinatura HMAC-SHA1 calculada sobre os bytes brutos UTF-8 do corpo
// A. Vetor oficial público independente (docs.kiwify.com.br/api-reference/webhooks/receiving)
const officialVectorSecret = 'kiwify-token-de-teste';
const officialVectorBody = '{"order_id":"9b1c2d3e-0000-4000-8000-000000000001","order_status":"paid","webhook_event_type":"order_approved"}';
const officialVectorSig = 'bf18f352a4f981b91dfa3f6d8742a81080ab8c86';

const vectorResult = await verifyKiwifyWebhookSignature(officialVectorBody, officialVectorSig, officialVectorSecret);
check(vectorResult.valid === true, 'Vetor oficial Kiwify é aceito com sucesso pelo verificador HMAC');

// B. Payload formatado com espaços e quebras de linha assinado sobre seus bytes brutos
const formattedJsonPayload = `{\n  "order_id": "kw_ord_100",\n  "order_status": "paid",\n  "Commissions": {\n    "charge_amount": 4990,\n    "currency": "BRL"\n  }\n}`;
const correctRawSignature = crypto
  .createHmac('sha1', 'segredo_webhook_kiwify_12345')
  .update(Buffer.from(formattedJsonPayload, 'utf8'))
  .digest('hex');

check(
  service.verifyWebhookSignature(correctRawSignature, formattedJsonPayload) === true,
  'Payload formatado assinado sobre os bytes UTF-8 brutos é verificado com sucesso'
);

// C. REJEITA assinatura feita reserializando (minified) quando os bytes recebidos diferem (sem fallback permissivo)
const minifiedSignature = crypto
  .createHmac('sha1', 'segredo_webhook_kiwify_12345')
  .update(JSON.stringify(JSON.parse(formattedJsonPayload)), 'utf8')
  .digest('hex');

check(
  service.verifyWebhookSignature(minifiedSignature, formattedJsonPayload) === false,
  'Assinatura de JSON minificado sobre corpo formatado é REJEITADA (sem fallback permissivo)'
);

// D. Assinatura com segredo incorreto falha
const wrongSecretSignature = crypto
  .createHmac('sha1', 'segredo_completamente_errado')
  .update(Buffer.from(formattedJsonPayload, 'utf8'))
  .digest('hex');
check(
  service.verifyWebhookSignature(wrongSecretSignature, formattedJsonPayload) === false,
  'Assinatura com segredo incorreto é rejeitada'
);

// E. Payload adulterado (ex: charge_amount alterado para 1000) falha
const tamperedPayload = formattedJsonPayload.replace('4990', '1000');
check(
  service.verifyWebhookSignature(correctRawSignature, tamperedPayload) === false,
  'Payload adulterado é rejeitado'
);

// F. Assinatura ausente ou vazia
check(service.verifyWebhookSignature(undefined, formattedJsonPayload) === false, 'Assinatura ausente é rejeitada');
check(service.verifyWebhookSignature('', formattedJsonPayload) === false, 'Assinatura vazia é rejeitada');
check(service.verifyWebhookSignature('curta', formattedJsonPayload) === false, 'Assinatura com menos de 40 chars hex é rejeitada');

// 7. Parsing determinístico de datas e formatos reais Kiwify
// A. Formato real Kiwify sem segundos: "YYYY-MM-DD HH:mm"
const dateMinutesOnly = '2026-11-01 10:30';
const parsedMin = parseKiwifyDate(dateMinutesOnly);
check(parsedMin !== null, 'Data no formato real oficial YYYY-MM-DD HH:mm (sem segundos) é aceita');
check(parsedMin?.toISOString() === '2026-11-01T13:30:00.000Z', 'Data YYYY-MM-DD HH:mm convertida determinística para UTC assumindo America/Sao_Paulo (-03:00)');

// B. Formato com segundos: "YYYY-MM-DD HH:mm:ss"
const dateSec = '2026-11-01 10:30:45';
const parsedSec = parseKiwifyDate(dateSec);
check(parsedSec?.toISOString() === '2026-11-01T13:30:45.000Z', 'Data com segundos convertida determinística com fuso -03:00');

// C. Formato ISO com Z
const dateIsoZ = '2026-11-01T10:30:00Z';
const parsedIsoZ = parseKiwifyDate(dateIsoZ);
check(parsedIsoZ?.toISOString() === '2026-11-01T10:30:00.000Z', 'Data ISO com Z preservada exatamente');

// D. Rejeição de datas inválidas ou impossíveis
check(parseKiwifyDate('2026-02-31 10:00') === null, 'Data impossível (31 de fevereiro) rejeitada');
check(parseKiwifyDate('2026-04-31 10:00') === null, 'Data impossível (31 de abril) rejeitada');
check(parseKiwifyDate('2026-13-01 10:00') === null, 'Mês impossível (13) rejeitado');
check(parseKiwifyDate('data_invalida') === null, 'String não-data rejeitada');

// E. Independência do fuso da máquina
const originalTZ = process.env.TZ;
try {
  process.env.TZ = 'UTC';
  const dUtc = parseKiwifyDate('2026-11-01 10:30')?.toISOString();
  process.env.TZ = 'America/Sao_Paulo';
  const dSp = parseKiwifyDate('2026-11-01 10:30')?.toISOString();
  process.env.TZ = 'Asia/Tokyo';
  const dTokyo = parseKiwifyDate('2026-11-01 10:30')?.toISOString();
  check(dUtc === dSp && dSp === dTokyo && dUtc === '2026-11-01T13:30:00.000Z', 'Parser de data produz resultado 100% idêntico em UTC, America/Sao_Paulo e Asia/Tokyo');
} finally {
  if (originalTZ) process.env.TZ = originalTZ;
  else delete process.env.TZ;
}

// 8. Validação e extração de payload de concessão de acesso (GRANT) com política FAIL-CLOSED
const validApprovedPayload = {
  webhook_event_type: 'order_approved',
  order_id: 'kw_ord_001',
  order_status: 'paid',
  approved_date: '2026-11-01 12:00',
  Product: { product_id: 'fe3f16c0-d5f4-11f1-bd40-b570d8dc84fc', product_name: 'TecniFlow Mensal' },
  Subscription: {
    id: 'kw_sub_001',
    start_date: '2026-11-01 12:00',
    next_payment: '2026-12-01 12:00',
    status: 'active',
    plan: { id: 'plan_mensal_4990', frequency: 'monthly' },
    customer_access: { access_until: '2026-12-01 12:00' }
  },
  subscription_id: 'kw_sub_001',
  Commissions: { charge_amount: 4990, currency: 'BRL' },
  TrackingParameters: { sck: opaqueToken }
};

const rawValid = JSON.stringify(validApprovedPayload);
const extracted = service.validateAndExtractPayload(validApprovedPayload, rawValid);

check(extracted.eventType === 'order_approved', 'Tipo de evento extraído corretamente');
check(extracted.orderId === 'kw_ord_001', 'ID do pedido extraído corretamente');
check(extracted.subscriptionId === 'kw_sub_001', 'ID da assinatura extraído corretamente');
check(extracted.amountCents === 4990, 'Valor de 4990 centavos conferido');
check(extracted.currency === 'BRL', 'Moeda BRL conferida');
check(extracted.sck === opaqueToken, 'Token sck do intent extraído');

// 9. Casos Negativos de Concessão de Acesso (GRANT) - FAIL-CLOSED:
// A. charge_amount ponto flutuante (4990.50) ou não inteiro
assert.throws(
  () => service.validateAndExtractPayload({ ...validApprovedPayload, Commissions: { charge_amount: 4990.5, currency: 'BRL' } }, rawValid),
  /diverge do (plano )?canônico/,
  'charge_amount com casas decimais (não inteiro) é rejeitado'
);

// B. charge_amount string ("4990")
assert.throws(
  () => service.validateAndExtractPayload({ ...validApprovedPayload, Commissions: { charge_amount: "4990", currency: 'BRL' } }, rawValid),
  /diverge do (plano )?canônico/,
  'charge_amount como string é rejeitado'
);

// C. Moeda ausente ou divergente
assert.throws(
  () => service.validateAndExtractPayload({ ...validApprovedPayload, Commissions: { charge_amount: 4990, currency: 'USD' } }, rawValid),
  /Moeda .* diverge do canônico/,
  'Moeda diferente de BRL é rejeitada'
);

// D. Produto não permitido
assert.throws(
  () => service.validateAndExtractPayload({ ...validApprovedPayload, Product: { product_id: 'outro_produto_nao_autorizado' } }, rawValid),
  /não autorizado/,
  'Produto não autorizado é rejeitado'
);

// E. Plan ID divergente do configurado
assert.throws(
  () => service.validateAndExtractPayload({
    ...validApprovedPayload,
    Subscription: { ...validApprovedPayload.Subscription, plan: { id: 'plano_errado_uuid', frequency: 'monthly' } }
  }, rawValid),
  /diverge do plano/,
  'Plan ID divergente de KIWIFY_PLAN_ID é sumariamente rejeitado'
);

// F. Frequência divergente de 'monthly'
assert.throws(
  () => service.validateAndExtractPayload({
    ...validApprovedPayload,
    Subscription: { ...validApprovedPayload.Subscription, plan: { id: 'plan_mensal_4990', frequency: 'quarterly' } }
  }, rawValid),
  /Frequência .* diverge/,
  'Frequência não-mensal é rejeitada'
);

// G. Inconsistência entre subscription_id e Subscription.id
assert.throws(
  () => service.validateAndExtractPayload({
    ...validApprovedPayload,
    subscription_id: 'kw_sub_A',
    Subscription: { ...validApprovedPayload.Subscription, id: 'kw_sub_B' }
  }, rawValid),
  /inconsistente/i,
  'Inconsistência entre subscription_id do root e do objeto é rejeitada'
);

// H. approved_date ausente
assert.throws(
  () => service.validateAndExtractPayload({
    ...validApprovedPayload,
    approved_date: null
  }, rawValid),
  /Data de aprovação/i,
  'approved_date ausente em evento pago é rejeitado'
);

// I. Duração de ciclo acima do limite mensal de 35 dias (ex: 90 dias)
assert.throws(
  () => service.validateAndExtractPayload({
    ...validApprovedPayload,
    Subscription: {
      ...validApprovedPayload.Subscription,
      next_payment: '2027-02-10 12:00',
      customer_access: { access_until: '2027-02-10 12:00' } // > 90 dias
    }
  }, rawValid),
  /fora dos limites mensais esperados/,
  'Ciclo com duração acima de 35 dias é rejeitado'
);

// 10. Teste do módulo compartilhado WebCrypto/Deno (kiwifyCommon.ts)
const sharedSigResult = await verifyKiwifyWebhookSignature(
  formattedJsonPayload,
  correctRawSignature,
  'segredo_webhook_kiwify_12345'
);
check(sharedSigResult.valid === true, 'Módulo compartilhado kiwifyCommon valida assinatura oficial HMAC-SHA1 sobre bytes brutos');

const sharedGrantResult = validateKiwifyGrantPayload(validApprovedPayload, {
  enabled: true,
  checkoutUrl: 'https://pay.kiwify.com.br/Tao519J',
  webhookSecret: 'segredo_webhook_kiwify_12345',
  allowedProductIds: ['fe3f16c0-d5f4-11f1-bd40-b570d8dc84fc'],
  planId: 'plan_mensal_4990',
});
check(sharedGrantResult.valid === true, 'Módulo compartilhado kiwifyCommon valida contrato GRANT fail-closed');

console.log(`\n================================================================`);
console.log(`  RESULTADO: ${passed} verificações do serviço Kiwify aprovadas com sucesso!`);
console.log('================================================================\n');
