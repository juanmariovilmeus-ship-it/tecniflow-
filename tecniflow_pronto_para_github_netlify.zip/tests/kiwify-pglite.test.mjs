import { PGlite } from '@electric-sql/pglite';
import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const db = new PGlite();
let passed = 0;
const check = (condition, label) => {
  assert.ok(condition, label);
  passed++;
  console.log(`  ✓ [PASS] ${label}`);
};

console.log('================================================================');
console.log('  TECNIFLOW: TESTES ISOLADOS KIWIFY BILLING & TRANSAÇÕES (PGLITE)');
console.log('================================================================\n');

// 1. Setup mock Supabase environment
await db.exec(`
  CREATE ROLE anon;
  CREATE ROLE authenticated;
  CREATE ROLE service_role;
  CREATE SCHEMA IF NOT EXISTS auth;
  CREATE TABLE IF NOT EXISTS auth.users(
    id uuid PRIMARY KEY,
    email text,
    raw_user_meta_data jsonb
  );
  CREATE OR REPLACE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $$
    SELECT nullif(current_setting('request.jwt.claim.sub', true), '')::uuid
  $$;

  CREATE TABLE IF NOT EXISTS public.profiles (
    id uuid PRIMARY KEY,
    email text,
    created_at timestamp with time zone DEFAULT now()
  );
`);

// 2. Carregar schemas e migrações existentes
await db.exec(readFileSync('supabase/tecniflow_schema.sql', 'utf8'));
await db.exec(readFileSync('supabase/003_operations_data_api.sql', 'utf8'));
await db.exec(readFileSync('supabase/005_company_logo.sql', 'utf8'));
await db.exec(readFileSync('supabase/006_billing_trial.sql', 'utf8'));

// 3. Executar e validar idempotência da nova migração 008_kiwify_billing.sql
await db.exec(readFileSync('supabase/008_kiwify_billing.sql', 'utf8'));
await db.exec(readFileSync('supabase/008_kiwify_billing.sql', 'utf8'));
check(true, '008_kiwify_billing.sql parseia e reexecuta com 100% de idempotência');

const scalar = async (sql, args = []) => Object.values((await db.query(sql, args)).rows[0])[0];

// 4. Verificação de privilégios e RLS
check(
  Boolean(await scalar("SELECT relrowsecurity FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='tecniflow' AND c.relname='billing_intents'")),
  'RLS habilitado na tabela privada tecniflow.billing_intents'
);
check(
  Boolean(await scalar("SELECT relrowsecurity FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='tecniflow' AND c.relname='company_kiwify_subscriptions'")),
  'RLS habilitado na tabela privada tecniflow.company_kiwify_subscriptions'
);
check(
  !await scalar("SELECT has_table_privilege('anon', 'tecniflow.billing_intents', 'SELECT')"),
  'anon não tem SELECT em billing_intents'
);
check(
  !await scalar("SELECT has_table_privilege('authenticated', 'tecniflow.billing_intents', 'SELECT')"),
  'authenticated não tem SELECT em billing_intents'
);
check(
  !await scalar("SELECT has_table_privilege('anon', 'tecniflow.company_kiwify_subscriptions', 'SELECT')"),
  'anon não tem SELECT em company_kiwify_subscriptions'
);
check(
  !await scalar("SELECT has_table_privilege('authenticated', 'tecniflow.company_kiwify_subscriptions', 'SELECT')"),
  'authenticated não tem SELECT em company_kiwify_subscriptions'
);
check(
  !await scalar("SELECT has_function_privilege('anon', 'public.tf_process_kiwify_payment(varchar,varchar,varchar,varchar,varchar,varchar,integer,varchar,varchar,timestamptz,timestamptz,timestamptz,varchar,varchar,timestamptz)', 'EXECUTE')"),
  'anon proibido de executar tf_process_kiwify_payment'
);
check(
  !await scalar("SELECT has_function_privilege('authenticated', 'public.tf_process_kiwify_payment(varchar,varchar,varchar,varchar,varchar,varchar,integer,varchar,varchar,timestamptz,timestamptz,timestamptz,varchar,varchar,timestamptz)', 'EXECUTE')"),
  'authenticated proibido de executar tf_process_kiwify_payment'
);
check(
  await scalar("SELECT has_function_privilege('service_role', 'public.tf_process_kiwify_payment(varchar,varchar,varchar,varchar,varchar,varchar,integer,varchar,varchar,timestamptz,timestamptz,timestamptz,varchar,varchar,timestamptz)', 'EXECUTE')"),
  'service_role possui EXECUTE em tf_process_kiwify_payment'
);

// Contar tabelas antes do teste transacional
const intentsBefore = Number(await scalar("SELECT count(*) FROM tecniflow.billing_intents"));
const subsBefore = Number(await scalar("SELECT count(*) FROM tecniflow.company_subscriptions"));
const paymentsBefore = Number(await scalar("SELECT count(*) FROM tecniflow.billing_payments"));
const kiwifySubsBefore = Number(await scalar("SELECT count(*) FROM tecniflow.company_kiwify_subscriptions"));

// 5. Teste real com SET LOCAL ROLE de segurança
await db.exec(`
BEGIN;
  SET LOCAL ROLE anon;
  DO $$
  BEGIN
    PERFORM public.tf_process_kiwify_payment('order_approved', '1', '1', 'paid', 'p', 'p', 4990, 'BRL', 'sck', now(), now(), now(), '1', 'h');
    RAISE EXCEPTION 'anon não deveria conseguir executar tf_process_kiwify_payment';
  EXCEPTION WHEN insufficient_privilege THEN
    NULL;
  END;
  $$;
ROLLBACK;
`);
check(true, 'SET LOCAL ROLE anon bloqueado com insufficient_privilege');

await db.exec(`
BEGIN;
  SET LOCAL ROLE authenticated;
  DO $$
  BEGIN
    PERFORM public.tf_process_kiwify_payment('order_approved', '1', '1', 'paid', 'p', 'p', 4990, 'BRL', 'sck', now(), now(), now(), '1', 'h');
    RAISE EXCEPTION 'authenticated não deveria conseguir executar tf_process_kiwify_payment';
  EXCEPTION WHEN insufficient_privilege THEN
    NULL;
  END;
  $$;
ROLLBACK;
`);
check(true, 'SET LOCAL ROLE authenticated bloqueado com insufficient_privilege');

// 6. Bloco de auditoria transacional com rollback
try {
  await db.exec(`
BEGIN;

DO $kiwify_audit$
DECLARE
  v_auth_a uuid := gen_random_uuid();
  v_auth_b uuid := gen_random_uuid();
  v_sync_a jsonb;
  v_sync_b jsonb;
  v_comp_a varchar(36);
  v_comp_b varchar(36);
  v_token_a varchar(64);
  v_token_b varchar(64);
  v_token_pix varchar(64);
  v_token_late varchar(64);
  v_token_exp_ok varchar(64);
  v_token_exp_fail varchar(64);
  v_intent_res jsonb;
  v_res jsonb;
  v_sub record;
  v_failed boolean;
  v_sqlstate text;
  v_pay record;
BEGIN
  -- A. Provisionar Empresa A e Empresa B
  INSERT INTO auth.users (id, email, raw_user_meta_data)
  VALUES 
    (v_auth_a, 'alfa_' || v_auth_a || '@teste.invalid', '{"company_name": "Assistência Alfa", "owner_name": "Carlos Alfa"}'::jsonb),
    (v_auth_b, 'beta_' || v_auth_b || '@teste.invalid', '{"company_name": "Assistência Beta", "owner_name": "Bruno Beta"}'::jsonb);

  PERFORM set_config('request.jwt.claim.sub', v_auth_a::text, true);
  v_sync_a := public.tf_sync_current_user();
  v_comp_a := v_sync_a->'company'->>'id';

  PERFORM set_config('request.jwt.claim.sub', v_auth_b::text, true);
  v_sync_b := public.tf_sync_current_user();
  v_comp_b := v_sync_b->'company'->>'id';

  -- B. Geração Segura de Intent Criptográfico pelo Servidor/Banco (>= 128 bits / 256 bits)
  PERFORM set_config('request.jwt.claim.sub', v_auth_a::text, true);
  v_intent_res := public.tf_create_billing_intent('prod_kw_01', 'plan_kw_mensal');
  v_token_a := v_intent_res->>'token';

  IF length(v_token_a) <> 64 THEN
    RAISE EXCEPTION 'Token criptográfico gerado não possui 256 bits (64 hex chars)!';
  END IF;

  v_intent_res := public.tf_create_billing_intent('prod_kw_01', 'plan_kw_mensal');
  v_token_pix := v_intent_res->>'token';

  -- Tentativa de criar intent por usuário sem papel de owner é bloqueada
  UPDATE tecniflow.users SET role = 'collaborator' WHERE auth_user_id = v_auth_a;
  v_failed := false;
  BEGIN
    PERFORM public.tf_create_billing_intent('prod_kw_01', 'plan_kw_mensal');
  EXCEPTION WHEN OTHERS THEN
    v_failed := true;
  END;
  IF NOT v_failed THEN
    RAISE EXCEPTION 'Colaborador sem papel de owner pôde criar intent de checkout!';
  END IF;
  UPDATE tecniflow.users SET role = 'owner' WHERE auth_user_id = v_auth_a;

  -- C. Evento informativo (pix_created / waiting_payment): NÃO consome intent e NÃO concede acesso
  v_res := tecniflow.process_kiwify_payment(
    'pix_created', 'ord_pix_01', 'sub_pix_01', 'waiting_payment', 'prod_kw_01', 'plan_kw_mensal',
    4990, 'BRL', v_token_pix, NULL, NULL, now(), 'evt_pix_01', 'hash_pix'
  );
  IF (v_res->>'granted')::boolean IS NOT FALSE THEN
    RAISE EXCEPTION 'pix_created concedeu acesso indevidamente!';
  END IF;

  -- Verifica que o intent v_token_pix PERMANECEU pendente (não foi consumido nem inutilizado)
  SELECT * INTO v_pay FROM tecniflow.billing_intents WHERE id = v_token_pix;
  IF v_pay.status <> 'pending' THEN
    RAISE EXCEPTION 'pix_created consumiu indevidamente o intent!';
  END IF;

  -- Expira trial da Empresa A para testar ativação limpa por pagamento Kiwify
  UPDATE tecniflow.company_subscriptions SET trial_ends_at = now() - INTERVAL '1 second' WHERE company_id = v_comp_a;
  IF tecniflow.check_subscription_active(v_comp_a) THEN
    RAISE EXCEPTION 'Empresa A deveria estar inativa após expiração do trial';
  END IF;

  -- D. Primeiro pagamento aprovado (order_approved) com sck válido
  v_res := tecniflow.process_kiwify_payment(
    'order_approved', 'ord_kw_100', 'sub_kw_100', 'paid', 'prod_kw_01', 'plan_kw_mensal',
    4990, 'BRL', v_token_a, now() + INTERVAL '30 days', now() + INTERVAL '30 days', now(), 'evt_kw_100', 'hash_100'
  );

  IF NOT tecniflow.check_subscription_active(v_comp_a) THEN
    RAISE EXCEPTION 'order_approved com sck válido não ativou a assinatura da Empresa A!';
  END IF;

  -- Verificar que o intent foi consumido atomicamente pelo pedido
  SELECT * INTO v_pay FROM tecniflow.billing_intents WHERE id = v_token_a;
  IF v_pay.status <> 'consumed' OR v_pay.consumed_by_order_id <> 'ord_kw_100' THEN
    RAISE EXCEPTION 'Intent não foi marcado como consumido pelo pedido!';
  END IF;

  -- Verificar que foi registrado em tecniflow.company_kiwify_subscriptions
  IF NOT EXISTS (
    SELECT 1 FROM tecniflow.company_kiwify_subscriptions 
    WHERE subscription_id = 'sub_kw_100' AND company_id = v_comp_a AND status = 'active'
  ) THEN
    RAISE EXCEPTION 'Assinatura Kiwify não registrada na tabela permanente de assinaturas!';
  END IF;

  -- E. Tentativa de iniciar NOVO checkout enquanto a assinatura paga está ativa é bloqueada
  PERFORM set_config('request.jwt.claim.sub', v_auth_a::text, true);
  v_failed := false;
  BEGIN
    PERFORM public.tf_create_billing_intent('prod_kw_01', 'plan_kw_mensal');
  EXCEPTION WHEN OTHERS THEN
    v_failed := true;
  END;
  IF NOT v_failed THEN
    RAISE EXCEPTION 'Empresa com assinatura paga ativa pôde iniciar novo checkout!';
  END IF;

  -- F. Retry do mesmo pedido com mesmo sck: idempotente, sem duplicar pagamento nem estender período
  v_res := tecniflow.process_kiwify_payment(
    'order_approved', 'ord_kw_100', 'sub_kw_100', 'paid', 'prod_kw_01', 'plan_kw_mensal',
    4990, 'BRL', v_token_a, now() + INTERVAL '30 days', now() + INTERVAL '30 days', now(), 'evt_kw_100_retry', 'hash_100'
  );
  IF (SELECT count(*) FROM tecniflow.billing_payments WHERE kiwify_order_id = 'ord_kw_100') <> 1 THEN
    RAISE EXCEPTION 'Retry do mesmo pedido duplicou linha de pagamento!';
  END IF;

  -- G. Tentativa de usar o intent já consumido para um NOVO pedido: bloqueada
  v_failed := false;
  BEGIN
    PERFORM tecniflow.process_kiwify_payment(
      'order_approved', 'ord_kw_novo', 'sub_kw_novo', 'paid', 'prod_kw_01', 'plan_kw_mensal',
      4990, 'BRL', v_token_a, now() + INTERVAL '30 days', now() + INTERVAL '30 days', now(), 'evt_novo', 'hash_novo'
    );
  EXCEPTION WHEN SQLSTATE 'P0004' THEN
    v_failed := true;
  END;
  IF NOT v_failed THEN
    RAISE EXCEPTION 'Intent já consumido pôde ser reutilizado por outro pedido!';
  END IF;

  -- H. Tentativa de conceder acesso com produto divergente do intent: bloqueada
  PERFORM set_config('request.jwt.claim.sub', v_auth_b::text, true);
  v_intent_res := public.tf_create_billing_intent('prod_kw_01', 'plan_kw_mensal');
  v_token_b := v_intent_res->>'token';

  v_failed := false;
  BEGIN
    PERFORM tecniflow.process_kiwify_payment(
      'order_approved', 'ord_kw_div', 'sub_kw_div', 'paid', 'produto_falso', 'plan_kw_mensal',
      4990, 'BRL', v_token_b, now() + INTERVAL '30 days', now() + INTERVAL '30 days', now(), 'evt_div', 'hash_div'
    );
  EXCEPTION WHEN SQLSTATE 'P0005' THEN
    v_failed := true;
  END;
  IF NOT v_failed THEN
    RAISE EXCEPTION 'Produto divergente do intent foi aceito!';
  END IF;

  -- I. Renovação de assinatura (subscription_renewed) SEM tracking sck (resolvida por subscription_id)
  v_res := tecniflow.process_kiwify_payment(
    'subscription_renewed', 'ord_kw_renov_200', 'sub_kw_100', 'paid', 'prod_kw_01', 'plan_kw_mensal',
    4990, 'BRL', NULL, now() + INTERVAL '60 days', now() + INTERVAL '60 days', now() + INTERVAL '30 days', 'evt_renov_200', 'hash_200'
  );
  IF NOT tecniflow.check_subscription_active(v_comp_a) THEN
    RAISE EXCEPTION 'Renovação por subscription_id sem sck falhou em manter acesso ativo!';
  END IF;

  -- J. subscription_late não revoga a cobertura já paga
  v_res := tecniflow.process_kiwify_payment(
    'subscription_late', 'ord_kw_renov_200', 'sub_kw_100', 'paid', 'prod_kw_01', 'plan_kw_mensal',
    4990, 'BRL', NULL, now() + INTERVAL '60 days', now() + INTERVAL '60 days', now(), 'evt_late_01', 'hash_late'
  );
  IF NOT tecniflow.check_subscription_active(v_comp_a) THEN
    RAISE EXCEPTION 'subscription_late cancelou indevidamente a cobertura vigente da empresa!';
  END IF;
  -- Verifica status 'late' na tabela permanente de assinaturas
  SELECT * INTO v_pay FROM tecniflow.company_kiwify_subscriptions WHERE subscription_id = 'sub_kw_100';
  IF v_pay.status <> 'late' THEN
    RAISE EXCEPTION 'subscription_late não atualizou status na tabela permanente!';
  END IF;

  -- K. Cancelamento da assinatura (subscription_canceled) preserva período pago (paid-through)
  v_res := tecniflow.process_kiwify_payment(
    'subscription_canceled', 'ord_kw_renov_200', 'sub_kw_100', 'canceled', 'prod_kw_01', 'plan_kw_mensal',
    4990, 'BRL', NULL, now() + INTERVAL '60 days', now() + INTERVAL '60 days', now(), 'evt_cancel_01', 'hash_cancel'
  );
  SELECT * INTO v_sub FROM tecniflow.company_subscriptions WHERE company_id = v_comp_a;
  IF v_sub.cancel_at_period_end IS NOT TRUE OR NOT tecniflow.check_subscription_active(v_comp_a) THEN
    RAISE EXCEPTION 'subscription_canceled revogou o acesso antes do término do período já pago!';
  END IF;

  -- L. Reembolso (order_refunded) do pedido de renovação revoga a cobertura respectiva
  v_res := tecniflow.process_kiwify_payment(
    'order_refunded', 'ord_kw_renov_200', 'sub_kw_100', 'refunded', 'prod_kw_01', 'plan_kw_mensal',
    4990, 'BRL', NULL, NULL, NULL, now(), 'evt_ref_200', 'hash_ref'
  );
  SELECT * INTO v_pay FROM tecniflow.billing_payments WHERE kiwify_order_id = 'ord_kw_renov_200';
  IF v_pay.status <> 'refunded' THEN
    RAISE EXCEPTION 'Pedido reembolsado não foi marcado como refunded!';
  END IF;

  -- M. Tombstone Terminal: Reembolso ANTES da aprovação impede aprovação tardia
  -- Simula estorno que chegou antes da aprovação do pedido 'ord_kw_tomb_01'
  v_res := tecniflow.process_kiwify_payment(
    'order_refunded', 'ord_kw_tomb_01', 'sub_kw_100', 'refunded', 'prod_kw_01', 'plan_kw_mensal',
    4990, 'BRL', NULL, NULL, NULL, now(), 'evt_tomb_ref', 'hash_tomb'
  );
  SELECT * INTO v_pay FROM tecniflow.billing_payments WHERE kiwify_order_id = 'ord_kw_tomb_01';
  IF v_pay.status <> 'refunded' THEN
    RAISE EXCEPTION 'Tombstone de reembolso prévio não foi inserido!';
  END IF;

  -- Tentativa tardia de aprovação desse pedido tombstoned NÃO concede acesso
  v_res := tecniflow.process_kiwify_payment(
    'order_approved', 'ord_kw_tomb_01', 'sub_kw_100', 'paid', 'prod_kw_01', 'plan_kw_mensal',
    4990, 'BRL', NULL, now() + INTERVAL '30 days', now() + INTERVAL '30 days', now(), 'evt_tomb_late', 'hash_late'
  );
  SELECT * INTO v_pay FROM tecniflow.billing_payments WHERE kiwify_order_id = 'ord_kw_tomb_01';
  IF v_pay.status <> 'refunded' THEN
    RAISE EXCEPTION 'Aprovação tardia sobrescreveu tombstone terminal de estorno!';
  END IF;

  -- N. Reembolso do primeiro pedido encerra cobertura e bloqueia operações com P0002
  PERFORM tecniflow.process_kiwify_payment(
    'order_refunded', 'ord_kw_100', 'sub_kw_100', 'refunded', 'prod_kw_01', 'plan_kw_mensal',
    4990, 'BRL', NULL, NULL, NULL, now(), 'evt_ref_100', 'hash_ref1'
  );
  IF tecniflow.check_subscription_active(v_comp_a) THEN
    RAISE EXCEPTION 'Empresa A continuou ativa mesmo após estorno de todos os pagamentos!';
  END IF;

  -- Operação de negócio bloqueada após expiração com P0002
  PERFORM set_config('request.jwt.claim.sub', v_auth_a::text, true);
  v_failed := false;
  BEGIN
    PERFORM public.tf_create_client('Cliente Bloqueado Kiwify', '11988887777');
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_sqlstate = RETURNED_SQLSTATE;
    IF v_sqlstate = 'P0002' THEN
      v_failed := true;
    END IF;
  END;
  IF NOT v_failed THEN
    RAISE EXCEPTION 'Operação de cliente foi permitida mesmo após assinatura expirada!';
  END IF;

  -- O. Ciclo pago atrasado com menos de 25 dias restantes (vencimento original preservado)
  PERFORM set_config('request.jwt.claim.sub', v_auth_b::text, true);
  v_intent_res := public.tf_create_billing_intent('prod_kw_01', 'plan_kw_mensal');
  v_token_late := v_intent_res->>'token';

  v_res := tecniflow.process_kiwify_payment(
    'order_approved', 'ord_late_cycle_01', 'sub_late_cycle_01', 'paid', 'prod_kw_01', 'plan_kw_mensal',
    4990, 'BRL', v_token_late, now() + INTERVAL '10 days', now() + INTERVAL '10 days', now(),
    'evt_late_cycle_01', 'hash_late_c', now() - INTERVAL '5 days'
  );
  IF (v_res->>'success')::boolean IS NOT TRUE THEN
    RAISE EXCEPTION 'Ciclo pago atrasado com menos de 25 dias restantes foi rejeitado indevidamente!';
  END IF;
  SELECT * INTO v_pay FROM tecniflow.billing_payments WHERE kiwify_order_id = 'ord_late_cycle_01';
  IF v_pay.period_ends_at > now() + INTERVAL '11 days' THEN
    RAISE EXCEPTION 'Vencimento do ciclo atrasado não preservou data original!';
  END IF;

  -- P. Intent expirado agora, mas pedido criado dentro do TTL e compensado depois (boleto)
  v_token_exp_ok := 'exp_ok_' || replace(gen_random_uuid()::text, '-', '');
  INSERT INTO tecniflow.billing_intents (
    id, company_id, provider, product_id, plan_id, status, expires_at, created_at
  ) VALUES (
    v_token_exp_ok, v_comp_b, 'kiwify', 'prod_kw_01', 'plan_kw_mensal', 'pending',
    now() - INTERVAL '4 hours', now() - INTERVAL '28 hours'
  );

  v_res := tecniflow.process_kiwify_payment(
    'order_approved', 'ord_bol_ok', 'sub_late_cycle_01', 'paid', 'prod_kw_01', 'plan_kw_mensal',
    4990, 'BRL', v_token_exp_ok, now() + INTERVAL '25 days', now() + INTERVAL '25 days', now(),
    'evt_bol_ok', 'hash_bol_ok', now() - INTERVAL '12 hours'
  );
  IF (v_res->>'success')::boolean IS NOT TRUE THEN
    RAISE EXCEPTION 'Boleto gerado dentro do TTL mas aprovado após o TTL foi recusado indevidamente!';
  END IF;

  v_token_exp_fail := 'exp_fail_' || replace(gen_random_uuid()::text, '-', '');
  INSERT INTO tecniflow.billing_intents (
    id, company_id, provider, product_id, plan_id, status, expires_at, created_at
  ) VALUES (
    v_token_exp_fail, v_comp_b, 'kiwify', 'prod_kw_01', 'plan_kw_mensal', 'pending',
    now() - INTERVAL '4 hours', now() - INTERVAL '28 hours'
  );
  v_failed := false;
  BEGIN
    PERFORM tecniflow.process_kiwify_payment(
      'order_approved', 'ord_bol_late_fail', 'sub_late_cycle_01', 'paid', 'prod_kw_01', 'plan_kw_mensal',
      4990, 'BRL', v_token_exp_fail, now() + INTERVAL '25 days', now() + INTERVAL '25 days', now(),
      'evt_bol_fail', 'hash_bol_fail', now() - INTERVAL '1 hour'
    );
  EXCEPTION WHEN SQLSTATE 'P0004' THEN
    v_failed := true;
  END;
  IF NOT v_failed THEN
    RAISE EXCEPTION 'Pedido criado após a expiração do intent foi aceito!';
  END IF;

  -- Q. SCK conflitante junto de subscription_id já vinculado e alteração de identidade
  v_failed := false;
  BEGIN
    PERFORM tecniflow.process_kiwify_payment(
      'subscription_renewed', 'ord_kw_renov_spoof', 'sub_late_cycle_01', 'paid', 'prod_kw_01', 'plan_kw_mensal',
      4990, 'BRL', v_token_a, now() + INTERVAL '25 days', now() + INTERVAL '25 days', now(),
      'evt_spoof', 'hash_spoof'
    );
  EXCEPTION WHEN SQLSTATE 'P0004' THEN
    v_failed := true;
  END;
  IF NOT v_failed THEN
    RAISE EXCEPTION 'sck de outra empresa não foi rejeitado!';
  END IF;

  v_failed := false;
  BEGIN
    PERFORM tecniflow.process_kiwify_payment(
      'order_approved', 'ord_late_cycle_01', 'sub_hacker_tamper', 'paid', 'prod_kw_01', 'plan_kw_mensal',
      4990, 'BRL', NULL, now() + INTERVAL '25 days', now() + INTERVAL '25 days', now(),
      'evt_tamper_sub', 'hash_tamper'
    );
  EXCEPTION WHEN SQLSTATE 'P0003' THEN
    v_failed := true;
  END;
  IF NOT v_failed THEN
    RAISE EXCEPTION 'Alteração de subscription_id em pedido já processado foi aceita!';
  END IF;

  -- R. Refund/chargeback prévio SEM commissions (tombstone terminal)
  INSERT INTO tecniflow.company_kiwify_subscriptions (subscription_id, company_id, status, plan_id, created_at, updated_at)
  VALUES ('sub_tomb_nc', v_comp_b, 'active', 'plan_kw_mensal', now(), now())
  ON CONFLICT DO NOTHING;

  v_res := tecniflow.process_kiwify_payment(
    'order_refunded', 'ord_tomb_nocomm', 'sub_tomb_nc', 'refunded', 'prod_kw_01', 'plan_kw_mensal',
    NULL, NULL, NULL, NULL, NULL, now(), 'evt_tomb_nc', 'hash_tomb_nc'
  );
  SELECT * INTO v_pay FROM tecniflow.billing_payments WHERE kiwify_order_id = 'ord_tomb_nocomm';
  IF v_pay.status <> 'refunded' OR v_pay.amount_cents <> 4990 OR v_pay.currency <> 'BRL' THEN
    RAISE EXCEPTION 'Tombstone sem commissions falhou em registrar metadados padrão canônicos!';
  END IF;

  -- Verifica que sub_tomb_nc foi cancelada automaticamente pelo estorno
  SELECT * INTO v_sub FROM tecniflow.company_kiwify_subscriptions WHERE subscription_id = 'sub_tomb_nc';
  IF v_sub.status <> 'canceled' OR v_sub.cancel_at_period_end IS NOT TRUE THEN
    RAISE EXCEPTION 'Estorno terminal falhou em cancelar automaticamente a assinatura vinculada!';
  END IF;

  -- E a assinatura ativa diferente da empresa (sub_late_cycle_01) continua NÃO cancelada
  SELECT * INTO v_sub FROM tecniflow.company_subscriptions WHERE company_id = v_comp_b;
  IF v_sub.kiwify_subscription_id = 'sub_late_cycle_01' AND v_sub.cancel_at_period_end IS TRUE THEN
    RAISE EXCEPTION 'Estorno de assinatura diferente cancelou indevidamente a assinatura ativa da empresa!';
  END IF;

  v_res := tecniflow.process_kiwify_payment(
    'order_approved', 'ord_tomb_nocomm', 'sub_tomb_nc', 'paid', 'prod_kw_01', 'plan_kw_mensal',
    4990, 'BRL', NULL, now() + INTERVAL '30 days', now() + INTERVAL '30 days', now(),
    'evt_tomb_nc_late', 'hash_tomb_nc_late'
  );
  SELECT * INTO v_pay FROM tecniflow.billing_payments WHERE kiwify_order_id = 'ord_tomb_nocomm';
  IF v_pay.status <> 'refunded' THEN
    RAISE EXCEPTION 'Aprovação tardia sobrescreveu tombstone terminal sem commissions!';
  END IF;

  -- S. Pagamento histórico não substitui assinatura atual vigente; cancelamento/atraso antigos não afetam a atual
  INSERT INTO tecniflow.company_kiwify_subscriptions (subscription_id, company_id, status, plan_id, created_at, updated_at)
  VALUES ('sub_old_historic', v_comp_b, 'active', 'plan_kw_mensal', now() - INTERVAL '90 days', now() - INTERVAL '90 days')
  ON CONFLICT DO NOTHING;

  PERFORM tecniflow.process_kiwify_payment(
    'order_approved', 'ord_old_historic', 'sub_old_historic', 'paid', 'prod_kw_01', 'plan_kw_mensal',
    4990, 'BRL', NULL, now() - INTERVAL '60 days', now() - INTERVAL '60 days', now() - INTERVAL '90 days',
    'evt_hist_old', 'hash_hist_old'
  );
  SELECT kiwify_subscription_id INTO v_pay FROM tecniflow.company_subscriptions WHERE company_id = v_comp_b;
  IF v_pay.kiwify_subscription_id <> 'sub_late_cycle_01' THEN
    RAISE EXCEPTION 'Pagamento histórico antigo substituiu indevidamente a assinatura atual vigente!';
  END IF;

  PERFORM tecniflow.process_kiwify_payment(
    'subscription_canceled', 'ord_old_historic', 'sub_old_historic', 'canceled', 'prod_kw_01', 'plan_kw_mensal',
    4990, 'BRL', NULL, NULL, NULL, now(), 'evt_cancel_old', 'hash_cancel_old'
  );
  SELECT cancel_at_period_end INTO v_pay FROM tecniflow.company_subscriptions WHERE company_id = v_comp_b;
  IF v_pay.cancel_at_period_end IS TRUE THEN
    RAISE EXCEPTION 'Cancelamento de assinatura antiga alterou cancel_at_period_end da assinatura vigente!';
  END IF;

  -- T. Assinatura cancelada ainda coberta por pagamento não permite novo checkout
  PERFORM tecniflow.process_kiwify_payment(
    'subscription_canceled', 'ord_late_cycle_01', 'sub_late_cycle_01', 'canceled', 'prod_kw_01', 'plan_kw_mensal',
    4990, 'BRL', NULL, NULL, NULL, now(), 'evt_cancel_current', 'hash_cancel_cur'
  );
  SELECT * INTO v_sub FROM tecniflow.company_subscriptions WHERE company_id = v_comp_b;
  IF v_sub.cancel_at_period_end IS NOT TRUE OR v_sub.current_period_ends_at <= now() THEN
    RAISE EXCEPTION 'Assinatura cancelada não manteve período vigente coberto!';
  END IF;

  PERFORM set_config('request.jwt.claim.sub', v_auth_b::text, true);
  v_failed := false;
  BEGIN
    PERFORM public.tf_create_billing_intent('prod_kw_01', 'plan_kw_mensal');
  EXCEPTION WHEN OTHERS THEN
    v_failed := true;
  END;
  IF NOT v_failed THEN
    RAISE EXCEPTION 'Empresa com assinatura cancelada porém com período pago vigente pôde abrir novo checkout!';
  END IF;

  -- U. service_role via GUC request.jwt.claims JSON (sem claim.role legado)
  PERFORM set_config('request.jwt.claim.role', '', true);
  PERFORM set_config('request.jwt.claims', '{"role": "service_role"}', true);
  v_res := public.tf_process_kiwify_payment(
    'subscription_renewed', 'ord_jwt_json_01', 'sub_late_cycle_01', 'paid', 'prod_kw_01', 'plan_kw_mensal',
    4990, 'BRL', NULL, now() + INTERVAL '20 days', now() + INTERVAL '20 days', now(), 'evt_jwt_json', 'hash_jwt'
  );
  IF (v_res->>'success')::boolean IS NOT TRUE THEN
    RAISE EXCEPTION 'service_role via request.jwt.claims JSON foi rejeitado!';
  END IF;

  PERFORM set_config('request.jwt.claims', '{"role": "authenticated"}', true);
  v_failed := false;
  BEGIN
    PERFORM public.tf_process_kiwify_payment(
      'order_approved', 'ord_jwt_auth_fail', 'sub_late_cycle_01', 'paid', 'prod_kw_01', 'plan_kw_mensal',
      4990, 'BRL', NULL, now() + INTERVAL '20 days', now() + INTERVAL '20 days', now(), 'evt_jwt_auth', 'hash_jwt'
    );
  EXCEPTION WHEN SQLSTATE '42501' THEN
    v_failed := true;
  END;
  IF NOT v_failed THEN
    RAISE EXCEPTION 'authenticated via request.jwt.claims pôde executar tf_process_kiwify_payment!';
  END IF;

  PERFORM set_config('request.jwt.claims', '{"role": "anon"}', true);
  v_failed := false;
  BEGIN
    PERFORM public.tf_process_kiwify_payment(
      'order_approved', 'ord_jwt_anon_fail', 'sub_late_cycle_01', 'paid', 'prod_kw_01', 'plan_kw_mensal',
      4990, 'BRL', NULL, now() + INTERVAL '20 days', now() + INTERVAL '20 days', now(), 'evt_jwt_anon', 'hash_jwt'
    );
  EXCEPTION WHEN SQLSTATE '42501' THEN
    v_failed := true;
  END;
  IF NOT v_failed THEN
    RAISE EXCEPTION 'anon via request.jwt.claims pôde executar tf_process_kiwify_payment!';
  END IF;

  -- V. Deduplicação após lock/retry e idempotência
  PERFORM set_config('request.jwt.claims', '{"role": "service_role"}', true);
  v_res := public.tf_process_kiwify_payment(
    'order_approved', 'ord_dedup_01', 'sub_late_cycle_01', 'paid', 'prod_kw_01', 'plan_kw_mensal',
    4990, 'BRL', NULL, now() + INTERVAL '25 days', now() + INTERVAL '25 days', now(), 'evt_dedup_unique_01', 'hash_dedup'
  );
  v_res := public.tf_process_kiwify_payment(
    'order_approved', 'ord_dedup_01', 'sub_late_cycle_01', 'paid', 'prod_kw_01', 'plan_kw_mensal',
    4990, 'BRL', NULL, now() + INTERVAL '25 days', now() + INTERVAL '25 days', now(), 'evt_dedup_unique_01', 'hash_dedup'
  );
  IF (v_res->>'duplicate_event')::boolean IS NOT TRUE THEN
    RAISE EXCEPTION 'Reenvio de evento com mesmo kiwify_event_id não retornou duplicate_event = true!';
  END IF;

  -- W. Evento subscription_canceled chegando com order_status = 'refunded'
  INSERT INTO tecniflow.company_kiwify_subscriptions (subscription_id, company_id, status, plan_id, created_at, updated_at)
  VALUES ('sub_cancel_with_refund', v_comp_a, 'active', 'plan_kw_mensal', now(), now())
  ON CONFLICT DO NOTHING;

  PERFORM tecniflow.process_kiwify_payment(
    'order_approved', 'ord_to_refund', 'sub_cancel_with_refund', 'paid', 'prod_kw_01', 'plan_kw_mensal',
    4990, 'BRL', NULL, now() + INTERVAL '30 days', now() + INTERVAL '30 days', now(), 'evt_ord_to_ref', 'hash_app'
  );

  -- Em seguida chega subscription_canceled com order_status = 'refunded'
  v_res := tecniflow.process_kiwify_payment(
    'subscription_canceled', 'ord_to_refund', 'sub_cancel_with_refund', 'refunded', 'prod_kw_01', 'plan_kw_mensal',
    NULL, NULL, NULL, NULL, NULL, now(), 'evt_cancel_ref', 'hash_cancel_ref'
  );

  SELECT * INTO v_pay FROM tecniflow.billing_payments WHERE kiwify_order_id = 'ord_to_refund';
  IF v_pay.status <> 'refunded' THEN
    RAISE EXCEPTION 'subscription_canceled com order_status refunded não marcou pagamento como refunded!';
  END IF;

  SELECT * INTO v_sub FROM tecniflow.company_kiwify_subscriptions WHERE subscription_id = 'sub_cancel_with_refund';
  IF v_sub.status <> 'canceled' OR v_sub.cancel_at_period_end IS NOT TRUE THEN
    RAISE EXCEPTION 'subscription_canceled com order_status refunded não cancelou a assinatura associada!';
  END IF;

  -- X. Chargeback terminal cancela assinatura associada sem revogar pagamentos aprovados não relacionados
  INSERT INTO tecniflow.company_kiwify_subscriptions (subscription_id, company_id, status, plan_id, created_at, updated_at)
  VALUES ('sub_chg_test', v_comp_a, 'active', 'plan_kw_mensal', now(), now())
  ON CONFLICT DO NOTHING;

  PERFORM tecniflow.process_kiwify_payment(
    'order_approved', 'ord_unrelated_approved', 'sub_late_cycle_01', 'paid', 'prod_kw_01', 'plan_kw_mensal',
    4990, 'BRL', NULL, now() + INTERVAL '28 days', now() + INTERVAL '28 days', now(), 'evt_unrel_app', 'hash_unrel'
  );

  PERFORM tecniflow.process_kiwify_payment(
    'order_approved', 'ord_to_chargeback', 'sub_chg_test', 'paid', 'prod_kw_01', 'plan_kw_mensal',
    4990, 'BRL', NULL, now() + INTERVAL '28 days', now() + INTERVAL '28 days', now(), 'evt_to_chg', 'hash_chg'
  );

  -- Evento chargeback no ord_to_chargeback
  PERFORM tecniflow.process_kiwify_payment(
    'chargeback', 'ord_to_chargeback', 'sub_chg_test', 'chargedback', 'prod_kw_01', 'plan_kw_mensal',
    NULL, NULL, NULL, NULL, NULL, now(), 'evt_chg_act', 'hash_chg_act'
  );

  SELECT * INTO v_pay FROM tecniflow.billing_payments WHERE kiwify_order_id = 'ord_to_chargeback';
  IF v_pay.status <> 'charged_back' THEN
    RAISE EXCEPTION 'Evento chargeback não marcou status como charged_back!';
  END IF;

  SELECT * INTO v_sub FROM tecniflow.company_kiwify_subscriptions WHERE subscription_id = 'sub_chg_test';
  IF v_sub.status <> 'canceled' OR v_sub.cancel_at_period_end IS NOT TRUE THEN
    RAISE EXCEPTION 'Chargeback não cancelou automaticamente a assinatura associada!';
  END IF;

  -- Pagamento aprovado não relacionado continua com status approved
  SELECT * INTO v_pay FROM tecniflow.billing_payments WHERE kiwify_order_id = 'ord_unrelated_approved';
  IF v_pay.status <> 'approved' THEN
    RAISE EXCEPTION 'Chargeback revogou indevidamente pagamento aprovado não relacionado!';
  END IF;

  -- Y. POLÍTICA DE PLAN_ID OPCIONAL E BINDING ATÔMICO PÓS-PAGAMENTO
  DECLARE
    v_token_no_plan varchar(64);
    v_intent_row record;
    v_kw_sub_row record;
  BEGIN
    -- 1. Intent sem plan_id criado pelo proprietário autenticado da Empresa A
    PERFORM set_config('request.jwt.claim.sub', v_auth_a::text, true);
    -- Expira assinaturas antigas da Empresa A se houver para permitir novo intent
    UPDATE tecniflow.company_subscriptions 
    SET current_period_ends_at = now() - INTERVAL '1 hour'
    WHERE company_id = v_comp_a;

    v_intent_res := public.tf_create_billing_intent('prod_kw_01', NULL);
    v_token_no_plan := v_intent_res->>'token';

    SELECT * INTO v_intent_row FROM tecniflow.billing_intents WHERE id = v_token_no_plan;
    IF v_intent_row.plan_id IS NOT NULL OR v_intent_row.status <> 'pending' THEN
      RAISE EXCEPTION 'Intent sem plan_id foi inicializado incorretamente!';
    END IF;

    -- 2. Tentativa de aprovação com plan_id vazio ou whitespace é rejeitada (P0005) e não consome intent
    v_failed := false;
    BEGIN
      PERFORM tecniflow.process_kiwify_payment(
        'order_approved', 'ord_blank_plan', 'sub_blank_plan', 'paid', 'prod_kw_01', '   ',
        4990, 'BRL', v_token_no_plan, now() + INTERVAL '30 days', now() + INTERVAL '30 days', now(),
        'evt_blank_plan', 'hash_blank_plan'
      );
    EXCEPTION WHEN SQLSTATE 'P0005' THEN
      v_failed := true;
    END;
    IF NOT v_failed THEN
      RAISE EXCEPTION 'Aprovação com plan_id em branco não falhou com P0005!';
    END IF;

    -- Verifica que o intent permaneceu pending e sem plan_id
    SELECT * INTO v_intent_row FROM tecniflow.billing_intents WHERE id = v_token_no_plan;
    IF v_intent_row.status <> 'pending' OR v_intent_row.plan_id IS NOT NULL THEN
      RAISE EXCEPTION 'Intent foi consumido indevidamente por tentativa inválida!';
    END IF;

    -- 3. Primeiro pagamento aprovado fixa o plan_id atomicamente no intent e na tabela permanente
    v_res := tecniflow.process_kiwify_payment(
      'order_approved', 'ord_atomic_bind_01', 'sub_atomic_bind_01', 'paid', 'prod_kw_01', 'plan_real_discovered_uuid',
      4990, 'BRL', v_token_no_plan, now() + INTERVAL '30 days', now() + INTERVAL '30 days', now(),
      'evt_atomic_01', 'hash_atomic_01'
    );
    IF (v_res->>'success')::boolean IS NOT TRUE THEN
      RAISE EXCEPTION 'Primeiro pagamento com descoberta atômica de plan_id falhou!';
    END IF;

    -- Verifica intent consumido com plan_id fixado
    SELECT * INTO v_intent_row FROM tecniflow.billing_intents WHERE id = v_token_no_plan;
    IF v_intent_row.status <> 'consumed' OR v_intent_row.plan_id <> 'plan_real_discovered_uuid' THEN
      RAISE EXCEPTION 'Intent não teve plan_id fixado atomicamente no consumo!';
    END IF;

    -- Verifica company_kiwify_subscriptions com plan_id fixado
    SELECT * INTO v_kw_sub_row FROM tecniflow.company_kiwify_subscriptions WHERE subscription_id = 'sub_atomic_bind_01';
    IF v_kw_sub_row.plan_id <> 'plan_real_discovered_uuid' OR v_kw_sub_row.status <> 'active' THEN
      RAISE EXCEPTION 'Tabela de assinaturas não vinculou o plan_id descoberto!';
    END IF;

    -- 4. Renovação com plan_id divergente para a mesma assinatura não pode alterar o vínculo imutável (P0003)
    v_failed := false;
    BEGIN
      PERFORM tecniflow.process_kiwify_payment(
        'subscription_renewed', 'ord_divergent_renew', 'sub_atomic_bind_01', 'paid', 'prod_kw_01', 'plano_diferente_adulterado',
        4990, 'BRL', NULL, now() + INTERVAL '60 days', now() + INTERVAL '60 days', now() + INTERVAL '30 days',
        'evt_div_renew', 'hash_div_renew'
      );
    EXCEPTION WHEN SQLSTATE 'P0003' THEN
      v_failed := true;
    END;
    IF NOT v_failed THEN
      RAISE EXCEPTION 'Renovação com plan_id divergente não foi bloqueada com P0003!';
    END IF;

    -- Verifica que o plan_id permanece intacto
    SELECT * INTO v_kw_sub_row FROM tecniflow.company_kiwify_subscriptions WHERE subscription_id = 'sub_atomic_bind_01';
    IF v_kw_sub_row.plan_id <> 'plan_real_discovered_uuid' THEN
      RAISE EXCEPTION 'Tentativa de renovação divergente adulterou o plan_id imutável!';
    END IF;

    -- 5. Cancelamento / Reembolso de assinatura antiga não cancela assinatura ativa diferente da empresa
    -- Criar assinatura antiga prévia para Empresa A
    INSERT INTO tecniflow.company_kiwify_subscriptions (subscription_id, company_id, status, plan_id, created_at, updated_at)
    VALUES ('sub_legacy_prev_a', v_comp_a, 'active', 'plan_real_discovered_uuid', now() - INTERVAL '60 days', now() - INTERVAL '60 days')
    ON CONFLICT DO NOTHING;

    -- Pagamento antigo vinculado
    PERFORM tecniflow.process_kiwify_payment(
      'order_approved', 'ord_legacy_prev_a', 'sub_legacy_prev_a', 'paid', 'prod_kw_01', 'plan_real_discovered_uuid',
      4990, 'BRL', NULL, now() - INTERVAL '30 days', now() - INTERVAL '30 days', now() - INTERVAL '60 days',
      'evt_leg_app', 'hash_leg_app'
    );

    -- Estorno da assinatura antiga sub_legacy_prev_a
    PERFORM tecniflow.process_kiwify_payment(
      'order_refunded', 'ord_legacy_prev_a', 'sub_legacy_prev_a', 'refunded', 'prod_kw_01', 'plan_real_discovered_uuid',
      4990, 'BRL', NULL, NULL, NULL, now(),
      'evt_leg_ref', 'hash_leg_ref'
    );

    -- A assinatura antiga foi cancelada
    SELECT * INTO v_kw_sub_row FROM tecniflow.company_kiwify_subscriptions WHERE subscription_id = 'sub_legacy_prev_a';
    IF v_kw_sub_row.status <> 'canceled' THEN
      RAISE EXCEPTION 'Assinatura antiga reembolsada não foi marcada como cancelada!';
    END IF;

    -- A assinatura atual sub_atomic_bind_01 CONTINUA ATIVA
    SELECT * INTO v_kw_sub_row FROM tecniflow.company_kiwify_subscriptions WHERE subscription_id = 'sub_atomic_bind_01';
    IF v_kw_sub_row.status <> 'active' OR v_kw_sub_row.cancel_at_period_end IS TRUE THEN
      RAISE EXCEPTION 'Cancelamento/estorno de assinatura antiga afetou a assinatura atual!';
    END IF;

    -- E a cobertura (paid-through) da Empresa A permanece ativa através de sub_atomic_bind_01
    IF NOT tecniflow.check_subscription_active(v_comp_a) THEN
      RAISE EXCEPTION 'Empresa A perdeu cobertura ativa legítima após estorno de assinatura antiga!';
    END IF;
  END;

  RAISE NOTICE 'Bateria completa de auditoria Kiwify transacional concluída com 100%% de sucesso.';
END;
$kiwify_audit$;

ROLLBACK;
`);
} catch (err) {
  console.log('\n>>> ERRO SQL DETECTADO: <<<');
  console.log('MSG:', err.message);
  console.log('DETAIL:', err.detail);
  console.log('HINT:', err.hint);
  console.log('WHERE:', err.where);
  process.exit(1);
}

check(true, 'Bateria completa de auditoria transacional Kiwify executada com sucesso');

// 7. Validar que o ROLLBACK reverteu tudo (zero fixtures persistidas)
const intentsAfter = Number(await scalar("SELECT count(*) FROM tecniflow.billing_intents"));
check(intentsAfter === intentsBefore, 'Zero intents de teste persistidos após ROLLBACK');

const subsAfter = Number(await scalar("SELECT count(*) FROM tecniflow.company_subscriptions"));
check(subsAfter === subsBefore, 'Zero assinaturas de teste persistidas após ROLLBACK');

const paymentsAfter = Number(await scalar("SELECT count(*) FROM tecniflow.billing_payments"));
check(paymentsAfter === paymentsBefore, 'Zero pagamentos de teste persistidos após ROLLBACK');

const kiwifySubsAfter = Number(await scalar("SELECT count(*) FROM tecniflow.company_kiwify_subscriptions"));
check(kiwifySubsAfter === kiwifySubsBefore, 'Zero registros em company_kiwify_subscriptions persistidos após ROLLBACK');

console.log(`\n================================================================`);
console.log(`  RESULTADO: TODOS OS ${passed} TESTES KIWIFY PGLITE PASSARAM COM SUCESSO!`);
console.log('================================================================\n');
