import {
  convertQuestionMarksToDollarNumbered,
  REQUIRED_TECNIFLOW_TABLES,
  PostgresAdapter,
  SSL_PARAMS_TO_REMOVE
} from '../server/db/postgres.js';
import pg from 'pg';

async function runPostgresAdapterTests() {
  console.log('================================================================');
  console.log('  TECNIFLOW - TESTES DO ADAPTADOR POSTGRESQL E COMPATIBILIDADE');
  console.log('================================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string, detail?: string) {
    if (condition) {
      console.log(`  ✓ [PASS] ${testName}`);
      passed++;
    } else {
      console.error(`  ✗ [FAIL] ${testName}${detail ? ` -> ${detail}` : ''}`);
      failed++;
    }
  }

  // 1. Placeholder conversion: ? -> $1, $2, ...
  const sql1 = 'SELECT * FROM users WHERE email = ? AND company_id = ?';
  const converted1 = convertQuestionMarksToDollarNumbered(sql1);
  assert(
    converted1 === 'SELECT * FROM users WHERE email = $1 AND company_id = $2',
    '1. Conversão de marcadores simples (? -> $1, $2)',
    `Esperado: $1, $2. Obtido: ${converted1}`
  );

  // 2. Placeholder inside string literal must NOT be converted
  const sql2 = "SELECT * FROM notes WHERE title = 'Qual o defeito?' AND status = ?";
  const converted2 = convertQuestionMarksToDollarNumbered(sql2);
  assert(
    converted2 === "SELECT * FROM notes WHERE title = 'Qual o defeito?' AND status = $1",
    '2. Preservação de interrogação dentro de literais de string',
    `Esperado $1 apenas no final. Obtido: ${converted2}`
  );

  // 3. String literal with escaped single quotes ''
  const sql3 = "INSERT INTO history (desc, user) VALUES ('Cliente disse ''O que houve?''', ?)";
  const converted3 = convertQuestionMarksToDollarNumbered(sql3);
  assert(
    converted3 === "INSERT INTO history (desc, user) VALUES ('Cliente disse ''O que houve?''', $1)",
    '3. Preservação de aspas escapadas com ponto de interrogação no texto',
    `Obtido: ${converted3}`
  );

  // 4. Verificação de tabelas obrigatórias do schema tecniflow
  const expectedTables = [
    'companies',
    'users',
    'sessions',
    'login_attempts',
    'clients',
    'inventory_items',
    'orders',
    'order_services',
    'order_parts',
    'inventory_movements',
    'order_history'
  ];
  assert(
    REQUIRED_TECNIFLOW_TABLES.length === 11 &&
    expectedTables.every((t) => (REQUIRED_TECNIFLOW_TABLES as readonly string[]).includes(t)),
    '4. Schema tecniflow define exatamente as 11 tabelas obrigatórias'
  );

  // 5. Fail-fast quando DB_PROVIDER=postgres sem DATABASE_URL
  let missingUrlThrew = false;
  try {
    new PostgresAdapter('');
  } catch (err: any) {
    missingUrlThrew = err.message.includes('DATABASE_URL está ausente');
  }
  assert(
    missingUrlThrew,
    '5. Falha imediata (fail-fast) quando DATABASE_URL está ausente (sem fallback silencioso)'
  );

  // 6. Fail-fast com URL em formato inválido
  let invalidUrlThrew = false;
  try {
    new PostgresAdapter('not-a-valid-url-format');
  } catch (err: any) {
    invalidUrlThrew = err.message.includes('não possui um formato de URL válido');
  }
  assert(
    invalidUrlThrew,
    '6. Rejeição imediata de connection string inválida'
  );

  // 7. Sanitização TLS estrita: verificação da configuração efetivamente entregue ao driver
  try {
    const maliciousUrl = 'postgresql://user:pass@localhost:5432/db?sslmode=disable&ssl=false&sslcert=bad.crt&sslkey=bad.key&uselibpqcompat=true&sslrootcert=bad.root';
    const adapter = new PostgresAdapter(maliciousUrl);
    const poolConfig = adapter.getPoolConfig();

    const isRejectUnauthorized = (poolConfig.ssl as any)?.rejectUnauthorized === true;
    const sanitizedUrl = new URL(poolConfig.connectionString!);
    const hasRemainingSslParam = SSL_PARAMS_TO_REMOVE.some((param) => sanitizedUrl.searchParams.has(param));

    assert(
      isRejectUnauthorized && !hasRemainingSslParam,
      '7. Configuração entregue ao driver pg.Pool impõe rejectUnauthorized:true e remove parâmetros de bypass',
      `rejectUnauthorized: ${isRejectUnauthorized}, params na URL: ${sanitizedUrl.search}`
    );
    await adapter.close();

    // 7b. Preservação de certificado CA customizado com rejectUnauthorized: true
    process.env.DB_CA_CERT = '-----BEGIN CERTIFICATE-----\nFAKE_CA_FOR_TEST\n-----END CERTIFICATE-----';
    const caAdapter = new PostgresAdapter('postgresql://user:pass@localhost:5432/db');
    const caConfig = caAdapter.getPoolConfig();
    assert(
      (caConfig.ssl as any)?.rejectUnauthorized === true && (caConfig.ssl as any)?.ca === process.env.DB_CA_CERT,
      '7b. Certificado CA customizado preservado mantendo rejectUnauthorized:true'
    );
    delete process.env.DB_CA_CERT;
    await caAdapter.close();
  } catch (err: any) {
    assert(false, '7. Sanitização TLS e inspeção de pool config', err.message);
  }

  // 8. Parser BIGINT (OID 20) com proteção de MAX_SAFE_INTEGER
  const bigintParser = pg.types.getTypeParser(20);
  const parsedNormal = bigintParser('55000');
  assert(parsedNormal === 55000, '8. Parser BIGINT converte inteiros monetários para número JS');

  let overflowThrew = false;
  try {
    bigintParser('9999999999999999999999');
  } catch (err: any) {
    overflowThrew = err.message.includes('MAX_SAFE_INTEGER');
  }
  assert(overflowThrew, '9. Parser BIGINT rejeita valores que excedem Number.MAX_SAFE_INTEGER');

  // 9. Parser TIMESTAMPTZ (OID 1184) converte para string ISO canônica
  const timestamptzParser = pg.types.getTypeParser(1184);
  const isoResult = timestamptzParser('2026-10-22 14:00:00-03');
  assert(
    typeof isoResult === 'string' && isoResult.endsWith('Z'),
    '10. Parser TIMESTAMPTZ normaliza timestamps para formato ISO canônico UTC (terminado em Z)'
  );

  console.log('\n================================================================');
  console.log(`  RESULTADO: ${passed} passaram, ${failed} falharam.`);
  console.log('================================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runPostgresAdapterTests().catch((err) => {
  console.error('Erro fatal nos testes:', err);
  process.exit(1);
});
