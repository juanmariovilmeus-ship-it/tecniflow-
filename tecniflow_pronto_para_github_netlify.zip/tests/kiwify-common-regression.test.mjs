import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';
import test from 'node:test';
import { parseKiwifyDate, verifyKiwifyWebhookSignature, validateKiwifyGrantPayload } from '../supabase/functions/_shared/kiwifyCommon.ts';

const config = { enabled: true, checkoutUrl: 'https://pay.kiwify.com.br/review', webhookSecret: 'review-secret-only-local', allowedProductIds: ['review-product'], planId: 'review-plan' };
const payload = () => ({ webhook_event_type: 'order_approved', order_id: 'review-order', subscription_id: 'review-subscription', order_status: 'paid', approved_date: '2026-02-01 10:30', Product: {product_id: 'review-product'}, Commissions: {charge_amount: 4990, currency: 'BRL'}, Subscription: {id: 'review-subscription', plan: {id: 'review-plan', frequency: 'monthly'}, next_payment: '2026-03-01T13:30:00Z', customer_access: {access_until: '2026-03-01T13:30:00Z'}} });

test('official Kiwify test vector is accepted', async () => {
  const secret = 'kiwify-token-de-teste';
  const rawBody = '{"order_id":"9b1c2d3e-0000-4000-8000-000000000001","order_status":"paid","webhook_event_type":"order_approved"}';
  const signature = 'bf18f352a4f981b91dfa3f6d8742a81080ab8c86';

  const res = await verifyKiwifyWebhookSignature(rawBody, signature, secret);
  assert.equal(res.valid, true);
  assert.equal(res.statusCode, 200);
  assert.equal(res.parsedBody?.order_id, '9b1c2d3e-0000-4000-8000-000000000001');
  assert.equal(res.parsedBody?.order_status, 'paid');
});

test('HMAC verifies raw body bytes and rejects minified signature on formatted body (no canonicalization fallback)', async () => {
  const body = payload();
  const rawPretty = JSON.stringify(body, null, 2);
  const minified = JSON.stringify(body);

  // Assinatura gerada sobre os bytes reais do corpo formatado
  const correctPrettySig = createHmac('sha1', config.webhookSecret).update(Buffer.from(rawPretty, 'utf8')).digest('hex');
  assert.equal((await verifyKiwifyWebhookSignature(rawPretty, correctPrettySig, config.webhookSecret)).valid, true);

  // Assinatura gerada sobre JSON minificado REJEITA o corpo formatado (prova ausência de fallback para JSON.stringify)
  const minifiedSig = createHmac('sha1', config.webhookSecret).update(Buffer.from(minified, 'utf8')).digest('hex');
  const rejectRes = await verifyKiwifyWebhookSignature(rawPretty, minifiedSig, config.webhookSecret);
  assert.equal(rejectRes.valid, false);
  assert.equal(rejectRes.statusCode, 401);
  assert.equal(rejectRes.errorCode, 'signature_mismatch');
});

test('HMAC authenticates UTF-8 accents and escape characters on raw bytes', async () => {
  const body = {
    ...payload(),
    company_name: 'Eletrônica & Assistência São João ⚡',
    notes: 'linha 1\nlinha 2\t"com aspas"',
  };
  const rawText = JSON.stringify(body);
  const sig = createHmac('sha1', config.webhookSecret).update(Buffer.from(rawText, 'utf8')).digest('hex');
  const res = await verifyKiwifyWebhookSignature(rawText, sig, config.webhookSecret);
  assert.equal(res.valid, true);
  assert.equal(res.parsedBody?.company_name, 'Eletrônica & Assistência São João ⚡');
});

test('renewal event name comes from webhook_event_type', () => {
  const body = payload(); body.webhook_event_type = 'subscription_renewed';
  const result = validateKiwifyGrantPayload(body, config);
  assert.equal(result.valid, true);
  assert.equal(result.grantData.eventType, 'subscription_renewed');
});

test('unknown paid event never becomes order_approved', () => {
  const body = payload(); body.webhook_event_type = 'unknown_event';
  assert.equal(validateKiwifyGrantPayload(body, config).valid, false);
});

test('missing event name never becomes order_approved', () => {
  const body = payload(); delete body.webhook_event_type;
  assert.equal(validateKiwifyGrantPayload(body, config).valid, false);
});

test('late February renewal retains original end date with fewer than 25 days', () => {
  const body = payload(); body.webhook_event_type = 'subscription_renewed'; body.approved_date = '2026-02-06 10:30';
  body.Subscription.next_payment = body.Subscription.customer_access.access_until = '2026-02-28T13:30:00Z';
  const result = validateKiwifyGrantPayload(body, config);
  assert.equal(result.valid, true);
  assert.equal(result.grantData.accessUntil, '2026-02-28T13:30:00.000Z');
});

test('provider ISO milliseconds are preserved', () => {
  assert.equal(parseKiwifyDate('2026-11-01T13:30:00.508Z'), '2026-11-01T13:30:00.508Z');
});

test('impossible timezone offset is rejected', () => {
  assert.equal(parseKiwifyDate('2026-11-01T13:30:00+99:99'), null);
});

test('minute precision without offset always uses Brazil offset', () => {
  assert.equal(parseKiwifyDate('2026-11-01 10:30'), '2026-11-01T13:30:00.000Z');
});

test('missing currency and fractional cents are rejected', () => {
  const missing = payload(); delete missing.Commissions.currency;
  const fractional = payload(); fractional.Commissions.charge_amount = 4990.1;
  assert.equal(validateKiwifyGrantPayload(missing, config).valid, false);
  assert.equal(validateKiwifyGrantPayload(fractional, config).valid, false);
});

test('empty config planId allows discovery and extracts payload planId', () => {
  const configNoPlan = { ...config, planId: '' };
  const body = payload();
  body.Subscription.plan.id = 'kw_discovered_plan_4990';
  const result = validateKiwifyGrantPayload(body, configNoPlan);
  assert.equal(result.valid, true);
  assert.equal(result.grantData.planId, 'kw_discovered_plan_4990');
});

test('empty or whitespace payload planId is rejected even when config planId is empty', () => {
  const configNoPlan = { ...config, planId: '' };
  const body = payload();
  body.Subscription.plan.id = '   ';
  const result = validateKiwifyGrantPayload(body, configNoPlan);
  assert.equal(result.valid, false);
  assert.match(result.reason, /Identificador do plano/);
});

test('placeholder in config planId is rejected (fail-closed)', () => {
  const configPlaceholder = { ...config, planId: 'seu_plano_uuid...' };
  const result = validateKiwifyGrantPayload(payload(), configPlaceholder);
  assert.equal(result.valid, false);
  assert.match(result.reason, /Configuração de plano Kiwify inválida/);
});

test('strictly configured planId rejects divergent payload planId', () => {
  const configStrict = { ...config, planId: 'plano_canonica_especifico' };
  const body = payload();
  body.Subscription.plan.id = 'outro_plano_divergente';
  const result = validateKiwifyGrantPayload(body, configStrict);
  assert.equal(result.valid, false);
  assert.match(result.reason, /diverge do plano/);
});

