import http from 'node:http';
import { AddressInfo } from 'node:net';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { createApp } from '../server.js';
import { createDatabase } from '../server/db.js';
import { SqliteAdapter } from '../server/db/sqlite.js';
import { setSupabaseAuthClient } from '../server/auth.js';
import { SessionCoordinator, getSafeRedirectUrl } from '../src/lib/sessionCoordinator.js';
import { SupabaseClient } from '@supabase/supabase-js';

class TestClient {
  public baseUrl: string;
  public token: string | null = null;
  public cookies: string[] = [];

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl;
  }

  setToken(token: string | null) {
    this.token = token;
  }

  setCookie(cookieStr: string) {
    this.cookies = [cookieStr];
  }

  clearCookie() {
    this.cookies = [];
  }

  async request(path: string, options: {
    method?: string;
    body?: any;
    headers?: Record<string, string>;
  } = {}) {
    const method = options.method || 'GET';
    const reqHeaders: Record<string, string> = {
      ...options.headers,
    };

    if (this.token) {
      reqHeaders['authorization'] = `Bearer ${this.token}`;
    }

    if (this.cookies.length > 0) {
      reqHeaders['cookie'] = this.cookies.join('; ');
    }

    let payload: string | undefined = undefined;
    if (options.body !== undefined) {
      reqHeaders['content-type'] = 'application/json';
      payload = JSON.stringify(options.body);
    }

    const res = await fetch(`${this.baseUrl}${path}`, {
      method,
      headers: reqHeaders,
      body: payload,
    });

    const rawText = await res.text();
    let body: any = null;
    try {
      body = JSON.parse(rawText);
    } catch {
      body = rawText;
    }

    return {
      status: res.status,
      headers: res.headers,
      body,
      rawText,
    };
  }
}

async function runTests() {
  console.log('================================================================');
  console.log('  TECNIFLOW - SUÍTE COMPLETA: SUPABASE AUTH, ISOLAMENTO E DB');
  console.log('================================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string, detail = '') {
    if (condition) {
      console.log(`  ✓ [PASS] ${testName}`);
      passed++;
    } else {
      console.error(`  ✗ [FAIL] ${testName}`);
      if (detail) console.error(`     Detalhe: ${detail}`);
      failed++;
    }
  }

  // ==========================================================================
  // BLOCO 1: TESTE ISOLADO DE MIGRAÇÃO SQLITE E PRAGMA table_info (PONTO 1)
  // ==========================================================================
  console.log('--- 1. Migração Isolada SQLite: PRAGMA table_info, Índices e Idempotência ---');
  const tempDbDir = path.resolve(process.cwd(), 'data', 'test-temp');
  if (!fs.existsSync(tempDbDir)) {
    fs.mkdirSync(tempDbDir, { recursive: true });
  }
  const tempDbPath = path.resolve(tempDbDir, `migration-test-${Date.now()}.db`);

  try {
    // 1.1 Criar base inicial com schema ANTERIOR (sem a coluna auth_user_id)
    const rawPreDb = new DatabaseSync(tempDbPath);
    rawPreDb.exec(`
      CREATE TABLE companies (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        document TEXT DEFAULT '',
        phone TEXT DEFAULT '',
        whatsapp TEXT DEFAULT '',
        email TEXT DEFAULT '',
        address TEXT DEFAULT '',
        warranty_terms TEXT DEFAULT '',
        receipt_notes TEXT DEFAULT '',
        created_at TEXT NOT NULL
      );

      CREATE TABLE users (
        id TEXT PRIMARY KEY,
        company_id TEXT NOT NULL,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'owner',
        created_at TEXT NOT NULL,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
      );
    `);

    // Inserir registros legados para conferir que permanecem preservados após a migração
    const legacyCompId = 'comp-legada-001';
    const legacyUserId = 'user-legado-001';
    rawPreDb.prepare(`
      INSERT INTO companies (id, name, created_at) VALUES (?, ?, ?)
    `).run(legacyCompId, 'Assistência Legada Original', new Date().toISOString());

    rawPreDb.prepare(`
      INSERT INTO users (id, company_id, name, email, password_hash, role, created_at)
      VALUES (?, ?, ?, ?, ?, 'owner', ?)
    `).run(legacyUserId, legacyCompId, 'Técnico Legado', 'legado@assistencia.com.br', 'hash_antigo', new Date().toISOString());

    rawPreDb.close();

    // 1.2 Primeira abertura com SqliteAdapter: deve detectar ausência via table_info, adicionar TEXT e criar índice
    const adapter1 = new SqliteAdapter(tempDbPath);

    const colsAfterMigration1 = adapter1.prepare('PRAGMA table_info(users)').all() as Array<{ name: string }>;
    const hasAuthCol1 = colsAfterMigration1.some((c) => c.name === 'auth_user_id');
    assert(hasAuthCol1, 'PRAGMA table_info confirma que a coluna auth_user_id foi adicionada na base legada');

    const indexList1 = adapter1.prepare('PRAGMA index_list(users)').all() as Array<{ name: string; unique: number }>;
    const hasUniqueIndex1 = indexList1.some((idx) => idx.name === 'idx_users_auth_user_id' && idx.unique === 1);
    assert(hasUniqueIndex1, 'PRAGMA index_list confirma que o índice UNIQUE idx_users_auth_user_id foi criado');

    const preservedUser = adapter1.prepare('SELECT id, name, email, auth_user_id FROM users WHERE id = ?').get(legacyUserId) as any;
    assert(preservedUser && preservedUser.name === 'Técnico Legado' && preservedUser.auth_user_id === null, 'Registros preexistentes foram 100% preservados com auth_user_id inicializado como null');

    await adapter1.close();

    // 1.3 Segunda abertura com SqliteAdapter: deve rodar de forma totalmente idempotente sem erros
    const adapter2 = new SqliteAdapter(tempDbPath);

    const colsAfterMigration2 = adapter2.prepare('PRAGMA table_info(users)').all() as Array<{ name: string }>;
    const hasAuthCol2 = colsAfterMigration2.some((c) => c.name === 'auth_user_id');
    assert(hasAuthCol2, 'Segunda abertura consecutiva preserva coluna auth_user_id sem erros de sintaxe');

    // 1.4 Testar rejeição de UUID duplicado através do índice UNIQUE criado
    const uuidTest = crypto.randomUUID();
    adapter2.prepare(`
      INSERT INTO users (id, company_id, name, email, password_hash, role, auth_user_id, created_at)
      VALUES (?, ?, ?, ?, '', 'owner', ?, ?)
    `).run('u1', legacyCompId, 'User 1', 'u1@test.com', uuidTest, new Date().toISOString());

    let duplicateRejected = false;
    try {
      adapter2.prepare(`
        INSERT INTO users (id, company_id, name, email, password_hash, role, auth_user_id, created_at)
        VALUES (?, ?, ?, ?, '', 'owner', ?, ?)
      `).run('u2', legacyCompId, 'User 2', 'u2@test.com', uuidTest, new Date().toISOString());
    } catch (err: any) {
      if (String(err?.message || '').includes('UNIQUE constraint failed: users.auth_user_id')) {
        duplicateRejected = true;
      }
    }
    assert(duplicateRejected, 'Índice UNIQUE rejeita inserção de auth_user_id duplicado no SQLite');

    await adapter2.close();
  } finally {
    try {
      if (fs.existsSync(tempDbPath)) fs.unlinkSync(tempDbPath);
      if (fs.existsSync(tempDbDir)) fs.rmdirSync(tempDbDir);
    } catch {}
  }

  // ==========================================================================
  // BLOCO 2: COORDENADOR DE SESSÃO COM PROMESSAS CONTROLADAS (PONTOS 2 E 3)
  // ==========================================================================
  console.log('\n--- 2. Coordenador de Sessão: Concorrência, Cleanup e Regressões Assíncronas ---');
  const coordinator = new SessionCoordinator<{ user: string; company: string }>();

  // 2.1 Resposta lenta que chega APÓS logout deve ser descartada
  let resolveSlow1: (val: any) => void;
  const slowPromise1 = new Promise((resolve) => { resolveSlow1 = resolve; });

  const syncP1 = coordinator.sync('token_antigo', 'user_1', () => slowPromise1 as any);

  // Simula usuário clicando em Sair antes da resposta de /api/auth/me chegar
  coordinator.invalidate();

  // Agora a resposta lenta de /auth/me é entregue
  resolveSlow1!({ user: 'User 1 Antigo', company: 'Empresa 1 Antiga' });
  const result1 = await syncP1;
  assert(result1.cancelled === true, 'Resposta lenta iniciada antes de logout é cancelada e não restaura usuário antigo');

  // 2.2 Troca rápida de conta: resposta lenta da Conta A não pode sobrescrever Conta B
  let resolveUserA: (val: any) => void;
  let resolveUserB: (val: any) => void;
  const promiseA = new Promise((resolve) => { resolveUserA = resolve; });
  const promiseB = new Promise((resolve) => { resolveUserB = resolve; });

  // Dispara sincronização para Conta A
  const syncPA = coordinator.sync('token_A', 'user_A', () => promiseA as any);

  // Usuário troca para Conta B antes de A resolver
  const syncPB = coordinator.sync('token_B', 'user_B', () => promiseB as any);

  // Responde A após B ter sido solicitada
  resolveUserA!({ user: 'Usuário A', company: 'Empresa A' });
  // Responde B
  resolveUserB!({ user: 'Usuário B', company: 'Empresa B' });

  const resA = await syncPA;
  const resB = await syncPB;
  assert(resA.cancelled === true, 'Resposta tardia do Usuário A foi descartada ao trocar para Conta B');
  assert(resB.cancelled === false && resB.data?.user === 'Usuário B', 'Dados da Conta B ativa foram aplicados com sucesso');

  // 2.3 Deduplicação de requisições concorrentes idênticas (evento + login simultâneo)
  let fetchCount = 0;
  const deduplicatedFetcher = async () => {
    fetchCount++;
    return { user: 'User Concurrent', company: 'Comp Concurrent' };
  };

  const [c1, c2] = await Promise.all([
    coordinator.sync('token_same', 'user_same', deduplicatedFetcher),
    coordinator.sync('token_same', 'user_same', deduplicatedFetcher),
  ]);
  assert(fetchCount === 1, 'Chamadas concorrentes idênticas executam apenas 1 requisição de rede');
  assert(c1.data?.user === 'User Concurrent' && c2.data?.user === 'User Concurrent', 'Ambas as promessas recebem o mesmo resultado sincronizado');

  // 2.4 Resolução tardia de getSession() após logout com promessa controlada
  const initialEpoch = coordinator.getGeneration();
  let resolveDelayedGetSession: (session: any) => void;
  const delayedSessionPromise = new Promise((resolve) => { resolveDelayedGetSession = resolve; });

  // Usuário clica logout antes de getSession resolver
  coordinator.invalidate();
  const epochAfterLogout = coordinator.getGeneration();

  // getSession() agora resolve tardiamente
  resolveDelayedGetSession!({ access_token: 'late_token', user: { id: 'late_user' } });
  const lateResolvedSession: any = await delayedSessionPromise;

  // Verificação de segurança: a época mudou, portanto a restauração tardia é estritamente ignorada
  const shouldIgnoreLateRestore = epochAfterLogout !== initialEpoch;
  assert(shouldIgnoreLateRestore, 'Inicialização tardia de getSession() após logout é detectada pela época e ignorada com segurança');

  // 2.5 Erro de sincronização de rede/servidor é capturado sem unhandled rejection
  let syncErrorCaught = false;
  const failingFetcher = async () => {
    throw new Error('Falha de rede intencional no teste');
  };
  const failResult = await coordinator.sync('err_token', 'err_user', failingFetcher);
  if (!failResult.cancelled && failResult.error && failResult.error.message.includes('Falha de rede')) {
    syncErrorCaught = true;
  }
  assert(syncErrorCaught, 'Erro de sincronização de rede é encapsulado como error no resultado sem unhandled rejection');

  // 2.6 Loading state: background refresh (mesmo token/userId) não ativa loading global
  // Simula lógica de AuthContext.scheduleSync
  const testCoordinator = new SessionCoordinator<{ user: string; company: string }>();
  let loadingState = false;

  const simulateScheduleSync = async (
    token: string,
    userId: string,
    isInitial: boolean,
    fetcher: () => Promise<{ user: string; company: string }>
  ) => {
    const activeUid = testCoordinator.getActiveUserId();
    const isSwitching = activeUid !== null && activeUid !== userId;

    if (isInitial || isSwitching) {
      loadingState = true;
    }

    const res = await testCoordinator.sync(token, userId, fetcher);
    if (res.cancelled) return;

    if (isInitial || isSwitching || testCoordinator.getActiveUserId() === userId) {
      loadingState = false;
    }
  };

  // Restauração inicial liga loading
  await simulateScheduleSync('tok1', 'u1', true, async () => ({ user: 'u1', company: 'c1' }));
  assert(loadingState === false, 'Restauração inicial conclui e encerra loading');

  // Background refresh do MESMO usuário: NÃO deve setar loading = true
  let loadingToggledInBackground = false;
  const backgroundFetchPromise = simulateScheduleSync('tok1_refreshed', 'u1', false, async () => {
    if (loadingState === true) {
      loadingToggledInBackground = true;
    }
    return { user: 'u1', company: 'c1' };
  });
  await backgroundFetchPromise;
  assert(!loadingToggledInBackground && loadingState === false, 'Background token refresh para mesma conta NÃO ativa loading global (protege rascunhos de formulário)');

  // 2.7 Invalidação no unmount do componente
  const unmountCoordinator = new SessionCoordinator<{ ok: boolean }>();
  unmountCoordinator.sync('tok_active', 'u_active', async () => ({ ok: true }));
  assert(unmountCoordinator.getActiveToken() === 'tok_active', 'Coordenador armazena token ativo');
  unmountCoordinator.invalidate();
  assert(unmountCoordinator.getActiveToken() === null && unmountCoordinator.getActiveUserId() === null, 'Invalidação no unmount limpa tokens e usuários ativos');

  // 2.8 Isolamento de Telas: Cálculo de chave estável para AuthScreenWrapper
  const getScreenKey = (user: { id: string } | null) => user?.id ? `user-session-${user.id}` : 'session-disconnected';
  const keyLoggedOut = getScreenKey(null);
  const keyUserA = getScreenKey({ id: 'user-uuid-A' });
  const keyUserARefreshed = getScreenKey({ id: 'user-uuid-A' });
  const keyUserB = getScreenKey({ id: 'user-uuid-B' });

  assert(keyLoggedOut === 'session-disconnected', 'Chave fixa definida para estado desconectado');
  assert(keyUserA === 'user-session-user-uuid-A', 'Chave estável gerada por user.id da conta conectada');
  assert(keyUserA === keyUserARefreshed, 'TOKEN_REFRESHED da mesma conta preserva chave idêntica sem remontar componentes');
  assert(keyUserA !== keyLoggedOut && keyUserA !== keyUserB, 'Logout ou troca de conta altera a chave de tela, desmontando e isolando estados em memória');

  // ==========================================================================
  // BLOCO 3: VALIDAÇÃO DE URLS DE REDIRECIONAMENTO CONFIGURÁVEIS
  // ==========================================================================
  console.log('\n--- 3. Validação de URLs de Redirecionamento Configuráveis ---');
  (globalThis as any).window = { location: { origin: 'https://tecniflow.app' } };

  const confirmUrl = getSafeRedirectUrl('/#auth-callback');
  assert(confirmUrl === 'https://tecniflow.app/#auth-callback', 'Callback de confirmação direciona para #auth-callback (não reset-password)');

  const resetUrl = getSafeRedirectUrl('/#reset-password');
  assert(resetUrl === 'https://tecniflow.app/#reset-password', 'Callback de recuperação direciona para #reset-password');

  const customOverride = getSafeRedirectUrl('/#auth-callback', 'https://minha-assistencia.com/confirm');
  assert(customOverride === 'https://minha-assistencia.com/confirm', 'Override de URL de redirecionamento aceita URL absoluta válida');

  const invalidOverride = getSafeRedirectUrl('/#auth-callback', '://url-invalida');
  assert(invalidOverride === 'https://tecniflow.app/#auth-callback', 'Override de URL malformada faz fallback seguro para a URL padrão');

  // ==========================================================================
  // BLOCO 4: 25 CASOS NEGATIVOS DE SEGURANÇA, CONTRATOS E ROLLBACK (PONTO 5)
  // ==========================================================================
  console.log('\n--- 4. 25 Casos Negativos de Segurança, Contratos e Rollback Transacional ---');
  const testDb = createDatabase(':memory:');
  // These cases exercise the legacy export/auth adapter only in an isolated test DB.
  // Production and default createApp still block legacy business/auth HTTP routes.
  const previousNodeEnv = process.env.NODE_ENV;
  process.env.NODE_ENV = 'test';
  let app: ReturnType<typeof createApp>;
  try {
    app = createApp(testDb, { allowLegacyTestRoutes: true });
  } finally {
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = previousNodeEnv;
  }
  const server = http.createServer(app);

  await new Promise<void>((resolve) => {
    server.listen(0, '127.0.0.1', () => resolve());
  });

  const address = server.address() as AddressInfo;
  const baseUrl = `http://127.0.0.1:${address.port}`;
  const client = new TestClient(baseUrl);

  // Inserir usuário legado preexistente em testDb com email conhecido
  const legacyEmail = 'existente@assistencia.com.br';
  await testDb.execute(`
    INSERT INTO companies (id, name, created_at) VALUES ('comp_leg_1', 'Empresa Antiga', '2025-01-01T00:00:00Z')
  `);
  await testDb.execute(`
    INSERT INTO users (id, company_id, name, email, password_hash, role, auth_user_id, created_at)
    VALUES ('user_leg_1', 'comp_leg_1', 'Dono Antigo', ?, 'hash_antigo', 'owner', NULL, '2025-01-01T00:00:00Z')
  `, [legacyEmail]);

  const user1Uid = crypto.randomUUID();
  const user2Uid = crypto.randomUUID();
  const userConflictUid = crypto.randomUUID();
  const oversizedEmailUid = crypto.randomUUID();
  const invalidEmailUid = crypto.randomUUID();

  // Mock do Supabase Auth para simular tokens
  const mockSupabaseClient = {
    auth: {
      async getUser(token: string) {
        if (token === 'valid_token_user_1') {
          return {
            data: {
              user: {
                id: user1Uid,
                email: 'proprietario1@assistencia.com.br',
                user_metadata: {
                  company_name: 'Tech Fix Cell 1'.repeat(10), // Testa truncamento > 100 caracteres
                  company_document: '11.222.333/0001-44',
                  owner_name: 'Carlos Oliveira',
                },
              },
            },
            error: null,
          };
        }
        if (token === 'valid_token_user_2') {
          return {
            data: {
              user: {
                id: user2Uid,
                email: 'proprietario2@computadores.com.br',
                user_metadata: {
                  company_name: 'Info Byte 2',
                  company_document: '55.666.777/0001-88',
                  owner_name: 'Mariana Santos',
                },
              },
            },
            error: null,
          };
        }
        if (token === 'token_conflict_email') {
          return {
            data: {
              user: {
                id: userConflictUid,
                email: legacyEmail,
                user_metadata: {
                  company_name: 'Tentativa Invasão ou Mesclagem',
                },
              },
            },
            error: null,
          };
        }
        if (token === 'oversized_email_token') {
          return {
            data: {
              user: {
                id: oversizedEmailUid,
                email: 'a'.repeat(95) + '@dominioassistencia.com.br', // > 100 caracteres
                user_metadata: { company_name: 'Empresa Email Longo' },
              },
            },
            error: null,
          };
        }
        if (token === 'invalid_format_email_token') {
          return {
            data: {
              user: {
                id: invalidEmailUid,
                email: 'email_sem_arroba_e_invalido',
                user_metadata: { company_name: 'Empresa Email Invalido' },
              },
            },
            error: null,
          };
        }
        if (token === 'expired_token') {
          return {
            data: { user: null },
            error: new Error('JWT token expired'),
          };
        }
        if (token === 'network_failure_token') {
          return {
            data: { user: null },
            error: new Error('Supabase Auth remote service unreachable'),
          };
        }
        return {
          data: { user: null },
          error: new Error('Invalid JWT token: signature verification failed'),
        };
      },
    },
  } as unknown as SupabaseClient;

  setSupabaseAuthClient(mockSupabaseClient);

  try {
    // Negativo 1: Ausência de token Authorization
    client.setToken(null);
    client.clearCookie();
    const neg1 = await client.request('/api/auth/me');
    assert(neg1.status === 401, '1. Acesso a /api/auth/me sem token Authorization retorna HTTP 401');

    // Negativo 2: Header Authorization sem prefixo Bearer ('Basic xyz')
    const neg2 = await client.request('/api/auth/me', { headers: { authorization: 'Basic dXNlcjpwYXNz' } });
    assert(neg2.status === 401, '2. Header Authorization sem prefixo Bearer retorna HTTP 401');

    // Negativo 3: Header Authorization com Bearer em branco ('Bearer ')
    const neg3 = await client.request('/api/auth/me', { headers: { authorization: 'Bearer ' } });
    assert(neg3.status === 401, '3. Header Authorization com Bearer em branco retorna HTTP 401');

    // Negativo 4: Token JWT com assinatura inválida/forjada
    client.setToken('forged_jwt_token_123');
    const neg4 = await client.request('/api/auth/me');
    assert(neg4.status === 401, '4. Token JWT com assinatura forjada/inválida retorna HTTP 401');

    // Negativo 5: Token JWT expirado
    client.setToken('expired_token');
    const neg5 = await client.request('/api/auth/me');
    assert(neg5.status === 401, '5. Token JWT expirado retorna HTTP 401');

    // Negativo 6: Falha remota no Supabase Auth
    client.setToken('network_failure_token');
    const neg6 = await client.request('/api/auth/me');
    assert(neg6.status === 401, '6. Falha remota de rede no Supabase Auth retorna HTTP 401 sem quebra do servidor');

    // Negativo 7: Tentativa de bypass por cookie legado tecniflow_session sem Bearer
    client.setToken(null);
    client.setCookie('tecniflow_session=cookie_legado_antigo');
    const neg7 = await client.request('/api/auth/me');
    assert(neg7.status === 401, '7. Tentativa de bypass via cookie legado em modo Supabase retorna HTTP 401 (sem fallback)');
    client.clearCookie();

    // Negativo 8: Endpoint /api/auth/register rejeita senhas locais
    const neg8 = await client.request('/api/auth/register', {
      method: 'POST',
      body: { email: 'teste@teste.com', password: 'SenhaLocal123!' },
    });
    assert(neg8.status === 400 && neg8.body.error?.includes('desativado'), '8. Endpoint local /api/auth/register rejeita cadastro e senhas com HTTP 400');

    // Negativo 9: Endpoint /api/auth/login rejeita senhas locais
    const neg9 = await client.request('/api/auth/login', {
      method: 'POST',
      body: { email: 'teste@teste.com', password: 'SenhaLocal123!' },
    });
    assert(neg9.status === 400 && neg9.body.error?.includes('desativado'), '9. Endpoint local /api/auth/login rejeita login local com senha com HTTP 400');

    // Negativo 10: Acesso desautenticado a /api/clients
    const neg10 = await client.request('/api/clients');
    assert(neg10.status === 401, '10. Acesso desautenticado a /api/clients retorna HTTP 401');

    // Negativo 11: Acesso desautenticado a /api/inventory
    const neg11 = await client.request('/api/inventory');
    assert(neg11.status === 401, '11. Acesso desautenticado a /api/inventory retorna HTTP 401');

    // Negativo 12: Acesso desautenticado a /api/orders
    const neg12 = await client.request('/api/orders');
    assert(neg12.status === 401, '12. Acesso desautenticado a /api/orders retorna HTTP 401');

    // Negativo 13: Acesso desautenticado a /api/reports/dashboard
    const neg13 = await client.request('/api/reports/dashboard');
    assert(neg13.status === 401, '13. Acesso desautenticado a /api/reports/dashboard retorna HTTP 401');

    // Negativo 14: Acesso desautenticado a /api/company
    const neg14 = await client.request('/api/company');
    assert(neg14.status === 401, '14. Acesso desautenticado a /api/company retorna HTTP 401');

    // Negativo 15: Provisão com e-mail > 100 caracteres retorna 422 sem truncar identidade
    client.setToken('oversized_email_token');
    const neg15 = await client.request('/api/auth/me');
    assert(neg15.status === 422, '15. E-mail excedendo 100 caracteres retorna HTTP 422 sem mutilar identidade');

    // Negativo 16: Provisão com e-mail em formato inválido retorna 422
    client.setToken('invalid_format_email_token');
    const neg16 = await client.request('/api/auth/me');
    assert(neg16.status === 422, '16. E-mail em formato inválido retorna HTTP 422');

    // Negativo 17: Tentativa de autenticar com e-mail de usuário legado retorna HTTP 409
    client.setToken('token_conflict_email');
    const neg17 = await client.request('/api/auth/me');
    assert(neg17.status === 409, '17. Conflito de e-mail com usuário legado retorna HTTP 409 claro');
    assert(neg17.body.error?.includes('Conflito de cadastro'), '18. Mensagem de 409 informa necessidade de migração e não mescla contas');

    // Negativo 18: Usuário legado e empresa permanecem intactos
    const legacyCheck = await testDb.queryOne('SELECT auth_user_id, company_id FROM users WHERE email = ?', [legacyEmail]);
    assert(legacyCheck?.auth_user_id === null && legacyCheck?.company_id === 'comp_leg_1', '19. Usuário legado preserva auth_user_id nulo e empresa intacta');

    // Negativo 19: Rollback transacional atômico comprovado
    let rollbackVerified = false;
    const initialCompanyCount = (await testDb.queryOne<{ c: number }>('SELECT count(*) as c FROM companies'))?.c || 0;
    try {
      await testDb.withTransaction(async (tx) => {
        await tx.execute(`
          INSERT INTO companies (id, name, created_at) VALUES ('comp_rollback_test', 'Empresa Rollback', ?)
        `, [new Date().toISOString()]);
        // Forçar falha intencional dentro da transação para testar rollback
        throw new Error('ROLLBACK_INTENCIONAL');
      });
    } catch {
      const postCompanyCount = (await testDb.queryOne<{ c: number }>('SELECT count(*) as c FROM companies'))?.c || 0;
      if (postCompanyCount === initialCompanyCount) {
        rollbackVerified = true;
      }
    }
    assert(rollbackVerified, '20. Rollback transacional atômico confirmado: transação revertida não deixa empresa órfã');

    // Autenticar User 1 para os próximos testes negativos de negócio
    client.setToken('valid_token_user_1');
    const resAuth1 = await client.request('/api/auth/me');
    assert(resAuth1.status === 200, 'User 1 autenticado para testes de contratos de negócio');
    const comp1Id = resAuth1.body.company?.id;

    // Criar cliente para testes
    const cliRes = await client.request('/api/clients', {
      method: 'POST',
      body: { name: 'Cliente Negativos', phone: '(11) 99999-0000' },
    });
    const testClientId = cliRes.body.client?.id;

    // Criar item de estoque com saldo 5
    const itmRes = await client.request('/api/inventory', {
      method: 'POST',
      body: {
        name: 'Bateria Samsung Teste',
        initialQuantity: 5,
        minQuantity: 1,
        costPriceCents: 5000,
        salePriceCents: 12000,
      },
    });
    const testItemId = itmRes.body.item?.id;

    // Criar OS
    const ordRes = await client.request('/api/orders', {
      method: 'POST',
      body: {
        clientId: testClientId,
        deviceType: 'smartphone',
        brand: 'Samsung',
        model: 'Galaxy S21',
        defectReported: 'Bateria viciada',
      },
    });
    const testOrderId = ordRes.body.order?.id;

    // Negativo 20: Transição inválida de status (ex: recebido -> pronto direto) retorna 400
    const neg20 = await client.request(`/api/orders/${testOrderId}/status`, {
      method: 'POST',
      body: { status: 'pronto', version: 1 },
    });
    assert(neg20.status === 400 && neg20.body.error?.includes('Transição inválida'), '21. Transição inválida de status (recebido -> pronto direto) rejeitada com HTTP 400');

    // Negativo 21: Transição direta para 'reparo' sem orçamento aprovado retorna 400
    const neg21 = await client.request(`/api/orders/${testOrderId}/status`, {
      method: 'POST',
      body: { status: 'reparo', version: 1 },
    });
    assert(neg21.status === 400, '22. Transição para status "reparo" sem orçamento aprovado é bloqueada com HTTP 400');

    // Negativo 22: Orçamento com preço unitário negativo retorna 400
    const neg22 = await client.request(`/api/orders/${testOrderId}/budget`, {
      method: 'PUT',
      body: {
        version: 1,
        services: [{ description: 'Serviço Negativo', unit_price_cents: -500, quantity: 1 }],
        parts: [],
      },
    });
    assert(neg22.status === 400 && neg22.body.error?.includes('não negativo'), '23. Orçamento com valor unitário negativo rejeitado com HTTP 400');

    // Negativo 23: Orçamento com quantidade de peças não-positiva (0) retorna 400
    const neg23 = await client.request(`/api/orders/${testOrderId}/budget`, {
      method: 'PUT',
      body: {
        version: 1,
        services: [],
        parts: [{ inventory_item_id: testItemId, description: 'Bateria', unit_price_cents: 12000, quantity: 0 }],
      },
    });
    assert(neg23.status === 400 && neg23.body.error?.includes('positivo'), '24. Orçamento com quantidade de peças não-positiva (0) rejeitado com HTTP 400');

    // Configurar orçamento válido com 10 unidades da peça (saldo no estoque é só 5!)
    await client.request(`/api/orders/${testOrderId}/budget`, {
      method: 'PUT',
      body: {
        version: 1,
        services: [{ description: 'Troca Bateria', unit_price_cents: 8000, quantity: 1 }],
        parts: [{ inventory_item_id: testItemId, description: 'Bateria', unit_price_cents: 12000, quantity: 10 }],
      },
    });
    // Avançar: recebido -> diagnostico -> aguardando_aprovacao -> aprovar
    await client.request(`/api/orders/${testOrderId}/status`, { method: 'POST', body: { status: 'diagnostico', version: 2 } });
    await client.request(`/api/orders/${testOrderId}/status`, { method: 'POST', body: { status: 'aguardando_aprovacao', version: 3 } });
    await client.request(`/api/orders/${testOrderId}/budget/decision`, { method: 'POST', body: { decision: 'aprovado', version: 4 } });

    // Negativo 24: Baixa de estoque com quantidade insuficiente rejeitada com 400 (estoque não-negativo)
    const neg24 = await client.request(`/api/orders/${testOrderId}/status`, {
      method: 'POST',
      body: { status: 'reparo', version: 5 },
    });
    assert(neg24.status === 400 && neg24.body.error?.includes('insuficiente'), '25. Tentativa de baixa de estoque com saldo insuficiente bloqueada com HTTP 400');

    // ==========================================================================
    // BLOCO 5: OPERAÇÕES DE NEGÓCIO E ISOLAMENTO MULTI-TENANT (USER 1 E USER 2)
    // ==========================================================================
    console.log('\n--- 5. Operações de Negócio (Clientes e OS) com Supabase Auth e Isolamento ---');

    // Reajustar peça para quantidade 1 no orçamento para concluir o ciclo de sucesso
    // Primeiro reabrir orçamento para revisão
    await testDb.execute("UPDATE orders SET budget_status = 'pendente', status = 'diagnostico' WHERE id = ?", [testOrderId]);
    const reopenBudgetRes = await client.request(`/api/orders/${testOrderId}/budget`, {
      method: 'PUT',
      body: {
        version: 5,
        services: [{ description: 'Troca Bateria', unit_price_cents: 8000, quantity: 1 }],
        parts: [{ inventory_item_id: testItemId, description: 'Bateria', unit_price_cents: 12000, quantity: 1 }],
      },
    });
    assert(reopenBudgetRes.status === 200, 'Orçamento reajustado com 1 unidade da peça (saldo suficiente)');

    // Transição: diagnostico -> aguardando_aprovacao
    const toAwaitingRes = await client.request(`/api/orders/${testOrderId}/status`, {
      method: 'POST',
      body: { status: 'aguardando_aprovacao', version: 6 },
    });
    assert(toAwaitingRes.status === 200, 'User 1 transita OS para status "aguardando_aprovacao" (200)');

    // User 1 aprova orçamento
    const approveRes = await client.request(`/api/orders/${testOrderId}/budget/decision`, {
      method: 'POST',
      body: { decision: 'aprovado', version: 7 },
    });
    assert(approveRes.status === 200, 'User 1 aprova orçamento da OS (200)');

    // Transição: aguardando_aprovacao -> reparo (dispara baixa atômica de estoque)
    const toRepairRes = await client.request(`/api/orders/${testOrderId}/status`, {
      method: 'POST',
      body: { status: 'reparo', version: 8 },
    });
    assert(toRepairRes.status === 200, 'User 1 transita OS para "reparo", disparando baixa atômica de estoque');

    // Transição: reparo -> pronto
    const statusRes = await client.request(`/api/orders/${testOrderId}/status`, {
      method: 'POST',
      body: { status: 'pronto', version: 9 },
    });
    assert(statusRes.status === 200, 'User 1 transita OS para status "pronto"');

    // Verificar que estoque foi debitado de 5 para 4
    const itemCheck = await client.request(`/api/inventory/${testItemId}`);
    assert(itemCheck.body.item?.quantity === 4, 'Estoque do item foi decrementado para 4');

    // User 1 cria uma segunda OS para verificar número sequencial
    const ord2Res = await client.request('/api/orders', {
      method: 'POST',
      body: {
        clientId: testClientId,
        deviceType: 'notebook',
        brand: 'Dell',
        model: 'Inspiron 15',
        defectReported: 'Não liga',
      },
    });
    assert(ord2Res.body.order?.order_number === 2, 'Segunda OS da empresa recebe número sequencial 2');

    // User 2 acessa a aplicação: isolamento rigoroso
    client.setToken('valid_token_user_2');
    const resUser2 = await client.request('/api/auth/me');
    assert(resUser2.status === 200, 'User 2 autenticado com sucesso');
    const company2Id = resUser2.body.company?.id;
    assert(company2Id !== comp1Id, 'Company 2 é estritamente distinta de Company 1');

    // User 2 não vê clientes, estoque nem ordens de User 1
    const user2Clients = await client.request('/api/clients');
    assert(user2Clients.body.clients?.length === 0, 'User 2 possui 0 clientes (isolamento garantido)');

    const user2Orders = await client.request('/api/orders');
    assert(user2Orders.body.orders?.length === 0, 'User 2 possui 0 ordens de serviço (isolamento garantido)');

    // User 2 tenta acessar cliente ou OS de User 1 diretamente por ID: recebe 404
    const crossClient = await client.request(`/api/clients/${testClientId}`);
    assert(crossClient.status === 404, 'User 2 recebe 404 ao tentar ler cliente de outra empresa');

    const crossOrder = await client.request(`/api/orders/${testOrderId}`);
    assert(crossOrder.status === 404, 'User 2 recebe 404 ao tentar ler OS de outra empresa');

    // User 2 tenta alterar cliente de User 1: recebe 404
    const crossUpdateClient = await client.request(`/api/clients/${testClientId}`, {
      method: 'PUT',
      body: { name: 'Invasão Tentada', phone: '(11) 99999-0000' },
    });
    assert(crossUpdateClient.status === 404, 'User 2 recebe 404 ao tentar modificar cliente de outra empresa');

    // User 2 tenta alterar orçamento de OS de User 1: recebe 404
    const crossUpdateBudget = await client.request(`/api/orders/${testOrderId}/budget`, {
      method: 'PUT',
      body: { version: 10, services: [], parts: [] },
    });
    assert(crossUpdateBudget.status === 404, 'User 2 recebe 404 ao tentar modificar orçamento de OS de outra empresa');

    // User 2 tenta alterar status de OS de User 1: recebe 404
    const crossUpdateStatus = await client.request(`/api/orders/${testOrderId}/status`, {
      method: 'POST',
      body: { status: 'cancelado', cancellationReason: 'Invasor tentando cancelar', version: 10 },
    });
    assert(crossUpdateStatus.status === 404, 'User 2 recebe 404 ao tentar transitar status de OS de outra empresa');


    // Exportação para transferência: identidade verificada, escopo fixo e sem segredos.
    // Reproduz a versão original do banco encontrada na prévia, sem datas nos itens.
    await testDb.execute('ALTER TABLE order_services DROP COLUMN created_at');
    await testDb.execute('ALTER TABLE order_parts DROP COLUMN created_at');
    const exportB = await client.request('/api/auth/export-legacy?company_id=' + comp1Id);
    assert(exportB.status === 200 && exportB.body.clients.length === 0, 'Exportação ignora empresa pedida pelo cliente e isola a conta B');
    assert(exportB.body.auth_user_id === user2Uid, 'Exportação vincula UUID verificado da conta B');
    client.setToken('valid_token_user_1');
    const exportA = await client.request('/api/auth/export-legacy');
    assert(exportA.status === 200 && exportA.body.clients.length > 0 && exportA.body.orders.length === 2, 'Exportação preserva cadastros e ordens da conta A');
    assert(exportA.body.auth_user_id === user1Uid && exportA.body.source_company_id === comp1Id, 'Origem contém vínculo exato com identidade e empresa verificadas');
    const serializedExport = JSON.stringify(exportA.body);
    assert(!/password_hash|token_hash|csrf_token|login_attempts/.test(serializedExport), 'Exportação não inclui senhas, tokens ou tentativas de login');
    assert(!('users' in exportA.body) && !('sessions' in exportA.body), 'Exportação não expõe tabelas de autenticação');
    client.setToken('');
    const unauthExport = await client.request('/api/auth/export-legacy');
    assert(unauthExport.status === 401, 'Exportação sem token é recusada');
    client.setToken('valid_token_user_1');
    await testDb.execute("UPDATE users SET role = 'technician' WHERE auth_user_id = ?", [user1Uid]);
    const nonOwnerExport = await client.request('/api/auth/export-legacy');
    assert(nonOwnerExport.status === 403, 'Exportação exige proprietário vinculado no banco');

  } finally {
    server.close();
    await testDb.close();
  }

  console.log('\n================================================================');
  console.log(`  RESULTADO: ${passed} passaram, ${failed} falharam.`);
  console.log('================================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runTests().catch((err) => {
  console.error('Erro fatal executando testes:', err);
  process.exit(1);
});

