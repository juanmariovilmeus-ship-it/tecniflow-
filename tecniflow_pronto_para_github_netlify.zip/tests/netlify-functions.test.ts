// ============================================================================
// TECNIFLOW - TESTES DO HANDLER SERVERLESS (NETLIFY FUNCTIONS)
// ============================================================================
// Valida o comportamento do handler de Netlify Functions para:
// 1. /api/health (Liveness)
// 2. /api/health/ready (Readiness / Probe)
// 3. /api/help/quota (Validação de Bearer token, identidade e formato)
// 4. /api/help/chat (Validação estrita de 16KB, chaves extras, alternância de histórico)
// 5. Bloqueio fail-closed de rotas legadas (/api/clients, /api/orders, /api/auth/*) com HTTP 410
// 6. Extração e normalização de caminhos (/api/* e /.netlify/functions/api/*)
// 7. Isolamento arquitetural: zero importação de SQLite, db.ts ou Vite no bundle serverless
// ============================================================================

import { readFileSync } from 'node:fs';
import { handler, extractApiPath } from '../netlify/functions/api.ts';
import type { HandlerEvent, HandlerContext, HandlerResponse } from '@netlify/functions';

let passed = 0;
let failed = 0;

function check(condition: boolean, description: string) {
  if (condition) {
    passed++;
    console.log(`  ✓ [PASS] ${description}`);
  } else {
    failed++;
    console.error(`  ✗ [FAIL] ${description}`);
  }
}

const mockContext: HandlerContext = {
  callbackWaitsForEmptyEventLoop: true,
  functionName: 'api',
  functionVersion: '1',
  invokedFunctionArn: 'arn:aws:lambda:us-east-1:123456789012:function:api',
  memoryLimitInMB: '1024',
  awsRequestId: 'req-test-123',
  logGroupName: '/aws/lambda/api',
  logStreamName: '2026/11/07/[$LATEST]test',
  getRemainingTimeInMillis: () => 15000,
  done: () => {},
  fail: () => {},
  succeed: () => {},
};

function createEvent(overrides: Partial<HandlerEvent>): HandlerEvent {
  return {
    rawUrl: 'https://app.tecniflow.com.br' + (overrides.path || '/'),
    rawQuery: '',
    path: overrides.path || '/',
    httpMethod: overrides.httpMethod || 'GET',
    headers: overrides.headers || {},
    multiValueHeaders: {},
    queryStringParameters: null,
    multiValueQueryStringParameters: null,
    body: overrides.body || null,
    isBase64Encoded: false,
    ...overrides,
  };
}

async function callHandler(overrides: Partial<HandlerEvent>): Promise<HandlerResponse> {
  const res = await handler(createEvent(overrides), mockContext);
  if (!res) throw new Error('Handler returned void unexpectedly');
  return res;
}

async function runTests() {
  console.log('\n================================================================');
  console.log('  TECNIFLOW - SUÍTE DE TESTES: NETLIFY SERVERLESS FUNCTIONS');
  console.log('================================================================\n');

  // --- 1. Auditoria de Dependências e Isolamento do Bundle ---
  console.log('--- 1. Auditoria de Dependências e Isolamento do Bundle ---');
  const functionCode = readFileSync('netlify/functions/api.ts', 'utf8');
  check(!functionCode.includes("from './server.ts'"), 'api.ts não importa server.ts');
  check(!functionCode.includes("from '../../server.ts'"), 'api.ts não importa root server.ts');
  check(!functionCode.includes('server/db'), 'api.ts não importa server/db.js');
  check(!functionCode.includes('sqlite'), 'api.ts não importa adaptadores SQLite');
  check(!functionCode.includes('createViteServer'), 'api.ts não importa Vite');
  check(!functionCode.includes('express.listen'), 'api.ts não contém listener HTTP');

  // --- 2. Normalização e Extração de Caminhos de Rota ---
  console.log('\n--- 2. Normalização e Extração de Caminhos de Rota ---');
  check(extractApiPath('/api/health') === '/health', 'Extrai /health a partir de /api/health');
  check(extractApiPath('/.netlify/functions/api/health') === '/health', 'Extrai /health a partir de /.netlify/functions/api/health');
  check(extractApiPath('/api/health/ready') === '/health/ready', 'Extrai /health/ready a partir de /api/health/ready');
  check(extractApiPath('/.netlify/functions/api/help/chat') === '/help/chat', 'Extrai /help/chat a partir de /.netlify/functions/api/help/chat');
  check(extractApiPath('/api/help/quota') === '/help/quota', 'Extrai /help/quota a partir de /api/help/quota');
  check(extractApiPath('/api/clients') === '/clients', 'Extrai /clients a partir de /api/clients');

  // --- 3. Liveness Endpoint (/api/health) ---
  console.log('\n--- 3. Liveness Endpoint (/api/health) ---');
  const healthRes = await callHandler({ path: '/api/health', httpMethod: 'GET' });
  check(healthRes.statusCode === 200, 'GET /api/health retorna HTTP 200');
  check(healthRes.headers?.['Content-Type'] === 'application/json', 'Content-Type é application/json');
  check(healthRes.headers?.['Cache-Control'] === 'no-store', 'Cache-Control é no-store');
  check(Boolean(healthRes.headers?.['X-Request-Id']), 'Header X-Request-Id presente na resposta');
  const healthBody = JSON.parse(healthRes.body || '{}');
  check(healthBody.status === 'ok', 'status é "ok"');
  check(healthBody.app === 'TecniFlow', 'app é "TecniFlow"');

  // --- 4. Readiness Endpoint (/api/health/ready) ---
  console.log('\n--- 4. Readiness Endpoint (/api/health/ready) ---');
  const readyRes = await callHandler({ path: '/api/health/ready', httpMethod: 'GET' });
  check(readyRes.statusCode === 200 || readyRes.statusCode === 503, 'GET /api/health/ready retorna HTTP 200 ou 503');
  check(readyRes.headers?.['Cache-Control'] === 'no-store', 'Cache-Control é no-store no readiness');
  const readyBody = JSON.parse(readyRes.body || '{}');
  check(readyBody.status === 'ready' || readyBody.status === 'unavailable', 'status é "ready" ou "unavailable"');
  check(typeof readyBody.latencyMs === 'number', 'latencyMs é retornado como número');

  // --- 5. Fail-Closed: Bloqueio de Rotas Legadas com HTTP 410 ---
  console.log('\n--- 5. Fail-Closed: Bloqueio de Rotas Legadas com HTTP 410 ---');
  const legacyRoutes = ['/api/clients', '/api/orders', '/api/inventory', '/api/auth/login', '/api/auth/register'];
  for (const route of legacyRoutes) {
    const res = await callHandler({ path: route, httpMethod: 'GET' });
    check(res.statusCode === 410, `Rota legada ${route} é bloqueada com HTTP 410`);
    const body = JSON.parse(res.body || '{}');
    check(body.code === 'CLOUD_OPERATIONS_ONLY', `Código da resposta para ${route} é CLOUD_OPERATIONS_ONLY`);
  }

  // --- 6. Central de Ajuda: Consulta de Cota (/api/help/quota) ---
  console.log('\n--- 6. Central de Ajuda: Consulta de Cota (/api/help/quota) ---');
  const quotaNoAuth = await callHandler({ path: '/api/help/quota', httpMethod: 'GET' });
  check(quotaNoAuth.statusCode === 401, 'GET /api/help/quota sem Authorization retorna HTTP 401');
  const quotaNoAuthBody = JSON.parse(quotaNoAuth.body || '{}');
  check(quotaNoAuthBody.error === 'Não autenticado.', 'Mensagem de não autenticado correta');

  const quotaBadHeader = await callHandler({
    path: '/api/help/quota',
    httpMethod: 'GET',
    headers: { authorization: 'Basic dXNlcjpwYXNz' },
  });
  check(quotaBadHeader.statusCode === 401, 'GET /api/help/quota com esquema não-Bearer retorna HTTP 401');

  const quotaInvalidToken = await callHandler({
    path: '/api/help/quota',
    httpMethod: 'GET',
    headers: { authorization: 'Bearer invalid.token.signature' },
  });
  check(quotaInvalidToken.statusCode === 401 || quotaInvalidToken.statusCode === 503, 'GET /api/help/quota com token inválido retorna HTTP 401 ou 503');

  // --- 7. Central de Ajuda: Validação Estrita do Chat (/api/help/chat) ---
  console.log('\n--- 7. Central de Ajuda: Validação Estrita do Chat (/api/help/chat) ---');
  const chatNoBody = await callHandler({ path: '/api/help/chat', httpMethod: 'POST', body: '' });
  check(chatNoBody.statusCode === 400, 'POST /api/help/chat com body vazio retorna HTTP 400');

  const chatInvalidJson = await callHandler({ path: '/api/help/chat', httpMethod: 'POST', body: '{ invalid json' });
  check(chatInvalidJson.statusCode === 400, 'POST /api/help/chat com JSON malformado retorna HTTP 400');

  // Limite de 16KB UTF-8
  const largePayload = 'A'.repeat(17000);
  const chatOversized = await callHandler({
    path: '/api/help/chat',
    httpMethod: 'POST',
    body: JSON.stringify({ message: largePayload }),
  });
  check(chatOversized.statusCode === 400, 'POST /api/help/chat com payload > 16KB retorna HTTP 400');

  // Rejeição de chaves extras
  const chatExtraKeys = await callHandler({
    path: '/api/help/chat',
    httpMethod: 'POST',
    body: JSON.stringify({ message: 'Como emitir OS?', prompt_injection: true }),
  });
  check(chatExtraKeys.statusCode === 400, 'POST /api/help/chat com chaves extras no nível superior retorna HTTP 400');

  // Mensagem vazia
  const chatEmptyMsg = await callHandler({
    path: '/api/help/chat',
    httpMethod: 'POST',
    body: JSON.stringify({ message: '   ' }),
  });
  check(chatEmptyMsg.statusCode === 400, 'POST /api/help/chat com mensagem vazia retorna HTTP 400');

  // Mensagem > 1500 caracteres
  const chatLongMsg = await callHandler({
    path: '/api/help/chat',
    httpMethod: 'POST',
    body: JSON.stringify({ message: 'B'.repeat(1501) }),
  });
  check(chatLongMsg.statusCode === 400, 'POST /api/help/chat com mensagem > 1500 chars retorna HTTP 400');

  // Histórico não array
  const chatBadHistoryType = await callHandler({
    path: '/api/help/chat',
    httpMethod: 'POST',
    body: JSON.stringify({ message: 'Ajuda', history: 'não-é-array' }),
  });
  check(chatBadHistoryType.statusCode === 400, 'POST /api/help/chat com histórico não-array retorna HTTP 400');

  // Histórico com mais de 6 turnos
  const chatTooManyHistory = await callHandler({
    path: '/api/help/chat',
    httpMethod: 'POST',
    body: JSON.stringify({
      message: 'Ajuda',
      history: [
        { role: 'user', content: '1' }, { role: 'model', content: '2' },
        { role: 'user', content: '3' }, { role: 'model', content: '4' },
        { role: 'user', content: '5' }, { role: 'model', content: '6' },
        { role: 'user', content: '7' },
      ],
    }),
  });
  check(chatTooManyHistory.statusCode === 400, 'POST /api/help/chat com histórico > 6 turnos retorna HTTP 400');

  // Histórico que não inicia com user
  const chatHistoryStartModel = await callHandler({
    path: '/api/help/chat',
    httpMethod: 'POST',
    body: JSON.stringify({
      message: 'Ajuda',
      history: [{ role: 'model', content: 'Olá' }],
    }),
  });
  check(chatHistoryStartModel.statusCode === 400, 'POST /api/help/chat com histórico que não inicia com user retorna HTTP 400');

  // Histórico sem alternância (user seguido de user)
  const chatHistoryNoAlternation = await callHandler({
    path: '/api/help/chat',
    httpMethod: 'POST',
    body: JSON.stringify({
      message: 'Ajuda',
      history: [
        { role: 'user', content: 'Primeira' },
        { role: 'user', content: 'Segunda' },
      ],
    }),
  });
  check(chatHistoryNoAlternation.statusCode === 400, 'POST /api/help/chat com histórico que não alterna estritamente retorna HTTP 400');

  // Histórico que não termina com model antes da pergunta atual
  const chatHistoryNotEndingWithModel = await callHandler({
    path: '/api/help/chat',
    httpMethod: 'POST',
    body: JSON.stringify({
      message: 'Ajuda',
      history: [
        { role: 'user', content: 'Primeira' },
        { role: 'model', content: 'Resposta' },
        { role: 'user', content: 'Terceira' },
      ],
    }),
  });
  check(chatHistoryNotEndingWithModel.statusCode === 400, 'POST /api/help/chat com histórico que não termina com model retorna HTTP 400');

  // Item do histórico com chaves extras
  const chatHistoryItemExtraKeys = await callHandler({
    path: '/api/help/chat',
    httpMethod: 'POST',
    body: JSON.stringify({
      message: 'Ajuda',
      history: [
        { role: 'user', content: 'Primeira', unauthorized_field: 'hack' },
        { role: 'model', content: 'Resposta' },
      ],
    }),
  });
  check(chatHistoryItemExtraKeys.statusCode === 400, 'POST /api/help/chat com chaves extras no item de histórico retorna HTTP 400');

  // Chat válido sintaticamente mas desautenticado
  const chatValidSyntaxNoAuth = await callHandler({
    path: '/api/help/chat',
    httpMethod: 'POST',
    body: JSON.stringify({
      message: 'Como cadastrar um cliente?',
      history: [
        { role: 'user', content: 'Qual a tela?' },
        { role: 'model', content: 'Acesse o menu Clientes.' },
      ],
    }),
  });
  check(chatValidSyntaxNoAuth.statusCode === 401, 'POST /api/help/chat com sintaxe válida mas sem Bearer token retorna HTTP 401');

  // --- 8. Preflight CORS OPTIONS ---
  console.log('\n--- 8. Preflight CORS OPTIONS ---');
  const optionsRes = await callHandler({ path: '/api/help/chat', httpMethod: 'OPTIONS' });
  check(optionsRes.statusCode === 204, 'OPTIONS retorna HTTP 204');
  check(optionsRes.headers?.['Access-Control-Allow-Origin'] === '*', 'CORS Allow-Origin presente');
  check(Boolean(optionsRes.headers?.['Access-Control-Allow-Methods']), 'CORS Allow-Methods presente');

  // --- 9. Auditoria do Arquivo netlify.toml ---
  console.log('\n--- 9. Auditoria do Arquivo netlify.toml ---');
  const netlifyToml = readFileSync('netlify.toml', 'utf8');
  check(netlifyToml.includes('publish = "dist"'), 'netlify.toml define publish = "dist"');
  check(netlifyToml.includes('command = "npm run build"'), 'netlify.toml define command = "npm run build"');
  check(netlifyToml.includes('NODE_VERSION = "22"'), 'netlify.toml define Node 22');
  check(netlifyToml.includes('directory = "netlify/functions"'), 'netlify.toml aponta functions para netlify/functions');
  check(netlifyToml.includes('node_bundler = "esbuild"'), 'netlify.toml configura node_bundler = "esbuild"');

  const apiRedirectIdx = netlifyToml.indexOf('from = "/api/*"');
  const spaRedirectIdx = netlifyToml.indexOf('from = "/*"');
  check(apiRedirectIdx !== -1 && spaRedirectIdx !== -1 && apiRedirectIdx < spaRedirectIdx, 'Redirect /api/* precede obrigatoriamente o fallback SPA /*');

  console.log('\n================================================================');
  console.log(`  RESULTADO: ${passed} passaram, ${failed} falharam.`);
  console.log('================================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runTests().catch((err) => {
  console.error('Erro na execução dos testes:', err);
  process.exit(1);
});
