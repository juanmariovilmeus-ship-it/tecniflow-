// ============================================================================
// TECNIFLOW - TESTES DA CENTRAL DE AJUDA, ASSISTENTE DE IA E COTAS
// ============================================================================
// Cobre os requisitos de A a F com execução real:
// 1. Execução real do SQL 009 em banco PostgreSQL isolado via PGlite
//    (advisory lock, quotas diárias São Paulo, burst 6/60s, RLS e grants).
// 2. Base de conhecimento e FAQ unificados sem invenções.
// 3. Handlers Express reais com validação de payload (16KB, 1500 chars, alternância).
// 4. Serviço helpAiService: modelo Flash-Lite configurável, maxOutputTokens, abortSignal, timeouts e logs limpos.
// 5. Componente HelpCenterView e App.tsx: chave por identidade, histórico 6x1000 chars, abort síncrono.
// ============================================================================

import assert from 'node:assert';
import fs from 'node:fs';
import path from 'node:path';
import { PGlite } from '@electric-sql/pglite';
import { createApp } from '../server.js';
import { HELP_FAQ_ITEMS, HELP_SYSTEM_KNOWLEDGE } from '../src/data/helpKnowledge.js';
import { checkAvailability } from '../server/services/helpAiService.js';

let passed = 0;
function check(condition: boolean, desc: string) {
  assert.ok(condition, desc);
  passed++;
  console.log(`  ✓ [PASS] ${desc}`);
}

console.log('================================================================');
console.log('  TECNIFLOW - SUÍTE COMPLETA: CENTRAL DE AJUDA E ASSISTENTE DE IA');
console.log('================================================================');

// ----------------------------------------------------------------------------
// 1. Execução Real da Migration 009 no PostgreSQL Isolado (PGlite)
// ----------------------------------------------------------------------------
console.log('\n--- 1. Execução Real da Migration 009 no PostgreSQL (PGlite) ---');

const migration009Path = path.resolve('supabase/009_help_ai_quota.sql');
check(fs.existsSync(migration009Path), 'Arquivo supabase/009_help_ai_quota.sql existe');

const migration009Sql = fs.readFileSync(migration009Path, 'utf8');

// Verificação de preflight e lock no SQL
check(migration009Sql.includes("to_regclass('tecniflow.companies')"), 'Migration 009 valida preflight de companies, users e current_company_id');
check(migration009Sql.includes('pg_advisory_xact_lock'), 'Migration 009 utiliza pg_advisory_xact_lock para serialização concorrente');
check(migration009Sql.includes('America/Sao_Paulo'), 'Migration 009 calcula início e reset do dia no fuso America/Sao_Paulo');

// Executar em PGlite simulando o ambiente do Supabase
const pglite = new PGlite();
await pglite.exec(`
  CREATE ROLE anon;
  CREATE ROLE authenticated;
  CREATE SCHEMA tecniflow;
  CREATE TABLE tecniflow.companies(id varchar(36) primary key);
  CREATE TABLE tecniflow.users(id varchar(36) primary key);
  CREATE SCHEMA auth;
  CREATE FUNCTION auth.uid() RETURNS uuid AS $$ SELECT '9b1c2d3e-0000-4000-8000-000000000001'::uuid $$ LANGUAGE sql;
  CREATE FUNCTION tecniflow.current_company_id() RETURNS varchar(36) AS $$ SELECT 'comp-test-01' $$ LANGUAGE sql;
  INSERT INTO tecniflow.companies(id) VALUES ('comp-test-01');
  INSERT INTO tecniflow.users(id) VALUES ('user-test-01');
`);

// Aplica a migration 009 real
await pglite.exec(migration009Sql);
await pglite.exec(fs.readFileSync('supabase/011_help_ai_limit_10.sql', 'utf8'));
check(true, 'Migration 009 aplicada com sucesso no PostgreSQL/PGlite sem erros de sintaxe ou de roles');

// Reserva inicial de cota
const reserveRes1 = await pglite.query<{ result: any }>('SELECT public.tf_reserve_help_ai_quota() AS result;');
const r1 = reserveRes1.rows[0].result;
check(r1.allowed === true && r1.used === 1 && r1.remaining === 9, 'Primeira reserva de cota autorizada com used=1 e remaining=9');
check(typeof r1.reset_at === 'string' && r1.reset_at.length > 0, 'Reserva retorna reset_at calculado para meia-noite no fuso correto');

// Consulta de status de cota (somente leitura)
const statusRes = await pglite.query<{ result: any }>('SELECT public.tf_get_help_ai_quota_status() AS result;');
const s1 = statusRes.rows[0].result;
check(s1.used === 1 && s1.remaining === 9 && s1.allowed === true, 'tf_get_help_ai_quota_status reflete a reserva sem realizar novas mutações');

// Simular 5 reservas adicionais para testar rate limit de 6 por minuto
for (let i = 0; i < 5; i++) {
  await pglite.query('SELECT public.tf_reserve_help_ai_quota();');
}

// A 7ª chamada consecutiva dentro do mesmo minuto deve atingir o rate limit de 6/60s
const burstRes = await pglite.query<{ result: any }>('SELECT public.tf_reserve_help_ai_quota() AS result;');
const b1 = burstRes.rows[0].result;
check(b1.allowed === false && b1.reason === 'rate_limit', 'Burst limit de 6 consultas em 60 segundos por usuário bloqueado com reason=rate_limit');
check(typeof b1.retry_after_seconds === 'number' && b1.retry_after_seconds > 0, 'Bloqueio de burst informa retry_after_seconds para o cliente');

// Uso anterior preservado mesmo ao reaplicar, inclusive empresas já acima de 10.
await pglite.exec(`INSERT INTO tecniflow.help_ai_quota_usage(company_id,user_id)
 SELECT 'comp-test-01','historical-user' FROM generate_series(1,5);`);
await pglite.exec(fs.readFileSync('supabase/011_help_ai_limit_10.sql', 'utf8'));
const after = (await pglite.query<{result:any}>('SELECT public.tf_get_help_ai_quota_status() result')).rows[0].result;
check(after.used === 11 && after.limit === 10 && after.remaining === 0 && !after.allowed, 'Reaplicação preserva uso anterior acima do novo limite');
const denied = (await pglite.query<{result:any}>('SELECT public.tf_reserve_help_ai_quota() result')).rows[0].result;
check(!denied.allowed && denied.reason === 'quota_exceeded' && denied.used === 11, 'Banco rejeita uso acima de dez sem reservar');
await pglite.close();

// ----------------------------------------------------------------------------
// 2. Base Curada de Conhecimento (src/data/helpKnowledge.ts)
// ----------------------------------------------------------------------------
console.log('\n--- 2. Base Curada de Conhecimento: Realidade Operacional e Anti-Alucinação ---');

check(HELP_FAQ_ITEMS.length >= 8, 'FAQ contém artigos curados para todas as áreas principais do sistema');

// Status reais da OS no FAQ
const hasRealStatus = HELP_FAQ_ITEMS.some((item) => item.answer.includes('Diagnóstico'));
check(hasRealStatus, 'Base de conhecimento lista o status real "Diagnóstico"');

// Ausência de invenções no prompt e FAQ
check(!HELP_SYSTEM_KNOWLEDGE.includes('Pix Automático'), 'Prompt do sistema não menciona Pix Automático');
check(!HELP_SYSTEM_KNOWLEDGE.includes('100% seguro') && !HELP_SYSTEM_KNOWLEDGE.includes('100% seguros'), 'Prompt não faz promessas de segurança absoluta "100% seguros"');
check(!HELP_SYSTEM_KNOWLEDGE.includes('portal de cancelamento'), 'Prompt não inventa portal de cancelamento externo');
check(HELP_SYSTEM_KNOWLEDGE.includes('Não invente endereço ou WhatsApp de suporte'), 'Prompt proíbe explicitamente inventar endereço ou WhatsApp de suporte');
check(HELP_SYSTEM_KNOWLEDGE.includes('Copiar pedido de ajuda'), 'Prompt orienta a utilizar a função "Copiar pedido de ajuda" para suporte humano');

// ----------------------------------------------------------------------------
// 3. Validação Estrita de Requisições HTTP (server/routes/helpRoutes.ts)
// ----------------------------------------------------------------------------
console.log('\n--- 3. Validação Estrita de Requisições: Chaves Extras, 1500 chars e 16KB ---');

const app = createApp();
const server = app.listen(0);
const port = (server.address() as any).port;
const baseUrl = `http://127.0.0.1:${port}`;

try {
  // Teste 3.1: Sem autenticação (401)
  const resNoAuth = await fetch(`${baseUrl}/api/help/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message: 'Como crio uma OS?' }),
  });
  check(resNoAuth.status === 401, 'POST /api/help/chat sem token Authorization retorna HTTP 401');

  // Teste 3.2: Rejeição de chaves extras no corpo (400)
  const resExtraKeys = await fetch(`${baseUrl}/api/help/chat`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer token-teste-invalido',
    },
    body: JSON.stringify({
      message: 'Olá',
      extra_key: 'hacker_payload',
    }),
  });
  check(resExtraKeys.status === 400, 'POST /api/help/chat com chave extra no corpo é rejeitado com HTTP 400');

  // Teste 3.3: Mensagem excedendo 1500 caracteres (400)
  const longPrompt = 'B'.repeat(1501);
  const resLongPrompt = await fetch(`${baseUrl}/api/help/chat`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer token-teste-invalido',
    },
    body: JSON.stringify({ message: longPrompt }),
  });
  check(resLongPrompt.status === 400, 'Mensagem com mais de 1500 caracteres é rejeitada com HTTP 400');

  // Teste 3.4: Rejeição de payload superior a 16KB UTF-8 (400)
  const giantString = 'A'.repeat(17000);
  const resGiant = await fetch(`${baseUrl}/api/help/chat`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer token-teste-invalido',
    },
    body: JSON.stringify({ message: giantString }),
  });
  check(resGiant.status === 400, 'POST /api/help/chat excedendo 16KB UTF-8 é rejeitado com HTTP 400');

  // Teste 3.5: Histórico excedendo 6 itens (400)
  const resTooManyTurns = await fetch(`${baseUrl}/api/help/chat`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer token-teste-invalido',
    },
    body: JSON.stringify({
      message: 'Como faço?',
      history: [
        { role: 'user', content: '1' }, { role: 'model', content: '2' },
        { role: 'user', content: '3' }, { role: 'model', content: '4' },
        { role: 'user', content: '5' }, { role: 'model', content: '6' },
        { role: 'user', content: '7' }, { role: 'model', content: '8' },
      ],
    }),
  });
  check(resTooManyTurns.status === 400, 'Histórico com mais de 6 turnos é rejeitado com HTTP 400');

  // Teste 3.6: Histórico deve alternar estritamente (400 se consecutivo)
  const resHistoryNoAlternate = await fetch(`${baseUrl}/api/help/chat`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer token-teste-invalido',
    },
    body: JSON.stringify({
      message: 'Como faço?',
      history: [
        { role: 'user', content: 'Pergunta 1' },
        { role: 'user', content: 'Pergunta 2 sem resposta no meio' },
      ],
    }),
  });
  check(resHistoryNoAlternate.status === 400, 'Histórico sem alternância estrita de turnos é rejeitado com HTTP 400');

  // Teste 3.7: Item de histórico com mais de 1000 caracteres (400)
  const resHistoryLongContent = await fetch(`${baseUrl}/api/help/chat`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer token-teste-invalido',
    },
    body: JSON.stringify({
      message: 'Como faço?',
      history: [
        { role: 'user', content: 'C'.repeat(1001) },
        { role: 'model', content: 'Resposta' },
      ],
    }),
  });
  check(resHistoryLongContent.status === 400, 'Item do histórico com mais de 1000 caracteres é rejeitado com HTTP 400');

} finally {
  server.close();
}

// ----------------------------------------------------------------------------
// 4. Auditoria de Código do Serviço de IA (server/services/helpAiService.ts)
// ----------------------------------------------------------------------------
console.log('\n--- 4. Serviço de IA: Modelo Flash-Lite, maxOutputTokens, abortSignal e Timeouts ---');

const helpServicePath = path.resolve('server/services/helpAiService.ts');
const helpServiceCode = fs.readFileSync(helpServicePath, 'utf8');

check(
  helpServiceCode.includes('gemini-3.5-flash-lite') &&
  helpServiceCode.includes('GEMINI_HELP_MODEL'),
  'helpAiService utiliza modelo Flash-Lite como padrão configurável via GEMINI_HELP_MODEL'
);

check(
  helpServiceCode.includes('maxOutputTokens: 600') &&
  helpServiceCode.includes('maxOutputTokens: 16'),
  'helpAiService limita a saída a 600 tokens na geração e 16 tokens no probe'
);

check(
  helpServiceCode.includes('abortSignal: controller.signal') &&
  helpServiceCode.includes('attempts: 1'),
  'helpAiService passa config.abortSignal ligado ao controller e desativa retries ({ attempts: 1 })'
);

check(
  helpServiceCode.includes('clearTimeout(timer)') &&
  helpServiceCode.includes('removeEventListener'),
  'helpAiService limpa timer e remove listener de abort no bloco finally'
);

// ----------------------------------------------------------------------------
// 5. Auditoria de Código da UI (src/components/HelpCenterView.tsx e App.tsx)
// ----------------------------------------------------------------------------
console.log('\n--- 5. UI: Chave por Identidade, Histórico 6x1000 chars e Acessibilidade ---');

const appPath = path.resolve('src/App.tsx');
const appCode = fs.readFileSync(appPath, 'utf8');

check(
  appCode.includes('<HelpCenterView key={`${user.id}:${company?.id || \'\'}`} />'),
  'App.tsx remonta HelpCenterView chaveado por user.id e company.id ao trocar de conta'
);

const helpViewPath = path.resolve('src/components/HelpCenterView.tsx');
const helpViewCode = fs.readFileSync(helpViewPath, 'utf8');

check(
  helpViewCode.includes('history.slice(-6)') || helpViewCode.includes('pairs.slice(-6)'),
  'HelpCenterView limita histórico a no máximo 6 turnos (3 pares completos)'
);

check(
  helpViewCode.includes('Copiar pedido de ajuda'),
  'HelpCenterView disponibiliza a ação "Copiar pedido de ajuda" para relato humano'
);

check(
  helpViewCode.includes('role="log"') &&
  helpViewCode.includes('aria-live="polite"'),
  'HelpCenterView inclui atributos de acessibilidade para leitores de tela'
);

// ----------------------------------------------------------------------------
// 6. Verificação Booleana de Credenciais e Disponibilidade de IA
// ----------------------------------------------------------------------------
console.log('\n--- 6. Verificação Booleana de Credenciais e Disponibilidade de IA ---');

const hasGeminiKey = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim());
console.log(`  [INFO] GEMINI_API_KEY configurada no servidor: ${hasGeminiKey ? 'SIM (presente)' : 'NÃO (ausente)'}`);
check(typeof hasGeminiKey === 'boolean', 'Verificação booleana de GEMINI_API_KEY realizada sem exibir o valor');

if (hasGeminiKey) {
  try {
    const probe = await checkAvailability();
    console.log(`  [INFO] Resultado da checagem de disponibilidade do modelo: ${probe.available ? 'Disponível' : probe.reason}`);
    check(typeof probe.available === 'boolean', 'Chamada mínima de availability concluída com sucesso');
  } catch (err: any) {
    console.log(`  [INFO] Falha controlada de disponibilidade: ${err.message || 'ERRO'}`);
  }
} else {
  console.log('  [INFO] GEMINI_API_KEY não configurada no ambiente local de teste; fallback de contingência ativo no servidor e UI.');
}

console.log('\n================================================================');
console.log(`  RESULTADO: ${passed} verificações da Central de Ajuda e IA aprovadas!`);
console.log('================================================================\n');
