process.env.TZ = 'America/Sao_Paulo';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

let passed = 0;
const check = (condition: boolean, label: string) => {
  assert.ok(condition, label);
  passed++;
  console.log(`  ✓ [PASS] ${label}`);
};

console.log('================================================================');
console.log('  TECNIFLOW - AUDITORIA DE PRONTIDÃO DE LANÇAMENTO (SEM PAGAMENTO)');
console.log('================================================================\n');

// ----------------------------------------------------------------------------
// 1. Configuração e Chaves Públicas do Supabase
// ----------------------------------------------------------------------------
console.log('--- 1. Auditoria de Configuração e Chaves Públicas ---');
const { DEFAULT_SUPABASE_URL, DEFAULT_SUPABASE_PUBLISHABLE_KEY, supabase } = await import('../src/lib/supabase.ts');

check(!!DEFAULT_SUPABASE_URL && DEFAULT_SUPABASE_URL.startsWith('https://'), 'URL pública do Supabase configurada com HTTPS');
check(DEFAULT_SUPABASE_URL.includes('.supabase.co'), 'URL aponta para domínio oficial do Supabase');
check(!!DEFAULT_SUPABASE_PUBLISHABLE_KEY && !DEFAULT_SUPABASE_PUBLISHABLE_KEY.includes('service_role'), 'Chave pública autorizada (nunca service_role)');
check(!DEFAULT_SUPABASE_PUBLISHABLE_KEY.startsWith('ey'), 'Chave não é token JWT secreto administrativo');
check(typeof supabase.rpc === 'function', 'Cliente Supabase inicializado com suporte a chamadas RPC');

// ----------------------------------------------------------------------------
// 2. Ativação de Operações em Nuvem e Ausência de Fallback Silencioso
// ----------------------------------------------------------------------------
console.log('\n--- 2. Ativação da Nuvem e Sem Fallback Silencioso para SQLite ---');
const { CLOUD_OPERATIONS_ENABLED, apiRequest, setApiAccessToken } = await import('../src/lib/api.ts');
const { cloudRequest } = await import('../src/services/cloudService.ts');

check(CLOUD_OPERATIONS_ENABLED === true, 'CLOUD_OPERATIONS_ENABLED está ativado para gravação em nuvem');

// Mock para simular erro da nuvem e comprovar que NENHUM fallback silencioso para SQLite acontece
let networkCalled = 0;
const originalFetch = globalThis.fetch;

// Cenário A: Erro de permissão 42501 (token expirado)
globalThis.fetch = async () => {
  networkCalled++;
  return new Response(JSON.stringify({ code: '42501', message: 'permission denied for function tf_get_clients' }), {
    status: 403,
    headers: { 'Content-Type': 'application/json' }
  });
};

await assert.rejects(
  async () => apiRequest('/api/clients'),
  (err: Error) => {
    check(err.message.includes('Acesso não autorizado') || err.message.includes('sessão expirada'), 'Erro 42501 lança exceção clara sem tentar SQLite');
    return true;
  }
);

// Cenário B: Erro de função não ativada (PGRST202)
globalThis.fetch = async () => {
  return new Response(JSON.stringify({ code: 'PGRST202', message: 'Could not find the function' }), {
    status: 404,
    headers: { 'Content-Type': 'application/json' }
  });
};

await assert.rejects(
  async () => apiRequest('/api/inventory'),
  (err: Error) => {
    check(err.message.includes('operações em nuvem ainda não foram ativadas'), 'PGRST202 informa necessidade de ativação no banco');
    return true;
  }
);

// Cenário C: Erro de regra de negócio vindo do PostgreSQL (ex.: estoque insuficiente)
globalThis.fetch = async () => {
  return new Response(JSON.stringify({ code: 'P0001', message: 'Estoque insuficiente para a peça "Conector": saldo atual (1), necessário (2).' }), {
    status: 400,
    headers: { 'Content-Type': 'application/json' }
  });
};

await assert.rejects(
  async () => apiRequest('/api/orders/order-1/status', { method: 'POST', body: JSON.stringify({ version: 1, status: 'reparo' }) }),
  (err: Error) => {
    check(err.message.includes('Estoque insuficiente'), 'Mensagem de regra de negócio do PostgreSQL propagada fielmente');
    return true;
  }
);

// ----------------------------------------------------------------------------
// 3. Auditoria de Contratos e Isolamento Multiempresa
// ----------------------------------------------------------------------------
console.log('\n--- 3. Isolamento Multiempresa e Mapeamento de Parâmetros ---');

const sql003 = readFileSync('supabase/003_operations_data_api.sql', 'utf8');

// Garante que nenhuma RPC pública exige ou aceita p_company_id vindo do cliente
const rpcSignatures = [...sql003.matchAll(/CREATE OR REPLACE FUNCTION public\.(tf_\w+)\(([\s\S]*?)\)\s*RETURNS/g)];
for (const [, name, params] of rpcSignatures) {
  const hasClientCompanyParam = params.toLowerCase().includes('p_company_id');
  check(!hasClientCompanyParam, `RPC ${name} resolve company_id pelo auth.uid() e não aceita p_company_id externo`);
}

// Verifica que todas as RPCs no SQL definem SET search_path = ''
const searchPathChecks = [...sql003.matchAll(/CREATE OR REPLACE FUNCTION public\.(tf_\w+)[\s\S]*?SECURITY DEFINER[\s\S]*?SET search_path\s*=\s*''/g)];
check(searchPathChecks.length === 24, 'Todas as 24 RPCs definem SECURITY DEFINER com search_path vazio');

// ----------------------------------------------------------------------------
// 4. Auditoria de Recuperação de Senha e URLs de Redirecionamento
// ----------------------------------------------------------------------------
console.log('\n--- 4. Recuperação de Senha e Redirecionamentos ---');
const { getSafeRedirectUrl } = await import('../src/lib/sessionCoordinator.ts');

(globalThis as any).window = { location: { origin: 'https://tecniflow.app' } };

const recoveryUrl = getSafeRedirectUrl('/#reset-password')!;
check(recoveryUrl.includes('#reset-password'), 'URL de recuperação direciona para a hash #reset-password');
check(!recoveryUrl.includes('auth-callback'), 'URL de recuperação não confunde com confirmação de e-mail');

const confirmationUrl = getSafeRedirectUrl('/#auth-callback')!;
check(confirmationUrl.includes('#auth-callback'), 'URL de confirmação direciona para #auth-callback');

// ----------------------------------------------------------------------------
// 5. Auditoria de Tratamento de Datas sem Distorção de Fuso Horário
// ----------------------------------------------------------------------------
console.log('\n--- 5. Tratamento de Datas e Fuso Horário (América/São Paulo) ---');
const { formatDate, formatDateOnly, formatDateTime } = await import('../src/lib/api.ts');

check(formatDateOnly('2026-10-27') === '27/10/2026', 'Data no formato AAAA-MM-DD convertida exatamente para DD/MM/AAAA');
check(formatDateTime('2026-10-27') === '27/10/2026', 'formatDateTime não salta para a noite anterior em datas puras');
check(formatDate('2026-10-27T03:00:00Z') === '27/10/2026', 'Timestamp ISO UTC tratado corretamente pelo fuso local');

// ----------------------------------------------------------------------------
// 6. Concorrência e Detecção de Troca de Sessão
// ----------------------------------------------------------------------------
console.log('\n--- 6. Proteção de Sessão contra Respostas Tardias ---');
let resumePendingFetch: (r: Response) => void;
globalThis.fetch = () => new Promise<Response>((r) => { resumePendingFetch = r; });

setApiAccessToken('token-usuario-ativo-1');
const activeCall = apiRequest('/api/clients');

// Simula que durante a chamada em voo, ocorreu logout ou troca de conta
await new Promise(r => setImmediate(r));
setApiAccessToken('token-outro-usuario-2');

// Resposta do primeiro usuário chega agora
resumePendingFetch!(new Response(JSON.stringify({ data: { clients: [{ id: '1', name: 'Cliente do Usuário 1' }] } }), {
  status: 200,
  headers: { 'Content-Type': 'application/json' }
}));

await assert.rejects(
  activeCall,
  /A sessão mudou durante a operação/,
  'Resposta tardia de conta anterior é descartada com erro de mudança de sessão'
);
check(true, 'Proteção contra vazamento de dados entre trocas de conta confirmada');

// ----------------------------------------------------------------------------
// 7. Auditoria Operacional de Cancelamento, Rastreabilidade e Ausência de Pagamentos
// ----------------------------------------------------------------------------
console.log('\n--- 7. Auditoria de Cancelamento, Rastreabilidade e Sem Pagamentos ---');

// A. Cancelamento requer justificativa
const orderDetailCode = readFileSync('src/components/OrderDetailModal.tsx', 'utf8');
check(orderDetailCode.includes('cancellationReason.trim()'), 'Cancelamento bloqueado na interface se não houver justificativa');
check(orderDetailCode.includes('Atenção ao estoque:'), 'Alerta de estoque exibido quando OS cancelada possui peças baixadas');
check(orderDetailCode.includes('Rastreabilidade de peças mantida:'), 'Banner da OS cancelada documenta preservação do histórico de peças');

// B. Painel Operacional: Faixa secundária removida integralmente, mantendo 4 cartões principais, ações e lista
const dashboardCode = readFileSync('src/components/DashboardView.tsx', 'utf8');
check(!dashboardCode.includes('Total de OS Registradas:'), 'Faixa secundária com Total de OS Registradas removida integralmente conforme solicitado pelo dono');
check(!dashboardCode.includes('Clientes Ativos:'), 'Faixa secundária não contém contagem redundante de clientes ativos');
check(!dashboardCode.includes('peça com estoque no limite'), 'Faixa secundária não contém alerta redundante de estoque no limite');
check(dashboardCode.includes('metrics ? metrics.inProgressCount : 0'), 'Cartão principal "Em Andamento" preservado');
check(dashboardCode.includes('metrics ? metrics.awaitingApprovalCount : 0'), 'Cartão principal "Aguardando Aprovação" preservado');
check(dashboardCode.includes('metrics ? metrics.readyForPickupCount : 0'), 'Cartão principal "Prontos p/ Retirada" preservado');
check(dashboardCode.includes('formatCurrency(metrics?.totalDeliveredCents || 0)'), 'Cartão principal "Serviços Entregues" preservado');
check(dashboardCode.includes('onNewOrder') && dashboardCode.includes('onNewClient') && dashboardCode.includes('onNewItem'), 'Ações rápidas Nova OS, Novo Cliente e Nova Peça preservadas');
check(dashboardCode.includes('Últimas Ordens de Serviço'), 'Tabela de ordens recentes mantida intacta');

// C. Ausência de gateways de terceiros não autorizados ou SDKs diretos no bundle do cliente
const appCode = readFileSync('src/App.tsx', 'utf8');
check(!appCode.toLowerCase().includes('stripe') && !appCode.toLowerCase().includes('pagseguro') && !appCode.toLowerCase().includes('paypal'), 'Nenhum gateway de pagamento de terceiros não autorizado presente no cliente');
check(!appCode.toLowerCase().includes('mercadopago.js') && !appCode.toLowerCase().includes('mercadopagosdk'), 'Nenhum SDK direto de pagamento no bundle do cliente (fluxo brokered server-side/Edge Functions)');

// D. Auditoria de Atualização de Componentes e Estados de Loading/Erro
check(appCode.includes('handleDataMutated') && appCode.includes('refreshTrigger={dataVersion}'), 'App.tsx propaga versão de dados para atualização imediata dos componentes');
check(appCode.includes('onRefreshList={handleDataMutated}'), 'OrderDetailModal configurado para disparar atualização das listas ao salvar/editar');
check(orderDetailCode.includes('savingBudget') && orderDetailCode.includes('submittingStatus'), 'OrderDetailModal gerencia estados de loading durante salvamento e transições');
check(orderDetailCode.includes('submittingCancellation') && orderDetailCode.includes('submittingDelivery'), 'OrderDetailModal desativa botões e sinaliza carregamento no cancelamento e entrega');
const clientsCode = readFileSync('src/components/ClientsView.tsx', 'utf8');
check(!clientsCode.includes('alert('), 'ClientsView não utiliza window.alert que quebraria em iFrame');
check(clientsCode.includes('drawerError'), 'ClientsView trata estado de erro e botão de repetição no drawer');

// ----------------------------------------------------------------------------
// 8. Auditoria do Script de Verificação Transacional (004)
// ----------------------------------------------------------------------------
console.log('\n--- 8. Auditoria do Script de Verificação Transacional (004) ---');

const sql004 = readFileSync('supabase/004_test_verification_rollback.sql', 'utf8');
check(sql004.includes('BEGIN;'), 'Script 004 inicia obrigatoriamente com transação atômica (BEGIN)');
check(sql004.trim().endsWith('ROLLBACK;'), 'Script 004 encerra obrigatoriamente com reversão atômica (ROLLBACK)');
check(!sql004.includes('COMMIT;'), 'Script 004 não contém COMMIT (garantia de zero persistência de dados de teste)');
check(sql004.includes("set_config('request.jwt.claim.sub'"), 'Script 004 simula identidades seguras via claims JWT de transação');
check(sql004.includes('tf_sync_current_user') && sql004.includes('tf_create_client') && sql004.includes('tf_create_order'), 'Script 004 cobre provisionamento, clientes e ordens de serviço');
check(sql004.includes('has_table_privilege'), 'Script 004 audita bloqueio de acesso direto a tabelas privadas tecniflow');
check(sql004.includes('GET STACKED DIAGNOSTICS') && sql004.includes('RETURNED_SQLSTATE'), 'Script 004 inspeciona explicitamente SQLSTATE e mensagem de erro contra falsos positivos');
check(sql004.includes('SET LOCAL ROLE anon') && sql004.includes('SET LOCAL ROLE authenticated'), 'Script 004 audita papéis reais PostgreSQL via SET LOCAL ROLE');
check(sql004.includes('_tf_meta_test_vulnerable') && sql004.includes('VULNERABILIDADE_DETECTADA'), 'Script 004 inclui meta-teste formal provando que funções vulneráveis falham o harness');
const hasSelfCapturingHandler = /BEGIN\s+(?:(?!\b(?:BEGIN|END)\b)[\s\S])*?RAISE EXCEPTION 'FALHA(?:(?!\b(?:BEGIN|END)\b)[\s\S])*?EXCEPTION\s+WHEN/i.test(sql004);
check(!hasSelfCapturingHandler, 'Script 004 não captura sua própria exceção de falha nos blocos negativos');

// ----------------------------------------------------------------------------
// 9. Auditoria de Identidade Visual, Logotipo da Empresa e Configurações Limpas
// ----------------------------------------------------------------------------
console.log('\n--- 9. Identidade da Empresa, Logotipo Auto-Save e Configurações ---');

const settingsCode = readFileSync('src/components/SettingsView.tsx', 'utf8');

// A. Remoção integral de blocos técnicos em SettingsView
check(!settingsCode.includes('Transferir dados anteriores'), 'Bloco técnico "Transferir dados anteriores" removido integralmente de SettingsView');
check(!settingsCode.includes('Segurança e Persistência de Dados'), 'Bloco técnico "Segurança e Persistência de Dados" removido integralmente de SettingsView');
check(!settingsCode.toLowerCase().includes('supabase'), 'Nenhuma menção técnica a Supabase no texto voltado ao usuário em SettingsView');
check(!settingsCode.includes('export-legacy') && !settingsCode.includes('import-legacy'), 'Rotas legadas de transferência técnica desvinculadas da tela de configurações');

// B. Preservação de dados cadastrais e termos operacionais
check(settingsCode.includes('Dados Cadastrais da Empresa'), 'Seção de dados cadastrais preservada');
check(settingsCode.includes('Termos Operacionais para Impressão da OS'), 'Seção de termos operacionais preservada');
check(settingsCode.includes('settings-company-name') && settingsCode.includes('settings-warranty-terms'), 'Campos de razão social e garantia mantidos');

// C. Seção de Identidade da Empresa, Auto-Save e Feedback
check(settingsCode.includes('Identidade da Empresa'), 'Seção "Identidade da Empresa" presente');
check(settingsCode.includes('Sem foto'), 'Placeholder discreto exibido no estado inicial sem imagem (sem fotos de exemplo precarregadas)');
check(settingsCode.includes('Salvando foto...'), 'Feedback "Salvando foto..." presente durante gravação');
check(settingsCode.includes('Foto salva'), 'Feedback "Foto salva" presente após gravação confirmada');
check(settingsCode.includes('updateCompanyLogo'), 'Auto-save utiliza função dedicada updateCompanyLogo sem submeter o formulário cadastral');
check(settingsCode.includes("file.type === 'image/svg+xml'"), 'Arquivos SVG explicitamente rejeitados na validação do cliente');
check(settingsCode.includes('5 * 1024 * 1024'), 'Limite de entrada de 5MB estritamente validado no cliente');
check(settingsCode.includes('307200'), 'Limite de payload final <= 300KB (307.200 caracteres base64) validado no cliente');
check(settingsCode.includes('maxDim = 512'), 'Redução de imagem para resolução máxima de 512x512 pixels no cliente');

// D. Auditoria da Migração 005_company_logo.sql
const sql005 = readFileSync('supabase/005_company_logo.sql', 'utf8');
check(sql005.includes('ALTER TABLE tecniflow.companies ADD COLUMN company_logo_data_url TEXT'), 'Migração 005 adiciona coluna company_logo_data_url de forma idempotente');
check(sql005.includes('CREATE OR REPLACE FUNCTION public.tf_update_company_logo'), 'Migração 005 define RPC dedicada public.tf_update_company_logo');
check(sql005.includes('tecniflow.current_company_id()'), 'RPC tf_update_company_logo resolve company_id pelo auth.uid()');
check(!sql005.match(/public\.tf_update_company_logo\s*\([^)]*p_company_id/i), 'RPC tf_update_company_logo não aceita company_id externo');
check(sql005.includes('REVOKE ALL ON FUNCTION public.tf_update_company_logo') && sql005.includes('GRANT EXECUTE ON FUNCTION public.tf_update_company_logo(text) TO authenticated'), 'Permissões restritas: EXECUTE concedido apenas para authenticated e revogado de anon/PUBLIC');
check(sql005.includes('307200'), 'Validação SQL rejeita payload de logotipo superior a 300KB');
check(sql005.includes('data:image/(jpeg|png|webp);base64,'), 'Validação SQL restringe formato a JPEG, PNG ou WebP base64');

// E. Preservação da assinatura de public.tf_update_company
const updateCompanySig = [...sql003.matchAll(/CREATE OR REPLACE FUNCTION public\.tf_update_company\(([\s\S]*?)\)\s*RETURNS/g)];
check(updateCompanySig.length === 1, 'Assinatura de public.tf_update_company permanece com 8 parâmetros intactos para compatibilidade');

// F. Avatar no cabeçalho e menu lateral com fallback de iniciais
const sidebarCode = readFileSync('src/components/Sidebar.tsx', 'utf8');
check(sidebarCode.includes('company_logo_data_url') && sidebarCode.includes('getInitials'), 'Sidebar exibe logotipo ou iniciais da empresa');
check(appCode.includes('company_logo_data_url'), 'Cabeçalho mobile em App.tsx exibe logotipo ou iniciais da empresa');

// ----------------------------------------------------------------------------
// 10. Auditoria de Monetização V1, Trial de 7 Dias e Mercado Pago
// ----------------------------------------------------------------------------
console.log('\n--- 10. Monetização V1, Trial 7 Dias e Preparação Mercado Pago ---');

// A. Presença de Minha Assinatura e navegação
check(sidebarCode.includes('Minha Assinatura') && sidebarCode.includes('subscription'), 'Minha Assinatura adicionada ao menu lateral');
check(appCode.includes('SubscriptionView') && appCode.includes('subscription'), 'SubscriptionView roteada na aplicação principal');

// B. Banner discreto de trial e banner de expiração
check(appCode.includes('Período de avaliação gratuito:') && appCode.includes('Assinar agora — R$ 49,90/mês'), 'Banner discreto de dias restantes no trial presente no topo');
check(appCode.includes('Acesso expirado:') && appCode.includes('Regularizar Acesso'), 'Banner e tela amigável de expiração presentes preservando dados');

// C. Tela de assinatura sem dados inventados e botão de checkout
const subscriptionViewCode = readFileSync('src/components/SubscriptionView.tsx', 'utf8');
check(subscriptionViewCode.includes('R$ 49,90'), 'Plano canônico R$ 49,90/mês exibido com clareza');
check(subscriptionViewCode.includes('TECNIFLOW-MENSAL-4990') || subscriptionViewCode.includes('TecniFlow Mensal'), 'Plano TecniFlow Mensal referenciado');
check(subscriptionViewCode.includes('Nenhum pagamento registrado até o momento'), 'Histórico vazio honesto sem dados ou pagamentos inventados');
check(subscriptionViewCode.includes('Contratação em Fase de Ativação') || subscriptionViewCode.includes('fase de configuração'), 'Botão Assinar Agora explica indisponibilidade da cobrança sem abrir links fictícios');
check(subscriptionViewCode.includes('isOwner') || subscriptionViewCode.includes('Apenas o proprietário'), 'Restrição: apenas o proprietário da assistência gerencia contratação');

// D. Auditoria da migração 006_billing_trial.sql
const sql006 = readFileSync('supabase/006_billing_trial.sql', 'utf8');
check(sql006.includes('CREATE TABLE IF NOT EXISTS tecniflow.company_subscriptions'), 'Tabela company_subscriptions criada de forma idempotente');
check(sql006.includes('CREATE TABLE IF NOT EXISTS tecniflow.billing_payments'), 'Tabela billing_payments criada com mp_payment_id UNIQUE');
check(sql006.includes('amount_cents INTEGER NOT NULL DEFAULT 4990 CHECK (amount_cents = 4990)'), 'Constraint estrita de 4990 centavos');
check(sql006.includes("currency VARCHAR(3) NOT NULL DEFAULT 'BRL' CHECK (currency = 'BRL')"), 'Constraint estrita de moeda BRL');
check(sql006.includes('ALTER TABLE tecniflow.company_subscriptions ENABLE ROW LEVEL SECURITY') && sql006.includes('REVOKE ALL ON TABLE tecniflow.company_subscriptions FROM PUBLIC, anon, authenticated'), 'RLS e zero acesso direto a tabelas de cobrança para anon e authenticated');
check(sql006.includes('CREATE OR REPLACE FUNCTION public.tf_get_billing_status()'), 'RPC pública tf_get_billing_status criada');
check(!sql006.match(/public\.tf_get_billing_status\s*\([^)]*p_company_id/i), 'tf_get_billing_status resolve empresa por auth.uid e não aceita company_id externo');
check(sql006.includes('tecniflow.assert_active_subscription()'), 'assert_active_subscription implementada para checagem server-side');
check(sql006.includes('ON CONFLICT (company_id) DO NOTHING'), 'Backfill de empresas preexistentes usa ON CONFLICT DO NOTHING (jamais recomeça trial existente)');

// Verificação de que tf_get_billing_status é puramente leitura (sem INSERT)
const getBillingStatusDef = sql006.substring(sql006.indexOf('FUNCTION public.tf_get_billing_status()'), sql006.indexOf('FUNCTION public.tf_sync_current_user()'));
check(!getBillingStatusDef.includes('INSERT INTO'), 'tf_get_billing_status é puramente de leitura e não contém comandos INSERT');

// Verificação de que 006 usa injeção dinâmica via pg_get_functiondef sem reescrever manualmente 21 RPCs
check(sql006.includes('pg_get_functiondef') && sql006.includes('tecniflow.assert_active_subscription'), 'Injeção dinâmica de assert_active_subscription via pg_get_functiondef preserva 100% dos contratos da 003');

// Verificação de bridge pública para service_role
check(sql006.includes('CREATE OR REPLACE FUNCTION public.tf_process_billing_payment'), 'Bridge pública public.tf_process_billing_payment criada para Edge Functions');
check(sql006.includes('GRANT EXECUTE ON FUNCTION public.tf_process_billing_payment') && sql006.includes('TO service_role'), 'Bridge tf_process_billing_payment concedida exclusivamente a service_role');
check(!sql006.includes('TO authenticated') || !sql006.match(/GRANT EXECUTE ON FUNCTION public\.tf_process_billing_payment[^\n]*TO authenticated/), 'authenticated proibido de executar tf_process_billing_payment');

// E. Auditoria do script 007_billing_verification_rollback.sql
const sql007 = readFileSync('supabase/007_billing_verification_rollback.sql', 'utf8');
check(sql007.includes('BEGIN;') && sql007.trim().endsWith('ROLLBACK;'), 'Script 007 abre com BEGIN e encerra estritamente com ROLLBACK');
check(!sql007.includes('COMMIT;'), 'Script 007 não contém COMMIT (zero dados persistidos)');
check(sql007.includes('gen_random_uuid()'), 'Script 007 utiliza UUIDs dinâmicos novos evitando conflitos e fixtures persistentes');
check(sql007.includes('process_billing_payment'), 'Script 007 testa pagamentos aprovados, rejeitados, duplicados e estornos');
check(sql007.includes('pay-distinct-01') && sql007.includes('pay-distinct-02'), 'Script 007 testa dois pagamentos distintos onde estorno do primeiro preserva o segundo');
check(sql007.includes('INTERVAL \'1 month\'') || sql007.includes('2026-02-28'), 'Script 007 valida aritmética de calendário mensal');

// F. Proteção de chaves e segredos
const envExample = readFileSync('.env.example', 'utf8');
check(envExample.includes('MERCADO_PAGO_ACCESS_TOKEN') && !envExample.includes('VITE_MERCADO_PAGO'), 'Chaves de cobrança server-side nunca utilizam prefixo VITE_');
check(envExample.includes('KIWIFY_ENABLED="false"'), 'KIWIFY_ENABLED=false configurado por padrão (fail-closed)');
check(envExample.includes('KIWIFY_WEBHOOK_SECRET') && !envExample.includes('VITE_KIWIFY'), 'Segredo Kiwify mantido estritamente no backend sem prefixo VITE_');

// ----------------------------------------------------------------------------
// 11. Auditoria de Monetização Kiwify (Migração 008, Edge Functions e Assinatura)
// ----------------------------------------------------------------------------
console.log('\n--- 11. Monetização Kiwify V1, Intents e Webhooks ---');
const sql008 = readFileSync('supabase/008_kiwify_billing.sql', 'utf8');
check(sql008.includes('CREATE TABLE IF NOT EXISTS tecniflow.billing_intents'), 'Tabela billing_intents criada com RLS na migração 008');
check(sql008.includes('CREATE OR REPLACE FUNCTION public.tf_create_billing_intent'), 'RPC pública tf_create_billing_intent criada para tokens opacos');
check(sql008.includes('CREATE OR REPLACE FUNCTION tecniflow.process_kiwify_payment'), 'Processador interno tecniflow.process_kiwify_payment criado com search_path vazio');
check(sql008.includes('GRANT EXECUTE ON FUNCTION public.tf_process_kiwify_payment') && sql008.includes('TO service_role'), 'Bridge pública tf_process_kiwify_payment restrita exclusivamente a service_role');
check(!sql008.match(/GRANT EXECUTE ON FUNCTION public\.tf_process_kiwify_payment[^\n]*TO authenticated/), 'tf_process_kiwify_payment não acessível por authenticated');

// Verificação de Edge Functions Kiwify e Configuração Supabase
const edgeCheckout = readFileSync('supabase/functions/kiwify-checkout/index.ts', 'utf8');
const edgeWebhook = readFileSync('supabase/functions/kiwify-webhook/index.ts', 'utf8');
const configToml = readFileSync('supabase/config.toml', 'utf8');
check(configToml.includes('[functions.kiwify-webhook]') && configToml.includes('verify_jwt = false'), 'supabase/config.toml configura kiwify-webhook como público (verify_jwt = false)');
check(configToml.includes('[functions.kiwify-checkout]') && configToml.includes('verify_jwt = true'), 'supabase/config.toml configura kiwify-checkout como autenticado (verify_jwt = true)');

check(edgeCheckout.includes('tf_create_billing_intent') && edgeCheckout.includes('sck'), 'Edge Function kiwify-checkout delega token ao banco e gera sck opaco');
check(edgeWebhook.includes('verifyKiwifyWebhookSignature') && edgeWebhook.includes('validateKiwifyGrantPayload'), 'Edge Function kiwify-webhook utiliza validações estritas do módulo compartilhado');

// Verificação de Serviço Kiwify Server / Express e Módulo Compartilhado
const kiwifyService = readFileSync('server/services/kiwifyService.ts', 'utf8');
const kiwifyCommon = readFileSync('supabase/functions/_shared/kiwifyCommon.ts', 'utf8');
const billingRoutes = readFileSync('server/routes/billingRoutes.ts', 'utf8');

check(kiwifyService.includes('verifyWebhookSignature') && kiwifyService.includes('timingSafeEqual'), 'kiwifyService verifica assinatura HMAC-SHA1 em tempo constante');
check(kiwifyService.includes('parseKiwifyDate') && (kiwifyService.includes('America/Sao_Paulo') || kiwifyCommon.includes('America/Sao_Paulo')), 'kiwifyService e módulo compartilhado fazem parsing determinístico de datas no fuso America/Sao_Paulo');
check(billingRoutes.includes("res.status(503).json({ error: 'billing_not_configured'") && billingRoutes.includes('/create-checkout') && billingRoutes.includes('/webhook'), 'Endpoints locais de billing estão desativados (503) eliminando processamento de pagamentos paralelo');

// Verificação de UI da SubscriptionView
check(subscriptionViewCode.includes('Kiwify') || subscriptionViewCode.includes('e-mail recebido'), 'SubscriptionView orienta usuário sobre link e e-mail da Kiwify');
check(subscriptionViewCode.includes('7 dias corridos gratuitos') || subscriptionViewCode.includes('7 dias'), 'SubscriptionView comunica período gratuito de 7 dias mantido pelo TecniFlow');
check(subscriptionViewCode.includes('Pix Automático'), 'SubscriptionView esclarece renovação automática via Pix Automático e cartão');
check(!subscriptionViewCode.includes('window.location.href = res.checkout_url') && !subscriptionViewCode.includes('window.location.href = checkoutUrl'), 'SubscriptionView não navega o iframe da aplicação para o checkout da Kiwify');
check(subscriptionViewCode.includes("window.open('about:blank', '_blank')") && subscriptionViewCode.includes('popup.opener = null'), 'SubscriptionView abre popup síncrono no clique e remove opener imediatamente');
check(subscriptionViewCode.includes("hostname === 'pay.kiwify.com.br'") && subscriptionViewCode.includes("searchParams.has('sck')"), 'SubscriptionView valida host HTTPS pay.kiwify.com.br e presença de sck antes de navegar');
check(subscriptionViewCode.includes('popup.close()'), 'SubscriptionView fecha janela vazia em caso de falha da API ou resposta inválida');
check(subscriptionViewCode.includes('Continuar para o pagamento') && subscriptionViewCode.includes('rel="noopener noreferrer"'), 'SubscriptionView oferece CTA alternativo seguro caso o navegador bloqueie popup');


// Verificação da Documentação e Guias Kiwify
const deploymentGuide = readFileSync('supabase/KIWIFY_DEPLOYMENT_GUIDE.md', 'utf8');
check(deploymentGuide.includes('/products/edit/:productUUID') && !deploymentGuide.includes('?plan='), 'Guia de implantação referencia rotas reais da UI Kiwify e remove queries fictícias');
check(deploymentGuide.includes('bytes UTF-8 brutos') || deploymentGuide.includes('raw body'), 'Guia documenta HMAC sobre raw body UTF-8');
check(envExample.includes('KIWIFY_PLAN_ID=""') && envExample.includes('Opcional antes da primeira cobrança'), '.env.example documenta KIWIFY_PLAN_ID opcional com binding atômico');

// Restaura fetch original
globalThis.fetch = originalFetch;

console.log('\n================================================================');
console.log(`  RESULTADO: ${passed} verificações de prontidão aprovadas com sucesso!`);
console.log('================================================================\n');


