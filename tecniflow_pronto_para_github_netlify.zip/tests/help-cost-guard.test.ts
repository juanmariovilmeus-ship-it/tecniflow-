import assert from 'node:assert/strict';
import { checkAvailability, generateHelpResponse, isHelpAiEnabled } from '../server/services/helpAiService.js';
import {handler} from '../netlify/functions/api.js';
let calls = 0;
globalThis.fetch = async () => { calls++; throw new Error('Unexpected external call'); };
process.env.GEMINI_API_KEY = 'test-placeholder-not-a-real-key';
for (const value of [undefined, 'false', 'TRUE', '']) {
 if (value === undefined) delete process.env.HELP_AI_ENABLED; else process.env.HELP_AI_ENABLED = value;
 assert.equal(isHelpAiEnabled(), false);
 assert.equal((await checkAvailability()).available, false);
 await assert.rejects(generateHelpResponse('Como abrir uma OS?'), /AI_SERVICE_UNAVAILABLE/);
}
assert.equal(calls, 0);
const invoke = async (event:any) => await (handler as any)({headers:{},httpMethod:'POST',path:'/api/help/chat',...event},{});
const result = await invoke({body:Buffer.from(JSON.stringify({message:'Como abrir OS?'})).toString('base64'),isBase64Encoded:true});
assert.equal(result.statusCode,401);
const health=await invoke({httpMethod:'GET',path:'/api/health',headers:{'x-request-id':'untrusted-personal-data'}});
assert.match(health.headers['X-Request-Id'],/^[0-9a-f-]{36}$/);
assert.notEqual(health.headers['X-Request-Id'],'untrusted-personal-data');
console.log('PASS: disabled AI performs zero network calls; base64 decoding and UUID verified');
