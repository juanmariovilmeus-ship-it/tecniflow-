import { PGlite } from '@electric-sql/pglite';
import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const db = new PGlite();
let passed = 0;
const check = (condition, label) => {
  assert.ok(condition, label);
  passed++;
  console.log('PASS', label);
};

const a = '11111111-1111-4111-8111-111111111111';
const b = '22222222-2222-4222-8222-222222222222';

// 1. Setup mock environment
await db.exec(`
  CREATE ROLE anon;
  CREATE ROLE authenticated;
  CREATE SCHEMA auth;
  CREATE TABLE auth.users(id uuid PRIMARY KEY, email text, raw_user_meta_data jsonb);
  CREATE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $$
    SELECT nullif(current_setting('request.jwt.claim.sub', true), '')::uuid
  $$;
`);

// 2. Load schemas and migrations
await db.exec(readFileSync('supabase/tecniflow_schema.sql', 'utf8'));
await db.exec(readFileSync('supabase/003_operations_data_api.sql', 'utf8'));

// 3. Load migration 005_company_logo.sql and verify idempotency
await db.exec(readFileSync('supabase/005_company_logo.sql', 'utf8'));
await db.exec(readFileSync('supabase/005_company_logo.sql', 'utf8'));
check(true, '005_company_logo.sql parseia e reexecuta com idempotência');

const scalar = async (sql, args = []) => Object.values((await db.query(sql, args)).rows[0])[0];

// 4. Role execution privileges
check(
  !await scalar("SELECT has_function_privilege('anon', 'public.tf_update_company_logo(text)', 'EXECUTE')"),
  'anon não possui permissão de EXECUTE em public.tf_update_company_logo'
);
check(
  await scalar("SELECT has_function_privilege('authenticated', 'public.tf_update_company_logo(text)', 'EXECUTE')"),
  'authenticated possui permissão de EXECUTE em public.tf_update_company_logo'
);

// 5. Provision test users
await db.query('INSERT INTO auth.users VALUES ($1, $2, $3), ($4, $5, $6)', [
  a, 'user_a@example.com', JSON.stringify({ company_name: 'Empresa A', owner_name: 'Owner A' }),
  b, 'user_b@example.com', JSON.stringify({ company_name: 'Empresa B', owner_name: 'Owner B' })
]);

async function asUser(id) {
  await db.exec('RESET ROLE');
  await db.query("SELECT set_config('request.jwt.claim.sub', $1, false)", [id]);
  await db.exec('SET ROLE authenticated');
}

async function call(name, p = {}) {
  const keys = Object.keys(p);
  return scalar(
    'SELECT public.tf_' + name + '(' + keys.map((k, i) => k + '=> $' + (i + 1)).join(',') + ') AS data',
    Object.values(p).map(v => (Array.isArray(v) ? JSON.stringify(v) : v))
  );
}

async function reject(fn, label) {
  let error;
  try {
    await fn();
  } catch (e) {
    error = e;
  }
  check(!!error, label);
}

// 6. Sync users and test initial empty state
await asUser(a);
const syncA = await call('sync_current_user');
check(syncA.company.company_logo_data_url === null, 'Logotipo inicial de Empresa A é nulo (sem imagem de exemplo)');

await asUser(b);
const syncB = await call('sync_current_user');
check(syncB.company.company_logo_data_url === null, 'Logotipo inicial de Empresa B é nulo');

// 7. Test invalid formats (SVG, random text, bad base64)
await asUser(a);
const svgPayload = 'data:image/svg+xml;base64,PHN2Zz48L3N2Zz4=';
await reject(() => call('update_company_logo', { p_logo_data_url: svgPayload }), 'SQL rejeita logotipo em formato SVG');

const textPayload = 'data:text/plain;base64,b2xh';
await reject(() => call('update_company_logo', { p_logo_data_url: textPayload }), 'SQL rejeita arquivo de texto comum');

const oversizedPayload = 'data:image/png;base64,' + 'A'.repeat(307200);
await reject(() => call('update_company_logo', { p_logo_data_url: oversizedPayload }), 'SQL rejeita payload excedendo 300KB');

// 8. Test valid formats (PNG, WebP, JPEG)
const validPng = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
const updateRes = await call('update_company_logo', { p_logo_data_url: validPng });
check(updateRes.company.company_logo_data_url === validPng, 'Logotipo válido salvo com sucesso');

// 9. Sync returns saved logo
const resyncA = await call('sync_current_user');
check(resyncA.company.company_logo_data_url === validPng, 'Sincronização de sessão carrega o logotipo salvo da Empresa A');

// 10. Multi-tenant isolation: User B doesn't see User A's logo
await asUser(b);
const resyncB = await call('sync_current_user');
check(resyncB.company.company_logo_data_url === null, 'Empresa B preserva logotipo próprio nulo (isolamento multiempresa)');

// 11. User A removes logo (sets to null)
await asUser(a);
const cleared = await call('update_company_logo', { p_logo_data_url: null });
check(cleared.company.company_logo_data_url === null, 'Remover logotipo atualiza campo para null');
const resyncCleared = await call('sync_current_user');
check(resyncCleared.company.company_logo_data_url === null, 'Logotipo removido persiste como null após recarregar');

// 12. Verify public.tf_update_company signature remains intact (8 parameters)
const compUpdate = await call('update_company', {
  p_name: 'Assistência Alfa Atualizada',
  p_document: '11.222.333/0001-81',
  p_phone: '11988887777',
  p_whatsapp: '11988887777',
  p_email: 'contato@alfa.com.br',
  p_address: 'Rua Principal, 100',
  p_warranty_terms: 'Garantia legal de 90 dias',
  p_receipt_notes: 'Retirada em até 30 dias'
});
check(compUpdate.company.name === 'Assistência Alfa Atualizada', 'public.tf_update_company com 8 parâmetros continua funcionando');

console.log(`\nTODOS OS ${passed} TESTES DE 005_company_logo.sql FORAM APROVADOS COM SUCESSO!`);
