import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { stripTypeScriptTypes } from 'node:module';
import test from 'node:test';

// Execute the actual Edge handlers. Only remote SDK and listener imports are replaced.
// This suite never creates a network client, listens on a port or contacts Supabase.
async function loadHandler(name) {
  const url = new URL(`../supabase/functions/${name}/index.ts`, import.meta.url);
  const source = stripTypeScriptTypes(await readFile(url, 'utf8'), {mode:'strip'});
  const body = source.replace(/^import\s*\{[^}]*\}\s*from\s*['"][^'"]+['"];?\s*$/gm, '');
  const sharedUrl = new URL('../supabase/functions/_shared/kiwifyCommon.ts', import.meta.url).href;
  const compiled = `import * as common from ${JSON.stringify(sharedUrl)};
    export function makeHandler(deps) {
      const {verifyKiwifyWebhookSignature, validateKiwifyGrantPayload, parseKiwifyDate,
        isKiwifyConfigured, isKiwifyCheckoutUrl} = common;
      const Deno = {env:{get:key=>deps.env[key]}};
      const createClient = (...args)=>deps.client(...args);
      let captured; const serve = fn=>{captured=fn};
      ${body}
      return captured;
    }`;
  return (await import('data:text/javascript;base64,' + Buffer.from(compiled).toString('base64'))).makeHandler;
}
const makeWebhook = await loadHandler('kiwify-webhook');
const makeCheckout = await loadHandler('kiwify-checkout');
const baseEnv = {
  SUPABASE_URL:'https://review.supabase.co', SUPABASE_SERVICE_ROLE_KEY:'local-review-service',
  SUPABASE_ANON_KEY:'local-review-anon', KIWIFY_ENABLED:'true',
  KIWIFY_WEBHOOK_SECRET:'local-review-webhook-secret', KIWIFY_CHECKOUT_URL:'https://pay.kiwify.com.br/review',
  KIWIFY_ALLOWED_PRODUCT_IDS:'review-product', KIWIFY_PLAN_ID:'review-plan',
};
const payload = () => ({webhook_event_type:'subscription_renewed', order_status:'paid',
  order_id:'review-order', subscription_id:'review-subscription', approved_date:'2026-02-06 10:30',
  created_at:'2026-02-01 10:30', Product:{product_id:'review-product'},
  Commissions:{charge_amount:4990, currency:'BRL'}, TrackingParameters:{sck:'review-opaque-intent'},
  Subscription:{id:'review-subscription', plan:{id:'review-plan', frequency:'monthly'},
    next_payment:'2026-02-28T13:30:00.508Z', customer_access:{access_until:'2026-02-28T13:30:00.508Z'}}});

function harness(factory, {env={}, authenticated=true, rpcError=null}={}) {
  const calls=[];
  const handler=factory({env:{...baseEnv,...env}, client:()=>({
    auth:{getUser:async()=>({data:{user:authenticated?{id:'session-owner'}:null},error:authenticated?null:{message:'invalid'}})},
    rpc:async(name,args)=>{calls.push({name,args});return {data:{token:'a'.repeat(64),expires_at:'2026-11-02T12:00:00Z',success:true},error:rpcError};},
  })});
  return {handler,calls};
}
function signedRequest(body, {method='POST', contentType='application/json', secret=baseEnv.KIWIFY_WEBHOOK_SECRET, pretty=false, rawText=null}={}) {
  const text = rawText !== null ? rawText : (['HEAD','GET'].includes(method) ? undefined : JSON.stringify(body, null, pretty ? 2 : undefined));
  const signature = text !== undefined ? createHmac('sha1', secret).update(Buffer.from(text, 'utf8')).digest('hex') : '';
  return new Request('https://review.supabase.co/functions/v1/kiwify-webhook?signature='+signature,
    {method,headers:{'content-type':contentType},body:text});
}

test('Edge verifies raw body HMAC and forwards the real renewal and order creation date', async()=>{
  const {handler,calls}=harness(makeWebhook);
  assert.equal((await handler(signedRequest(payload(),{pretty:true}))).status,200);
  assert.equal(calls.length,1);
  assert.equal(calls[0].name,'tf_process_kiwify_payment');
  assert.equal(calls[0].args.p_event_type,'subscription_renewed');
  assert.equal(calls[0].args.p_order_created_at,'2026-02-01T13:30:00.000Z');
  assert.equal(calls[0].args.p_access_until,'2026-02-28T13:30:00.508Z');
  assert.equal('company_id' in calls[0].args,false);
});

test('Edge rejects minified signature when body is sent formatted (no canonicalization fallback)', async()=>{
  const {handler,calls}=harness(makeWebhook);
  const minifiedSig = createHmac('sha1', baseEnv.KIWIFY_WEBHOOK_SECRET).update(JSON.stringify(payload())).digest('hex');
  const req = new Request('https://review.supabase.co/functions/v1/kiwify-webhook?signature='+minifiedSig, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(payload(), null, 2),
  });
  const res = await handler(req);
  assert.equal(res.status, 401);
  assert.equal(calls.length, 0);
});

test('Edge rejects forged signatures before any database call',async()=>{
  const {handler,calls}=harness(makeWebhook);
  assert.equal((await handler(signedRequest(payload(),{secret:'wrong-secret'}))).status,401);
  assert.equal(calls.length,0);
});

test('Edge ignores an unknown paid event without a database call',async()=>{
  const {handler,calls}=harness(makeWebhook);const body=payload();body.webhook_event_type='unknown_event';
  assert.equal((await handler(signedRequest(body))).status,200);assert.equal(calls.length,0);
});

test('Edge checks allowed product on refunds as well as approvals',async()=>{
  const {handler,calls}=harness(makeWebhook);const body=payload();body.webhook_event_type='order_refunded';body.order_status='refunded';body.Product.product_id='foreign-product';
  assert.equal((await handler(signedRequest(body))).status,400);assert.equal(calls.length,0);
});

test('Edge rejects contradictory subscription identities on control events',async()=>{
  const {handler,calls}=harness(makeWebhook);const body=payload();body.webhook_event_type='subscription_canceled';body.Subscription.id='different-subscription';
  assert.equal((await handler(signedRequest(body))).status,400);assert.equal(calls.length,0);
});

test('Edge forwards a refund without payment metadata for a terminal database record',async()=>{
  const {handler,calls}=harness(makeWebhook);const body=payload();body.webhook_event_type='order_refunded';body.order_status='refunded';delete body.Commissions;
  assert.equal((await handler(signedRequest(body))).status,200);assert.equal(calls.length,1);
  assert.equal(calls[0].args.p_event_type,'order_refunded');
});

test('Edge rejects incomplete configuration before contacting the database',async()=>{
  for (const env of [{KIWIFY_ENABLED:'false'},{KIWIFY_PLAN_ID:'placeholder...'},{KIWIFY_WEBHOOK_SECRET:''},{KIWIFY_CHECKOUT_URL:'https://evil.example/review'}]) {
    const {handler,calls}=harness(makeWebhook,{env});assert.equal((await handler(signedRequest(payload()))).status,503);assert.equal(calls.length,0);
  }
});

test('Edge accepts optional empty KIWIFY_PLAN_ID and delegates plan binding to payment', async () => {
  const { handler, calls } = harness(makeWebhook, { env: { KIWIFY_PLAN_ID: '' } });
  const res = await handler(signedRequest(payload()));
  assert.equal(res.status, 200);
  assert.equal(calls.length, 1);
  assert.equal(calls[0].args.p_plan_id, 'review-plan');
});

test('Edge rejects payment payload with empty or whitespace plan ID', async () => {
  const { handler, calls } = harness(makeWebhook, { env: { KIWIFY_PLAN_ID: '' } });
  const body = payload();
  body.Subscription.plan.id = '   ';
  const res = await handler(signedRequest(body));
  assert.equal(res.status, 400);
  assert.equal(calls.length, 0);
});

test('Edge rejects fractional cents and a wrong plan',async()=>{
  for(const mutate of [body=>body.Commissions.charge_amount=4990.4,body=>body.Subscription.plan.id='other-plan']) {
    const body=payload();mutate(body);const {handler,calls}=harness(makeWebhook);
    assert.equal((await handler(signedRequest(body))).status,400);assert.equal(calls.length,0);
  }
});

test('Edge implements method, type and byte size guards without database effects',async()=>{
  const {handler,calls}=harness(makeWebhook);
  assert.equal((await handler(new Request('https://review.supabase.co/webhook',{method:'GET'}))).status,405);
  assert.equal((await handler(new Request('https://review.supabase.co/webhook',{method:'HEAD'}))).status,204);
  assert.equal((await handler(signedRequest(payload(),{contentType:'text/plain'}))).status,400);
  const oversized=new Request('https://review.supabase.co/webhook',{method:'POST',headers:{'content-type':'application/json'},body:'é'.repeat(300000)});
  assert.equal((await handler(oversized)).status,413);assert.equal(calls.length,0);
});

test('Checkout rejects a missing or invalid authenticated session',async()=>{
  for(const authenticated of [true,false]) {
    const {handler,calls}=harness(makeCheckout,{authenticated});
    const headers=authenticated?{}:{Authorization:'Bearer invalid'};
    assert.equal((await handler(new Request('https://review.supabase.co/checkout',{method:'POST',headers}))).status,401);
    assert.equal(calls.length,0);
  }
});

test('Checkout derives the company in the authenticated database RPC and ignores body identifiers',async()=>{
  const {handler,calls}=harness(makeCheckout);
  const response=await handler(new Request('https://review.supabase.co/checkout',{method:'POST',headers:{Authorization:'Bearer local-session','content-type':'application/json'},body:JSON.stringify({company_id:'foreign-company',expires_at:'2099-01-01',token:'chosen-by-client'})}));
  assert.equal(response.status,200);assert.equal(calls.length,1);
  assert.deepEqual(calls[0],{name:'tf_create_billing_intent',args:{p_product_id:'review-product',p_plan_id:'review-plan'}});
  const url=new URL((await response.json()).checkout_url);
  assert.equal(url.hostname,'pay.kiwify.com.br');assert.deepEqual([...url.searchParams.keys()],['sck']);
});

test('Checkout refuses configured URLs with an extra query or lookalike host',async()=>{
  for(const url of ['https://pay.kiwify.com.br.evil.example/review','https://pay.kiwify.com.br/review?email=private@example.com']) {
    const {handler,calls}=harness(makeCheckout,{env:{KIWIFY_CHECKOUT_URL:url}});
    assert.equal((await handler(new Request('https://review.supabase.co/checkout',{method:'POST',headers:{Authorization:'Bearer local-session'}}))).status,503);
    assert.equal(calls.length,0);
  }
});

test('Checkout creates intent with empty plan_id when KIWIFY_PLAN_ID is not configured', async () => {
  const { handler, calls } = harness(makeCheckout, { env: { KIWIFY_PLAN_ID: '' } });
  const response = await handler(new Request('https://review.supabase.co/checkout', {
    method: 'POST',
    headers: { Authorization: 'Bearer local-session' },
  }));
  assert.equal(response.status, 200);
  assert.equal(calls.length, 1);
  assert.deepEqual(calls[0], { name: 'tf_create_billing_intent', args: { p_product_id: 'review-product', p_plan_id: '' } });
  const url = new URL((await response.json()).checkout_url);
  assert.equal(url.hostname, 'pay.kiwify.com.br');
  assert.deepEqual([...url.searchParams.keys()], ['sck']);
});

