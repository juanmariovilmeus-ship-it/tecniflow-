process.env.TZ = 'America/Sao_Paulo';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
let checks=0;
const check=(v:unknown,label:string)=>{assert.ok(v,label);checks++;};
let network=0;
const originalFetch=globalThis.fetch;
globalThis.fetch=async()=>{network++;throw new Error('Network is prohibited in isolated tests');};
const {cloudRequest}=await import('../src/services/cloudService.ts');
const {isValidBrazilianPhone,isValidDocumentOrEmpty,sanitizeAccessories,sanitizeConditions}=await import('../src/lib/validation.ts');
const {formatDate,formatDateOnly,formatDateTime,apiRequest,setApiAccessToken}=await import('../src/lib/api.ts');
check(!isValidBrazilianPhone('00000000000'),'repeated phone');
check(!isValidBrazilianPhone('10900000000'),'invalid DDD');
check(isValidBrazilianPhone('+55 (11) 90000-0000'),'country prefix');
check(!isValidBrazilianPhone('abc11900000000'),'no discarded phone letters');
check(!isValidDocumentOrEmpty('abc'),'junk document');
check(!isValidDocumentOrEmpty('...'),'punctuation document');
check(isValidDocumentOrEmpty('  '),'optional empty document');
check(isValidDocumentOrEmpty('529.982.247-25'),'CPF checksum');
check(!isValidDocumentOrEmpty('529.982.247-24'),'wrong CPF checksum');
check(isValidDocumentOrEmpty('12.ABC.345/01DE-35'),'official alphanumeric CNPJ example');
check(!isValidDocumentOrEmpty('12.ABC.345/01DE-36'),'wrong alphanumeric CNPJ checksum');
check(!sanitizeAccessories(['Nenhum acessório','Cartão SIM / Chip'],'').valid,'none conflicts with any accessory');
check(!sanitizeAccessories(['Nenhum acessório'],'custom').valid,'none conflicts with free text');
check(!sanitizeConditions(['Liga normalmente','Não liga / Sem sinal'],'').valid,'contradictory power state');
check(formatDateOnly('2026-10-28')==='28/10/2026','date-only stable');
check(formatDateTime('2026-10-28')==='28/10/2026','date-only never renders previous evening');
check(formatDate('2026-10-26T00:00:00Z')==='25/10/2026','timestamps still use actual timezone');
const sql=readFileSync('supabase/003_operations_data_api.sql','utf8');
const signatures=new Map([...sql.matchAll(/CREATE OR REPLACE FUNCTION public\.(tf_\w+)\(([\s\S]*?)\)\s*RETURNS/g)].map(m=>[m[1],m[2].split(',').map(s=>s.trim().split(/\s+/)[0]).filter(Boolean)]));
const routes:[string,string,any,string][]=[
 ['/api/auth/me','GET',null,'tf_sync_current_user'],
 ['/api/legacy/import','POST',{format:'tecniflow-legacy-v1'},'tf_import_legacy'],
 ['/api/clients?search=TEST&includeArchived=true','GET',null,'tf_get_clients'],
 ['/api/clients','POST',{name:'TEST',phone:'11900000000'},'tf_create_client'],
 ['/api/clients/id','PUT',{name:'TEST',phone:'11900000000'},'tf_update_client'],
 ['/api/clients/id','GET',null,'tf_get_client_details'],
 ['/api/clients/id/archive','POST',{},'tf_archive_client'],
 ['/api/clients/id/unarchive','POST',{},'tf_archive_client'],
 ['/api/inventory','POST',{name:'TEST',initialQuantity:3},'tf_create_inventory_item'],
 ['/api/inventory/id','PUT',{name:'TEST'},'tf_update_inventory_item'],
 ['/api/inventory/id','GET',null,'tf_get_inventory_details'],
 ['/api/inventory/id/movement','POST',{type:'saida_manual',quantity:1,reason:'TEST'},'tf_adjust_inventory'],
 ['/api/orders?priority=alta','GET',null,'tf_get_orders'],
 ['/api/orders','POST',{clientId:'client',deviceType:'smartphone',brand:'TEST',model:'TEST',defectReported:'TEST'},'tf_create_order'],
 ['/api/orders/id','GET',null,'tf_get_order_details'],
 ['/api/orders/id','PUT',{version:1,deviceType:'smartphone',brand:'TEST',model:'TEST',defectReported:'TEST'},'tf_update_order'],
 ['/api/orders/id/budget','PUT',{version:1,services:[],parts:[]},'tf_save_budget'],
 ['/api/orders/id/budget/decision','POST',{version:1,decision:'aprovado'},'tf_decide_budget'],
 ['/api/orders/id/budget/revise','POST',{version:1},'tf_reopen_budget'],
 ['/api/orders/id/status','POST',{version:1,status:'diagnostico'},'tf_transition_order_status'],
 ['/api/reports/dashboard','GET',null,'tf_get_dashboard_stats'],
 ['/api/reports/period?startDate=2026-10-26&endDate=2026-10-26','GET',null,'tf_get_reports'],
 ['/api/company','GET',null,'tf_get_company'],
 ['/api/company','PUT',{name:'TEST'},'tf_update_company'],
];
for(const [endpoint,method,body,expected]of routes){
 let invoked=false;
 await cloudRequest(endpoint,method,body,async(name,p={})=>{
  check(name===expected,'route '+endpoint);invoked=true;
  assert.deepEqual(Object.keys(p).sort(),signatures.get(name)?.slice().sort(),'SQL parameter contract '+name);checks++;
  if(endpoint.endsWith('/unarchive')) check(p.p_archived===0,'unarchive does not archive');
  if(name==='tf_get_reports') check(p.p_start_date==='2026-10-26','reports send date-only without UTC shift');
  return {};
 });check(invoked,'RPC invoked '+endpoint);
}
const inventory=await cloudRequest('/api/inventory?category=conectores&lowStock=true','GET',null,async()=>({items:[{name:'TEST',sku:'T',category:'conectores',is_archived:0,quantity:1,min_quantity:2},{name:'Other',sku:'O',category:'geral',is_archived:0,quantity:3,min_quantity:2}],summary:{total_items:2,low_stock_count:1,total_cost_value_cents:100,total_sale_value_cents:200}}));
check(inventory.items.length===1 && inventory.summary.totalItems===2 && inventory.summary.totalSaleValueCents===200,'stock filters and summary contract');
await assert.rejects(cloudRequest('/api/missing','GET',null,async()=>({})));checks++;
await assert.rejects(cloudRequest('/api/clients','GET',null,async()=>{throw new Error('offline');}));checks++;
check(network===0,'cloud route tests never use local fetch or remote network');
let complete:(r:Response)=>void;
globalThis.fetch=()=>new Promise<Response>(r=>{complete=r;});
setApiAccessToken('isolated-token-not-real');
const pending=apiRequest('/api/clients');
await new Promise(r=>setImmediate(r));
setApiAccessToken('');
complete!(new Response(JSON.stringify({clients:[]})));
await assert.rejects(pending,/sessão mudou/);checks++;
globalThis.fetch=async()=>new Response('<html>fallback da hospedagem</html>',{headers:{'Content-Type':'text/html'}});
await assert.rejects(apiRequest('/api/auth/export-legacy'),/resposta inválida/);checks++;
globalThis.fetch=async()=>new Response(JSON.stringify({error:'Erro informado pela API'}),{status:500});
await assert.rejects(apiRequest('/api/clients'),/Erro informado pela API/);checks++;
globalThis.fetch=originalFetch;
console.log('RESULT',checks,'passed; UI helpers + all RPC route contracts + stale session; no remote calls.');
